# KlaimCreator

Dashboard web untuk tim TikTok Affiliate Marketing Specialist: memantau data creator dari sumber berotorisasi setiap 1 menit, mendeteksi username berstatus **Available**, mengelola antrian klaim (otomatis via integrasi resmi atau **Assisted Claim Mode**), dan mengekspor username yang berhasil diklaim ke CSV/Excel untuk dimasukkan ke database perusahaan.

Semua fitur berjalan penuh di atas **Mock Integration** yang selalu berlabel "Sumber: Mock" di UI; integrasi resmi cukup ditambahkan sebagai adapter baru tanpa mengubah core monitoring/klaim.

---

## Ringkasan Arsitektur

```
klaimcreator/
├── client/                 # Vite + React 18 + TypeScript + Tailwind v4 + shadcn-style UI
│   └── src/pages/          # 12 halaman (login, dashboard, creators, claims, export, settings, logs, users)
├── server/                 # Node.js 20 + Express + TypeScript + Zod + better-sqlite3
│   └── src/
│       ├── repository/     # SATU modul akses data (semua query parameterized)
│       ├── services/       # sync, claim engine, export, scheduler, backup, notifications
│       ├── adapters/       # Mock + Official HTTP (source & claim adapter, pluggable)
│       ├── routes/         # API v1 dengan validasi Zod per endpoint
│       └── db/             # koneksi SQLite (WAL) + migration runner
├── Dockerfile              # 2 target: app (API + static) dan worker (satu-satunya pemilik node-cron)
├── docker-compose.yml      # 2 service berbagi volume /data + volume backup terpisah
└── docs/                   # ERD (Mermaid), panduan deploy produksi VPS
```

- **app** : API + frontend statis, TANPA scheduler. `GET /api/health` untuk Docker healthcheck.
- **worker** : satu-satunya pemilik node-cron (sync tiap 1 menit), loop klaim, poller job tabel, heartbeat, backup harian. `GET /health` di port `WORKER_PORT` untuk healthcheck.
- State **Monitoring aktif** dan **Emergency Stop** dipersistenkan di database (bukan memori) sehingga restart container tidak pernah menyalakan monitoring sendiri dan Emergency Stop tetap terkunci sampai Admin membukanya.

## Menjalankan Secara Lokal (development)

```bash
npm install

# Terminal 1: API + frontend dev server (proxy /api ke 4173)
npm run dev:client     # Vite di http://localhost:5173

# Terminal 2: API server
npm run dev:server     # Express di http://localhost:4173

# Terminal 3 (opsional): worker untuk scheduler + eksekusi klaim
npm run dev:worker
```

Akun admin dev dibuat otomatis saat database kosong: `admin@klaimcreator.local` / `devadmin123`
(hanya untuk NODE_ENV development/test; **produksi wajib** `SEED_ADMIN_EMAIL` + `SEED_ADMIN_PASSWORD`).
Password sementara: wajib diganti pada login pertama.

## Build Produksi & Serve Lokal

```bash
npm install
npm run build          # build client (vite) + server (tsc)
node server/dist/index.js      # serve API + static client di satu origin, default port 4173
# worker terpisah (scheduler/klaim):
node server/dist/worker.js
```

Untuk mencoba tanpa worker, aplikasi tetap berfungsi untuk login/monitoring UI; worker hanya diperlukan
agar sinkronisasi terjadwal, eksekusi klaim otomatis, dan job manual sinkronisasi berjalan.

## Docker (2 service)

```bash
cp .env.example .env   # isi JWT_SECRET (wajib) dan SEED_ADMIN_*
docker compose up -d --build
docker ps              # status healthcheck tiap service terlihat
```

`docker-compose.yml` menjalankan `app` (port 4173) dan `worker` (heartbeat 3001) berbagi volume `kc_data:/data`,
dengan backup ditulis ke volume terpisah `kc_backups:/backups`.

## Perintah Penting

| Perintah | Fungsi |
| --- | --- |
| `npm run build` | Build produksi client + server |
| `npm test` | Seluruh suite Vitest (server + client), non-interaktif (`vitest run`) |
| `npm run dev:client` / `dev:server` / `dev:worker` | Development |
| `npm start` / `npm run start:worker` | Jalankan hasil build |

## Keamanan

- **Auth** : JWT access token 15 menit di cookie `httpOnly` `SameSite=Strict` (flag `Secure` di produksi) + refresh token rotasi (hash SHA-256 di DB, path cookie terbatas `/api/auth`). Epoch sesi per user membuat logout/ganti password menutup semua access token seketika.
- **Password** : bcrypt cost 12; kebijakan minimal 8 karakter + huruf + angka divalidasi server.
- **CSRF** : semua mutasi wajib header `X-Requested-With: XMLHttpRequest`.
- **RBAC** : dua peran (Admin, Operator) ditegakkan middleware per route di server, bukan hanya UI. Verifikasi klaim (`POST /api/claims/{id}/verify`) dan pembukaan Emergency Stop hanya Admin.
- **Rate limit** : login 5 percobaan/menit, API umum moderat; `TRUST_PROXY` dikonfigurasi sesuai hop reverse proxy.
- **Header keamanan** : CSP ketat (`default-src 'self'`, `frame-ancestors 'none'`, dsb), `X-Content-Type-Options: nosniff`, HSTS di produksi. Halaman `/api/docs` (Swagger) memakai CSP khusus yang tetap menonaktifkan frame.
- **Audit log append-only** : tidak ada endpoint untuk mengubah/menghapusnya.
- **Kredensial** : hanya lewat environment variables; database hanya menyimpan NAMA referensi variabel (PRD 3G). Logger menyanitasi field sensitif (password/token/cookie) sebelum tercatat.
- **Export tersanitasi** : sel CSV/Excel berawalan `=`, `+`, `-`, `@`, TAB, CR di-escape dengan prefix kutip (anti formula injection); username divalidasi whitelist regex saat ingest dari sumber.
- **Idempotensi klaim** : unique partial index pada klaim aktif per creator + transaksi; hasil tidak pasti menjadi `Verification Required` dan tidak pernah dieksekusi ulang tanpa verifikasi.
- **Tidak ada mekanisme melewati CAPTCHA/MFA/anti-bot**; semua integrasi hanya via akses resmi, mundur ke Assisted Claim Mode bila izin tidak ada.

## Retensi Data

90 hari hanya untuk **notifikasi** dan **log operasional** (`synchronization_logs`, `system_events`, refresh token kedaluwarsa).
`claims`, `claim_attempts`, `creators`, `creator_status_histories`, dan `audit_logs` adalah data bisnis **permanen** agar seluruh
username terklaim dan riwayatnya tetap lengkap untuk export.

## Dokumentasi Lanjutan

- [docs/ERD.md](docs/ERD.md) : skema database (Mermaid + tabel)
- [docs/deployment.md](docs/deployment.md) : panduan deploy produksi VPS Linux (Nginx, TLS, backup/restore)
- Swagger UI: `http://localhost:4173/api/docs` (OpenAPI 3 di `/api/docs/openapi.json`)

## Testing

Suite berjalan sepenuhnya di atas **Mock adapter**, tanpa klaim sungguhan:

- **Backend** (Vitest + Supertest, 80 test): authentication, synchronization, pagination, duplicate detection, availability detection, claim validation, claim idempotency, claim result verification, export CSV/Excel (termasuk sanitasi), scheduler locking (lease), error handling/validasi, kontrol akses per endpoint, persistence antar restart.
- **Frontend** (Vitest Testing Library, 31 test): login (validasi per field, error server, loading), dashboard statistics, creator filtering, claim status (termasuk Already Claimed), Emergency Stop, export (preview + clipboard), settings admin, kontrol monitoring.

```bash
npm test      # vitest run di kedua workspace, non-interaktif
```

## Catatan Desain (Deviasi PRD, Dideklarasikan)

Sesuai keputusan build: PostgreSQL digantikan SQLite (better-sqlite3, WAL) dengan migration runner bawaan;
Redis/Celery digantikan antrian berbasis tabel SQLite + node-cron yang hanya berjalan di service worker;
Docker Compose diringkas menjadi 2 service; Next.js digantikan Vite + React (dashboard internal, tanpa SSR/SEO;
frontend dilayani Express sehingga satu origin tanpa CORS). Mode klaim default **Assisted**; otomatis hanya dapat
diaktifkan Admin setelah integrasi resmi terkonfigurasi dan teruji. Aplikasi berjalan sebagai 1 app + 1 worker
(SQLite single-writer; tulisan berat hanya di worker dengan transaksi chunked ~500 baris).
