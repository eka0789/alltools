import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import type { ReactNode } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useMe } from "@/lib/queries";
import { Skeleton } from "@/components/ui/skeleton";
import { LoginPage } from "@/pages/LoginPage";
import { ChangePasswordPage } from "@/pages/ChangePasswordPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { CreatorsPage } from "@/pages/CreatorsPage";
import { AvailableCreatorsPage } from "@/pages/AvailableCreatorsPage";
import { ClaimsPage } from "@/pages/ClaimsPage";
import { ClaimHistoryPage } from "@/pages/ClaimHistoryPage";
import { ExportPage } from "@/pages/ExportPage";
import { IntegrationSettingsPage } from "@/pages/IntegrationSettingsPage";
import { AutomationSettingsPage } from "@/pages/AutomationSettingsPage";
import { LogsPage } from "@/pages/LogsPage";
import { UsersPage } from "@/pages/UsersPage";

function FullPageSkeleton() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background" role="status" aria-label="Memuat aplikasi">
      <div className="flex w-64 flex-col gap-3">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    </div>
  );
}

/** Guard sesi: belum login -> /login; wajib ganti password -> /change-password. */
function RequireAuth({ children }: { children: ReactNode }) {
  const { data, isLoading, isError } = useMe();
  const location = useLocation();
  if (isLoading) return <FullPageSkeleton />;
  if (isError || !data?.user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }
  if (data.user.mustChangePassword && location.pathname !== "/change-password") {
    return <Navigate to="/change-password" replace />;
  }
  return <>{children}</>;
}

/** Guard peran: halaman Admin dijaga di sisi UI, dan tetap ditegakkan di server. */
function RequireAdmin({ children }: { children: ReactNode }) {
  const { data } = useMe();
  if (data?.user?.role !== "admin") {
    return <Navigate to="/" replace />;
  }
  return <>{children}</>;
}

/** Sudah login tapi membuka /login -> lempar ke dashboard. */
function RedirectIfAuthed({ children }: { children: ReactNode }) {
  const { data, isLoading } = useMe();
  if (isLoading) return <FullPageSkeleton />;
  if (data?.user) {
    return <Navigate to={data.user.mustChangePassword ? "/change-password" : "/"} replace />;
  }
  return <>{children}</>;
}

export function App() {
  return (
    <Routes>
      <Route
        path="/login"
        element={
          <RedirectIfAuthed>
            <LoginPage />
          </RedirectIfAuthed>
        }
      />
      <Route
        path="/change-password"
        element={
          <RequireAuth>
            <ChangePasswordPage />
          </RequireAuth>
        }
      />
      <Route
        element={
          <RequireAuth>
            <AppShell />
          </RequireAuth>
        }
      >
        <Route path="/" element={<DashboardPage />} />
        <Route path="/creators" element={<CreatorsPage />} />
        <Route path="/creators/available" element={<AvailableCreatorsPage />} />
        <Route path="/claims" element={<ClaimsPage />} />
        <Route path="/claims/history" element={<ClaimHistoryPage />} />
        <Route path="/export" element={<ExportPage />} />
        <Route path="/logs" element={<LogsPage />} />
        <Route
          path="/users"
          element={
            <RequireAdmin>
              <UsersPage />
            </RequireAdmin>
          }
        />
        <Route
          path="/settings/integration"
          element={
            <RequireAdmin>
              <IntegrationSettingsPage />
            </RequireAdmin>
          }
        />
        <Route
          path="/settings/automation"
          element={
            <RequireAdmin>
              <AutomationSettingsPage />
            </RequireAdmin>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
