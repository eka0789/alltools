import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  Activity,
  Bell,
  CircleStop,
  Download,
  FileClock,
  History,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Menu,
  Radio,
  Settings2,
  ShieldCheck,
  Users,
  UsersRound,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLogout, useMarkNotificationsRead, useMe, useMonitoringStatus, useNotifications } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { fmtDateTime, timeAgo } from "@/lib/format";
import { EVENT_TYPE_LABELS } from "@/lib/status";
import { cn } from "@/lib/utils";

const NAV_MAIN = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/creators", label: "Creator Monitoring", icon: UsersRound },
  { to: "/creators/available", label: "Available Creators", icon: Radio },
  { to: "/claims", label: "Klaim", icon: KeyRound },
  { to: "/claims/history", label: "Riwayat Klaim", icon: History },
  { to: "/export", label: "Export", icon: Download },
  { to: "/logs", label: "System Logs", icon: FileClock },
];

const NAV_ADMIN = [
  { to: "/users", label: "Manajemen Akun", icon: Users },
  { to: "/settings/integration", label: "Integrasi", icon: Settings2 },
  { to: "/settings/automation", label: "Automasi", icon: Activity },
];

function NavItems({ onNavigate }: { onNavigate?: () => void }) {
  const { data } = useMe();
  const isAdmin = data?.user?.role === "admin";
  return (
    <nav aria-label="Navigasi utama" className="flex flex-col gap-0.5">
      {NAV_MAIN.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.to === "/" || item.to === "/creators"}
          onClick={onNavigate}
          className={({ isActive }) =>
            cn(
              "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors",
              isActive
                ? "bg-accent-soft text-accent font-medium"
                : "text-muted hover:bg-surface-2 hover:text-foreground"
            )
          }
        >
          <item.icon className="size-4 shrink-0" aria-hidden="true" />
          {item.label}
        </NavLink>
      ))}
      {isAdmin ? (
        <>
          <p className="px-3 pb-1 pt-4 text-[11px] font-medium uppercase tracking-wider text-faint">Admin</p>
          {NAV_ADMIN.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={onNavigate}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors",
                  isActive
                    ? "bg-accent-soft text-accent font-medium"
                    : "text-muted hover:bg-surface-2 hover:text-foreground"
                )
              }
            >
              <item.icon className="size-4 shrink-0" aria-hidden="true" />
              {item.label}
            </NavLink>
          ))}
        </>
      ) : null}
    </nav>
  );
}

function BrandMark() {
  return (
    <div className="flex items-center gap-2.5 px-2">
      <span className="flex size-8 items-center justify-center rounded-lg bg-accent-soft text-accent">
        <ShieldCheck className="size-4.5" aria-hidden="true" />
      </span>
      <div className="leading-tight">
        <p className="text-sm font-semibold text-foreground">KlaimCreator</p>
        <p className="text-[11px] text-faint">Affiliate Claim Desk</p>
      </div>
    </div>
  );
}

function EmergencyBanner() {
  const { data } = useMonitoringStatus(20_000);
  if (!data?.emergencyStop) return null;
  return (
    <div role="alert" className="flex items-center gap-2 border-b border-danger/40 bg-danger-soft px-4 py-2 text-sm text-danger">
      <CircleStop className="size-4 shrink-0" aria-hidden="true" />
      <p>
        <strong>Emergency Stop aktif.</strong> Scheduler dan eksekusi klaim dihentikan. Hanya Admin yang dapat membukanya di halaman Klaim.
      </p>
    </div>
  );
}

function NotificationBell() {
  const { data } = useNotifications(30_000);
  const markRead = useMarkNotificationsRead();
  const [open, setOpen] = useState(false);
  const unread = data?.unread ?? 0;
  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label={`Notifikasi, ${unread} belum dibaca`} className="relative">
          <Bell className="size-4.5" aria-hidden="true" />
          {unread > 0 ? (
            <span className="absolute right-1.5 top-1.5 flex size-2 rounded-full bg-accent" aria-hidden="true" />
          ) : null}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 sm:w-96">
        <div className="flex items-center justify-between px-2 py-1.5">
          <p className="text-sm font-semibold text-foreground">Notifikasi</p>
          {unread > 0 ? (
            <button
              className="text-xs text-accent hover:underline"
              onClick={() => markRead.mutate({ all: true })}
              disabled={markRead.isPending}
            >
              Tandai semua dibaca
            </button>
          ) : null}
        </div>
        <DropdownMenuSeparator />
        <div className="max-h-80 overflow-y-auto">
          {(data?.items.length ?? 0) === 0 ? (
            <p className="px-2.5 py-6 text-center text-sm text-muted">Belum ada notifikasi.</p>
          ) : (
            data!.items.map((n) => (
              <div
                key={n.id}
                className={cn("rounded-md px-2.5 py-2", !n.isRead && "bg-accent-soft/40")}
              >
                <div className="flex items-center justify-between gap-2">
                  <p className={cn("text-xs font-semibold", n.isRead ? "text-muted" : "text-foreground")}>
                    {n.title}
                  </p>
                  <span className="shrink-0 text-[10px] text-faint">{timeAgo(n.createdAt)}</span>
                </div>
                <p className="mt-0.5 line-clamp-2 text-xs text-muted">{n.message}</p>
                <p className="mt-1 text-[10px] uppercase tracking-wide text-faint">
                  {EVENT_TYPE_LABELS[n.eventType] ?? n.eventType} · {fmtDateTime(n.createdAt)}
                </p>
              </div>
            ))
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function UserMenu() {
  const { data } = useMe();
  const logout = useLogout();
  const navigate = useNavigate();
  const user = data?.user;
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-surface-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60"
          aria-label="Menu pengguna"
        >
          <span className="flex size-8 items-center justify-center rounded-full bg-surface-2 text-xs font-semibold text-accent">
            {(user?.name ?? "?").slice(0, 2).toUpperCase()}
          </span>
          <span className="hidden leading-tight sm:block">
            <span className="block text-xs font-medium text-foreground">{user?.name ?? "..."}</span>
            <span className="block text-[11px] text-faint">{user?.role === "admin" ? "Admin" : "Operator"}</span>
          </span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <span className="block truncate text-xs text-muted">{user?.email}</span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onSelect={() => {
            logout.mutate(undefined, {
              onSuccess: () => {
                navigate("/login", { replace: true });
              },
              onError: (err) => {
                navigate("/login", { replace: true });
              },
            });
          }}
        >
          <LogOut className="size-4" aria-hidden="true" />
          Keluar
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function AppShell() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const location = useLocation();
  useEffect(() => {
    setDrawerOpen(false);
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="flex min-h-[100dvh] bg-background">
      {/* Sidebar desktop */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-line bg-surface/60 p-3 lg:flex">
        <div className="pb-4 pt-2">
          <BrandMark />
        </div>
        <div className="flex-1 overflow-y-auto">
          <NavItems />
        </div>
        <p className="px-3 pb-2 text-[11px] text-faint">Zona waktu Asia/Jakarta (WIB)</p>
      </aside>

      {/* Drawer mobile */}
      {drawerOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu navigasi">
          <div className="absolute inset-0 bg-black/70" onClick={() => setDrawerOpen(false)} aria-hidden="true" />
          <div className="absolute inset-y-0 left-0 flex w-72 flex-col border-r border-line bg-surface p-3 slide-up">
            <div className="flex items-center justify-between pb-4 pt-2">
              <BrandMark />
              <Button variant="ghost" size="icon" onClick={() => setDrawerOpen(false)} aria-label="Tutup menu">
                <X className="size-4" aria-hidden="true" />
              </Button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <NavItems onNavigate={() => setDrawerOpen(false)} />
            </div>
          </div>
        </div>
      ) : null}

      {/* Konten */}
      <div className="flex min-w-0 flex-1 flex-col lg:pl-60">
        <header className="sticky top-0 z-30 border-b border-line bg-background/90 backdrop-blur">
          <EmergencyBanner />
          <div className="flex h-14 items-center justify-between gap-3 px-4">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setDrawerOpen(true)} aria-label="Buka menu">
              <Menu className="size-5" aria-hidden="true" />
            </Button>
            <div className="hidden items-center gap-2 lg:flex">
              <ConnectionChip />
            </div>
            <div className="flex items-center gap-1.5">
              <NotificationBell />
              <UserMenu />
            </div>
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1400px] flex-1 px-4 py-5 sm:px-6 sm:py-6">
          <Outlet />
        </main>
        <footer className="border-t border-line px-4 py-3 text-center text-[11px] text-faint">
          KlaimCreator · data waktu ditampilkan dalam WIB · Sumber data berlabel di halaman Integrasi
        </footer>
      </div>
    </div>
  );
}

function ConnectionChip() {
  const { data } = useMonitoringStatus(30_000);
  if (!data) return <Badge className="bg-surface-2 text-faint">Memuat status...</Badge>;
  return (
    <span className="flex items-center gap-2">
      <Badge className={data.worker.online ? "border-accent/30 bg-accent-soft text-accent" : "border-danger/30 bg-danger-soft text-danger"}>
        Worker {data.worker.online ? "aktif" : "offline"}
      </Badge>
      <Badge className="border-line bg-surface-2 text-muted">{data.sourceLabel}</Badge>
      {data.emergencyStop ? <Badge className="border-danger/40 bg-danger-soft text-danger">Emergency Stop</Badge> : null}
    </span>
  );
}

export function getErrorMessage(err: unknown): string {
  return errorMessage(err);
}
