import { Badge } from "@/components/ui/badge";
import { claimStatusMeta, creatorStatusMeta } from "@/lib/status";
import { cn } from "@/lib/utils";

export function CreatorStatusBadge({ status, className }: { status: string; className?: string }) {
  const meta = creatorStatusMeta(status);
  return (
    <Badge className={cn(meta.className, className)} title={status}>
      {meta.label}
    </Badge>
  );
}

export function ClaimStatusBadge({ status, className }: { status: string; className?: string }) {
  const meta = claimStatusMeta(status);
  return (
    <Badge className={cn(meta.className, className)} title={status}>
      {meta.label}
    </Badge>
  );
}
