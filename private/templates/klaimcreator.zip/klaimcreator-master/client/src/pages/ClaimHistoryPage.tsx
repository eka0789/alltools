import { useState } from "react";
import { History } from "lucide-react";
import { PageHeader, SectionCard } from "@/components/Structure";
import { ClaimStatusBadge } from "@/components/StatusBadge";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { Pagination } from "@/components/Pagination";
import { SkeletonRows } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableWrap,
} from "@/components/ui/table";
import { useClaims } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { useSeo } from "@/lib/seo";
import { fmtDateTime } from "@/lib/format";

/** Claim History: seluruh klaim, status, tanggal, dan detail creator. */
export function ClaimHistoryPage() {
  useSeo(
    "Claim History — Riwayat Klaim Username | KlaimCreator",
    "Telusuri seluruh riwayat klaim username beserta status, tanggal, detail creator, dan riwayat attempt per klaim untuk audit tim affiliate Anda."
  );
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const query = useClaims({ page, pageSize });

  const items = query.data?.items ?? [];

  return (
    <div className="fade-in">
      <PageHeader
        title="Claim History — Riwayat Klaim Username"
        description="Seluruh klaim sepanjang waktu beserta status akhir, tanggal, dan detail creator. Data ini permanen untuk kebutuhan export."
      />
      <SectionCard title="Seluruh Klaim" description={query.data ? `${query.data.total} klaim tercatat` : "Memuat data..."}>
        {query.isError ? (
          <ErrorState message={errorMessage(query.error)} onRetry={() => void query.refetch()} />
        ) : query.isLoading ? (
          <SkeletonRows rows={8} />
        ) : items.length === 0 ? (
          <EmptyState
            icon={<History />}
            title="Belum ada klaim tercatat"
            description="Riwayat klaim akan terisi begitu creator masuk antrian dan dieksekusi."
          />
        ) : (
          <>
            <TableWrap>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead className="hidden sm:table-cell">Creator ID</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden md:table-cell">Tanggal Klaim</TableHead>
                    <TableHead className="hidden lg:table-cell">Dibuat</TableHead>
                    <TableHead className="hidden xl:table-cell">Catatan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium text-foreground">@{c.username}</TableCell>
                      <TableCell className="hidden font-num text-xs text-muted sm:table-cell">{c.externalId ?? "-"}</TableCell>
                      <TableCell>
                        <ClaimStatusBadge status={c.status} />
                      </TableCell>
                      <TableCell className="hidden text-xs text-muted md:table-cell">{fmtDateTime(c.claimedAt)}</TableCell>
                      <TableCell className="hidden text-xs text-muted lg:table-cell">{fmtDateTime(c.createdAt)}</TableCell>
                      <TableCell className="hidden max-w-52 truncate text-xs text-faint xl:table-cell" title={c.lastError ?? undefined}>
                        {c.lastError ?? "-"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableWrap>
            <Pagination
              page={query.data!.page}
              totalPages={query.data!.totalPages}
              pageSize={pageSize}
              total={query.data!.total}
              onPageChange={setPage}
              onPageSizeChange={(s) => {
                setPageSize(s);
                setPage(1);
              }}
            />
          </>
        )}
      </SectionCard>
    </div>
  );
}
