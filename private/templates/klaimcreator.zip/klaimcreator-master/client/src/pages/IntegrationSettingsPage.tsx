import { useEffect, useState } from "react";
import { Cable, PlugZap, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, SectionCard } from "@/components/Structure";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useIntegration, useSaveIntegration, useTestConnection } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { useSeo } from "@/lib/seo";
import { fmtDateTime } from "@/lib/format";

/** Integration Settings (Admin): adapter sumber, uji koneksi, status koneksi. */
export function IntegrationSettingsPage() {
  useSeo(
    "Integration Settings — Adapter Sumber Data | KlaimCreator",
    "Atur sumber data creator: pilih adapter Mock berlabel jelas atau integrasi resmi via environment variables, uji koneksi, dan pantau statusnya."
  );
  const query = useIntegration();
  const save = useSaveIntegration();
  const testConn = useTestConnection();
  const [mock, setMock] = useState({ pages: 3, itemsPerPage: 15, newItemsPerCycle: 2, faultMode: "none" as "none" | "disconnected" });

  useEffect(() => {
    if (query.data) setMock(query.data.mock);
  }, [query.data]);

  function onSave() {
    const data = query.data;
    if (!data) return;
    save.mutate(
      {
        adapter: data.adapter,
        official: data.official,
        mock,
      },
      {
        onSuccess: () => toast.success("Pengaturan integrasi disimpan."),
        onError: (err) => toast.error(errorMessage(err)),
      }
    );
  }

  if (query.isError) {
    return (
      <div className="fade-in">
        <PageHeader title="Integration Settings — Adapter Sumber Data Creator" />
        <SectionCard title="Gagal memuat" description="Periksa koneksi lalu coba lagi.">{null}</SectionCard>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <PageHeader
        title="Integration Settings — Adapter Sumber Data Creator"
        description="Sumber data creator dan integrasi klaim resmi. Adapter Mock selalu diberi label jelas. Kredensial resmi hanya lewat environment variables; database hanya menyimpan nama variabelnya."
      />

      {query.isLoading || !query.data ? (
        <div className="space-y-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-56 w-full" />
        </div>
      ) : (
        <div className="space-y-4">
          <SectionCard
            title="Status Koneksi"
            description={query.data.sourceLabel}
            actions={
              <Button variant="secondary" onClick={() => testConn.mutate()} disabled={testConn.isPending}>
                <PlugZap className="size-4" aria-hidden="true" />
                {testConn.isPending ? "Menguji..." : "Uji Koneksi"}
              </Button>
            }
          >
            <div className="flex flex-wrap items-center gap-2">
              <Badge className={query.data.officialConfigured ? "border-accent/30 bg-accent-soft text-accent" : "border-line bg-surface-2 text-muted"}>
                {query.data.officialConfigured ? "Integrasi resmi siap" : "Assisted Claim Mode (tanpa integrasi resmi)"}
              </Badge>
              {query.data.lastCheck ? (
                <Badge className={query.data.lastCheck.ok ? "border-accent/30 bg-accent-soft text-accent" : "border-danger/30 bg-danger-soft text-danger"}>
                  {query.data.lastCheck.ok ? "Uji terakhir: berhasil" : "Uji terakhir: gagal"}
                </Badge>
              ) : (
                <Badge className="border-line bg-surface-2 text-muted">Belum pernah diuji</Badge>
              )}
            </div>
            {query.data.lastCheck ? (
              <p className="mt-2 text-xs text-muted">
                {query.data.lastCheck.message} · {fmtDateTime(query.data.lastCheck.checkedAt)}
              </p>
            ) : null}
          </SectionCard>

          <SectionCard title="Adapter Sumber" description="Pilih sumber data yang dipakai worker saat sinkronisasi">
            <div className="grid gap-4 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => save.mutate({ adapter: "mock", official: query.data!.official, mock })}
                className={`rounded-xl border p-4 text-left transition-colors ${
                  query.data.adapter === "mock" ? "border-accent/50 bg-accent-soft/40" : "border-line bg-surface-2/40 hover:bg-surface-2"
                }`}
                aria-pressed={query.data.adapter === "mock"}
              >
                <p className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Cable className="size-4 text-accent" aria-hidden="true" />
                  Sumber: Mock
                </p>
                <p className="mt-1 text-xs text-muted">
                  Data simulasi untuk uji end-to-end. Selalu berlabel "Sumber: Mock" di seluruh UI. Tidak ada klaim sungguhan yang dieksekusi.
                </p>
              </button>
              <div
                className={`rounded-xl border p-4 ${
                  query.data.adapter === "official" ? "border-accent/50 bg-accent-soft/40" : "border-line bg-surface-2/40"
                }`}
              >
                <p className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Cable className="size-4 text-info" aria-hidden="true" />
                  Integrasi Resmi
                </p>
                <p className="mt-1 text-xs text-muted">
                  Aktif otomatis ketika variabel environment <code className="font-num">{query.data.official.baseUrlEnv}</code> dan{" "}
                  <code className="font-num">{query.data.official.apiKeyEnv}</code> tersedia, dan diaktifkan di bawah ini.
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <Switch
                    id="official-enabled"
                    checked={query.data.official.enabled}
                    onCheckedChange={(checked) =>
                      save.mutate(
                        { adapter: checked ? "official" : "mock", official: { ...query.data!.official, enabled: checked }, mock },
                        {
                          onSuccess: () =>
                            toast.success(
                              checked
                                ? "Integrasi resmi diaktifkan. Mode klaim otomatis kini tersedia di Automasi."
                                : "Integrasi resmi dimatikan. Sistem kembali ke Mock/Assisted."
                            ),
                          onError: (err) => toast.error(errorMessage(err)),
                        }
                      )
                    }
                    aria-label="Aktifkan integrasi resmi"
                  />
                  <Label htmlFor="official-enabled" className="text-xs text-muted">
                    {query.data.official.enabled ? "Diaktifkan" : "Nonaktif"}
                  </Label>
                </div>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Parameter Sumber Mock" description="Mengatur perilaku simulasi (jumlah halaman, item, creator baru per siklus, dan injeksi gangguan untuk pengujian)">
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="mock-pages">Jumlah halaman</Label>
                <Input
                  id="mock-pages"
                  type="number"
                  min={1}
                  max={50}
                  value={mock.pages}
                  onChange={(e) => setMock({ ...mock, pages: Number(e.target.value) || 1 })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="mock-items">Item per halaman</Label>
                <Input
                  id="mock-items"
                  type="number"
                  min={1}
                  max={500}
                  value={mock.itemsPerPage}
                  onChange={(e) => setMock({ ...mock, itemsPerPage: Number(e.target.value) || 1 })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="mock-new">Creator baru per siklus</Label>
                <Input
                  id="mock-new"
                  type="number"
                  min={0}
                  max={50}
                  value={mock.newItemsPerCycle}
                  onChange={(e) => setMock({ ...mock, newItemsPerCycle: Number(e.target.value) || 0 })}
                />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-3 rounded-lg border border-warning/30 bg-warning-soft p-3">
              <ShieldAlert className="size-4 shrink-0 text-warning" aria-hidden="true" />
              <div className="flex-1 text-xs text-muted">
                Mode gangguan <strong className="text-warning">disconnected</strong> mensimulasikan sumber mati untuk menguji alert dan pemulihan.
              </div>
              <Switch
                checked={mock.faultMode === "disconnected"}
                onCheckedChange={(checked) => setMock({ ...mock, faultMode: checked ? "disconnected" : "none" })}
                aria-label="Mode gangguan disconnected"
              />
            </div>
            <div className="mt-4">
              <Button onClick={onSave} disabled={save.isPending}>
                {save.isPending ? "Menyimpan..." : "Simpan Parameter Mock"}
              </Button>
            </div>
          </SectionCard>
        </div>
      )}
    </div>
  );
}
