import { useState, type FormEvent } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { LoaderCircle, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLogin } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { useSeo } from "@/lib/seo";

export function LoginPage() {
  useSeo(
    "Login KlaimCreator — Masuk ke Dashboard TikTok Affiliate",
    "Masuk ke dashboard KlaimCreator untuk memantau creator TikTok, mengelola antrian klaim, dan mengekspor username yang berhasil diklaim dengan aman."
  );
  const login = useLogin();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState<{ email?: string; password?: string }>({});
  const [formError, setFormError] = useState<string | null>(null);

  function validate(): boolean {
    const errors: { email?: string; password?: string } = {};
    if (!email.trim()) errors.email = "Email wajib diisi";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) errors.email = "Format email tidak valid";
    if (!password) errors.password = "Password wajib diisi";
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    if (!validate()) return;
    login.mutate(
      { email: email.trim(), password },
      {
        onSuccess: (data) => {
          navigate(data.user.mustChangePassword ? "/change-password" : "/", { replace: true });
        },
        onError: (err) => {
          setFormError(errorMessage(err, "Login gagal. Coba lagi."));
        },
      }
    );
  }

  return (
    <div className="grid min-h-[100dvh] lg:grid-cols-2">
      {/* Panel brand: hanya tampil di layar lebar */}
      <div className="relative hidden flex-col justify-between border-r border-line bg-surface/40 p-10 lg:flex">
        <div className="flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-xl bg-accent-soft text-accent">
            <ShieldCheck className="size-5" aria-hidden="true" />
          </span>
          <div>
            <p className="text-lg font-semibold tracking-tight text-foreground">KlaimCreator</p>
            <p className="text-xs text-muted">Affiliate Claim Desk</p>
          </div>
        </div>
        <div className="max-w-md">
          <p className="text-3xl font-semibold leading-tight tracking-tight text-foreground">
            Pantau creator, klaim tepat waktu, ekspor tanpa drama.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Dashboard internal untuk tim TikTok Affiliate Marketing Specialist: sinkronisasi data creator tiap menit,
            deteksi username tersedia, antrian klaim terkontrol, dan export CSV/Excel siap database perusahaan.
          </p>
          <ul className="mt-6 space-y-2 text-sm text-muted">
            <li className="flex items-center gap-2">
              <span className="size-1.5 rounded-full bg-accent" aria-hidden="true" />
              Monitoring aktif hanya lewat kontrol resmi dan tercatat di audit trail
            </li>
            <li className="flex items-center gap-2">
              <span className="size-1.5 rounded-full bg-accent" aria-hidden="true" />
              Assisted Claim Mode default, otomatis hanya dengan integrasi resmi
            </li>
            <li className="flex items-center gap-2">
              <span className="size-1.5 rounded-full bg-accent" aria-hidden="true" />
              Emergency Stop terkunci sampai Admin membukanya
            </li>
          </ul>
        </div>
        <p className="text-xs text-faint">Sesi dilindungi cookie httpOnly SameSite=Strict. Semua aksi tercatat.</p>
      </div>

      {/* Form */}
      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-sm fade-in">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <span className="flex size-10 items-center justify-center rounded-xl bg-accent-soft text-accent">
              <ShieldCheck className="size-5" aria-hidden="true" />
            </span>
            <p className="text-lg font-semibold text-foreground">KlaimCreator</p>
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-foreground">Masuk ke KlaimCreator</h1>
          <p className="mt-1 text-sm text-muted">Gunakan akun yang diberikan Admin tim Anda.</p>

          <form onSubmit={onSubmit} className="mt-6 space-y-4" noValidate>
            {formError ? (
              <div role="alert" className="rounded-lg border border-danger/40 bg-danger-soft px-3 py-2.5 text-sm text-danger">
                {formError}
              </div>
            ) : null}
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                placeholder="nama@perusahaan.id"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                aria-invalid={Boolean(fieldErrors.email)}
                aria-describedby={fieldErrors.email ? "email-error" : undefined}
                className={fieldErrors.email ? "border-danger/60" : undefined}
              />
              {fieldErrors.email ? (
                <p id="email-error" className="text-xs text-danger">
                  {fieldErrors.email}
                </p>
              ) : null}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                placeholder="Password Anda"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                aria-invalid={Boolean(fieldErrors.password)}
                aria-describedby={fieldErrors.password ? "password-error" : undefined}
                className={fieldErrors.password ? "border-danger/60" : undefined}
              />
              {fieldErrors.password ? (
                <p id="password-error" className="text-xs text-danger">
                  {fieldErrors.password}
                </p>
              ) : null}
            </div>
            <Button type="submit" className="w-full" size="lg" disabled={login.isPending}>
              {login.isPending ? (
                <>
                  <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
                  Memeriksa...
                </>
              ) : (
                "Masuk"
              )}
            </Button>
          </form>

          <p className="mt-6 text-xs leading-relaxed text-faint">
            Lupa password? Minta Admin me-reset password akun Anda lewat halaman Manajemen Akun. Percobaan login dibatasi
            5 kali per menit.
          </p>
        </div>
      </div>
    </div>
  );
}

// Dipakai guard untuk redirect bila sesi sudah ada.
export { Navigate as LoginNavigate };
