import { useState } from "react";
import { AlertTriangle, KeyRound, LifeBuoy, RefreshCw, Search, ShieldX } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, SectionCard } from "@/components/Structure";
import { ClaimStatusBadge } from "@/components/StatusBadge";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { Pagination } from "@/components/Pagination";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SkeletonRows } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableWrap,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useClaims, useMe, useMonitoringAction, useMonitoringStatus, useRetryClaim, useVerifyClaim } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { useSeo } from "@/lib/seo";
import { fmtDateTime, timeAgo } from "@/lib/format";
import type { Claim } from "@/lib/types";

const STATUS_OPTIONS = [
  { value: "all", label: "Semua Status" },
  { value: "Pending", label: "Menunggu" },
  { value: "Processing", label: "Sedang Diproses" },
  { value: "Success", label: "Berhasil" },
  { value: "Failed", label: "Gagal" },
  { value: "Already Claimed", label: "Sudah Terklaim" },
  { value: "Verification Required", label: "Perlu Verifikasi" },
];

/** Claim Management: antrian, retry, verifikasi, mode Otomatis/Assisted, Emergency Stop. */
export function ClaimsPage() {
  useSeo(
    "Claim Management — Kelola Antrian Klaim | KlaimCreator",
    "Kelola antrian dan eksekusi klaim username TikTok dengan mode Otomatis atau Assisted. Atur retry, verifikasi, dan Emergency Stop dalam satu halaman."
  );
  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [estopOpen, setEstopOpen] = useState(false);
  const [releaseOpen, setReleaseOpen] = useState(false);
  const [attemptsClaim, setAttemptsClaim] = useState<Claim | null>(null);

  const me = useMe();
  const isAdmin = me.data?.user?.role === "admin";
  const query = useClaims({ status: status === "all" ? undefined : status, search: search || undefined, page, pageSize });
  const monitoring = useMonitoringStatus(15_000);
  const estop = useMonitoringAction("emergency-stop");
  const release = useMonitoringAction("emergency-release");
  const retry = useRetryClaim();
  const verify = useVerifyClaim();

  const items = query.data?.items ?? [];
  const mode = monitoring.data?.claimMode ?? "assisted";

  function doEstop() {
    estop.mutate(undefined, {
      onSuccess: (res) => {
        toast.error(`Emergency Stop aktif. ${res.flipped ?? 0} klaim Processing menjadi Perlu Verifikasi.`);
        setEstopOpen(false);
      },
      onError: (err) => {
        toast.error(errorMessage(err));
        setEstopOpen(false);
      },
    });
  }

  function doRelease() {
    release.mutate(undefined, {
      onSuccess: () => {
        toast.success("Emergency Stop dibuka. Monitoring dapat dinyalakan kembali.");
        setReleaseOpen(false);
      },
      onError: (err) => {
        toast.error(errorMessage(err));
        setReleaseOpen(false);
      },
    });
  }

  function doRetry(claim: Claim) {
    retry.mutate(claim.id, {
      onSuccess: () => toast.success(`Klaim @${claim.username} dijadwalkan ulang.`),
      onError: (err) => toast.error(errorMessage(err)),
    });
  }

  function doVerify(claim: Claim, result: "success" | "already_claimed" | "failed") {
    verify.mutate(
      { claimId: claim.id, result },
      {
        onSuccess: (res) => toast.success(`Verifikasi @${claim.username} disimpan: ${res.status}.`),
        onError: (err) => toast.error(errorMessage(err)),
      }
    );
  }

  return (
    <div className="fade-in">
      <PageHeader
        title="Claim Management — Antrian & Eksekusi Klaim Username"
        description="Antrian dan eksekusi klaim. Klaim gagal sementara diulang otomatis dengan backoff; hasil tidak pasti menunggu verifikasi Admin."
        actions={
          <>
            <span
              className={`rounded-full border px-3 py-1 text-xs font-medium ${
                mode === "automatic" ? "border-accent/30 bg-accent-soft text-accent" : "border-line bg-surface-2 text-muted"
              }`}
            >
              Mode: {mode === "automatic" ? "Otomatis" : "Assisted"}
            </span>
            {monitoring.data?.emergencyStop ? (
              isAdmin ? (
                <Button variant="secondary" onClick={() => setReleaseOpen(true)}>
                  <LifeBuoy className="size-4" aria-hidden="true" />
                  Buka Emergency Stop
                </Button>
              ) : (
                <span className="rounded-full border border-danger/40 bg-danger-soft px-3 py-1 text-xs text-danger">
                  Emergency Stop aktif: hubungi Admin
                </span>
              )
            ) : (
              <Button variant="danger" onClick={() => setEstopOpen(true)}>
                <ShieldX className="size-4" aria-hidden="true" />
                Emergency Stop
              </Button>
            )}
          </>
        }
      />

      <SectionCard
        title="Antrian & Eksekusi Klaim"
        description={query.data ? `${query.data.total} klaim` : "Memuat data..."}
        actions={
          <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" aria-hidden="true" />
              <Input
                type="search"
                placeholder="Cari username..."
                className="w-full pl-9 sm:w-56"
                value={search}
                aria-label="Cari klaim"
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
              />
            </div>
            <div className="w-full sm:w-44">
              <Select
                value={status}
                onValueChange={(v) => {
                  setStatus(v);
                  setPage(1);
                }}
              >
                <SelectTrigger aria-label="Filter status klaim">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        }
      >
        {query.isError ? (
          <ErrorState message={errorMessage(query.error)} onRetry={() => void query.refetch()} />
        ) : query.isLoading ? (
          <SkeletonRows rows={6} />
        ) : items.length === 0 ? (
          <EmptyState
            icon={<KeyRound />}
            title="Belum ada klaim pada filter ini"
            description="Creator Available akan otomatis masuk antrian saat sinkronisasi berjalan, atau tambahkan manual dari halaman Available Creators."
          />
        ) : (
          <>
            <TableWrap>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden md:table-cell">Mode</TableHead>
                    <TableHead className="hidden lg:table-cell">Percobaan</TableHead>
                    <TableHead className="hidden xl:table-cell">Diperbarui</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <p className="font-medium text-foreground">@{c.username}</p>
                        {c.lastError ? (
                          <p className="max-w-56 truncate text-xs text-danger" title={c.lastError}>
                            {c.lastError}
                          </p>
                        ) : c.nextRetryAt ? (
                          <p className="text-xs text-warning">retry {fmtDateTime(c.nextRetryAt)}</p>
                        ) : null}
                      </TableCell>
                      <TableCell>
                        <ClaimStatusBadge status={c.status} />
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <span className="text-xs text-muted">{c.mode === "automatic" ? "Otomatis" : "Assisted"}</span>
                      </TableCell>
                      <TableCell className="hidden font-num lg:table-cell">{c.attemptCount}</TableCell>
                      <TableCell className="hidden text-xs text-muted xl:table-cell">{timeAgo(c.updatedAt)}</TableCell>
                      <TableCell>
                        <div className="flex justify-end gap-1.5">
                          <Button variant="ghost" size="sm" aria-label={`Lihat attempt @${c.username}`} onClick={() => setAttemptsClaim(c)}>
                            Detail
                          </Button>
                          {c.status === "Failed" ? (
                            <Button variant="secondary" size="sm" onClick={() => doRetry(c)} disabled={retry.isPending}>
                              <RefreshCw className="size-3.5" aria-hidden="true" />
                              Retry
                            </Button>
                          ) : null}
                          {c.status === "Verification Required" && isAdmin ? (
                            <>
                              <Button size="sm" onClick={() => doVerify(c, "success")} disabled={verify.isPending}>
                                Hasil: Berhasil
                              </Button>
                              <Button variant="secondary" size="sm" onClick={() => doVerify(c, "already_claimed")} disabled={verify.isPending}>
                                Sudah Terklaim
                              </Button>
                            </>
                          ) : null}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableWrap>
            <Pagination
              page={query.data!.page}
              totalPages={query.data!.totalPages}
              pageSize={pageSize}
              total={query.data!.total}
              onPageChange={setPage}
              onPageSizeChange={(s) => {
                setPageSize(s);
                setPage(1);
              }}
            />
          </>
        )}
      </SectionCard>

      {/* Dialog detail attempt */}
      <Dialog open={attemptsClaim !== null} onOpenChange={(open) => !open && setAttemptsClaim(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Riwayat Attempt @{attemptsClaim?.username ?? ""}</DialogTitle>
            <DialogDescription>Setiap eksekusi klaim tercatat: hasil, waktu, dan pesan sumber.</DialogDescription>
          </DialogHeader>
          {attemptsClaim ? (
            <ul className="space-y-2.5">
              <li className="rounded-lg border border-line bg-surface-2/60 p-3 text-sm">
                <p className="text-muted">
                  Percobaan total: <span className="font-num text-foreground">{attemptsClaim.attemptCount}</span>
                </p>
                {attemptsClaim.nextRetryAt ? (
                  <p className="text-warning">Retry otomatis dijadwalkan {fmtDateTime(attemptsClaim.nextRetryAt)}</p>
                ) : null}
              </li>
              <AttemptList claimId={attemptsClaim.id} />
            </ul>
          ) : null}
          <DialogFooter>
            <Button variant="secondary" onClick={() => setAttemptsClaim(null)}>
              Tutup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={estopOpen}
        onOpenChange={setEstopOpen}
        title="Aktifkan Emergency Stop?"
        description="Scheduler dan worker langsung berhenti. Klaim yang sedang diproses menjadi Perlu Verifikasi. Hanya Admin yang dapat membukanya kembali."
        confirmLabel="Ya, STOP sekarang"
        danger
        loading={estop.isPending}
        onConfirm={doEstop}
      />
      <ConfirmDialog
        open={releaseOpen}
        onOpenChange={setReleaseOpen}
        title="Buka Emergency Stop?"
        description="Setelah dibuka, Monitoring dapat dinyalakan kembali dan antrian klaim berjalan sesuai jadwal operasional."
        confirmLabel="Buka Emergency Stop"
        loading={release.isPending}
        onConfirm={doRelease}
      />
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

function AttemptList({ claimId }: { claimId: string }) {
  const attempts = useQuery({
    queryKey: ["claim-attempts-inline", claimId],
    queryFn: () => api.get<{ items: Array<{ id: string; attemptNumber: number; result: string; message: string | null; startedAt: string }> }>(`/api/claims/${claimId}/attempts`),
  });
  if (attempts.isLoading) return <SkeletonRows rows={2} />;
  if (attempts.isError) return <ErrorState message={errorMessage(attempts.error)} />;
  const items = attempts.data?.items ?? [];
  if (items.length === 0) {
    return (
      <li className="flex items-center gap-2 text-sm text-muted">
        <AlertTriangle className="size-4 text-warning" aria-hidden="true" />
        Belum ada attempt tercatat.
      </li>
    );
  }
  return (
    <>
      {items.map((a) => (
        <li key={a.id} className="rounded-lg border border-line p-3 text-sm">
          <div className="flex items-center justify-between">
            <p className="font-medium text-foreground">
              Attempt <span className="font-num">{a.attemptNumber}</span>: {a.result}
            </p>
            <span className="text-xs text-faint font-num">{fmtDateTime(a.startedAt)}</span>
          </div>
          {a.message ? <p className="mt-1 text-xs text-muted">{a.message}</p> : null}
        </li>
      ))}
    </>
  );
}
