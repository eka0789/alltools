import { useState } from "react";
import { History, Search, Users } from "lucide-react";
import { PageHeader, SectionCard } from "@/components/Structure";
import { CreatorStatusBadge } from "@/components/StatusBadge";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { Pagination } from "@/components/Pagination";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SkeletonRows } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableWrap,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { useCreatorHistory, useCreators } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { fmtDateTime, fmtNumber } from "@/lib/format";
import { useSeo } from "@/lib/seo";

const STATUS_OPTIONS = [
  { value: "all", label: "Semua Status" },
  { value: "Available", label: "Tersedia" },
  { value: "Claimed", label: "Terklaim" },
  { value: "Pending", label: "Diproses" },
  { value: "Failed", label: "Gagal" },
  { value: "Unavailable", label: "Tidak Tersedia" },
];

/** Creator Monitoring: seluruh creator, pencarian, filter status, pagination, drawer riwayat. */
export function CreatorsPage() {
  useSeo(
    "Creator Monitoring — Daftar Creator TikTok | KlaimCreator",
    "Lihat seluruh creator TikTok beserta status terkininya. Cari, filter status, dan telusuri riwayat perubahan status tiap creator di KlaimCreator."
  );
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const query = useCreators({ search: search || undefined, status: status === "all" ? undefined : status, page, pageSize, sort: "newest" });
  const history = useCreatorHistory(selectedId);

  const items = query.data?.items ?? [];

  return (
    <div className="fade-in">
      <PageHeader
        title="Creator Monitoring TikTok"
        description="Seluruh creator dari sumber data beserta status terkininya. Setiap perubahan status tercatat di riwayat."
      />

      <SectionCard
        title="Daftar Creator"
        description={query.data ? `${query.data.total} creator ditemukan` : "Memuat data..."}
        actions={
          <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:items-center">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" aria-hidden="true" />
              <Input
                type="search"
                placeholder="Cari username atau ID..."
                className="w-full pl-9 sm:w-64"
                value={search}
                aria-label="Cari creator"
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
              />
            </div>
            <div className="w-full sm:w-44">
              <Select
                value={status}
                onValueChange={(v) => {
                  setStatus(v);
                  setPage(1);
                }}
              >
                <SelectTrigger aria-label="Filter status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        }
      >
        {query.isError ? (
          <ErrorState message={errorMessage(query.error)} onRetry={() => void query.refetch()} />
        ) : query.isLoading ? (
          <SkeletonRows rows={6} />
        ) : items.length === 0 ? (
          <EmptyState
            icon={<Users />}
            title={search || status !== "all" ? "Tidak ada creator yang cocok" : "Belum ada creator"}
            description={
              search || status !== "all"
                ? "Coba ubah kata kunci pencarian atau filter status."
                : "Jalankan sinkronisasi dari Dashboard untuk menarik data creator pertama kali."
            }
          />
        ) : (
          <>
            <TableWrap>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead className="hidden sm:table-cell">ID Sumber</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden text-right md:table-cell">Followers</TableHead>
                    <TableHead className="hidden text-right lg:table-cell">Diperbarui</TableHead>
                    <TableHead className="text-right">Riwayat</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <p className="font-medium text-foreground">@{c.username}</p>
                        <p className="text-xs text-faint">{c.nickname ?? "-"}</p>
                      </TableCell>
                      <TableCell className="hidden font-num text-xs text-muted sm:table-cell">{c.externalId}</TableCell>
                      <TableCell>
                        <CreatorStatusBadge status={c.status} />
                      </TableCell>
                      <TableCell className="hidden text-right font-num md:table-cell">{fmtNumber(c.followerCount)}</TableCell>
                      <TableCell className="hidden text-right text-xs text-muted lg:table-cell">{fmtDateTime(c.lastUpdatedAt)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          aria-label={`Lihat riwayat status @${c.username}`}
                          onClick={() => setSelectedId(c.id)}
                        >
                          <History className="size-4" aria-hidden="true" />
                          <span className="sr-only sm:not-sr-only sm:text-xs">Riwayat</span>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableWrap>
            <Pagination
              page={query.data!.page}
              totalPages={query.data!.totalPages}
              pageSize={pageSize}
              total={query.data!.total}
              onPageChange={setPage}
              onPageSizeChange={(s) => {
                setPageSize(s);
                setPage(1);
              }}
            />
          </>
        )}
      </SectionCard>

      {/* Drawer riwayat status */}
      <Dialog open={selectedId !== null} onOpenChange={(open) => !open && setSelectedId(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Riwayat Status @{history.data?.creator.username ?? "..."}</DialogTitle>
            <DialogDescription>Urutan perubahan status creator, terbaru di atas.</DialogDescription>
          </DialogHeader>
          {history.isLoading ? (
            <SkeletonRows rows={3} />
          ) : history.isError ? (
            <ErrorState message={errorMessage(history.error)} onRetry={() => void history.refetch()} />
          ) : (history.data?.items.length ?? 0) === 0 ? (
            <EmptyState icon={<History />} title="Belum ada perubahan" description="Creator ini belum pernah berubah status sejak terdeteksi." />
          ) : (
            <ol className="relative space-y-4 border-l border-line pl-4">
              {history.data!.items.map((h) => (
                <li key={h.id} className="relative">
                  <span className="absolute -left-[21px] top-1 size-2.5 rounded-full bg-accent" aria-hidden="true" />
                  <p className="text-sm font-medium text-foreground">
                    {h.oldStatus ? `${h.oldStatus} menjadi ${h.newStatus}` : `Terdeteksi sebagai ${h.newStatus}`}
                  </p>
                  <p className="text-xs text-muted">{h.reason ?? "-"}</p>
                  <p className="mt-0.5 text-xs text-faint font-num">{fmtDateTime(h.changedAt)}</p>
                </li>
              ))}
            </ol>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
