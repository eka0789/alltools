import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { LoaderCircle, LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useChangePassword } from "@/lib/queries";
import { errorMessage } from "@/lib/api";

/** Halaman wajib ganti password (login pertama / setelah Admin me-reset). */
export function ChangePasswordPage() {
  const change = useChangePassword();
  const navigate = useNavigate();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const errors: Record<string, string> = {};
    if (!currentPassword) errors.currentPassword = "Password saat ini wajib diisi";
    if (newPassword.length < 8) errors.newPassword = "Password minimal 8 karakter";
    else if (!/[A-Za-z]/.test(newPassword) || !/[0-9]/.test(newPassword)) errors.newPassword = "Password harus mengandung huruf dan angka";
    if (confirm !== newPassword) errors.confirm = "Konfirmasi password tidak sama";
    setFieldErrors(errors);
    if (Object.keys(errors).length > 0) return;

    change.mutate(
      { currentPassword, newPassword },
      {
        onSuccess: () => {
          navigate("/login", { replace: true });
        },
        onError: (err) => {
          setFormError(errorMessage(err, "Gagal mengganti password."));
        },
      }
    );
  }

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background p-6">
      <div className="w-full max-w-md fade-in">
        <div className="mb-6 flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-xl bg-accent-soft text-accent">
            <LockKeyhole className="size-5" aria-hidden="true" />
          </span>
          <div>
            <h1 className="text-lg font-semibold tracking-tight text-foreground">Ganti password Anda</h1>
            <p className="text-sm text-muted">Password sementara harus diganti sebelum masuk ke dashboard.</p>
          </div>
        </div>

        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          {formError ? (
            <div role="alert" className="rounded-lg border border-danger/40 bg-danger-soft px-3 py-2.5 text-sm text-danger">
              {formError}
            </div>
          ) : null}
          <div className="space-y-1.5">
            <Label htmlFor="currentPassword">Password saat ini</Label>
            <Input
              id="currentPassword"
              type="password"
              autoComplete="current-password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              aria-invalid={Boolean(fieldErrors.currentPassword)}
            />
            {fieldErrors.currentPassword ? <p className="text-xs text-danger">{fieldErrors.currentPassword}</p> : null}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="newPassword">Password baru</Label>
            <Input
              id="newPassword"
              type="password"
              autoComplete="new-password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              aria-invalid={Boolean(fieldErrors.newPassword)}
            />
            {fieldErrors.newPassword ? (
              <p className="text-xs text-danger">{fieldErrors.newPassword}</p>
            ) : (
              <p className="text-xs text-faint">Minimal 8 karakter, mengandung huruf dan angka.</p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="confirm">Konfirmasi password baru</Label>
            <Input
              id="confirm"
              type="password"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              aria-invalid={Boolean(fieldErrors.confirm)}
            />
            {fieldErrors.confirm ? <p className="text-xs text-danger">{fieldErrors.confirm}</p> : null}
          </div>
          <Button type="submit" className="w-full" size="lg" disabled={change.isPending}>
            {change.isPending ? (
              <>
                <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
                Menyimpan...
              </>
            ) : (
              "Simpan password baru"
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}
