import { useState } from "react";
import { FileClock, ScrollText } from "lucide-react";
import { PageHeader, SectionCard } from "@/components/Structure";
import { Badge } from "@/components/ui/badge";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { Pagination } from "@/components/Pagination";
import { SkeletonRows } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableWrap,
} from "@/components/ui/table";
import { useAudit, useEvents, useMe, useSyncLogs } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { useSeo } from "@/lib/seo";
import { fmtDateTime } from "@/lib/format";
import { EVENT_STATUS, EVENT_TYPE_LABELS } from "@/lib/status";

const EVENT_TYPES = [
  { value: "all", label: "Semua Tipe" },
  { value: "creator_available", label: "Creator Tersedia" },
  { value: "claim_success", label: "Klaim Berhasil" },
  { value: "claim_failed", label: "Klaim Gagal" },
  { value: "session_expired", label: "Sesi Berakhir" },
  { value: "source_disconnected", label: "Sumber Terputus" },
  { value: "sync_failed", label: "Sinkronisasi Gagal" },
  { value: "worker_stopped", label: "Worker Berhenti" },
];

const EVENT_STATUSES = [
  { value: "all", label: "Semua Status" },
  { value: "Info", label: "Info" },
  { value: "Success", label: "Sukses" },
  { value: "Warning", label: "Peringatan" },
  { value: "Error", label: "Error" },
];

/** System Logs: event, log sinkronisasi, dan Audit Trail (Admin). */
export function LogsPage() {
  useSeo(
    "System Logs — Log Sinkronisasi & Audit Trail | KlaimCreator",
    "Pantau log sinkronisasi, deteksi, klaim, retry, integrasi, dan worker dalam satu tempat. Tab Audit Trail khusus admin mencatat aktivitas pengguna."
  );
  const me = useMe();
  const isAdmin = me.data?.user?.role === "admin";
  const [tab, setTab] = useState(isAdmin ? "events" : "events");
  const [type, setType] = useState("all");
  const [eventStatus, setEventStatus] = useState("all");
  const [page, setPage] = useState(1);
  const events = useEvents({
    type: type === "all" ? undefined : type,
    status: eventStatus === "all" ? undefined : eventStatus,
    page,
    pageSize: 20,
  });

  return (
    <div className="fade-in">
      <PageHeader
        title="System Logs & Audit Trail"
        description="Jejak operasional sistem: sinkronisasi, deteksi, klaim, retry, integrasi, dan worker. Log operasional dibersihkan otomatis setelah 90 hari; data klaim tetap permanen."
      />
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList aria-label="Jenis log">
          <TabsTrigger value="events">Event Sistem</TabsTrigger>
          <TabsTrigger value="sync">Log Sinkronisasi</TabsTrigger>
          {isAdmin ? <TabsTrigger value="audit">Audit Trail</TabsTrigger> : null}
        </TabsList>

        <TabsContent value="events">
          <SectionCard
            title="Event Sistem"
            description={events.data ? `${events.data.total} event` : "Memuat..."}
            actions={
              <div className="flex flex-col gap-2 sm:flex-row">
                <Select
                  value={type}
                  onValueChange={(v) => {
                    setType(v);
                    setPage(1);
                  }}
                >
                  <SelectTrigger className="w-full sm:w-44" aria-label="Filter tipe event">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {EVENT_TYPES.map((o) => (
                      <SelectItem key={o.value} value={o.value}>
                        {o.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select
                  value={eventStatus}
                  onValueChange={(v) => {
                    setEventStatus(v);
                    setPage(1);
                  }}
                >
                  <SelectTrigger className="w-full sm:w-40" aria-label="Filter status event">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {EVENT_STATUSES.map((o) => (
                      <SelectItem key={o.value} value={o.value}>
                        {o.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            }
          >
            {events.isError ? (
              <ErrorState message={errorMessage(events.error)} onRetry={() => void events.refetch()} />
            ) : events.isLoading ? (
              <SkeletonRows rows={6} />
            ) : (events.data?.items.length ?? 0) === 0 ? (
              <EmptyState
                icon={<FileClock />}
                title="Tidak ada event pada filter ini"
                description="Event muncul saat sistem mendeteksi perubahan: creator baru, hasil klaim, gangguan sumber, atau aktivitas worker."
              />
            ) : (
              <>
                <TableWrap>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-24">Event ID</TableHead>
                        <TableHead>Tipe</TableHead>
                        <TableHead>Deskripsi</TableHead>
                        <TableHead className="hidden md:table-cell">Creator</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="hidden text-right lg:table-cell">Waktu</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {events.data!.items.map((e) => (
                        <TableRow key={e.id}>
                          <TableCell className="font-num text-xs text-faint">{e.id.slice(0, 8)}</TableCell>
                          <TableCell className="whitespace-nowrap text-xs font-medium text-foreground">
                            {EVENT_TYPE_LABELS[e.eventType] ?? e.eventType}
                          </TableCell>
                          <TableCell className="max-w-72 text-sm text-muted">
                            <span className="line-clamp-2">{e.description}</span>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            {e.creatorUsername ? <span className="text-xs text-muted">@{e.creatorUsername}</span> : <span className="text-xs text-faint">-</span>}
                          </TableCell>
                          <TableCell>
                            <Badge className={EVENT_STATUS[e.status]?.className ?? "border-line bg-surface-2 text-muted"}>
                              {EVENT_STATUS[e.status]?.label ?? e.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden text-right text-xs text-muted lg:table-cell">{fmtDateTime(e.createdAt)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableWrap>
                <Pagination
                  page={events.data!.page}
                  totalPages={events.data!.totalPages}
                  pageSize={20}
                  total={events.data!.total}
                  onPageChange={setPage}
                />
              </>
            )}
          </SectionCard>
        </TabsContent>

        <TabsContent value="sync">
          <SyncLogsCard />
        </TabsContent>

        {isAdmin ? (
          <TabsContent value="audit">
            <AuditCard />
          </TabsContent>
        ) : null}
      </Tabs>
    </div>
  );
}

function SyncLogsCard() {
  const query = useSyncLogs(50);
  const items = query.data?.items ?? [];
  return (
    <SectionCard title="Log Sinkronisasi" description="50 siklus terakhir: jumlah halaman, item, dan hasil deteksi">
      {query.isError ? (
        <ErrorState message={errorMessage(query.error)} onRetry={() => void query.refetch()} />
      ) : query.isLoading ? (
        <SkeletonRows rows={6} />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<FileClock />}
          title="Belum ada sinkronisasi"
          description="Jalankan sinkronisasi manual dari Dashboard atau aktifkan Monitoring."
        />
      ) : (
        <TableWrap>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Mulai</TableHead>
                <TableHead>Pemicu</TableHead>
                <TableHead>Hasil</TableHead>
                <TableHead className="text-right">Halaman</TableHead>
                <TableHead className="text-right">Item</TableHead>
                <TableHead className="text-right">Baru</TableHead>
                <TableHead className="text-right">Available</TableHead>
                <TableHead className="hidden lg:table-cell">Error</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="whitespace-nowrap text-xs text-muted font-num">{fmtDateTime(s.startedAt)}</TableCell>
                  <TableCell className="text-xs text-muted">{s.trigger === "manual" ? "Manual" : "Terjadwal"}</TableCell>
                  <TableCell>
                    <Badge className={s.status === "Success" ? "border-accent/30 bg-accent-soft text-accent" : "border-danger/30 bg-danger-soft text-danger"}>
                      {s.status === "Success" ? "Sukses" : "Gagal"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-num">{s.pagesFetched}</TableCell>
                  <TableCell className="text-right font-num">{s.itemsFetched}</TableCell>
                  <TableCell className="text-right font-num">{s.itemsCreated}</TableCell>
                  <TableCell className="text-right font-num">{s.availableDetected}</TableCell>
                  <TableCell className="hidden max-w-52 truncate text-xs text-danger lg:table-cell" title={s.error ?? undefined}>
                    {s.error ?? "-"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableWrap>
      )}
    </SectionCard>
  );
}

function AuditCard() {
  const [page, setPage] = useState(1);
  const query = useAudit({ page, pageSize: 20 });
  const items = query.data?.items ?? [];
  return (
    <SectionCard
      title="Audit Trail"
      description="Aktivitas pengguna. Catatan ini append-only: tidak ada peran yang dapat mengubah atau menghapusnya."
    >
      {query.isError ? (
        <ErrorState message={errorMessage(query.error)} onRetry={() => void query.refetch()} />
      ) : query.isLoading ? (
        <SkeletonRows rows={6} />
      ) : items.length === 0 ? (
        <EmptyState icon={<ScrollText />} title="Belum ada aktivitas" description="Aksi pengguna (login, perubahan pengaturan, klaim) akan tercatat di sini." />
      ) : (
        <>
          <TableWrap>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Waktu</TableHead>
                  <TableHead>Pengguna</TableHead>
                  <TableHead>Aksi</TableHead>
                  <TableHead className="hidden md:table-cell">Entitas</TableHead>
                  <TableHead className="hidden xl:table-cell">IP</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell className="whitespace-nowrap text-xs text-muted font-num">{fmtDateTime(a.createdAt)}</TableCell>
                    <TableCell className="text-xs text-muted">{a.userEmail ?? "sistem"}</TableCell>
                    <TableCell>
                      <Badge className="border-line bg-surface-2 text-muted font-num">{a.action}</Badge>
                    </TableCell>
                    <TableCell className="hidden text-xs text-faint md:table-cell">
                      {a.entity ? `${a.entity}${a.entityId ? ` (${a.entityId.slice(0, 8)})` : ""}` : "-"}
                    </TableCell>
                    <TableCell className="hidden font-num text-xs text-faint xl:table-cell">{a.ip ?? "-"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableWrap>
          <Pagination
            page={query.data!.page}
            totalPages={query.data!.totalPages}
            pageSize={20}
            total={query.data!.total}
            onPageChange={setPage}
          />
        </>
      )}
    </SectionCard>
  );
}
