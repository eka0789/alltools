import { useEffect, useState } from "react";
import { Bot, Hand, Save, Timer } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, SectionCard } from "@/components/Structure";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAutomation, useSaveAutomation } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { useSeo } from "@/lib/seo";
import type { AutomationSettings } from "@/lib/types";

const DAY_LABELS = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
const HOURS = Array.from({ length: 24 }, (_, i) => ({ value: String(i), label: `${String(i).padStart(2, "0")}:00` }));

/** Automation Settings (Admin): interval, retry, mode klaim, jadwal, notifikasi, export. */
export function AutomationSettingsPage() {
  useSeo(
    "Automation Settings — Interval & Mode Klaim | KlaimCreator",
    "Atur interval refresh, maximum retry, mode klaim, jadwal operasional, notifikasi, dan konfigurasi export agar otomatisasi KlaimCreator tetap terkendali."
  );
  const query = useAutomation();
  const save = useSaveAutomation();
  const [form, setForm] = useState<AutomationSettings | null>(null);
  const [claimMode, setClaimMode] = useState<"automatic" | "assisted">("assisted");

  useEffect(() => {
    if (query.data) {
      setForm(query.data.automation);
      setClaimMode(query.data.claimMode);
    }
  }, [query.data]);

  function onSave() {
    if (!form) return;
    save.mutate(
      {
        claimMode,
        refreshIntervalSeconds: form.refreshIntervalSeconds,
        maxRetries: form.maxRetries,
        retryBaseDelaySeconds: form.retryBaseDelaySeconds,
        claimSchedule: form.claimSchedule,
        notifications: form.notifications,
        export: form.export,
      },
      {
        onSuccess: () => toast.success("Pengaturan automasi disimpan."),
        onError: (err) => toast.error(errorMessage(err)),
      }
    );
  }

  if (query.isError) {
    return (
      <div className="fade-in">
        <PageHeader title="Automation Settings — Interval & Mode Klaim" />
        <SectionCard title="Gagal memuat" description={errorMessage(query.error)}>{null}</SectionCard>
      </div>
    );
  }

  if (query.isLoading || !form || !query.data) {
    return (
      <div className="fade-in">
        <PageHeader title="Automation Settings — Interval & Mode Klaim" description="Memuat pengaturan..." />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  const automaticPossible = query.data.automaticPossible;

  return (
    <div className="fade-in">
      <PageHeader
        title="Automation Settings — Interval & Mode Klaim"
        description="Atur interval sinkronisasi, kebijakan retry, mode klaim, jadwal operasional, kanal notifikasi, dan konfigurasi export."
        actions={
          <Button onClick={onSave} disabled={save.isPending}>
            <Save className="size-4" aria-hidden="true" />
            {save.isPending ? "Menyimpan..." : "Simpan Semua"}
          </Button>
        }
      />

      <div className="grid gap-4 xl:grid-cols-2">
        <SectionCard title="Monitoring & Sinkronisasi" description="Interval data terbaru di dashboard dan scheduler worker">
          <FieldRow label="Interval refresh (detik)" hint="15 sampai 3600 detik">
            <Input
              type="number"
              min={15}
              max={3600}
              value={form.refreshIntervalSeconds}
              onChange={(e) => setForm({ ...form, refreshIntervalSeconds: Number(e.target.value) || 60 })}
              className="w-28"
              aria-label="Interval refresh dalam detik"
            />
          </FieldRow>
          <FieldRow label="Mode klaim" hint={automaticPossible ? "Integrasi resmi siap: otomatis boleh diaktifkan" : "Tanpa integrasi resmi, sistem berjalan pada Assisted Claim Mode"}>
            <div className="flex items-center gap-2">
              {claimMode === "automatic" ? <Bot className="size-4 text-accent" aria-hidden="true" /> : <Hand className="size-4 text-muted" aria-hidden="true" />}
              <Select
                value={claimMode}
                onValueChange={(v) => setClaimMode(v as "automatic" | "assisted")}
              >
                <SelectTrigger className="w-44" aria-label="Mode klaim">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="assisted">Assisted (manual)</SelectItem>
                  <SelectItem value="automatic" disabled={!automaticPossible}>
                    Otomatis {automaticPossible ? "" : "(butuh integrasi resmi)"}
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </FieldRow>
        </SectionCard>

        <SectionCard title="Kebijakan Retry" description="Klaim gagal sementara diulang dengan exponential backoff hingga batas ini">
          <FieldRow label="Maximum retry" hint="0 sampai 10 percobaan">
            <Input
              type="number"
              min={0}
              max={10}
              value={form.maxRetries}
              onChange={(e) => setForm({ ...form, maxRetries: Number(e.target.value) || 0 })}
              className="w-28"
              aria-label="Maximum retry"
            />
          </FieldRow>
          <FieldRow label="Delay dasar (detik)" hint="Percobaan ke-N menunggu delay x 2^(N-1)">
            <Input
              type="number"
              min={5}
              max={3600}
              value={form.retryBaseDelaySeconds}
              onChange={(e) => setForm({ ...form, retryBaseDelaySeconds: Number(e.target.value) || 30 })}
              className="w-28"
              aria-label="Delay dasar retry dalam detik"
            />
          </FieldRow>
        </SectionCard>

        <SectionCard title="Jadwal Operasional Klaim" description="Klaim hanya dieksekusi pada jam/hari ini; monitoring tetap berjalan di luar jadwal">
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="sched-start">Jam mulai</Label>
              <Select
                value={String(form.claimSchedule.startHour)}
                onValueChange={(v) => setForm({ ...form, claimSchedule: { ...form.claimSchedule, startHour: Number(v) } })}
              >
                <SelectTrigger id="sched-start" className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {HOURS.map((h) => (
                    <SelectItem key={h.value} value={h.value}>
                      {h.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sched-end">Jam selesai</Label>
              <Select
                value={String(form.claimSchedule.endHour)}
                onValueChange={(v) => setForm({ ...form, claimSchedule: { ...form.claimSchedule, endHour: Number(v) } })}
              >
                <SelectTrigger id="sched-end" className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {HOURS.map((h) => (
                    <SelectItem key={h.value} value={h.value}>
                      {h.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4">
            <Label>Hari operasional</Label>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {DAY_LABELS.map((label, index) => {
                const active = form.claimSchedule.days.includes(index);
                return (
                  <button
                    key={label}
                    type="button"
                    aria-pressed={active}
                    onClick={() =>
                      setForm({
                        ...form,
                        claimSchedule: {
                          ...form.claimSchedule,
                          days: active
                            ? form.claimSchedule.days.filter((d) => d !== index)
                            : [...form.claimSchedule.days, index].sort((a, b) => a - b),
                        },
                      })
                    }
                    className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
                      active ? "border-accent/40 bg-accent-soft text-accent" : "border-line bg-surface-2 text-muted hover:text-foreground"
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Notifikasi" description="Kanal tambahan nonaktif secara default; butuh kredensial di environment variables">
          <FieldRow label="Notifikasi in-app" hint="Selalu tersedia di lonceng notifikasi">
            <Switch
              checked={form.notifications.inApp}
              onCheckedChange={(v) => setForm({ ...form, notifications: { ...form.notifications, inApp: v } })}
              aria-label="Notifikasi in-app"
            />
          </FieldRow>
          <FieldRow label="Kanal Telegram" hint="Butuh TELEGRAM_BOT_TOKEN dan TELEGRAM_CHAT_ID">
            <Switch
              checked={form.notifications.telegram}
              onCheckedChange={(v) => setForm({ ...form, notifications: { ...form.notifications, telegram: v } })}
              aria-label="Kanal Telegram"
            />
          </FieldRow>
          <FieldRow label="Kanal email" hint="Butuh konfigurasi SMTP/gateway email">
            <Switch
              checked={form.notifications.email}
              onCheckedChange={(v) => setForm({ ...form, notifications: { ...form.notifications, email: v } })}
              aria-label="Kanal email"
            />
          </FieldRow>
        </SectionCard>

        <SectionCard title="Konfigurasi Export" description="Default nama file hasil unduhan CSV/Excel">
          <FieldRow label="Prefix nama file" hint="Contoh: klaim-creator menghasilkan klaim-creator-2026-01-05.csv">
            <Input
              value={form.export.filenamePrefix}
              onChange={(e) => setForm({ ...form, export: { ...form.export, filenamePrefix: e.target.value } })}
              className="w-56"
              aria-label="Prefix nama file export"
            />
          </FieldRow>
          <FieldRow label="Default export hanya username" hint="Satu kolom Username saja">
            <Switch
              checked={form.export.usernamesOnlyDefault}
              onCheckedChange={(v) => setForm({ ...form, export: { ...form.export, usernamesOnlyDefault: v } })}
              aria-label="Default export hanya username"
            />
          </FieldRow>
          <p className="mt-3 flex items-center gap-1.5 text-xs text-faint">
            <Timer className="size-3.5" aria-hidden="true" />
            Perubahan interval langsung memengaruhi polling dashboard dan jadwal worker.
          </p>
        </SectionCard>
      </div>
    </div>
  );
}

function FieldRow({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2 border-b border-line py-3 last:border-0 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-sm font-medium text-foreground">{label}</p>
        {hint ? <p className="text-xs text-muted">{hint}</p> : null}
      </div>
      {children}
    </div>
  );
}
