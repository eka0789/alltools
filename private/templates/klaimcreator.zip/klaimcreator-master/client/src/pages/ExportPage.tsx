import { useMemo, useState } from "react";
import { Check, Copy, Download, FileSpreadsheet, FileText, Search } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, SectionCard } from "@/components/Structure";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { ClaimStatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SkeletonRows } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableWrap,
} from "@/components/ui/table";
import { downloadUrl, errorMessage } from "@/lib/api";
import { useExportPreview } from "@/lib/queries";
import { fmtDate } from "@/lib/format";
import { useSeo } from "@/lib/seo";

const STATUS_OPTIONS = [
  { value: "Success", label: "Berhasil (default)" },
  { value: "Already Claimed", label: "Sudah Terklaim" },
  { value: "Failed", label: "Gagal" },
  { value: "Verification Required", label: "Perlu Verifikasi" },
  { value: "Pending", label: "Menunggu" },
  { value: "Processing", label: "Sedang Diproses" },
];

/** Username Export: filter, preview, unduh CSV/Excel tersanitasi, copy & bulk copy. */
export function ExportPage() {
  useSeo(
    "Username Export — Unduh CSV & Excel Klaim | KlaimCreator",
    "Filter klaim per tanggal dan status, lalu unduh CSV/Excel tersanitasi atau copy username massal. Siap diimpor ke database perusahaan dengan cepat."
  );
  const [status, setStatus] = useState("Success");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [filter, setFilter] = useState("");
  const [copied, setCopied] = useState<string | null>(null);

  const query = useExportPreview({ status, from: from || undefined, to: to || undefined });
  const rows = query.data?.rows ?? [];
  const filteredRows = useMemo(() => {
    if (!filter) return rows;
    const q = filter.toLowerCase();
    return rows.filter((r) => r.username.toLowerCase().includes(q) || r.creatorId.toLowerCase().includes(q));
  }, [rows, filter]);

  async function copyOne(username: string) {
    try {
      await navigator.clipboard.writeText(username);
      setCopied(username);
      toast.success(`@${username} disalin.`);
      setTimeout(() => setCopied(null), 1500);
    } catch {
      toast.error("Browser menolak akses clipboard.");
    }
  }

  async function copySelected() {
    if (filteredRows.length === 0) return;
    try {
      await navigator.clipboard.writeText(filteredRows.map((r) => r.username).join("\n"));
      toast.success(`${filteredRows.length} username disalin.`);
    } catch {
      toast.error("Browser menolak akses clipboard.");
    }
  }

  function download(kind: "csv" | "excel") {
    // Unduhan lewat navigasi langsung; cookie httpOnly ikut terkirim (same-origin).
    window.location.href = downloadUrl(`/api/export/${kind === "csv" ? "csv" : "excel"}`, {
      status,
      from: from || undefined,
      to: to || undefined,
    });
    toast.success(kind === "csv" ? "CSV diunduh." : "Excel diunduh.");
  }

  return (
    <div className="fade-in">
      <PageHeader
        title="Export Username Klaim ke CSV & Excel"
        description="Unduh username hasil klaim untuk dimasukkan ke database perusahaan. Kolom: No, Creator ID, Username, Claim Status, Claim Date. Tanpa duplikat username dan tersanitasi dari formula injection."
      />

      <SectionCard
        title="Filter Export"
        description="Preview dan unduhan mengikuti filter ini"
        actions={
          <>
            <Button variant="secondary" onClick={() => void copySelected()} disabled={filteredRows.length === 0}>
              <Copy className="size-4" aria-hidden="true" />
              Bulk Copy ({filteredRows.length})
            </Button>
            <Button variant="secondary" onClick={() => download("csv")} disabled={rows.length === 0}>
              <FileText className="size-4" aria-hidden="true" />
              Unduh CSV
            </Button>
            <Button onClick={() => download("excel")} disabled={rows.length === 0}>
              <FileSpreadsheet className="size-4" aria-hidden="true" />
              Unduh Excel
            </Button>
          </>
        }
      >
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label htmlFor="export-status">Status klaim</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger id="export-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="export-from">Tanggal mulai</Label>
            <Input id="export-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="export-to">Tanggal akhir</Label>
            <Input id="export-to" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
        </div>
      </SectionCard>

      <div className="mt-4">
        <SectionCard
          title="Preview Data"
          description={query.data ? `${query.data.total} baris tersedia (preview maksimal 500)` : "Memuat..."}
          actions={
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" aria-hidden="true" />
              <Input
                type="search"
                placeholder="Saring username/ID..."
                className="w-56 pl-9"
                value={filter}
                aria-label="Saring preview"
                onChange={(e) => setFilter(e.target.value)}
              />
            </div>
          }
        >
          {query.isError ? (
            <ErrorState message={errorMessage(query.error)} onRetry={() => void query.refetch()} />
          ) : query.isLoading ? (
            <SkeletonRows rows={5} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon={<Download />}
              title="Tidak ada data untuk filter ini"
              description="Belum ada klaim berstatus terpilih pada rentang tanggal tersebut. Ubah filter atau klaim beberapa creator terlebih dahulu."
            />
          ) : filteredRows.length === 0 ? (
            <EmptyState
              icon={<Search />}
              title="Tidak cocok dengan pencarian"
              description="Tidak ada username/ID yang cocok dengan kata kunci pada preview ini."
            />
          ) : (
            <TableWrap>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10">No</TableHead>
                    <TableHead>Creator ID</TableHead>
                    <TableHead>Username</TableHead>
                    <TableHead>Claim Status</TableHead>
                    <TableHead>Claim Date</TableHead>
                    <TableHead className="text-right">Copy</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRows.map((r) => (
                    <TableRow key={`${r.creatorId}-${r.username}`}>
                      <TableCell className="font-num text-muted">{r.no}</TableCell>
                      <TableCell className="font-num text-xs text-muted">{r.creatorId}</TableCell>
                      <TableCell className="font-medium text-foreground">@{r.username}</TableCell>
                      <TableCell>
                        <ClaimStatusBadge status={r.claimStatus} />
                      </TableCell>
                      <TableCell className="text-xs text-muted font-num">{fmtDate(r.claimDate)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => void copyOne(r.username)}
                          aria-label={`Copy username ${r.username}`}
                        >
                          {copied === r.username ? (
                            <Check className="size-4 text-accent" aria-hidden="true" />
                          ) : (
                            <Copy className="size-4" aria-hidden="true" />
                          )}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableWrap>
          )}
        </SectionCard>
      </div>
    </div>
  );
}
