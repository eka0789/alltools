import { useState } from "react";
import { ClipboardList, HandCoins, Plus, Radio, UserCheck } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, SectionCard } from "@/components/Structure";
import { CreatorStatusBadge } from "@/components/StatusBadge";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { Pagination } from "@/components/Pagination";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Button } from "@/components/ui/button";
import { SkeletonRows } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableWrap,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAssistedResult, useAvailableCreators, useMonitoringStatus, useQueueClaim } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { fmtDateTime, fmtNumber } from "@/lib/format";
import { useSeo } from "@/lib/seo";

/** Available Creators: antrian creator siap klaim, terbaru dulu, aksi cepat. */
export function AvailableCreatorsPage() {
  useSeo(
    "Available Creators — Username Siap Diklaim | KlaimCreator",
    "Antrian creator berstatus Available yang siap diklaim, diurutkan terbaru lebih dulu. Masukkan ke queue atau catat klaim assisted dengan satu klik."
  );
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [queueTarget, setQueueTarget] = useState<{ id: string; username: string } | null>(null);
  const [assistedTarget, setAssistedTarget] = useState<{ id: string; username: string } | null>(null);
  const [assistedResult, setAssistedResult] = useState<"success" | "already_claimed" | "failed">("success");

  const query = useAvailableCreators(page, pageSize);
  const status = useMonitoringStatus(15_000);
  const queueClaim = useQueueClaim();
  const assisted = useAssistedResult();

  const items = query.data?.items ?? [];

  function confirmQueue() {
    if (!queueTarget) return;
    queueClaim.mutate(queueTarget.id, {
      onSuccess: () => {
        toast.success(`@${queueTarget.username} masuk antrian klaim.`);
        setQueueTarget(null);
      },
      onError: (err) => {
        toast.error(errorMessage(err));
        setQueueTarget(null);
      },
    });
  }

  function submitAssisted() {
    if (!assistedTarget) return;
    // Alur assisted: creator di halaman ini belum punya klaim aktif, jadi buat klaim dulu
    // (operator sudah mengklaim manual di dashboard sumber), lalu catat hasilnya.
    queueClaim.mutate(assistedTarget.id, {
      onSuccess: (res) => {
        assisted.mutate(
          { claimId: res.claim.id, result: assistedResult },
          {
            onSuccess: (res2) => {
              toast.success(`Hasil klaim @${assistedTarget.username} dicatat: ${res2.status}.`);
              setAssistedTarget(null);
            },
            onError: (err) => toast.error(errorMessage(err)),
          }
        );
      },
      onError: (err) => {
        toast.error(errorMessage(err));
      },
    });
  }

  return (
    <div className="fade-in">
      <PageHeader
        title="Available Creators — Antrian Username Siap Diklaim"
        description="Creator berstatus tersedia yang belum memiliki klaim aktif, diurutkan dari yang terbaru."
        actions={
          <div className="flex items-center gap-2 text-xs text-muted">
            <span className="size-2 rounded-full bg-accent" aria-hidden="true" />
            Mode: {status.data?.claimMode === "automatic" ? "Klaim Otomatis" : "Assisted Claim Mode"}
          </div>
        }
      />

      <SectionCard
        title="Antrian Kandidat Klaim"
        description={query.data ? `${query.data.total} creator tersedia` : "Memuat data..."}
      >
        {query.isError ? (
          <ErrorState message={errorMessage(query.error)} onRetry={() => void query.refetch()} />
        ) : query.isLoading ? (
          <SkeletonRows rows={6} />
        ) : items.length === 0 ? (
          <EmptyState
            icon={<Radio />}
            title="Tidak ada creator tersedia saat ini"
            description="Creator baru akan muncul di sini setelah sinkronisasi menemukan username berstatus Available yang belum diklaim."
          />
        ) : (
          <>
            <TableWrap>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead className="hidden md:table-cell">Followers</TableHead>
                    <TableHead className="hidden lg:table-cell">Terdeteksi</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <p className="font-medium text-foreground">@{c.username}</p>
                        <p className="text-xs text-faint">{c.nickname ?? c.externalId}</p>
                      </TableCell>
                      <TableCell className="hidden font-num md:table-cell">{fmtNumber(c.followerCount)}</TableCell>
                      <TableCell className="hidden text-xs text-muted lg:table-cell">{fmtDateTime(c.firstSeenAt)}</TableCell>
                      <TableCell>
                        <CreatorStatusBadge status={c.status} />
                      </TableCell>
                      <TableCell>
                        <div className="flex justify-end gap-1.5">
                          <Button size="sm" variant="secondary" onClick={() => setQueueTarget({ id: c.id, username: c.username })}>
                            <Plus className="size-3.5" aria-hidden="true" />
                            <span className="hidden sm:inline">Ke Antrian</span>
                            <span className="sr-only">Masukkan @{c.username} ke antrian</span>
                          </Button>
                          <Button size="sm" onClick={() => setAssistedTarget({ id: c.id, username: c.username })}>
                            <HandCoins className="size-3.5" aria-hidden="true" />
                            <span className="hidden sm:inline">Catat Klaim</span>
                            <span className="sr-only">Catat klaim assisted @{c.username}</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableWrap>
            <Pagination
              page={query.data!.page}
              totalPages={query.data!.totalPages}
              pageSize={pageSize}
              total={query.data!.total}
              onPageChange={setPage}
              onPageSizeChange={(s) => {
                setPageSize(s);
                setPage(1);
              }}
            />
          </>
        )}
      </SectionCard>

      <ConfirmDialog
        open={queueTarget !== null}
        onOpenChange={(open) => !open && setQueueTarget(null)}
        title={`Masukkan @${queueTarget?.username ?? ""} ke antrian klaim?`}
        description="Creator akan berstatus menunggu di Claim Management dan dieksekusi sesuai mode klaim yang berlaku."
        confirmLabel="Ya, masukkan"
        loading={queueClaim.isPending}
        onConfirm={confirmQueue}
      />

      {/* Dialog catat klaim assisted */}
      <Dialog open={assistedTarget !== null} onOpenChange={(open) => !open && setAssistedTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Catat hasil klaim assisted @{assistedTarget?.username}</DialogTitle>
            <DialogDescription>
              Klaim dulu secara manual di dashboard sumber. Setelah itu pilih hasilnya agar sistem mencatat dengan benar.
              Hasil "sudah diklaim" akan ditandai tanpa retry.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="assisted-result">Hasil klaim</Label>
            <Select value={assistedResult} onValueChange={(v) => setAssistedResult(v as typeof assistedResult)}>
              <SelectTrigger id="assisted-result" aria-label="Hasil klaim assisted">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="success">Berhasil diklaim</SelectItem>
                <SelectItem value="already_claimed">Sudah diklaim pihak lain</SelectItem>
                <SelectItem value="failed">Gagal (bisa dicoba lagi)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setAssistedTarget(null)}>
              Batal
            </Button>
            <Button onClick={submitAssisted} disabled={assisted.isPending}>
              <ClipboardList className="size-4" aria-hidden="true" />
              {assisted.isPending ? "Menyimpan..." : "Simpan Hasil"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
