import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  CheckCircle2,
  CircleDot,
  Clock,
  Database,
  Eye,
  HandCoins,
  Play,
  RefreshCw,
  Server,
  Square,
  UserCheck,
  Users,
  XCircle,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { StatCard, PageHeader, SectionCard } from "@/components/Structure";
import { CreatorStatusBadge, ClaimStatusBadge } from "@/components/StatusBadge";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { Button } from "@/components/ui/button";
import { Skeleton, SkeletonCards, SkeletonRows } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableWrap,
} from "@/components/ui/table";
import { useDashboard, useMonitoringAction } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { dayLabel, fmtNumber, fmtDateTime, shortDay, timeAgo } from "@/lib/format";
import { useMe } from "@/lib/queries";
import { useSeo } from "@/lib/seo";

export function DashboardPage() {
  useSeo(
    "Dashboard KlaimCreator — Pantau Creator & Klaim TikTok",
    "Pantau statistik creator, grafik klaim & sinkronisasi, serta status monitoring real-time. Kelola klaim username TikTok dari satu dashboard KlaimCreator."
  );
  const me = useMe();
  const { data, isLoading, isError, error, refetch, isRefetching } = useDashboard(
    me.data?.user?.role === "admin" ? 60 : 60
  );
  const startAction = useMonitoringAction(data?.monitoring.monitoringActive ? "stop" : "start");
  const manualSync = useMonitoringAction("sync");

  function toggleMonitoring() {
    const turningOn = !data?.monitoring.monitoringActive;
    startAction.mutate(undefined, {
      onSuccess: () => {
        toast.success(turningOn ? "Monitoring diaktifkan. Sinkronisasi berjalan tiap 1 menit." : "Monitoring dihentikan.");
      },
      onError: (err) => toast.error(errorMessage(err)),
    });
  }

  function triggerSync() {
    manualSync.mutate(undefined, {
      onSuccess: (res) => {
        toast.success(res.message ?? "Sinkronisasi dijadwalkan.");
        void refetch();
      },
      onError: (err) => toast.error(errorMessage(err)),
    });
  }

  if (isError) {
    return (
      <ErrorState message={errorMessage(error)} onRetry={() => void refetch()} className="mt-8" />
    );
  }

  const stats = data?.stats;
  const monitoring = data?.monitoring;

  return (
    <div className="fade-in">
      <PageHeader
        title="Dashboard Monitoring Klaim & Creator TikTok"
        description="Ringkasan pemantauan creator, aktivitas klaim, dan kesehatan sistem."
        actions={
          <>
            <Button variant="secondary" onClick={triggerSync} disabled={manualSync.isPending || monitoring?.emergencyStop}>
              <RefreshCw className={manualSync.isPending ? "size-4 animate-spin" : "size-4"} aria-hidden="true" />
              Sinkronisasi Sekarang
            </Button>
            {monitoring?.monitoringActive ? (
              <Button variant="secondary" onClick={toggleMonitoring} disabled={startAction.isPending}>
                <Square className="size-4" aria-hidden="true" />
                Stop Monitoring
              </Button>
            ) : (
              <Button onClick={toggleMonitoring} disabled={startAction.isPending || monitoring?.emergencyStop}>
                <Play className="size-4" aria-hidden="true" />
                Start Monitoring
              </Button>
            )}
          </>
        }
      />

      {/* 7 kartu statistik */}
      {isLoading || !stats ? (
        <SkeletonCards />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-7">
          <StatCard label="Total Creator" value={fmtNumber(stats.totalCreators)} icon={<Users />} hint="seluruh creator tersinkron" />
          <StatCard label="Available" value={fmtNumber(stats.availableCreators)} icon={<UserCheck />} tone="accent" hint="siap masuk antrian" />
          <StatCard label="Total Claimed" value={fmtNumber(stats.totalClaimed)} icon={<HandCoins />} tone="info" hint="creator terklaim" />
          <StatCard label="Success" value={fmtNumber(stats.claimsSuccess)} icon={<CheckCircle2 />} tone="accent" hint="klaim berhasil" />
          <StatCard label="Failed" value={fmtNumber(stats.claimsFailed)} icon={<XCircle />} tone="danger" hint="gagal + sudah terklaim" />
          <StatCard label="Pending" value={fmtNumber(stats.claimsPending)} icon={<Clock />} tone="warning" hint="menunggu / diproses" />
          <StatCard label="Last Sync" value={stats.lastSyncAt ? timeAgo(stats.lastSyncAt) : "belum ada"} icon={<Database />} hint={stats.lastSyncAt ? fmtDateTime(stats.lastSyncAt) : "jalankan sinkronisasi"} />
        </div>
      )}

      {/* Status sistem */}
      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        <SectionCard title="Status Koneksi Sumber" description={monitoring?.sourceLabel ?? "Memuat..."}>
          <StatusRow
            icon={<Server />}
            label="Sumber data"
            value={monitoring ? (monitoring.worker.online ? "Terhubung" : "Belum diuji") : "..."}
          />
          <StatusRow
            icon={<Zap />}
            label="Mode klaim"
            value={data?.claimMode === "automatic" ? "Otomatis (integrasi resmi)" : "Assisted Claim Mode"}
          />
          <StatusRow
            icon={<RefreshCw />}
            label="Interval refresh"
            value={data ? `setiap ${data.refreshIntervalSeconds} detik` : "..."}
          />
        </SectionCard>
        <SectionCard title="Status Worker" description="Service pemilik scheduler dan eksekusi klaim">
          <StatusRow
            icon={<Server />}
            label="Worker"
            value={
              monitoring ? (
                <span className={monitoring.worker.online ? "text-accent" : "text-danger"}>
                  {monitoring.worker.online ? (monitoring.worker.running ? "Sibuk bekerja" : "Aktif") : "Offline"}
                </span>
              ) : (
                "..."
              )
            }
          />
          <StatusRow
            icon={<Clock />}
            label="Heartbeat terakhir"
            value={monitoring?.worker.lastHeartbeatAt ? timeAgo(monitoring.worker.lastHeartbeatAt) : "belum ada"}
          />
          <StatusRow
            icon={<Eye />}
            label="Sinkronisasi berjalan"
            value={monitoring?.lease ? "Ya (lock aktif)" : "Tidak"}
          />
        </SectionCard>
        <SectionCard title="Monitoring" description="State tersimpan di database, aman dari restart">
          <StatusRow
            icon={<CircleDot />}
            label="Monitoring"
            value={
              monitoring ? (
                <span className={monitoring.monitoringActive ? "text-accent" : "text-muted"}>
                  {monitoring.monitoringActive ? "Aktif" : "Nonaktif"}
                </span>
              ) : (
                "..."
              )
            }
          />
          <StatusRow
            icon={<XCircle />}
            label="Emergency Stop"
            value={
              monitoring ? (
                <span className={monitoring.emergencyStop ? "text-danger" : "text-muted"}>
                  {monitoring.emergencyStop ? "AKTIF: semua eksekusi berhenti" : "Tidak aktif"}
                </span>
              ) : (
                "..."
              )
            }
          />
          <StatusRow
            icon={<Database />}
            label="Sinkronisasi terakhir"
            value={monitoring?.lastSync ? `${monitoring.lastSync.status} · ${timeAgo(monitoring.lastSync.finished_at ?? monitoring.lastSync.started_at)}` : "belum pernah"}
          />
        </SectionCard>
      </div>

      {/* Grafik */}
      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <SectionCard title="Aktivitas Klaim 14 Hari" description="Jumlah klaim berdasarkan hasil per hari">
          {isLoading || !data ? (
            <Skeleton className="h-52 w-full" />
          ) : (
            <div className="h-52" aria-label="Grafik aktivitas klaim">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.charts.claimsPerDay} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="gSuccess" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#34d399" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#34d399" stopOpacity={0.02} />
                    </linearGradient>
                    <linearGradient id="gFailed" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f87171" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#f87171" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="#27272f" strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="day" tickFormatter={shortDay} tick={{ fill: "#71717a", fontSize: 11 }} axisLine={{ stroke: "#27272f" }} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fill: "#71717a", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: "#17171c", border: "1px solid #27272f", borderRadius: 10, fontSize: 12 }}
                    labelFormatter={(l: string) => dayLabel(l)}
                  />
                  <Area type="monotone" dataKey="success" name="Berhasil" stroke="#34d399" fill="url(#gSuccess)" strokeWidth={2} />
                  <Area type="monotone" dataKey="failed" name="Gagal" stroke="#f87171" fill="url(#gFailed)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </SectionCard>
        <SectionCard title="Sinkronisasi per Hari" description="Jumlah siklus sinkronisasi per hari">
          {isLoading || !data ? (
            <Skeleton className="h-52 w-full" />
          ) : (
            <div className="h-52" aria-label="Grafik sinkronisasi">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.charts.syncPerDay} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid stroke="#27272f" strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="day" tickFormatter={shortDay} tick={{ fill: "#71717a", fontSize: 11 }} axisLine={{ stroke: "#27272f" }} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fill: "#71717a", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    cursor={{ fill: "rgba(255,255,255,0.03)" }}
                    contentStyle={{ background: "#17171c", border: "1px solid #27272f", borderRadius: 10, fontSize: 12 }}
                    labelFormatter={(l: string) => dayLabel(l)}
                  />
                  <Bar dataKey="count" name="Sinkronisasi" fill="#7dd3fc" radius={[4, 4, 0, 0]} maxBarSize={26} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </SectionCard>
      </div>

      {/* Tabel */}
      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <SectionCard
          title="Creator Terbaru"
          description="8 creator terakhir yang terdeteksi"
          actions={
            <Link to="/creators" className="text-xs text-accent hover:underline">
              Lihat semua
            </Link>
          }
        >
          {isLoading ? (
            <SkeletonRows rows={4} />
          ) : (data?.recentCreators.length ?? 0) === 0 ? (
            <EmptyState
              icon={<Users />}
              title="Belum ada creator"
              description="Aktifkan Monitoring atau jalankan sinkronisasi manual untuk menarik data creator dari sumber."
              action={
                <Button size="sm" onClick={triggerSync} disabled={manualSync.isPending}>
                  <RefreshCw className="size-4" aria-hidden="true" />
                  Sinkronisasi Sekarang
                </Button>
              }
            />
          ) : (
            <TableWrap>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Followers</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data!.recentCreators.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <p className="font-medium text-foreground">@{c.username}</p>
                        <p className="text-xs text-faint">{c.nickname ?? c.id.slice(0, 8)}</p>
                      </TableCell>
                      <TableCell>
                        <CreatorStatusBadge status={c.status} />
                      </TableCell>
                      <TableCell className="text-right font-num">{fmtNumber(c.followerCount)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableWrap>
          )}
        </SectionCard>

        <SectionCard
          title="Claim History Terbaru"
          description="8 klaim terakhir beserta statusnya"
          actions={
            <Link to="/claims/history" className="text-xs text-accent hover:underline">
              Lihat semua
            </Link>
          }
        >
          {isLoading ? (
            <SkeletonRows rows={4} />
          ) : (data?.recentClaims.length ?? 0) === 0 ? (
            <EmptyState
              icon={<HandCoins />}
              title="Belum ada klaim"
              description="Creator yang tersedia akan masuk antrian klaim setelah sinkronisasi berjalan."
            />
          ) : (
            <TableWrap>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Waktu</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data!.recentClaims.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium text-foreground">@{c.username}</TableCell>
                      <TableCell>
                        <ClaimStatusBadge status={c.status} />
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted font-num">
                        {timeAgo(c.claimedAt ?? c.createdAt)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableWrap>
          )}
        </SectionCard>
      </div>
    </div>
  );
}

function StatusRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-line py-2.5 last:border-0">
      <span className="flex items-center gap-2 text-sm text-muted [&_svg]:size-4 [&_svg]:text-faint">
        {icon}
        {label}
      </span>
      <span className="text-sm font-medium text-foreground">{value}</span>
    </div>
  );
}
