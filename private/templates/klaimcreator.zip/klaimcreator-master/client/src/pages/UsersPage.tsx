import { useState } from "react";
import { KeyRound, UserPlus, Users } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, SectionCard } from "@/components/Structure";
import { Badge } from "@/components/ui/badge";
import { EmptyState, ErrorState } from "@/components/StateViews";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SkeletonRows } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableWrap,
} from "@/components/ui/table";
import { useCreateUser, useMe, useResetPassword, useUpdateUser, useUsers } from "@/lib/queries";
import { errorMessage } from "@/lib/api";
import { useSeo } from "@/lib/seo";
import { fmtDate } from "@/lib/format";
import type { UserItem } from "@/lib/types";

/** User Management (Admin): buat/edit/nonaktifkan akun, atur peran, reset password. */
export function UsersPage() {
  useSeo(
    "User Management — Kelola Akun & Peran | KlaimCreator",
    "Buat, edit, atau nonaktifkan akun tim, atur peran akses, dan reset password dari satu halaman admin. Kelola pengguna KlaimCreator dengan rapi."
  );
  const me = useMe();
  const query = useUsers();
  const create = useCreateUser();
  const update = useUpdateUser();
  const resetPassword = useResetPassword();

  const [createOpen, setCreateOpen] = useState(false);
  const [newUser, setNewUser] = useState({ name: "", email: "", role: "operator", password: "" });
  const [newUserErrors, setNewUserErrors] = useState<Record<string, string>>({});
  const [resetTarget, setResetTarget] = useState<UserItem | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmDeactivate, setConfirmDeactivate] = useState<UserItem | null>(null);

  const items = query.data?.items ?? [];

  function submitCreate() {
    const errors: Record<string, string> = {};
    if (newUser.name.trim().length < 2) errors.name = "Nama minimal 2 karakter";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newUser.email.trim())) errors.email = "Format email tidak valid";
    if (newUser.password.length < 8) errors.password = "Password minimal 8 karakter";
    else if (!/[A-Za-z]/.test(newUser.password) || !/[0-9]/.test(newUser.password)) errors.password = "Password harus mengandung huruf dan angka";
    setNewUserErrors(errors);
    if (Object.keys(errors).length > 0) return;
    create.mutate(newUser, {
      onSuccess: () => {
        toast.success(`Akun ${newUser.email} dibuat. Pengguna wajib mengganti password saat login pertama.`);
        setCreateOpen(false);
        setNewUser({ name: "", email: "", role: "operator", password: "" });
      },
      onError: (err) => toast.error(errorMessage(err)),
    });
  }

  function submitReset() {
    if (!resetTarget) return;
    if (newPassword.length < 8 || !/[A-Za-z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
      toast.error("Password baru minimal 8 karakter, mengandung huruf dan angka.");
      return;
    }
    resetPassword.mutate(
      { id: resetTarget.id, newPassword },
      {
        onSuccess: () => {
          toast.success(`Password ${resetTarget.email} direset. Sesi lama dicabut dan wajib ganti password saat login berikutnya.`);
          setResetTarget(null);
          setNewPassword("");
        },
        onError: (err) => toast.error(errorMessage(err)),
      }
    );
  }

  function toggleActive(user: UserItem) {
    if (user.is_active === 1) {
      setConfirmDeactivate(user);
      return;
    }
    update.mutate(
      { id: user.id, isActive: true },
      {
        onSuccess: () => toast.success(`Akun ${user.email} diaktifkan.`),
        onError: (err) => toast.error(errorMessage(err)),
      }
    );
  }

  function confirmDeactivateUser() {
    if (!confirmDeactivate) return;
    update.mutate(
      { id: confirmDeactivate.id, isActive: false },
      {
        onSuccess: () => {
          toast.success(`Akun ${confirmDeactivate.email} dinonaktifkan.`);
          setConfirmDeactivate(null);
        },
        onError: (err) => {
          toast.error(errorMessage(err));
          setConfirmDeactivate(null);
        },
      }
    );
  }

  function changeRole(user: UserItem, role: string) {
    update.mutate(
      { id: user.id, role },
      {
        onSuccess: () => toast.success(`Peran ${user.email} diubah menjadi ${role === "admin" ? "Admin" : "Operator"}.`),
        onError: (err) => toast.error(errorMessage(err)),
      }
    );
  }

  return (
    <div className="fade-in">
      <PageHeader
        title="User Management — Kelola Akun & Peran Tim"
        description="Kelola akun tim: Admin mengelola pengaturan, audit, Emergency Stop, dan verifikasi klaim. Operator untuk monitoring, pencatatan klaim assisted, dan export."
        actions={
          <Button onClick={() => setCreateOpen(true)}>
            <UserPlus className="size-4" aria-hidden="true" />
            Tambah Akun
          </Button>
        }
      />

      <SectionCard title="Daftar Akun" description={`${items.length} akun terdaftar`}>
        {query.isError ? (
          <ErrorState message={errorMessage(query.error)} onRetry={() => void query.refetch()} />
        ) : query.isLoading ? (
          <SkeletonRows rows={4} />
        ) : items.length === 0 ? (
          <EmptyState icon={<Users />} title="Belum ada akun" description="Tambahkan akun untuk anggota tim Anda." />
        ) : (
          <TableWrap>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pengguna</TableHead>
                  <TableHead>Peran</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden md:table-cell">Dibuat</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((u) => {
                  const isSelf = u.id === me.data?.user?.id;
                  return (
                    <TableRow key={u.id}>
                      <TableCell>
                        <p className="font-medium text-foreground">{u.name}</p>
                        <p className="text-xs text-faint">{u.email}</p>
                      </TableCell>
                      <TableCell>
                        {isSelf ? (
                          <Badge className="border-line bg-surface-2 text-muted">{u.role === "admin" ? "Admin" : "Operator"}</Badge>
                        ) : (
                          <Select value={u.role} onValueChange={(v) => changeRole(u, v)}>
                            <SelectTrigger className="h-8 w-32 text-xs" aria-label={`Peran ${u.email}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="admin">Admin</SelectItem>
                              <SelectItem value="operator">Operator</SelectItem>
                            </SelectContent>
                          </Select>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge className={u.is_active === 1 ? "border-accent/30 bg-accent-soft text-accent" : "border-danger/30 bg-danger-soft text-danger"}>
                          {u.is_active === 1 ? "Aktif" : "Nonaktif"}
                        </Badge>
                        {u.must_change_password === 1 ? (
                          <Badge className="ml-1 border-warning/30 bg-warning-soft text-warning">Password sementara</Badge>
                        ) : null}
                      </TableCell>
                      <TableCell className="hidden text-xs text-muted md:table-cell">{fmtDate(u.created_at)}</TableCell>
                      <TableCell>
                        <div className="flex justify-end gap-1.5">
                          <Button variant="ghost" size="sm" onClick={() => setResetTarget(u)} aria-label={`Reset password ${u.email}`}>
                            <KeyRound className="size-3.5" aria-hidden="true" />
                            <span className="hidden sm:inline">Reset Password</span>
                          </Button>
                          {isSelf ? null : (
                            <Button
                              variant={u.is_active === 1 ? "destructive" : "secondary"}
                              size="sm"
                              onClick={() => toggleActive(u)}
                            >
                              {u.is_active === 1 ? "Nonaktifkan" : "Aktifkan"}
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableWrap>
        )}
      </SectionCard>

      {/* Dialog buat akun */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tambah akun baru</DialogTitle>
            <DialogDescription>Pengguna akan diminta mengganti password saat login pertama.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="new-name">Nama</Label>
              <Input id="new-name" value={newUser.name} onChange={(e) => setNewUser({ ...newUser, name: e.target.value })} aria-invalid={Boolean(newUserErrors.name)} />
              {newUserErrors.name ? <p className="text-xs text-danger">{newUserErrors.name}</p> : null}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="new-email">Email</Label>
              <Input id="new-email" type="email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} aria-invalid={Boolean(newUserErrors.email)} />
              {newUserErrors.email ? <p className="text-xs text-danger">{newUserErrors.email}</p> : null}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="new-role">Peran</Label>
              <Select value={newUser.role} onValueChange={(v) => setNewUser({ ...newUser, role: v })}>
                <SelectTrigger id="new-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="operator">Operator</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="new-password">Password sementara</Label>
              <Input
                id="new-password"
                type="text"
                value={newUser.password}
                onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                aria-invalid={Boolean(newUserErrors.password)}
              />
              {newUserErrors.password ? <p className="text-xs text-danger">{newUserErrors.password}</p> : null}
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setCreateOpen(false)}>
              Batal
            </Button>
            <Button onClick={submitCreate} disabled={create.isPending}>
              {create.isPending ? "Membuat..." : "Buat Akun"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog reset password */}
      <Dialog open={resetTarget !== null} onOpenChange={(open) => !open && setResetTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Reset password {resetTarget?.email}</DialogTitle>
            <DialogDescription>Sesi aktif pengguna dicabut, dan password ini wajib diganti saat login berikutnya.</DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="reset-password">Password baru</Label>
            <Input id="reset-password" type="text" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            <p className="text-xs text-faint">Minimal 8 karakter, mengandung huruf dan angka.</p>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setResetTarget(null)}>
              Batal
            </Button>
            <Button onClick={submitReset} disabled={resetPassword.isPending}>
              {resetPassword.isPending ? "Menyimpan..." : "Reset Password"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={confirmDeactivate !== null}
        onOpenChange={(open) => !open && setConfirmDeactivate(null)}
        title={`Nonaktifkan akun ${confirmDeactivate?.email ?? ""}?`}
        description="Pengguna tidak dapat login dan seluruh sesinya dicabut. Riwayat auditnya tetap tersimpan."
        confirmLabel="Nonaktifkan"
        danger
        loading={update.isPending}
        onConfirm={confirmDeactivateUser}
      />
    </div>
  );
}
