export type Role = "admin" | "operator";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: Role;
  mustChangePassword: boolean;
}

export type CreatorStatus = "Available" | "Claimed" | "Pending" | "Failed" | "Unavailable";
export type ClaimStatus = "Pending" | "Processing" | "Success" | "Failed" | "Already Claimed" | "Verification Required";
export type ClaimMode = "automatic" | "assisted";

export interface Creator {
  id: string;
  source: string;
  externalId: string;
  username: string;
  nickname: string | null;
  followerCount: number | null;
  status: CreatorStatus;
  firstSeenAt: string;
  lastUpdatedAt: string;
}

export interface Paginated<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface Claim {
  id: string;
  creatorId: string;
  username: string;
  status: ClaimStatus;
  mode: ClaimMode;
  attemptCount: number;
  nextRetryAt: string | null;
  lastError: string | null;
  claimedAt: string | null;
  verifiedAt: string | null;
  createdAt: string;
  updatedAt: string;
  nickname?: string | null;
  source?: string;
  externalId?: string;
}

export interface StatusHistoryItem {
  id: string;
  oldStatus: string | null;
  newStatus: string;
  reason: string | null;
  changedAt: string;
}

export interface DashboardData {
  stats: {
    totalCreators: number;
    availableCreators: number;
    totalClaimed: number;
    claimsSuccess: number;
    claimsFailed: number;
    claimsPending: number;
    lastSyncAt: string | null;
  };
  charts: {
    claimsPerDay: Array<{ day: string; success: number; failed: number; total: number }>;
    syncPerDay: Array<{ day: string; count: number }>;
  };
  recentCreators: Array<{ id: string; username: string; nickname: string | null; status: CreatorStatus; followerCount: number | null; firstSeenAt: string }>;
  recentClaims: Array<{ id: string; username: string; status: ClaimStatus; mode: ClaimMode; claimedAt: string | null; createdAt: string; lastError: string | null }>;
  monitoring: MonitoringStatus;
  claimMode: ClaimMode;
  refreshIntervalSeconds: number;
}

export interface MonitoringStatus {
  monitoringActive: boolean;
  emergencyStop: boolean;
  claimMode: ClaimMode;
  automaticPossible: boolean;
  sourceAdapter: string;
  sourceLabel: string;
  worker: { online: boolean; lastHeartbeatAt: string | null; running: boolean; instance: string | null };
  lastSync: { started_at: string; finished_at: string | null; status: string } | null;
  lease: { owner: string; expiresAt: string; renewedAt: string } | null;
  queuedJobs: number;
  refreshIntervalSeconds: number;
}

export interface AutomationSettings {
  refreshIntervalSeconds: number;
  maxRetries: number;
  retryBaseDelaySeconds: number;
  claimSchedule: { startHour: number; endHour: number; days: number[] };
  notifications: { inApp: boolean; telegram: boolean; email: boolean };
  export: { filenamePrefix: string; usernamesOnlyDefault: boolean };
}

export interface AutomationResponse {
  automation: AutomationSettings;
  claimMode: ClaimMode;
  automaticPossible: boolean;
  monitoringActive: boolean;
  emergencyStop: boolean;
}

export interface IntegrationResponse {
  adapter: string;
  official: { enabled: boolean; baseUrlEnv: string; apiKeyEnv: string; claimPath: string };
  mock: { pages: number; itemsPerPage: number; newItemsPerCycle: number; faultMode: "none" | "disconnected" };
  officialConfigured: boolean;
  sourceLabel: string;
  lastCheck: { ok: boolean; message: string; checkedAt: string } | null;
}

export interface SystemEvent {
  id: string;
  eventType: string;
  description: string;
  creatorId: string | null;
  creatorUsername: string | null;
  status: "Info" | "Success" | "Warning" | "Error";
  createdAt: string;
}

export interface SyncLog {
  id: string;
  trigger: string;
  status: string;
  startedAt: string;
  finishedAt: string | null;
  pagesFetched: number;
  itemsFetched: number;
  itemsCreated: number;
  itemsUpdated: number;
  availableDetected: number;
  error: string | null;
}

export interface AuditItem {
  id: string;
  userId: string | null;
  userEmail: string | null;
  action: string;
  entity: string | null;
  entityId: string | null;
  details: Record<string, unknown> | null;
  ip: string | null;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  eventType: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface UserItem {
  id: string;
  email: string;
  name: string;
  role: Role;
  is_active: number;
  must_change_password: number;
  created_at: string;
  updated_at: string;
}

export interface ExportRow {
  no: number;
  creatorId: string;
  username: string;
  claimStatus: string;
  claimDate: string | null;
}

export interface ExportPreview {
  rows: ExportRow[];
  total: number;
  usernamesOnly: boolean;
  statuses: string[];
}

export interface ClaimAttempt {
  id: string;
  attemptNumber: number;
  result: string;
  message: string | null;
  executedBy: string | null;
  startedAt: string;
  finishedAt: string | null;
}
