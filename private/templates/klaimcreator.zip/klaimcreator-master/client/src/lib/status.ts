import type { ClaimStatus, CreatorStatus } from "./types";

export interface StatusMeta {
  label: string;
  className: string;
}

/**
 * Badge status konsisten untuk operator (bahasa Indonesia natural).
 * Warna semantik: hijau sukses, amber perhatian, merah gagal, biru info, abu netral.
 */
export const CREATOR_STATUS: Record<CreatorStatus, StatusMeta> = {
  Available: { label: "Tersedia", className: "bg-accent-soft text-accent border-accent/30" },
  Claimed: { label: "Terklaim", className: "bg-info-soft text-info border-info/30" },
  Pending: { label: "Diproses", className: "bg-warning-soft text-warning border-warning/30" },
  Failed: { label: "Gagal", className: "bg-danger-soft text-danger border-danger/30" },
  Unavailable: { label: "Tidak Tersedia", className: "bg-surface-2 text-muted border-line" },
};

export const CLAIM_STATUS: Record<ClaimStatus, StatusMeta> = {
  Pending: { label: "Menunggu", className: "bg-warning-soft text-warning border-warning/30" },
  Processing: { label: "Sedang Diproses", className: "bg-warning-soft text-warning border-warning/30" },
  Success: { label: "Berhasil", className: "bg-accent-soft text-accent border-accent/30" },
  Failed: { label: "Gagal", className: "bg-danger-soft text-danger border-danger/30" },
  "Already Claimed": { label: "Sudah Terklaim", className: "bg-info-soft text-info border-info/30" },
  "Verification Required": { label: "Perlu Verifikasi", className: "bg-danger-soft text-danger border-danger/30" },
};

export const EVENT_STATUS: Record<string, StatusMeta> = {
  Info: { label: "Info", className: "bg-surface-2 text-muted border-line" },
  Success: { label: "Sukses", className: "bg-accent-soft text-accent border-accent/30" },
  Warning: { label: "Peringatan", className: "bg-warning-soft text-warning border-warning/30" },
  Error: { label: "Error", className: "bg-danger-soft text-danger border-danger/30" },
};

export const EVENT_TYPE_LABELS: Record<string, string> = {
  creator_available: "Creator Tersedia",
  claim_success: "Klaim Berhasil",
  claim_failed: "Klaim Gagal",
  session_expired: "Sesi Berakhir",
  source_disconnected: "Sumber Terputus",
  sync_failed: "Sinkronisasi Gagal",
  worker_stopped: "Worker Berhenti",
  emergency_stop: "Emergency Stop",
  system: "Sistem",
};

export function creatorStatusMeta(status: string): StatusMeta {
  return CREATOR_STATUS[status as CreatorStatus] ?? { label: status, className: "bg-surface-2 text-muted border-line" };
}

export function claimStatusMeta(status: string): StatusMeta {
  return CLAIM_STATUS[status as ClaimStatus] ?? { label: status, className: "bg-surface-2 text-muted border-line" };
}
