import { useMutation, useQuery, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { api, downloadUrl, errorMessage } from "./api";
import type {
  AppNotification,
  AuditItem,
  AuthUser,
  AutomationResponse,
  Claim,
  ClaimAttempt,
  Creator,
  DashboardData,
  ExportPreview,
  IntegrationResponse,
  MonitoringStatus,
  Paginated,
  SyncLog,
  SystemEvent,
  UserItem,
} from "./types";

export const qk = {
  me: ["me"] as const,
  dashboard: (interval: number) => ["dashboard", interval] as const,
  monitoring: ["monitoring"] as const,
  creators: (params: Record<string, unknown>) => ["creators", params] as const,
  available: (params: Record<string, unknown>) => ["available", params] as const,
  history: (id: string) => ["creator-history", id] as const,
  claims: (params: Record<string, unknown>) => ["claims", params] as const,
  attempts: (id: string) => ["claim-attempts", id] as const,
  exportPreview: (params: Record<string, unknown>) => ["export-preview", params] as const,
  automation: ["automation"] as const,
  integration: ["integration"] as const,
  events: (params: Record<string, unknown>) => ["events", params] as const,
  syncLogs: ["sync-logs"] as const,
  audit: (params: Record<string, unknown>) => ["audit", params] as const,
  notifications: ["notifications"] as const,
  users: ["users"] as const,
};

export function useMe() {
  return useQuery({
    queryKey: qk.me,
    queryFn: () => api.get<{ user: AuthUser }>("/api/auth/me"),
    retry: false,
    staleTime: 60_000,
  });
}

export function useLogin() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { email: string; password: string }) => api.post<{ user: AuthUser }>("/api/auth/login", input),
    onSuccess: (data) => {
      qc.setQueryData(qk.me, { user: data.user });
    },
  });
}

export function useLogout() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api.post<{ ok: boolean }>("/api/auth/logout"),
    onSuccess: () => {
      qc.clear();
    },
  });
}

export function useChangePassword() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { currentPassword: string; newPassword: string }) =>
      api.post<{ user: AuthUser }>("/api/auth/change-password", input),
    onSuccess: () => qc.clear(),
  });
}

export function useDashboard(refreshIntervalSeconds: number) {
  return useQuery({
    queryKey: qk.dashboard(refreshIntervalSeconds),
    queryFn: () => api.get<DashboardData>("/api/dashboard"),
    refetchInterval: Math.max(15, refreshIntervalSeconds) * 1000,
    placeholderData: keepPreviousData,
  });
}

export function useMonitoringStatus(refreshMs = 30_000) {
  return useQuery({
    queryKey: qk.monitoring,
    queryFn: () => api.get<MonitoringStatus>("/api/monitoring/status"),
    refetchInterval: refreshMs,
  });
}

export function useMonitoringAction(action: "start" | "stop" | "sync" | "emergency-stop" | "emergency-release") {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api.post<{ ok: boolean; flipped?: number; message?: string; jobId?: string }>(`/api/monitoring/${action}`),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: qk.monitoring });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useCreators(params: { search?: string; status?: string; page: number; pageSize: number; sort?: string }) {
  return useQuery({
    queryKey: qk.creators(params),
    queryFn: () => api.get<Paginated<Creator>>("/api/creators", params),
    placeholderData: keepPreviousData,
  });
}

export function useAvailableCreators(page: number, pageSize: number) {
  return useQuery({
    queryKey: qk.available({ page, pageSize }),
    queryFn: () => api.get<Paginated<Creator>>("/api/creators/available", { page, pageSize }),
    placeholderData: keepPreviousData,
    refetchInterval: 60_000,
  });
}

export function useCreatorHistory(creatorId: string | null) {
  return useQuery({
    queryKey: qk.history(creatorId ?? "none"),
    queryFn: () =>
      api.get<{ creator: Creator; items: Array<{ id: string; oldStatus: string | null; newStatus: string; reason: string | null; changedAt: string }> }>(
        `/api/creators/${creatorId}/history`
      ),
    enabled: Boolean(creatorId),
  });
}

export function useClaims(params: { status?: string; search?: string; page: number; pageSize: number }) {
  return useQuery({
    queryKey: qk.claims(params),
    queryFn: () => api.get<Paginated<Claim>>("/api/claims", params),
    placeholderData: keepPreviousData,
  });
}

export function useClaimAttempts(claimId: string | null) {
  return useQuery({
    queryKey: qk.attempts(claimId ?? "none"),
    queryFn: () => api.get<{ items: ClaimAttempt[] }>(`/api/claims/${claimId}/attempts`),
    enabled: Boolean(claimId),
  });
}

export function useQueueClaim() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (creatorId: string) => api.post<{ claim: Claim }>("/api/claims", { creatorId }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["claims"] });
      void qc.invalidateQueries({ queryKey: ["available"] });
      void qc.invalidateQueries({ queryKey: ["creators"] });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useAssistedResult() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { claimId: string; result: "success" | "already_claimed" | "failed" }) =>
      api.post<{ status: string }>(`/api/claims/${input.claimId}/assisted-result`, { result: input.result }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["claims"] });
      void qc.invalidateQueries({ queryKey: ["creators"] });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useVerifyClaim() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { claimId: string; result: "success" | "already_claimed" | "failed" }) =>
      api.post<{ status: string }>(`/api/claims/${input.claimId}/verify`, { result: input.result }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["claims"] });
      void qc.invalidateQueries({ queryKey: ["creators"] });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useRetryClaim() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (claimId: string) => api.post<{ claim: Claim }>(`/api/claims/${claimId}/retry`),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["claims"] });
    },
  });
}

export function useExportPreview(params: { status?: string; from?: string; to?: string; usernamesOnly?: boolean }) {
  return useQuery({
    queryKey: qk.exportPreview(params),
    queryFn: () => api.get<ExportPreview>("/api/export/preview", { ...params, usernamesOnly: params.usernamesOnly ? "true" : undefined }),
    placeholderData: keepPreviousData,
  });
}

export function useAutomation() {
  return useQuery({ queryKey: qk.automation, queryFn: () => api.get<AutomationResponse>("/api/settings/automation") });
}

export function useSaveAutomation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.put<AutomationResponse>("/api/settings/automation", body),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: qk.automation });
      void qc.invalidateQueries({ queryKey: qk.monitoring });
    },
  });
}

export function useIntegration() {
  return useQuery({ queryKey: qk.integration, queryFn: () => api.get<IntegrationResponse>("/api/settings/integration") });
}

export function useSaveIntegration() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.put<IntegrationResponse>("/api/settings/integration", body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: qk.integration }),
  });
}

export function useTestConnection() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api.post<{ ok: boolean; message: string; checkedAt: string; label: string }>("/api/settings/integration/test"),
    onSuccess: () => void qc.invalidateQueries({ queryKey: qk.integration }),
  });
}

export function useEvents(params: { type?: string; status?: string; creatorId?: string; page: number; pageSize: number }) {
  return useQuery({
    queryKey: qk.events(params),
    queryFn: () => api.get<Paginated<SystemEvent>>("/api/logs/events", params),
    placeholderData: keepPreviousData,
  });
}

export function useSyncLogs(limit = 50) {
  return useQuery({
    queryKey: qk.syncLogs,
    queryFn: () => api.get<{ items: SyncLog[] }>("/api/logs/sync", { limit }),
  });
}

export function useAudit(params: { action?: string; page: number; pageSize: number }) {
  return useQuery({
    queryKey: qk.audit(params),
    queryFn: () => api.get<Paginated<AuditItem>>("/api/logs/audit", params),
    placeholderData: keepPreviousData,
  });
}

export function useNotifications(refreshMs = 30_000) {
  return useQuery({
    queryKey: qk.notifications,
    queryFn: () => api.get<{ items: AppNotification[]; unread: number }>("/api/notifications", { limit: 30 }),
    refetchInterval: refreshMs,
  });
}

export function useMarkNotificationsRead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { ids?: string[]; all?: boolean }) => api.post<{ ok: boolean }>("/api/notifications/mark-read", input),
    onSuccess: () => void qc.invalidateQueries({ queryKey: qk.notifications }),
  });
}

export function useUsers() {
  return useQuery({ queryKey: qk.users, queryFn: () => api.get<{ items: UserItem[] }>("/api/users") });
}

export function useCreateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { email: string; name: string; role: string; password: string }) =>
      api.post<{ user: UserItem }>("/api/users", body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: qk.users }),
  });
}

export function useUpdateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { id: string; name?: string; role?: string; isActive?: boolean }) =>
      api.put<{ user: UserItem }>(`/api/users/${input.id}`, input),
    onSuccess: () => void qc.invalidateQueries({ queryKey: qk.users }),
  });
}

export function useResetPassword() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { id: string; newPassword: string }) => api.post<{ ok: boolean }>(`/api/users/${input.id}/reset-password`, input),
    onSuccess: () => void qc.invalidateQueries({ queryKey: qk.users }),
  });
}

export { downloadUrl, errorMessage };
