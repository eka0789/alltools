/**
 * Layer API frontend.
 * - Semua request diberi timeout.
 * - Retry otomatis HANYA untuk GET (idempotent); mutasi tidak pernah di-retry.
 * - Header X-Requested-With disertakan selalu (proteksi CSRF).
 */

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public fields?: Record<string, string>
  ) {
    super(message);
    this.name = "ApiError";
  }
}

const TIMEOUT_MS = 15_000;
const RETRY_DELAYS_MS = [400, 900];

interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  query?: Record<string, string | number | boolean | undefined | null>;
}

function buildUrl(path: string, query?: RequestOptions["query"]): string {
  if (!query) return path;
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined && value !== null && value !== "") params.set(key, String(value));
  }
  const qs = params.toString();
  return qs ? `${path}?${qs}` : path;
}

async function once<T>(path: string, opts: RequestOptions): Promise<T> {
  const method = opts.method ?? "GET";
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  let res: Response;
  try {
    res = await fetch(buildUrl(path, opts.query), {
      method,
      credentials: "same-origin",
      signal: controller.signal,
      headers: {
        "X-Requested-With": "XMLHttpRequest",
        ...(opts.body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
  } catch (err) {
    if ((err as Error).name === "AbortError") {
      throw new ApiError(0, "TIMEOUT", "Server tidak merespons dalam batas waktu. Periksa koneksi Anda.");
    }
    throw new ApiError(0, "NETWORK", "Tidak dapat menghubungi server. Periksa koneksi jaringan.");
  } finally {
    clearTimeout(timer);
  }

  let payload: unknown = null;
  const text = await res.text();
  if (text.length > 0) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = text; // mis. file CSV saat download via fetch
    }
  }
  if (!res.ok) {
    const err = (payload as { error?: { code?: string; message?: string; fields?: Record<string, string> } } | null)?.error;
    throw new ApiError(
      res.status,
      err?.code ?? `HTTP_${res.status}`,
      err?.message ?? `Permintaan gagal (status ${res.status}).`,
      err?.fields
    );
  }
  return payload as T;
}

async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const isGet = (opts.method ?? "GET") === "GET";
  let lastError: unknown;
  const maxAttempts = isGet ? 1 + RETRY_DELAYS_MS.length : 1;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      return await once<T>(path, opts);
    } catch (err) {
      lastError = err;
      const status = err instanceof ApiError ? err.status : 0;
      // Sesi berakhir (401): pulihkan via refresh token (single-flight) lalu ulangi sekali.
      // Aman juga untuk mutasi karena 401 berarti request asli tidak pernah dieksekusi server.
      if (status === 401 && !path.startsWith("/api/auth/")) {
        const restored = await refreshSession();
        if (restored) {
          return once<T>(path, opts);
        }
        throw err;
      }
      // Retry otomatis HANYA untuk GET (idempotent) dengan error jaringan/timeout/5xx.
      if (isGet && (status === 0 || status >= 500) && attempt < maxAttempts - 1) {
        await new Promise((r) => setTimeout(r, RETRY_DELAYS_MS[attempt]));
        continue;
      }
      throw err;
    }
  }
  throw lastError;
}

let refreshPromise: Promise<boolean> | null = null;

/** Single-flight refresh: banyak request 401 bersamaan hanya memicu satu POST /api/auth/refresh. */
export function refreshSession(): Promise<boolean> {
  if (!refreshPromise) {
    refreshPromise = once<{ user?: unknown }>("/api/auth/refresh", { method: "POST" })
      .then(() => true)
      .catch(() => false)
      .finally(() => {
        refreshPromise = null;
      });
  }
  return refreshPromise;
}

export const api = {
  get: <T>(path: string, query?: RequestOptions["query"]) => request<T>(path, { method: "GET", query }),
  post: <T>(path: string, body?: unknown) => request<T>(path, { method: "POST", body }),
  put: <T>(path: string, body?: unknown) => request<T>(path, { method: "PUT", body }),
};

/** Unduh file biner/teks (export) sebagai blob. */
export async function downloadFile(path: string, query?: RequestOptions["query"]): Promise<Blob> {
  const url = buildUrl(path, query);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { credentials: "same-origin", signal: controller.signal, headers: { "X-Requested-With": "XMLHttpRequest" } });
    if (!res.ok) {
      const err = (await res.json().catch(() => null)) as { error?: { message?: string } } | null;
      throw new ApiError(res.status, "DOWNLOAD_FAILED", err?.error?.message ?? "Gagal mengunduh file.");
    }
    return await res.blob();
  } finally {
    clearTimeout(timer);
  }
}

/** URL unduhan (dipakai <a download> atau window.open). */
export function downloadUrl(path: string, query?: RequestOptions["query"]): string {
  return buildUrl(path, query);
}

export function errorMessage(err: unknown, fallback = "Terjadi kesalahan. Coba lagi."): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof Error) return err.message;
  return fallback;
}
