import { useEffect } from "react";

/**
 * Terapkan SEO per halaman pada SPA: title tag + meta description.
 * H1 diset langsung di markup masing-masing halaman (satu H1 per halaman).
 * Nilai per halaman bersumber dari spesifikasi meta/SEO KlaimCreator.
 */
export function useSeo(title: string, description: string): void {
  useEffect(() => {
    document.title = title;
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "description");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", description);
  }, [title, description]);
}
