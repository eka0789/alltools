import { apiGet, mockMe, renderWithProviders } from "./mocks";
import { describe, expect, it } from "vitest";
import userEvent from "@testing-library/user-event";
import { screen, waitFor } from "@testing-library/react";
import { ExportPage } from "@/pages/ExportPage";

const PREVIEW = {
  rows: [
    { no: 1, creatorId: "mock-00001", username: "creator_0001", claimStatus: "Success", claimDate: "2026-01-05T02:00:00.000Z" },
    { no: 2, creatorId: "mock-00007", username: "creator_0007", claimStatus: "Success", claimDate: "2026-01-06T02:00:00.000Z" },
  ],
  total: 2,
  usernamesOnly: false,
  statuses: ["Success"],
};

function mockExportApi(): void {
  apiGet.mockImplementation((path: string) => {
    if (String(path).startsWith("/api/export/preview")) return Promise.resolve(PREVIEW);
    if (path === "/api/auth/me") {
      return Promise.resolve({ user: { id: "u1", email: "a@b.c", name: "Op", role: "operator", mustChangePassword: false } });
    }
    if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
    if (path === "/api/monitoring/status") {
      return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: true } });
    }
    return Promise.resolve({});
  });
}

describe("halaman export", () => {
  it("menampilkan preview kolom No, Creator ID, Username, Claim Status, Claim Date", async () => {
    mockExportApi();
    renderWithProviders(<ExportPage />);
    expect(await screen.findByText("Claim Status")).toBeInTheDocument();
    expect(screen.getByText("Creator ID")).toBeInTheDocument();
    expect(screen.getByText("Claim Date")).toBeInTheDocument();
    expect(screen.getByText("@creator_0001")).toBeInTheDocument();
    expect(screen.getByText("@creator_0007")).toBeInTheDocument();
    expect(screen.getAllByText("Berhasil").length).toBeGreaterThan(0);
  });

  it("copy satu username memanggil clipboard", async () => {
    mockExportApi();
    const user = userEvent.setup();
    renderWithProviders(<ExportPage />);
    await user.click(await screen.findByRole("button", { name: /copy username creator_0001/i }));
    await waitFor(async () => {
      await expect(navigator.clipboard.readText()).resolves.toBe("creator_0001");
    });
  });

  it("bulk copy menyalin semua username terlihat", async () => {
    mockExportApi();
    const user = userEvent.setup();
    renderWithProviders(<ExportPage />);
    await user.click(await screen.findByRole("button", { name: /bulk copy/i }));
    await waitFor(async () => {
      await expect(navigator.clipboard.readText()).resolves.toBe("creator_0001\ncreator_0007");
    });
  });

  it("menampilkan empty state saat tidak ada data untuk filter", async () => {
    mockMe("operator");
    apiGet.mockImplementation((path: string) => {
      if (String(path).startsWith("/api/export/preview")) return Promise.resolve({ rows: [], total: 0, usernamesOnly: false, statuses: ["Success"] });
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: true } });
      return Promise.resolve({});
    });
    renderWithProviders(<ExportPage />);
    expect(await screen.findByText(/Tidak ada data untuk filter ini/i)).toBeInTheDocument();
  });
});
