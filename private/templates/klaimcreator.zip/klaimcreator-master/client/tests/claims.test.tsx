import { apiGet, apiPost, mockMe, renderWithProviders } from "./mocks";
import { describe, expect, it } from "vitest";
import userEvent from "@testing-library/user-event";
import { screen, waitFor } from "@testing-library/react";
import { ClaimsPage } from "@/pages/ClaimsPage";

const CLAIMS_PAGE = {
  items: [
    { id: "a1", creatorId: "cr1", username: "creator_0001", status: "Already Claimed", mode: "automatic", attemptCount: 1, nextRetryAt: null, lastError: "sudah diklaim pihak lain", claimedAt: null, verifiedAt: null, createdAt: "2026-01-05T01:00:00.000Z", updatedAt: "2026-01-05T01:05:00.000Z" },
    { id: "a2", creatorId: "cr2", username: "creator_0002", status: "Verification Required", mode: "automatic", attemptCount: 1, nextRetryAt: null, lastError: "hasil tidak pasti", claimedAt: null, verifiedAt: null, createdAt: "2026-01-05T01:10:00.000Z", updatedAt: "2026-01-05T01:15:00.000Z" },
    { id: "a3", creatorId: "cr3", username: "creator_0003", status: "Failed", mode: "assisted", attemptCount: 2, nextRetryAt: null, lastError: "gateway sibuk", claimedAt: null, verifiedAt: null, createdAt: "2026-01-05T01:20:00.000Z", updatedAt: "2026-01-05T01:25:00.000Z" },
  ],
  page: 1,
  pageSize: 20,
  total: 3,
  totalPages: 1,
};

function mockClaimsApi(role: "admin" | "operator") {
  apiGet.mockImplementation((path: string) => {
    if (path === "/api/auth/me") {
      return Promise.resolve({
        user: { id: "u-admin", email: "admin@klaimcreator.local", name: "Admin Uji", role, mustChangePassword: false },
      });
    }
    if (String(path).startsWith("/api/claims")) return Promise.resolve(CLAIMS_PAGE);
    if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: true }, refreshIntervalSeconds: 60, lastSync: null, lease: null, queuedJobs: 0 });
    if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
    return Promise.resolve({});
  });
}

describe("claim status & kontrol klaim", () => {
  it("menampilkan badge Sudah Terklaim untuk klaim Already Claimed", async () => {
    mockClaimsApi("admin");
    renderWithProviders(<ClaimsPage />);
    expect(await screen.findByText("@creator_0001")).toBeInTheDocument();
    // Badge "Sudah Terklaim" bisa berdampingan dengan tombol verifikasi berlabel sama (admin).
    expect(screen.getAllByText("Sudah Terklaim").length).toBeGreaterThan(0);
    expect(screen.getByText("Perlu Verifikasi")).toBeInTheDocument();
    expect(screen.getByText("Gagal")).toBeInTheDocument();
  });

  it("admin melihat tombol verifikasi pada klaim Perlu Verifikasi", async () => {
    mockClaimsApi("admin");
    renderWithProviders(<ClaimsPage />);
    expect(await screen.findByText("Hasil: Berhasil")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Sudah Terklaim" })).toBeInTheDocument();
  });

  it("operator tidak melihat tombol verifikasi (dijaga juga di server)", async () => {
    mockClaimsApi("operator");
    renderWithProviders(<ClaimsPage />);
    expect(await screen.findByText("@creator_0002")).toBeInTheDocument();
    expect(screen.queryByText("Hasil: Berhasil")).not.toBeInTheDocument();
    // Tombol retry Failed tetap tersedia untuk operator.
    expect(screen.getByRole("button", { name: /retry/i })).toBeInTheDocument();
  });

  it("tombol retry memanggil API retry klaim", async () => {
    mockClaimsApi("operator");
    apiPost.mockResolvedValue({ claim: { id: "a3", status: "Pending" } });
    const user = userEvent.setup();
    renderWithProviders(<ClaimsPage />);
    await user.click(await screen.findByRole("button", { name: /retry/i }));
    await waitFor(() => {
      expect(apiPost).toHaveBeenCalledWith("/api/claims/a3/retry");
    });
  });

  it("Emergency Stop membuka dialog konfirmasi lalu memanggil endpoint", async () => {
    mockClaimsApi("admin");
    apiPost.mockResolvedValue({ ok: true, flipped: 1 });
    const user = userEvent.setup();
    renderWithProviders(<ClaimsPage />);
    await user.click(await screen.findByRole("button", { name: /emergency stop/i }));
    expect(await screen.findByRole("alertdialog")).toBeInTheDocument();
    expect(screen.getByText(/Aktifkan Emergency Stop\?/)).toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: /ya, stop sekarang/i }));
    await waitFor(() => {
      expect(apiPost).toHaveBeenCalledWith("/api/monitoring/emergency-stop");
    });
  });

  it("operator tidak bisa membuka Emergency Stop yang sudah aktif (hanya Admin)", async () => {
    mockMe("operator");
    apiGet.mockImplementation((path: string) => {
      if (String(path).startsWith("/api/claims")) return Promise.resolve(CLAIMS_PAGE);
      if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: false, emergencyStop: true, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: true }, refreshIntervalSeconds: 60, lastSync: null, lease: null, queuedJobs: 0 });
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      return Promise.resolve({});
    });
    renderWithProviders(<ClaimsPage />);
    expect(await screen.findByText(/Emergency Stop aktif: hubungi Admin/i)).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /buka emergency stop/i })).not.toBeInTheDocument();
  });
});
