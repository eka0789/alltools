import { apiGet, apiPost, mockMe, renderWithProviders } from "./mocks";
import { describe, expect, it } from "vitest";
import userEvent from "@testing-library/user-event";
import { screen, waitFor } from "@testing-library/react";
import { DashboardPage } from "@/pages/DashboardPage";

const MONITORING_OFF = {
  monitoringActive: false,
  emergencyStop: false,
  claimMode: "assisted",
  automaticPossible: false,
  sourceAdapter: "mock",
  sourceLabel: "Sumber: Mock",
  worker: { online: false, lastHeartbeatAt: null, running: false, instance: null },
  lastSync: null,
  lease: null,
  queuedJobs: 0,
  refreshIntervalSeconds: 60,
};

const DASHBOARD_MIN = {
  stats: { totalCreators: 0, availableCreators: 0, totalClaimed: 0, claimsSuccess: 0, claimsFailed: 0, claimsPending: 0, lastSyncAt: null },
  charts: { claimsPerDay: [], syncPerDay: [] },
  recentCreators: [],
  recentClaims: [],
  monitoring: MONITORING_OFF,
  claimMode: "assisted",
  refreshIntervalSeconds: 60,
};

function mockDashboardApi(overrides?: Record<string, unknown>) {
  mockMe("operator");
  apiGet.mockImplementation((path: string) => {
    if (path === "/api/dashboard") return Promise.resolve({ ...DASHBOARD_MIN, ...(overrides ?? {}) });
    if (path === "/api/monitoring/status") return Promise.resolve(overrides?.monitoring ?? MONITORING_OFF);
    if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
    return Promise.resolve({});
  });
}

describe("kontrol monitoring di dashboard", () => {
  it("menampilkan tombol Start Monitoring saat monitoring nonaktif dan memanggil endpoint start", async () => {
    mockDashboardApi();
    apiPost.mockResolvedValue({ ok: true });
    const user = userEvent.setup();
    renderWithProviders(<DashboardPage />);
    const startBtn = await screen.findByRole("button", { name: /start monitoring/i });
    await user.click(startBtn);
    await waitFor(() => {
      expect(apiPost).toHaveBeenCalledWith("/api/monitoring/start");
    });
  });

  it("menampilkan tombol Stop Monitoring saat monitoring aktif dan memanggil endpoint stop", async () => {
    mockDashboardApi({ monitoring: { ...MONITORING_OFF, monitoringActive: true }, monitoringActive: true });
    apiGet.mockImplementation((path: string) => {
      if (path === "/api/dashboard") return Promise.resolve({ ...DASHBOARD_MIN, monitoring: { ...MONITORING_OFF, monitoringActive: true } });
      if (path === "/api/monitoring/status") return Promise.resolve({ ...MONITORING_OFF, monitoringActive: true });
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      return Promise.resolve({});
    });
    apiPost.mockResolvedValue({ ok: true });
    const user = userEvent.setup();
    renderWithProviders(<DashboardPage />);
    const stopBtn = await screen.findByRole("button", { name: /stop monitoring/i });
    await user.click(stopBtn);
    await waitFor(() => {
      expect(apiPost).toHaveBeenCalledWith("/api/monitoring/stop");
    });
  });

  it("tombol Sinkronisasi Sekarang memanggil endpoint sync manual", async () => {
    mockDashboardApi();
    apiPost.mockResolvedValue({ jobId: "job-1", message: "Sinkronisasi dijadwalkan." });
    const user = userEvent.setup();
    renderWithProviders(<DashboardPage />);
    await user.click(await screen.findByRole("button", { name: /sinkronisasi sekarang/i }));
    await waitFor(() => {
      expect(apiPost).toHaveBeenCalledWith("/api/monitoring/sync");
    });
  });

  it("menampilkan state empty pada tabel creator saat belum ada data", async () => {
    mockDashboardApi();
    renderWithProviders(<DashboardPage />);
    expect(await screen.findByText("Belum ada creator")).toBeInTheDocument();
    expect(screen.getByText(/Aktifkan Monitoring atau jalankan sinkronisasi manual/i)).toBeInTheDocument();
  });

  it("menampilkan worker offline saat heartbeat kedaluwarsa", async () => {
    mockDashboardApi();
    renderWithProviders(<DashboardPage />);
    // Kartu Status Worker menampilkan "Offline" ketika heartbeat kedaluwarsa.
    expect(await screen.findByText("Offline")).toBeInTheDocument();
  });
});
