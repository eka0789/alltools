import { apiGet, apiPut, mockMe, renderWithProviders } from "./mocks";
import { describe, expect, it } from "vitest";
import userEvent from "@testing-library/user-event";
import { screen, waitFor } from "@testing-library/react";
import { AutomationSettingsPage } from "@/pages/AutomationSettingsPage";
import { IntegrationSettingsPage } from "@/pages/IntegrationSettingsPage";

const AUTOMATION = {
  automation: {
    refreshIntervalSeconds: 60,
    maxRetries: 3,
    retryBaseDelaySeconds: 30,
    claimSchedule: { startHour: 0, endHour: 23, days: [0, 1, 2, 3, 4, 5, 6] },
    notifications: { inApp: true, telegram: false, email: false },
    export: { filenamePrefix: "klaim-creator", usernamesOnlyDefault: false },
  },
  claimMode: "assisted",
  automaticPossible: false,
  monitoringActive: true,
  emergencyStop: false,
};

const INTEGRATION = {
  adapter: "mock",
  official: { enabled: false, baseUrlEnv: "OFFICIAL_API_BASE_URL", apiKeyEnv: "OFFICIAL_API_KEY", claimPath: "/v1/claims" },
  mock: { pages: 3, itemsPerPage: 15, newItemsPerCycle: 2, faultMode: "none" },
  officialConfigured: false,
  sourceLabel: "Sumber: Mock",
  lastCheck: { ok: true, message: "Koneksi sehat", checkedAt: "2026-01-05T02:00:00.000Z" },
};

describe("halaman settings (admin)", () => {
  it("Automation Settings menampilkan nilai terpasang dan mode klaim assisted", async () => {
    mockMe("admin");
    apiGet.mockImplementation((path: string) => {
      if (path === "/api/settings/automation") return Promise.resolve(AUTOMATION);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: true } });
      return Promise.resolve({});
    });
    renderWithProviders(<AutomationSettingsPage />);
    expect(await screen.findByText("Monitoring & Sinkronisasi")).toBeInTheDocument();
    const intervalInput = screen.getByLabelText(/interval refresh dalam detik/i) as HTMLInputElement;
    expect(intervalInput.value).toBe("60");
    const retryInput = screen.getByLabelText(/maximum retry/i) as HTMLInputElement;
    expect(retryInput.value).toBe("3");
    // Opsi otomatis ter-disable karena integrasi resmi belum siap.
    expect(screen.getByText(/Assisted \(manual\)/)).toBeInTheDocument();
  });

  it("menyimpan Automation Settings via PUT dengan payload lengkap", async () => {
    mockMe("admin");
    apiGet.mockImplementation((path: string) => {
      if (path === "/api/settings/automation") return Promise.resolve(AUTOMATION);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: true } });
      return Promise.resolve({});
    });
    apiPut.mockResolvedValue(AUTOMATION);
    const user = userEvent.setup();
    renderWithProviders(<AutomationSettingsPage />);
    const retryInput = await screen.findByLabelText(/maximum retry/i);
    await user.clear(retryInput);
    await user.type(retryInput, "5");
    await user.click(screen.getByRole("button", { name: /simpan semua/i }));
    await waitFor(() => {
      expect(apiPut).toHaveBeenCalledWith(
        "/api/settings/automation",
        expect.objectContaining({ maxRetries: 5, claimMode: "assisted" })
      );
    });
  });

  it("Integration Settings menampilkan label Sumber: Mock dan hasil uji koneksi terakhir", async () => {
    mockMe("admin");
    apiGet.mockImplementation((path: string) => {
      if (path === "/api/settings/integration") return Promise.resolve(INTEGRATION);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: true } });
      return Promise.resolve({});
    });
    renderWithProviders(<IntegrationSettingsPage />);
    expect(await screen.findAllByText("Sumber: Mock").then((els) => els.length)).toBeGreaterThan(0);
    expect(screen.queryByText("Belum pernah diuji")).not.toBeInTheDocument();
    expect(screen.getByText("Uji terakhir: berhasil")).toBeInTheDocument();
    expect(screen.getByText(/OFFICIAL_API_BASE_URL/)).toBeInTheDocument();
  });
});
