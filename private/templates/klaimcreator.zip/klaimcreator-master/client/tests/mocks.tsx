// Import vitest HARUS paling atas agar vi.mock dapat di-hoist dengan benar.
import { vi, type Mock } from "vitest";
import type { ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MemoryRouter } from "react-router-dom";
import { render, type RenderOptions } from "@testing-library/react";
import { Toaster } from "sonner";
import { api } from "@/lib/api";

/** Mock adapter: seluruh test frontend berjalan di atas API tiruan, tanpa klaim sungguhan. */
vi.mock("@/lib/api", async () => {
  const actual = (await vi.importActual("@/lib/api")) as Record<string, unknown>;
  return {
    ...actual,
    api: {
      get: vi.fn(),
      post: vi.fn(),
      put: vi.fn(),
    },
  };
});

// Handle mock yang sudah terpasang (bukan variabel hoisted yang diekspor).
export const apiGet = api.get as unknown as Mock;
export const apiPost = api.post as unknown as Mock;
export const apiPut = api.put as unknown as Mock;

export function createWrapper(route = "/") {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
  return function Wrapper({ children }: { children: ReactNode }) {
    return (
      <QueryClientProvider client={queryClient}>
        <MemoryRouter initialEntries={[route]}>
          {children}
          <Toaster position="top-right" />
        </MemoryRouter>
      </QueryClientProvider>
    );
  };
}

export function renderWithProviders(ui: ReactElement, options?: Omit<RenderOptions, "wrapper"> & { route?: string }) {
  const { route = "/", ...renderOptions } = options ?? {};
  const Wrapper = createWrapper(route);
  return render(ui, { wrapper: Wrapper, ...renderOptions });
}

import type { ReactElement } from "react";

export const ADMIN_USER = {
  user: {
    id: "11111111-1111-1111-1111-111111111111",
    email: "admin@klaimcreator.local",
    name: "Admin Uji",
    role: "admin" as const,
    mustChangePassword: false,
  },
};

export function mockMe(role: "admin" | "operator" = "admin"): void {
  apiGet.mockImplementation((path: string) => {
    if (path === "/api/auth/me") {
      return Promise.resolve({
        user: { ...ADMIN_USER.user, role },
      });
    }
    return Promise.resolve({});
  });
}
