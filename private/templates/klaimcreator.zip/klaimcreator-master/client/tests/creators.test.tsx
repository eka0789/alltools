import { apiGet, mockMe, renderWithProviders } from "./mocks";
import { describe, expect, it } from "vitest";
import userEvent from "@testing-library/user-event";
import { screen, waitFor } from "@testing-library/react";
import { CreatorsPage } from "@/pages/CreatorsPage";

const CREATORS_PAGE = {
  items: [
    { id: "c1", source: "mock", externalId: "mock-00001", username: "creator_0001", nickname: "Creator 0001", followerCount: 125000, status: "Available", firstSeenAt: "2026-01-05T01:00:00.000Z", lastUpdatedAt: "2026-01-05T02:00:00.000Z" },
    { id: "c2", source: "mock", externalId: "mock-00002", username: "creator_0002", nickname: null, followerCount: 3000, status: "Claimed", firstSeenAt: "2026-01-04T01:00:00.000Z", lastUpdatedAt: "2026-01-05T02:00:00.000Z" },
    { id: "c3", source: "mock", externalId: "mock-00003", username: "creator_0003", nickname: null, followerCount: 900, status: "Failed", firstSeenAt: "2026-01-03T01:00:00.000Z", lastUpdatedAt: "2026-01-05T02:00:00.000Z" },
  ],
  page: 1,
  pageSize: 20,
  total: 3,
  totalPages: 1,
};

describe("creator filtering & daftar creator", () => {
  it("menampilkan daftar creator dengan badge status bahasa Indonesia", async () => {
    mockMe("operator");
    apiGet.mockImplementation((path: string) => {
      if (String(path).startsWith("/api/creators")) return Promise.resolve(CREATORS_PAGE);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: false } });
      return Promise.resolve({});
    });
    renderWithProviders(<CreatorsPage />);
    expect(await screen.findByText("@creator_0001")).toBeInTheDocument();
    expect(screen.getByText("Tersedia")).toBeInTheDocument();
    expect(screen.getByText("Terklaim")).toBeInTheDocument();
    expect(screen.getByText("Gagal")).toBeInTheDocument();
  });

  it("mencari creator memicu query dengan parameter search", async () => {
    mockMe("operator");
    apiGet.mockImplementation((path: string) => {
      if (String(path).startsWith("/api/creators")) return Promise.resolve(CREATORS_PAGE);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: false } });
      return Promise.resolve({});
    });
    const user = userEvent.setup();
    renderWithProviders(<CreatorsPage />);
    const search = await screen.findByPlaceholderText(/cari username atau id/i);
    await user.type(search, "0001");
    await waitFor(() => {
      const calls = (apiGet.mock.calls as unknown[][]).filter((c: unknown[]) => String(c[0]).startsWith("/api/creators"));
      const last = calls[calls.length - 1] as unknown[] | undefined;
      expect(last?.[1]).toMatchObject({ search: "0001" });
    });
  });

  it("menampilkan empty state dengan CTA saat tidak ada creator", async () => {
    mockMe("operator");
    apiGet.mockImplementation((path: string) => {
      if (String(path).startsWith("/api/creators")) return Promise.resolve({ items: [], page: 1, pageSize: 20, total: 0, totalPages: 1 });
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      if (path === "/api/monitoring/status") return Promise.resolve({ monitoringActive: true, emergencyStop: false, claimMode: "assisted", sourceLabel: "Sumber: Mock", worker: { online: false } });
      return Promise.resolve({});
    });
    renderWithProviders(<CreatorsPage />);
    expect(await screen.findByText("Belum ada creator")).toBeInTheDocument();
    expect(screen.getByText(/Jalankan sinkronisasi dari Dashboard/i)).toBeInTheDocument();
  });
});
