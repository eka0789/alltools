import { apiPost, renderWithProviders } from "./mocks";
import { describe, expect, it, vi } from "vitest";
import userEvent from "@testing-library/user-event";
import { screen, waitFor } from "@testing-library/react";
import { LoginPage } from "@/pages/LoginPage";

describe("halaman login", () => {
  it("menampilkan label form dan tombol masuk yang aksesibel", () => {
    renderWithProviders(<LoginPage />);
    expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /masuk/i })).toBeInTheDocument();
  });

  it("menampilkan pesan validasi per field saat dikirim kosong", async () => {
    const user = userEvent.setup();
    renderWithProviders(<LoginPage />);
    await user.click(screen.getByRole("button", { name: /masuk/i }));
    expect(await screen.findByText("Email wajib diisi")).toBeInTheDocument();
    expect(screen.getByText("Password wajib diisi")).toBeInTheDocument();
    expect(apiPost).not.toHaveBeenCalled();
  });

  it("menolak format email tidak valid", async () => {
    const user = userEvent.setup();
    renderWithProviders(<LoginPage />);
    await user.type(screen.getByLabelText(/email/i), "bukan-email");
    await user.type(screen.getByLabelText(/password/i), "password123");
    await user.click(screen.getByRole("button", { name: /masuk/i }));
    expect(await screen.findByText("Format email tidak valid")).toBeInTheDocument();
  });

  it("menampilkan pesan error dari server saat kredensial salah", async () => {
    apiPost.mockRejectedValueOnce(new Error("Email atau password salah"));
    const user = userEvent.setup();
    renderWithProviders(<LoginPage />);
    await user.type(screen.getByLabelText(/email/i), "admin@klaimcreator.local");
    await user.type(screen.getByLabelText(/password/i), "password-salah");
    await user.click(screen.getByRole("button", { name: /masuk/i }));
    expect(await screen.findByText("Email atau password salah")).toBeInTheDocument();
    expect(apiPost).toHaveBeenCalledWith("/api/auth/login", {
      email: "admin@klaimcreator.local",
      password: "password-salah",
    });
  });

  it("mengirim kredensial saat login sukses", async () => {
    apiPost.mockResolvedValueOnce({
      user: { id: "1", email: "admin@klaimcreator.local", name: "Admin", role: "admin", mustChangePassword: false },
    });
    const user = userEvent.setup();
    renderWithProviders(<LoginPage />);
    await user.type(screen.getByLabelText(/email/i), "admin@klaimcreator.local");
    await user.type(screen.getByLabelText(/password/i), "rahasia123");
    await user.click(screen.getByRole("button", { name: /masuk/i }));
    await waitFor(() => {
      expect(apiPost).toHaveBeenCalledWith("/api/auth/login", {
        email: "admin@klaimcreator.local",
        password: "rahasia123",
      });
    });
  });

  it("tombol masuk berada dalam state loading saat request berjalan", async () => {
    let resolveLogin: (v: unknown) => void = () => undefined;
    apiPost.mockReturnValueOnce(new Promise((resolve) => (resolveLogin = resolve)));
    const user = userEvent.setup();
    renderWithProviders(<LoginPage />);
    await user.type(screen.getByLabelText(/email/i), "admin@klaimcreator.local");
    await user.type(screen.getByLabelText(/password/i), "rahasia123");
    await user.click(screen.getByRole("button", { name: /masuk/i }));
    expect(await screen.findByText(/memeriksa/i)).toBeInTheDocument();
    resolveLogin({ user: { id: "1", email: "x", name: "x", role: "admin", mustChangePassword: false } });
    await waitFor(() => expect(screen.queryByText(/memeriksa/i)).not.toBeInTheDocument());
  });
});
