import { apiGet, mockMe, renderWithProviders } from "./mocks";
import { describe, expect, it } from "vitest";
import { screen } from "@testing-library/react";
import { DashboardPage } from "@/pages/DashboardPage";

const DASHBOARD_PAYLOAD = {
  stats: {
    totalCreators: 482,
    availableCreators: 63,
    totalClaimed: 190,
    claimsSuccess: 121,
    claimsFailed: 17,
    claimsPending: 8,
    lastSyncAt: "2026-01-05T02:30:00.000Z",
  },
  charts: {
    claimsPerDay: Array.from({ length: 14 }, (_, i) => ({ day: `2026-01-${String(i + 1).padStart(2, "0")}`, success: i, failed: i > 3 ? 1 : 0, total: i + 1 })),
    syncPerDay: Array.from({ length: 14 }, (_, i) => ({ day: `2026-01-${String(i + 1).padStart(2, "0")}`, count: i })),
  },
  recentCreators: [
    { id: "c1", username: "creator_0001", nickname: "Creator 0001", status: "Available", followerCount: 12000, firstSeenAt: "2026-01-05T01:00:00.000Z" },
    { id: "c2", username: "creator_0002", nickname: null, status: "Claimed", followerCount: 800, firstSeenAt: "2026-01-04T01:00:00.000Z" },
  ],
  recentClaims: [
    { id: "cl1", username: "creator_0002", status: "Success", mode: "assisted", claimedAt: "2026-01-05T02:00:00.000Z", createdAt: "2026-01-05T01:30:00.000Z", lastError: null },
    { id: "cl2", username: "creator_0003", status: "Already Claimed", mode: "automatic", claimedAt: null, createdAt: "2026-01-05T01:00:00.000Z", lastError: "sudah diklaim pihak lain" },
  ],
  monitoring: {
    monitoringActive: true,
    emergencyStop: false,
    claimMode: "assisted",
    automaticPossible: false,
    sourceAdapter: "mock",
    sourceLabel: "Sumber: Mock",
    worker: { online: true, lastHeartbeatAt: new Date().toISOString(), running: false, instance: "w-1" },
    lastSync: { started_at: "2026-01-05T02:30:00.000Z", finished_at: "2026-01-05T02:30:10.000Z", status: "Success" },
    lease: null,
    queuedJobs: 0,
    refreshIntervalSeconds: 60,
  },
  claimMode: "assisted",
  refreshIntervalSeconds: 60,
};

describe("dashboard statistics", () => {
  it("menampilkan 7 kartu statistik dengan nilai terformat", async () => {
    mockMe("admin");
    apiGet.mockImplementation((path: string) => {
      if (path === "/api/dashboard") return Promise.resolve(DASHBOARD_PAYLOAD);
      if (path === "/api/monitoring/status") return Promise.resolve(DASHBOARD_PAYLOAD.monitoring);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      return Promise.resolve({});
    });
    renderWithProviders(<DashboardPage />);

    expect(await screen.findByText("Total Creator")).toBeInTheDocument();
    expect(screen.getByText("Available")).toBeInTheDocument();
    expect(screen.getByText("Total Claimed")).toBeInTheDocument();
    expect(screen.getByText("Success")).toBeInTheDocument();
    expect(screen.getByText("Failed")).toBeInTheDocument();
    expect(screen.getByText("Pending")).toBeInTheDocument();
    expect(screen.getByText("Last Sync")).toBeInTheDocument();

    // Nilai terformat id-ID (482, 63, dst) muncul sebagai angka.
    expect(screen.getAllByText("482").length).toBeGreaterThan(0);
    expect(screen.getAllByText("63").length).toBeGreaterThan(0);
    expect(screen.getByText("121")).toBeInTheDocument();
  });

  it("menampilkan status worker aktif dan label sumber Mock", async () => {
    mockMe("admin");
    apiGet.mockImplementation((path: string) => {
      if (path === "/api/dashboard") return Promise.resolve(DASHBOARD_PAYLOAD);
      if (path === "/api/monitoring/status") return Promise.resolve(DASHBOARD_PAYLOAD.monitoring);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      return Promise.resolve({});
    });
    renderWithProviders(<DashboardPage />);
    expect(await screen.findByText("Sumber: Mock")).toBeInTheDocument();
    expect(await screen.findByText("Status Koneksi Sumber")).toBeInTheDocument();
    expect(await screen.findByText("Status Worker")).toBeInTheDocument();
  });

  it("menampilkan tabel creator terbaru dengan badge status", async () => {
    mockMe("admin");
    apiGet.mockImplementation((path: string) => {
      if (path === "/api/dashboard") return Promise.resolve(DASHBOARD_PAYLOAD);
      if (path === "/api/monitoring/status") return Promise.resolve(DASHBOARD_PAYLOAD.monitoring);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      return Promise.resolve({});
    });
    renderWithProviders(<DashboardPage />);
    expect(await screen.findByText("@creator_0001")).toBeInTheDocument();
    expect(screen.getByText("Tersedia")).toBeInTheDocument();
    expect(screen.getByText("Terklaim")).toBeInTheDocument();
    expect(screen.getByText("Sudah Terklaim")).toBeInTheDocument();
  });

  it("menampilkan state error yang dapat dipahami saat API gagal", async () => {
    mockMe("admin");
    apiGet.mockImplementation((path: string) => {
      if (path === "/api/dashboard") return Promise.reject(new Error("Server sedang bermasalah"));
      if (path === "/api/monitoring/status") return Promise.resolve(DASHBOARD_PAYLOAD.monitoring);
      if (path === "/api/notifications") return Promise.resolve({ items: [], unread: 0 });
      return Promise.resolve({});
    });
    renderWithProviders(<DashboardPage />);
    expect(await screen.findByRole("alert")).toBeInTheDocument();
    expect(await screen.findByText(/Server sedang bermasalah/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /coba lagi/i })).toBeInTheDocument();
  });
});
