import fs from "node:fs";
import type { AppConfig } from "./config";
import { openDatabase, type SqliteDb } from "./db/connection";
import { runMigrations } from "./db/migrate";
import { DEFAULT_SETTINGS, makeRepository, type Repository } from "./repository";
import { AuthService } from "./services/authService";
import { NotificationService } from "./services/notificationService";

export interface Bootstrap {
  db: SqliteDb;
  repo: Repository;
  cfg: AppConfig;
  authService: AuthService;
  notifier: NotificationService;
}

/** Bootstrap bersama app dan worker: buka DB, migrasi, default settings, seed admin. */
export function bootstrap(cfg: AppConfig): Bootstrap {
  fs.mkdirSync(cfg.dataDir, { recursive: true });
  fs.mkdirSync(cfg.backupDir, { recursive: true });
  const db = openDatabase(cfg.dbFile);
  runMigrations(db);
  const repo = makeRepository(db);
  repo.settings.ensureDefaults(DEFAULT_SETTINGS);
  const authService = new AuthService(repo, cfg);
  const seed = authService.ensureSeedAdmin();
  if (!seed.seeded) {
    // Database sudah berisi pengguna: tidak ada aksi seed.
  }
  const notifier = new NotificationService(repo, cfg);
  return { db, repo, cfg, authService, notifier };
}
