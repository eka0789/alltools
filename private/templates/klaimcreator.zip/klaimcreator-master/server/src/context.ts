import type { AppConfig } from "./config";
import type { SqliteDb } from "./db/connection";
import type { Repository } from "./repository";
import type { AuthService } from "./services/authService";
import type { NotificationService } from "./services/notificationService";
import type { ClaimDeps } from "./services/claimService";
import type { AdapterBundle } from "./adapters/registry";
import type { RateLimiters } from "./middleware/rateLimit";

/**
 * Konteks aplikasi yang di-inject ke routes (dependency injection agar mudah dites).
 */
export interface AppContext {
  db: SqliteDb;
  repo: Repository;
  cfg: AppConfig;
  authService: AuthService;
  notifier: NotificationService;
  adapters: () => AdapterBundle;
  claimDeps: () => ClaimDeps;
  limiters: RateLimiters;
}
