import path from "node:path";
import { createRequire } from "node:module";
import express, { type Express } from "express";
import cookieParser from "cookie-parser";
import fs from "node:fs";
import type { AppContext } from "./context";
import { applySecurityHeaders, swaggerCsp } from "./middleware/security";
import { csrfGuard, centralErrorHandler, makeRequireAuth } from "./middleware/auth";
import { authRoutes } from "./routes/auth";
import { userRoutes } from "./routes/users";
import { creatorRoutes } from "./routes/creators";
import { claimRoutes } from "./routes/claims";
import { monitoringRoutes } from "./routes/monitoring";
import { exportRoutes } from "./routes/export";
import { settingsRoutes } from "./routes/settings";
import { logRoutes } from "./routes/logs";
import { notificationRoutes } from "./routes/notifications";
import { dashboardRoutes } from "./routes/dashboard";
import { healthRoutes } from "./routes/health";
import { openApiSpec } from "./openapi";
import { errorResponse } from "./middleware/auth";

/** Temukan direktori aset swagger-ui-dist; null bila paket tidak tersedia. */
function resolveSwaggerDist(): string | null {
  try {
    const req = createRequire(__filename);
    return path.dirname(req.resolve("swagger-ui-dist/package.json"));
  } catch {
    return null;
  }
}

/** Membangun aplikasi Express (dipakai produksi maupun Supertest). */
export function createApp(ctx: AppContext, opts: { serveClient?: boolean } = {}): Express {
  const app = express();
  app.set("trust proxy", ctx.cfg.trustProxy);
  app.disable("x-powered-by");

  applySecurityHeaders(app, ctx.cfg);
  app.use(express.json({ limit: "1mb" }));
  app.use(cookieParser());
  app.use(csrfGuard);
  app.use(ctx.limiters.apiLimiter);

  const requireAuth = makeRequireAuth(ctx.authService);

  // --- Swagger docs (/api/docs) dengan CSP khusus ---
  const swaggerDist = resolveSwaggerDist();
  app.get("/api/docs/openapi.json", (_req, res) => {
    res.json(openApiSpec);
  });
  if (swaggerDist) {
    app.use("/api/docs/assets", swaggerCsp, express.static(swaggerDist, { index: false }));
  }
  app.get("/api/docs", swaggerCsp, (_req, res) => {
    res.type("html").send(`<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>KlaimCreator API Docs</title>
  <link rel="stylesheet" href="/api/docs/assets/swagger-ui.css" />
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="/api/docs/assets/swagger-ui-bundle.js" crossorigin></script>
  <script>
    window.onload = function () {
      window.ui = SwaggerUIBundle({
        url: "/api/docs/openapi.json",
        dom_id: "#swagger-ui",
        docExpansion: "list",
        persistAuthorization: false,
      });
    };
  </script>
</body>
</html>`);
  });

  // --- API v1 ---
  app.use("/api/auth", authRoutes(ctx));
  app.use("/api/users", requireAuth, userRoutes(ctx));
  app.use("/api/creators", requireAuth, creatorRoutes(ctx));
  app.use("/api/claims", requireAuth, claimRoutes(ctx));
  app.use("/api/monitoring", requireAuth, monitoringRoutes(ctx));
  app.use("/api/export", requireAuth, exportRoutes(ctx));
  app.use("/api/settings", requireAuth, settingsRoutes(ctx));
  app.use("/api/logs", requireAuth, logRoutes(ctx));
  app.use("/api/notifications", requireAuth, notificationRoutes(ctx));
  app.use("/api/dashboard", requireAuth, dashboardRoutes(ctx));
  app.use("/api", healthRoutes(ctx));

  // --- Static frontend (produksi: satu origin, tanpa CORS) ---
  if (opts.serveClient !== false && fs.existsSync(ctx.cfg.clientDistDir)) {
    app.use(express.static(ctx.cfg.clientDistDir));
    app.get("*", (req, res, next) => {
      if (req.path.startsWith("/api/") || req.path.startsWith("/api/docs")) {
        next();
        return;
      }
      res.sendFile(path.join(ctx.cfg.clientDistDir, "index.html"));
    });
  }

  // --- 404 API + error handler ---
  app.use("/api", (_req, res) => {
    errorResponse(res, 404, "NOT_FOUND", "Endpoint tidak ditemukan");
  });
  app.use(centralErrorHandler);

  return app;
}
