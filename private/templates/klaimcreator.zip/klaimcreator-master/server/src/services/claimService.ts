import type { SqliteDb } from "../db/connection";
import type { Repository } from "../repository";
import type { AuthUser, ClaimRow, ClaimStatus } from "../types";
import type { ClaimExecutionAdapter } from "../adapters/types";
import { getAutomation, isWithinClaimSchedule, NotificationService } from "./notificationService";

export type AssistedResult = "success" | "already_claimed" | "failed";

export class ClaimError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public fields?: Record<string, string>
  ) {
    super(message);
    this.name = "ClaimError";
  }
}

export const CLAIM_ACTIVE_STATUSES: ClaimStatus[] = ["Pending", "Processing"];
/** Status klaim terminal yang MEMBLOKIR klaim baru (Failed tetap boleh dicoba ulang). */
export const CLAIM_BLOCKING_STATUSES: ClaimStatus[] = ["Pending", "Processing", "Success", "Already Claimed", "Verification Required"];

export function getClaimMode(repo: Repository): "automatic" | "assisted" {
  return repo.settings.get<"automatic" | "assisted">("claim_mode") === "automatic" ? "automatic" : "assisted";
}

export function isEmergencyStop(repo: Repository): boolean {
  return repo.settings.get<boolean>("emergency_stop") === true;
}

export function isMonitoringActive(repo: Repository): boolean {
  return repo.settings.get<boolean>("monitoring_active") === true;
}

function backoffDelayMs(baseDelaySeconds: number, attemptCount: number): number {
  const cappedBase = Math.max(1, Math.min(baseDelaySeconds, 3600));
  const delay = cappedBase * 1000 * Math.pow(2, Math.max(0, attemptCount - 1));
  return Math.min(delay, 3_600_000);
}

export interface ClaimDeps {
  db: SqliteDb;
  repo: Repository;
  notifier: NotificationService;
  /** Adapter eksekusi klaim otomatis; null berarti Assisted Claim Mode. */
  claimAdapter: ClaimExecutionAdapter | null;
}

/**
 * Masukkan creator ke antrian klaim (status Pending) bila memenuhi kriteria:
 * status Available dan belum memiliki klaim aktif maupun terminal pemblokir.
 * Idempotensi ditegakkan di transaksi DAN unique partial index database.
 */
export function enqueueIfEligible(deps: ClaimDeps, creatorId: string, requestedBy: string | null): { ok: boolean; claim?: ClaimRow; reason?: string } {
  const repo = deps.repo;
  const insert = deps.db.transaction((): { ok: boolean; claim?: ClaimRow; reason?: string } => {
    const creator = repo.creators.findById(creatorId);
    if (!creator) return { ok: false, reason: "CREATOR_NOT_FOUND" };
    if (creator.status !== "Available") return { ok: false, reason: "NOT_AVAILABLE" };
    const existingActive = repo.claims.findActiveByCreator(creatorId);
    if (existingActive) return { ok: false, reason: "ALREADY_QUEUED" };
    const blocking = repo.claims.findBlockingByCreator(creatorId);
    if (blocking) return { ok: false, reason: `TERMINAL_${blocking.status.replace(" ", "_").toUpperCase()}` };
    const claim = repo.claims.insert({
      creator_id: creatorId,
      status: "Pending",
      mode: getClaimMode(repo),
      requested_by: requestedBy,
    });
    // Creator yang masuk antrian berstatus Pending secara lokal.
    repo.creators.updateFromSource(creator.id, {
      username: creator.username,
      nickname: creator.nickname,
      follower_count: creator.follower_count,
      status: "Pending",
      raw_data: creator.raw_data,
    });
    repo.creators.insertStatusHistory(creator.id, creator.status, "Pending", "Masuk antrian klaim");
    repo.logs.createEvent({
      event_type: "system",
      description: `@${creator.username} masuk antrian klaim`,
      creator_id: creator.id,
      status: "Info",
    });
    return { ok: true, claim };
  });
  return insert();
}

// Catatan: cek pemblokiran klaim dilakukan lewat repository.claims.findBlockingByCreator
// (satu query parameterized), bukan iterasi status.

/**
 * Eksekusi klaim otomatis untuk antrian yang jatuh tempo.
 * Idempotent: klaim yang sudah bukan Pending tidak pernah dieksekusi dua kali.
 * Hasil uncertain menjadi Verification Required dan TIDAK PERNAH di-retry otomatis.
 */
export async function processDueClaims(
  deps: ClaimDeps,
  opts: { limit?: number; executedBy?: string | null; checkSchedule?: boolean } = {}
): Promise<{ processed: number; success: number; failed: number; alreadyClaimed: number; verificationRequired: number; skipped?: string }> {
  const repo = deps.repo;
  if (isEmergencyStop(repo)) return { processed: 0, success: 0, failed: 0, alreadyClaimed: 0, verificationRequired: 0, skipped: "emergency_stop" };
  if (!deps.claimAdapter) return { processed: 0, success: 0, failed: 0, alreadyClaimed: 0, verificationRequired: 0, skipped: "assisted_mode" };
  if (getClaimMode(repo) !== "automatic") {
    return { processed: 0, success: 0, failed: 0, alreadyClaimed: 0, verificationRequired: 0, skipped: "assisted_mode" };
  }
  const automation = getAutomation(repo);
  if (opts.checkSchedule && !isWithinClaimSchedule(automation)) {
    return { processed: 0, success: 0, failed: 0, alreadyClaimed: 0, verificationRequired: 0, skipped: "outside_schedule" };
  }

  const due = repo.claims.pendingDue(new Date().toISOString(), opts.limit ?? 10);
  let success = 0;
  let failed = 0;
  let alreadyClaimed = 0;
  let verificationRequired = 0;

  for (const claim of due) {
    // Transaksi klaim idempotent: hanya klaim yang masih Pending diubah menjadi Processing.
    const claimTx = deps.db.transaction(() => {
      const current = repo.claims.findById(claim.id);
      if (!current || current.status !== "Pending") return null;
      repo.claims.update(claim.id, { status: "Processing", last_error: null });
      return repo.claims.findById(claim.id);
    });
    const processing = claimTx();
    if (!processing) continue;

    const creator = repo.creators.findById(claim.creator_id);
    if (!creator) {
      repo.claims.update(claim.id, { status: "Failed", last_error: "Creator tidak ditemukan" });
      continue;
    }

    const startedAt = new Date().toISOString();
    let outcome: "success" | "already_claimed" | "transient_error" | "uncertain" | "hard_error" = "hard_error";
    let message = "Adapter tidak tersedia";
    try {
      const result = await deps.claimAdapter.claim(creator.username);
      outcome = result.outcome;
      message = result.message;
    } catch (err) {
      outcome = "transient_error";
      message = `Gangguan saat eksekusi klaim: ${(err as Error).message}`;
    }

    applyClaimOutcome(deps, {
      claimId: claim.id,
      creatorId: creator.id,
      username: creator.username,
      outcome,
      message,
      startedAt,
      executedBy: opts.executedBy ?? null,
    });
    if (outcome === "success") success += 1;
    else if (outcome === "already_claimed") alreadyClaimed += 1;
    else if (outcome === "uncertain") verificationRequired += 1;
    else failed += 1;
  }

  return { processed: due.length, success, failed, alreadyClaimed, verificationRequired };
}

export function applyClaimOutcome(
  deps: ClaimDeps,
  input: {
    claimId: string;
    creatorId: string;
    username: string;
    outcome: "success" | "already_claimed" | "transient_error" | "uncertain" | "hard_error";
    message: string;
    startedAt: string;
    executedBy: string | null;
  }
): ClaimStatus {
  const repo = deps.repo;
  const automation = getAutomation(repo);
  const claim = repo.claims.findById(input.claimId);
  if (!claim) throw new ClaimError(404, "NOT_FOUND", "Klaim tidak ditemukan");
  const attemptNumber = repo.claims.nextAttemptNumber(input.claimId);

  const finalize = deps.db.transaction((finalStatus: ClaimStatus, patch: Parameters<typeof repo.claims.update>[1]) => {
    repo.claims.insertAttempt({
      claim_id: input.claimId,
      attempt_number: attemptNumber,
      result: mapOutcomeToAttemptResult(input.outcome),
      message: input.message,
      executed_by: input.executedBy,
      started_at: input.startedAt,
      finished_at: new Date().toISOString(),
    });
    repo.claims.update(input.claimId, patch);
    setCreatorStatusFromClaim(deps, input.creatorId, input.username, finalStatus);
  });

  switch (input.outcome) {
    case "success": {
      finalize("Success", { status: "Success", claimed_at: new Date().toISOString(), last_error: null });
      repo.logs.createEvent({
        event_type: "claim_success",
        description: `Klaim @${input.username} berhasil`,
        creator_id: input.creatorId,
        status: "Success",
      });
      deps.notifier.notify({
        eventType: "claim_success",
        title: "Klaim berhasil",
        message: `Username @${input.username} berhasil diklaim.`,
        creatorId: input.creatorId,
        eventStatus: "Success",
      });
      return "Success";
    }
    case "already_claimed": {
      // Terminal: tanpa retry. Muncul di filter, badge, dan kolom Claim Status export.
      finalize("Already Claimed", { status: "Already Claimed", last_error: input.message });
      repo.logs.createEvent({
        event_type: "claim_failed",
        description: `Klaim @${input.username} ditandai Sudah Terklaim (sudah diklaim pihak lain)`,
        creator_id: input.creatorId,
        status: "Warning",
      });
      deps.notifier.notify({
        eventType: "claim_failed",
        title: "Username sudah diklaim pihak lain",
        message: `@${input.username} ternyata sudah diklaim pihak lain. Klaim ditandai Sudah Terklaim tanpa retry.`,
        creatorId: input.creatorId,
        eventStatus: "Warning",
      });
      return "Already Claimed";
    }
    case "uncertain": {
      // Hasil tidak pasti: tidak pernah dieksekusi ulang sebelum diverifikasi.
      finalize("Verification Required", { status: "Verification Required", last_error: input.message });
      repo.logs.createEvent({
        event_type: "claim_failed",
        description: `Klaim @${input.username} perlu verifikasi manual: ${input.message}`,
        creator_id: input.creatorId,
        status: "Warning",
      });
      deps.notifier.notify({
        eventType: "claim_failed",
        title: "Klaim perlu verifikasi",
        message: `Hasil klaim @${input.username} tidak pasti (${input.message}). Klaim menunggu verifikasi Admin.`,
        creatorId: input.creatorId,
        eventStatus: "Warning",
      });
      return "Verification Required";
    }
    case "transient_error":
    case "hard_error":
    default: {
      const attemptCount = claim.attempt_count + 1;
      const maxRetries = Math.max(0, automation.maxRetries);
      if (attemptCount >= maxRetries) {
        finalize("Failed", {
          status: "Failed",
          attempt_count: attemptCount,
          last_error: input.message,
          next_retry_at: null,
        });
        repo.logs.createEvent({
          event_type: "claim_failed",
          description: `Klaim @${input.username} gagal permanen setelah ${attemptCount} percobaan: ${input.message}`,
          creator_id: input.creatorId,
          status: "Error",
        });
        deps.notifier.notify({
          eventType: "claim_failed",
          title: "Klaim gagal",
          message: `Klaim @${input.username} gagal permanen setelah ${attemptCount} percobaan: ${input.message}`,
          creatorId: input.creatorId,
          eventStatus: "Error",
        });
        return "Failed";
      }
      // Gagal karena error sementara: retry dengan exponential backoff sampai batas Maximum Retry.
      const delayMs = backoffDelayMs(automation.retryBaseDelaySeconds, attemptCount);
      const nextRetryAt = new Date(Date.now() + delayMs).toISOString();
      finalize("Pending", {
        status: "Pending",
        attempt_count: attemptCount,
        last_error: input.message,
        next_retry_at: nextRetryAt,
      });
      repo.logs.createEvent({
        event_type: "system",
        description: `Klaim @${input.username} gagal sementara (percobaan ${attemptCount}/${Math.max(maxRetries, 1)}), retry otomatis pada ${nextRetryAt}`,
        creator_id: input.creatorId,
        status: "Warning",
      });
      return "Pending";
    }
  }
}

function mapOutcomeToAttemptResult(outcome: string): "Success" | "Failed" | "Already Claimed" | "Verification Required" | "Error" {
  switch (outcome) {
    case "success":
      return "Success";
    case "already_claimed":
      return "Already Claimed";
    case "uncertain":
      return "Verification Required";
    case "transient_error":
    case "hard_error":
    default:
      return "Failed";
  }
}

function setCreatorStatusFromClaim(deps: ClaimDeps, creatorId: string, username: string, claimStatus: ClaimStatus): void {
  const repo = deps.repo;
  const creator = repo.creators.findById(creatorId);
  if (!creator) return;
  let next: string | null = null;
  if (claimStatus === "Success" || claimStatus === "Already Claimed") next = "Claimed";
  else if (claimStatus === "Failed") next = "Failed";
  else if (claimStatus === "Verification Required") next = "Pending";
  else if (claimStatus === "Pending") next = creator.status === "Pending" ? null : "Pending";
  else if (claimStatus === "Processing") next = null;
  if (!next || next === creator.status) return;
  repo.creators.updateFromSource(creator.id, {
    username: creator.username,
    nickname: creator.nickname,
    follower_count: creator.follower_count,
    status: next as never,
    raw_data: creator.raw_data,
  });
  repo.creators.insertStatusHistory(creatorId, creator.status, next as never, `Klaim berstatus ${claimStatus} (@${username})`);
}

/** Operator mencatat hasil klaim assisted (diklaim manual di dashboard sumber). */
export function recordAssistedResult(
  deps: ClaimDeps,
  claimId: string,
  result: AssistedResult,
  actor: AuthUser
): ClaimStatus {
  const repo = deps.repo;
  const claim = repo.claims.findById(claimId);
  if (!claim) throw new ClaimError(404, "NOT_FOUND", "Klaim tidak ditemukan");
  if (claim.status !== "Pending") {
    throw new ClaimError(409, "INVALID_STATE", `Klaim berstatus ${claim.status} tidak dapat dicatat ulang.`);
  }
  const creator = repo.creators.findById(claim.creator_id);
  if (!creator) throw new ClaimError(404, "NOT_FOUND", "Creator tidak ditemukan");

  const outcomeMap: Record<AssistedResult, "success" | "already_claimed" | "transient_error"> = {
    success: "success",
    already_claimed: "already_claimed",
    failed: "transient_error",
  };
  const messageMap: Record<AssistedResult, string> = {
    success: `Diklaim manual oleh ${actor.name} (Assisted Claim Mode)`,
    already_claimed: `Operator melaporkan username sudah diklaim pihak lain (Assisted)`,
    failed: `Operator melaporkan klaim gagal (Assisted)`,
  };
  const final = applyClaimOutcome(deps, {
    claimId,
    creatorId: claim.creator_id,
    username: creator.username,
    outcome: outcomeMap[result],
    message: messageMap[result],
    startedAt: new Date().toISOString(),
    executedBy: actor.id,
  });
  repo.logs.createAudit({
    user_id: actor.id,
    user_email: actor.email,
    action: "claim.assisted_result",
    entity: "claim",
    entity_id: claimId,
    details: { result },
  });
  return final;
}

/** Retry manual klaim gagal (Failed) kembali ke antrian. Verification Required TIDAK boleh lewat sini. */
export function retryClaim(deps: ClaimDeps, claimId: string, actor: AuthUser): ClaimRow {
  const repo = deps.repo;
  const claim = repo.claims.findById(claimId);
  if (!claim) throw new ClaimError(404, "NOT_FOUND", "Klaim tidak ditemukan");
  if (claim.status !== "Failed") {
    throw new ClaimError(409, "INVALID_STATE", `Hanya klaim berstatus Failed yang dapat di-retry (status sekarang: ${claim.status}).`);
  }
  repo.claims.update(claimId, { status: "Pending", next_retry_at: null, last_error: null });
  repo.logs.createAudit({
    user_id: actor.id,
    user_email: actor.email,
    action: "claim.retry",
    entity: "claim",
    entity_id: claimId,
  });
  repo.logs.createEvent({
    event_type: "system",
    description: `Klaim dijadwalkan ulang oleh ${actor.name}`,
    creator_id: claim.creator_id,
    status: "Info",
  });
  return repo.claims.findById(claimId) as ClaimRow;
}

/** Verifikasi manual (khusus Admin) atas klaim Verification Required. */
export function verifyClaim(
  deps: ClaimDeps,
  claimId: string,
  result: Extract<AssistedResult, "success" | "already_claimed" | "failed">,
  admin: AuthUser
): ClaimStatus {
  const repo = deps.repo;
  const claim = repo.claims.findById(claimId);
  if (!claim) throw new ClaimError(404, "NOT_FOUND", "Klaim tidak ditemukan");
  if (claim.status !== "Verification Required") {
    throw new ClaimError(409, "INVALID_STATE", `Hanya klaim berstatus Verification Required yang dapat diverifikasi (status sekarang: ${claim.status}).`);
  }
  const creator = repo.creators.findById(claim.creator_id);
  if (!creator) throw new ClaimError(404, "NOT_FOUND", "Creator tidak ditemukan");
  const outcomeMap = { success: "success", already_claimed: "already_claimed", failed: "hard_error" } as const;
  const final = applyClaimOutcome(deps, {
    claimId,
    creatorId: claim.creator_id,
    username: creator.username,
    outcome: outcomeMap[result],
    message: `Diverifikasi manual oleh ${admin.name}: ${result}`,
    startedAt: new Date().toISOString(),
    executedBy: admin.id,
  });
  repo.claims.update(claimId, { verified_at: new Date().toISOString(), verified_by: admin.id });
  repo.logs.createAudit({
    user_id: admin.id,
    user_email: admin.email,
    action: "claim.verify",
    entity: "claim",
    entity_id: claimId,
    details: { result },
  });
  return final;
}

/**
 * Emergency Stop: dipersistenkan di database (bukan memori) sehingga tidak bisa
 * dilewati dengan restart container. Klaim Processing langsung menjadi Verification Required.
 */
export function triggerEmergencyStop(deps: ClaimDeps, actor: AuthUser): { flipped: number } {
  const repo = deps.repo;
  repo.settings.set("emergency_stop", true, actor.id);
  const flipped = repo.claims.flipProcessingToVerificationRequired("Emergency Stop diaktifkan");
  for (const stale of repo.claims.processingStale(new Date(Date.now() + 86_400_000).toISOString())) {
    // no-op: hanya memastikan tidak ada sisa Processing yang terlewat pada batas waktu ekstrem
    void stale;
  }
  repo.logs.createEvent({
    event_type: "emergency_stop",
    description: `Emergency Stop diaktifkan oleh ${actor.name}. ${flipped} klaim Processing menjadi Verification Required. Scheduler dan worker dihentikan.`,
    status: "Warning",
  });
  repo.logs.createAudit({
    user_id: actor.id,
    user_email: actor.email,
    action: "monitoring.emergency_stop",
    entity: "system",
    details: { flipped },
  });
  return { flipped };
}

/** Hanya Admin yang dapat membuka Emergency Stop (direlease lewat dialog konfirmasi). */
export function releaseEmergencyStop(deps: ClaimDeps, admin: AuthUser): void {
  const repo = deps.repo;
  repo.settings.set("emergency_stop", false, admin.id);
  repo.logs.createEvent({
    event_type: "system",
    description: `Emergency Stop dibuka oleh ${admin.name}. Monitoring dapat dinyalakan kembali.`,
    status: "Info",
  });
  repo.logs.createAudit({
    user_id: admin.id,
    user_email: admin.email,
    action: "monitoring.emergency_release",
    entity: "system",
  });
}

/**
 * Pemulihan klaim yatim (orphan): klaim Processing yang melewati batas waktu
 * dipulihkan menjadi Verification Required TANPA eksekusi ulang.
 */
export function recoverStaleProcessing(deps: ClaimDeps, timeoutMs: number): number {
  const repo = deps.repo;
  const cutoff = new Date(Date.now() - timeoutMs).toISOString();
  const stale = repo.claims.processingStale(cutoff);
  for (const claim of stale) {
    repo.claims.update(claim.id, {
      status: "Verification Required",
      last_error: `Dipulihkan oleh pemulihan crash: eksekusi melewati batas waktu`,
    });
    repo.logs.createEvent({
      event_type: "system",
      description: `Klaim Processing yatim dipulihkan menjadi Verification Required (melewati batas waktu eksekusi)`,
      creator_id: claim.creator_id,
      status: "Warning",
    });
  }
  return stale.length;
}
