import type { SqliteDb } from "../db/connection";
import { logger } from "../logger";
import type { Repository } from "../repository";
import type { CreatorStatus } from "../types";
import type { CreatorItem, SourceAdapter } from "../adapters/types";
import { SourceUnavailableError } from "../adapters/types";
import { isValidUsername } from "../utils/sanitize";
import { NotificationService } from "./notificationService";
import { enqueueIfEligible, isEmergencyStop } from "./claimService";

const LOCK_NAME = "sync";
export const DEFAULT_LOCK_TTL_MS = 60_000;
/** Transaksi chunked: sekitar 500 baris per transaksi agar event loop app API tidak terblokir. */
export const CHUNK_SIZE = 500;

export interface SyncResult {
  ok: boolean;
  skipped?: "locked" | "monitoring_off" | "emergency_stop";
  syncLogId?: string;
  pages?: number;
  items?: number;
  created?: number;
  updated?: number;
  available?: number;
  error?: string;
}

export interface SyncDeps {
  db: SqliteDb;
  repo: Repository;
  source: SourceAdapter;
  notifier: NotificationService;
  /** Identitas proses pemilik lease (instance id worker). */
  owner: string;
  lockTtlMs?: number;
}

interface PageIngestSummary {
  created: number;
  updated: number;
  available: number;
  newAvailableCreators: Array<{ id: string; username: string }>;
  skippedInvalid: number;
}

/**
 * Sinkronisasi pagination-aware dengan lease lock:
 * - Hanya satu sinkronisasi berjalan pada satu waktu (lock berbasis lease di DB).
 * - Lease diperpanjang berkala; lease kedaluwarsa dapat diambil alih worker baru.
 * - Tulisan dibungkus transaksi chunked (<= 500 baris per transaksi).
 * - Perubahan status tercatat di creator_status_histories.
 */
export async function runSync(
  deps: SyncDeps,
  trigger: "schedule" | "manual",
  opts: { respectMonitoring?: boolean; respectEmergencyStop?: boolean } = {}
): Promise<SyncResult> {
  const repo = deps.repo;
  // Emergency Stop menghentikan semua sinkronisasi (jadwal maupun manual).
  if (opts.respectEmergencyStop !== false && repo.settings.get<boolean>("emergency_stop") === true) {
    return { ok: false, skipped: "emergency_stop" };
  }
  // Sinkronisasi terjadwal hanya berjalan saat Monitoring aktif; trigger manual tetap boleh.
  if (opts.respectMonitoring && repo.settings.get<boolean>("monitoring_active") !== true) {
    return { ok: false, skipped: "monitoring_off" };
  }

  const ttl = deps.lockTtlMs ?? DEFAULT_LOCK_TTL_MS;
  const acquired = repo.logs.acquireLock(LOCK_NAME, deps.owner, ttl);
  if (!acquired.acquired) {
    logger.info("Sinkronisasi dilewati: lock sedang dipegang proses lain", { owner: deps.owner, until: acquired.expiresAt });
    return { ok: false, skipped: "locked", error: "Sinkronisasi lain sedang berjalan" };
  }

  const syncLogId = repo.logs.startSyncLog(trigger);
  let pages = 0;
  let items = 0;
  let created = 0;
  let updated = 0;
  let availableDetected = 0;
  const allNewAvailable: Array<{ id: string; username: string }> = [];

  try {
    let page = 1;
    let totalPages = 1;
    const pageSize = CHUNK_SIZE; // ambil maksimal 500 per halaman = 1 transaksi per halaman
    do {
      const res = await deps.source.fetchCreatorsPage(page, pageSize);
      totalPages = Math.max(1, res.totalPages);
      const summary = ingestPage(deps, res.items);
      pages += 1;
      items += res.items.length;
      created += summary.created;
      updated += summary.updated;
      availableDetected += summary.available;
      allNewAvailable.push(...summary.newAvailableCreators);
      page += 1;
      if (page <= totalPages) {
        const renewed = repo.logs.renewLock(LOCK_NAME, deps.owner, ttl);
        if (!renewed) {
          throw new Error("Lease lock hilang: sinkronisasi diambil alih proses lain");
        }
      }
    } while (page <= totalPages);

    repo.logs.finishSyncLog(syncLogId, {
      status: "Success",
      pages,
      items,
      created,
      updated,
      available: availableDetected,
    });

    // Lanjutkan siklus mock agar creator baru muncul pada siklus berikutnya (adapter mock saja).
    if (deps.source instanceof Object && "advanceCycle" in deps.source && typeof deps.source.advanceCycle === "function") {
      (deps.source as unknown as { advanceCycle(): void }).advanceCycle();
    }

    if (availableDetected > 0) {
      const first = allNewAvailable[0];
      const label =
        availableDetected === 1 ? `@${first.username}` : `${availableDetected} creator baru tersedia (termasuk @${first.username})`;
      deps.notifier.notify({
        eventType: "creator_available",
        title: "Creator baru tersedia",
        message: `${label}. Cek halaman Available Creators untuk menindaklanjuti.`,
        creatorId: first.id,
        eventStatus: "Info",
      });

      // Creator yang memenuhi kriteria klaim otomatis masuk claim queue (Pending)
      // tanpa duplikat: unik per creator ditegakkan transaksi + partial unique index.
      if (!isEmergencyStop(deps.repo)) {
        let queued = 0;
        for (const creator of allNewAvailable) {
          const outcome = enqueueIfEligible({ db: deps.db, repo, notifier: deps.notifier, claimAdapter: null }, creator.id, null);
          if (outcome.ok) queued += 1;
        }
        if (queued > 0) {
          logger.info("Creator Available masuk antrian klaim", { queued });
        }
      }
    }

    logger.info("Sinkronisasi selesai", { trigger, pages, items, created, updated, available: availableDetected });
    return { ok: true, syncLogId, pages, items, created, updated, available: availableDetected };
  } catch (err) {
    const message = (err as Error).message;
    repo.logs.finishSyncLog(syncLogId, {
      status: "Failed",
      pages,
      items,
      created,
      updated,
      available: availableDetected,
      error: message,
    });
    repo.logs.createEvent({
      event_type: "sync_failed",
      description: `Sinkronisasi gagal: ${message}`,
      status: "Error",
      metadata: { trigger, pages, items },
    });
    deps.notifier.notify({
      eventType: "sync_failed",
      title: "Sinkronisasi gagal",
      message: `Sinkronisasi data creator gagal: ${message}`,
      eventStatus: "Error",
    });
    if (err instanceof SourceUnavailableError) {
      repo.logs.createEventThrottled(
        { event_type: "source_disconnected", description: `Sumber data terputus: ${message}`, status: "Error" },
        5 * 60_000
      );
      deps.notifier.notify({
        eventType: "source_disconnected",
        title: "Sumber data terputus",
        message,
        eventStatus: "Error",
      });
    }
    logger.error("Sinkronisasi gagal", { error: message, trigger });
    return { ok: false, syncLogId, pages, items, created, updated, available: availableDetected, error: message };
  } finally {
    repo.logs.releaseLock(LOCK_NAME, deps.owner);
  }
}

/** Proses satu halaman item dalam SATU transaksi (halaman <= 500 baris). */
function ingestPage(deps: SyncDeps, items: CreatorItem[]): PageIngestSummary {
  const repo = deps.repo;
  const sourceName = deps.source.name;
  const summary: PageIngestSummary = { created: 0, updated: 0, available: 0, newAvailableCreators: [], skippedInvalid: 0 };

  const tx = deps.db.transaction(() => {
    for (const item of items) {
      const username = String(item.username ?? "").trim();
      const externalId = String(item.externalId ?? "").trim();
      if (!externalId || !isValidUsername(username)) {
        // Input dari sumber eksternal divalidasi server-side; username di luar whitelist ditolak.
        summary.skippedInvalid += 1;
        repo.logs.createEventThrottled(
          {
            event_type: "system",
            description: `Item sumber dilewati: username tidak valid (${username ? username.slice(0, 8) + "..." : "kosong"})`,
            status: "Warning",
          },
          60_000
        );
        continue;
      }
      const status: CreatorStatus = item.status;
      const existing = repo.creators.findByExternalId(sourceName, externalId);
      if (!existing) {
        const sameUsername = repo.creators.findByUsername(sourceName, username);
        if (sameUsername) {
          // Username sama dengan external_id berbeda: konflik dedup, jangan buat baris baru.
          summary.skippedInvalid += 1;
          repo.logs.createEventThrottled(
            { event_type: "system", description: `Konflik dedup: @${username} sudah terdaftar dengan ID sumber berbeda`, status: "Warning" },
            60_000
          );
          continue;
        }
        const row = repo.creators.insertFromSource({
          source: sourceName,
          external_id: externalId,
          username,
          nickname: item.nickname ? String(item.nickname).slice(0, 120) : null,
          follower_count: typeof item.followerCount === "number" && Number.isFinite(item.followerCount) ? Math.max(0, Math.trunc(item.followerCount)) : null,
          status,
          raw_data: item.rawData ? JSON.stringify(item.rawData) : null,
        });
        repo.creators.insertStatusHistory(row.id, null, status, "Terdeteksi pertama kali dari sinkronisasi");
        repo.logs.createEvent({
          event_type: status === "Available" ? "creator_available" : "system",
          description: `Creator @${username} terdeteksi dengan status ${status}`,
          creator_id: row.id,
          status: status === "Available" ? "Success" : "Info",
        });
        summary.created += 1;
        if (status === "Available") {
          summary.available += 1;
          summary.newAvailableCreators.push({ id: row.id, username });
        }
      } else {
        const changed =
          existing.username !== username ||
          existing.status !== status ||
          existing.nickname !== (item.nickname ?? null) ||
          existing.follower_count !== (item.followerCount ?? null);
        if (changed) {
          repo.creators.updateFromSource(existing.id, {
            username,
            nickname: item.nickname ? String(item.nickname).slice(0, 120) : null,
            follower_count: typeof item.followerCount === "number" && Number.isFinite(item.followerCount) ? Math.max(0, Math.trunc(item.followerCount)) : null,
            status,
            raw_data: item.rawData ? JSON.stringify(item.rawData) : null,
          });
          if (existing.status !== status) {
            repo.creators.insertStatusHistory(existing.id, existing.status, status, "Perubahan status dari sinkronisasi");
            repo.logs.createEvent({
              event_type: status === "Available" ? "creator_available" : "system",
              description: `@${username}: status berubah ${existing.status} menjadi ${status}`,
              creator_id: existing.id,
              status: "Info",
            });
            if (status === "Available" && existing.status !== "Available") {
              summary.available += 1;
              summary.newAvailableCreators.push({ id: existing.id, username });
            }
          }
          summary.updated += 1;
        } else {
          // Creator sama dari sinkronisasi berulang: hanya perbarui last_updated_at (dedup).
          repo.creators.touch(existing.id);
          summary.updated += 1;
        }
      }
    }
  });

  tx();
  return summary;
}
