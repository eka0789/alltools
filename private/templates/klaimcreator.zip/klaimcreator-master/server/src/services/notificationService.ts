import type { AppConfig } from "../config";
import { logger } from "../logger";
import type { Repository } from "../repository";
import type { NotificationEventType } from "../types";

export interface AutomationSettings {
  refreshIntervalSeconds: number;
  maxRetries: number;
  retryBaseDelaySeconds: number;
  claimSchedule: { startHour: number; endHour: number; days: number[] };
  notifications: { inApp: boolean; telegram: boolean; email: boolean };
  export: { filenamePrefix: string; usernamesOnlyDefault: boolean };
}

export const DEFAULT_AUTOMATION: AutomationSettings = {
  refreshIntervalSeconds: 60,
  maxRetries: 3,
  retryBaseDelaySeconds: 30,
  claimSchedule: { startHour: 0, endHour: 23, days: [0, 1, 2, 3, 4, 5, 6] },
  notifications: { inApp: true, telegram: false, email: false },
  export: { filenamePrefix: "klaim-creator", usernamesOnlyDefault: false },
};

export function getAutomation(repo: Repository): AutomationSettings {
  const stored = repo.settings.get<Partial<AutomationSettings>>("automation");
  if (!stored) return DEFAULT_AUTOMATION;
  return {
    ...DEFAULT_AUTOMATION,
    ...stored,
    claimSchedule: { ...DEFAULT_AUTOMATION.claimSchedule, ...(stored.claimSchedule ?? {}) },
    notifications: { ...DEFAULT_AUTOMATION.notifications, ...(stored.notifications ?? {}) },
    export: { ...DEFAULT_AUTOMATION.export, ...(stored.export ?? {}) },
  };
}

/** Jadwal operasional klaim (monitoring tetap berjalan di luar jadwal). */
export function isWithinClaimSchedule(automation: AutomationSettings, now = new Date()): boolean {
  const day = now.getDay();
  if (!automation.claimSchedule.days.includes(day)) return false;
  const hour = now.getHours();
  const { startHour, endHour } = automation.claimSchedule;
  if (startHour === endHour) return true;
  if (startHour < endHour) return hour >= startHour && hour < endHour;
  // Jadwal melewati tengah malam (mis. 22 -> 06)
  return hour >= startHour || hour < endHour;
}

/**
 * Notifikasi: selalu tulis in-app (kecuali dimatikan), kirim kanal eksternal
 * (Telegram/email) hanya bila diaktifkan di Automation Settings DAN kredensial ada.
 * Kredensial tidak pernah masuk database, hanya env vars.
 */
export class NotificationService {
  constructor(
    private repo: Repository,
    private cfg: AppConfig
  ) {}

  notify(input: {
    eventType: NotificationEventType;
    title: string;
    message: string;
    creatorId?: string | null;
    eventStatus?: "Info" | "Success" | "Warning" | "Error";
  }): void {
    const automation = getAutomation(this.repo);
    if (automation.notifications.inApp) {
      this.repo.logs.createNotification(input.eventType, input.title, input.message);
    }
    if (automation.notifications.telegram && this.cfg.telegram.botToken && this.cfg.telegram.chatId) {
      void this.sendTelegram(`${input.title}\n${input.message}`).catch((err) =>
        logger.warn("Gagal mengirim notifikasi Telegram", { error: (err as Error).message, eventType: input.eventType })
      );
    }
    if (automation.notifications.email && this.cfg.smtp.host && this.cfg.smtp.from) {
      void this.sendEmail(input.title, input.message).catch((err) =>
        logger.warn("Gagal mengirim notifikasi email", { error: (err as Error).message, eventType: input.eventType })
      );
    }
  }

  private async sendTelegram(text: string): Promise<void> {
    const { botToken, chatId } = this.cfg.telegram;
    if (!botToken || !chatId) return;
    await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text }),
    });
  }

  private async sendEmail(subject: string, text: string): Promise<void> {
    // Pengiriman email via SMTP diimplementasikan dengan HTTP API gateway internal
    // jika SMTP_HOST menunjuk gateway HTTP; untuk SMTP klasik gunakan relay yang
    // tersedia di infrastruktur. Default: dinonaktifkan (nonaktif secara default).
    const host = this.cfg.smtp.host as string;
    if (!/^https?:\/\//.test(host)) {
      logger.info("Kanal email diaktifkan tapi SMTP host bukan gateway HTTP; email dilewati", { host });
      return;
    }
    await fetch(`${host.replace(/\/$/, "")}/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        from: this.cfg.smtp.from,
        to: this.cfg.smtp.user,
        subject,
        text,
      }),
    });
  }
}
