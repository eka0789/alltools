import fs from "node:fs";
import path from "node:path";
import type { SqliteDb } from "../db/connection";
import { logger } from "../logger";
import type { Repository } from "../repository";

const RETENTION_DAYS = 90;
const MAX_BACKUPS = 14;

/**
 * Backup harian konsisten terhadap mode WAL via VACUUM INTO.
 * Ditulis ke BACKUP_DIR terpisah (di luar volume data) sesuai asumsi build.
 */
export function runBackup(db: SqliteDb, backupDir: string): { ok: boolean; file?: string; error?: string } {
  try {
    fs.mkdirSync(backupDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const file = path.join(backupDir, `klaimcreator-${stamp}.db`);
    db.prepare(`VACUUM INTO ?`).run(file);
    pruneOldBackups(backupDir);
    logger.info("Backup database selesai", { file });
    return { ok: true, file };
  } catch (err) {
    logger.error("Backup database gagal", { error: (err as Error).message });
    return { ok: false, error: (err as Error).message };
  }
}

function pruneOldBackups(backupDir: string): void {
  const files = fs
    .readdirSync(backupDir)
    .filter((f) => f.startsWith("klaimcreator-") && f.endsWith(".db"))
    .sort()
    .reverse();
  for (const old of files.slice(MAX_BACKUPS)) {
    try {
      fs.rmSync(path.join(backupDir, old), { force: true });
    } catch {
      // biarkan: pembersihan backup lama tidak boleh menggagalkan backup baru
    }
  }
}

/** Retensi 90 hari hanya untuk notifikasi dan log operasional; data bisnis permanen. */
export function applyRetention(repo: Repository): void {
  const cutoff = new Date(Date.now() - RETENTION_DAYS * 86_400_000).toISOString();
  const result = repo.logs.applyRetention(cutoff);
  logger.info("Retensi 90 hari diterapkan (log operasional + notifikasi)", result);
}
