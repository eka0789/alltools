import cron from "node-cron";
import crypto from "node:crypto";
import type { AppConfig } from "../config";
import type { Repository } from "../repository";
import type { SqliteDb } from "../db/connection";
import { logger } from "../logger";
import type { AdapterBundle } from "../adapters/registry";
import { NotificationService, getAutomation, isWithinClaimSchedule } from "./notificationService";
import { processDueClaims, recoverStaleProcessing } from "./claimService";
import { runSync } from "./syncService";
import { applyRetention, runBackup } from "./backupService";

export interface WorkerDeps {
  db: SqliteDb;
  repo: Repository;
  cfg: AppConfig;
  notifier: NotificationService;
  /** resolveAdapters(repo, cfg) dari pemanggil agar test bisa mengganti adapter. */
  adapters: () => AdapterBundle;
}

export interface WorkerHandle {
  instanceId: string;
  stop: () => Promise<void>;
  /** Trigger sinkronisasi segera (dipakai job poller dan test). */
  runSyncNow: (trigger: "schedule" | "manual") => Promise<void>;
  processClaimsNow: () => Promise<void>;
}

/**
 * Scheduler node-cron HANYA berjalan di service worker:
 * - Sync tiap 1 menit saat Monitoring aktif (state dari database, bukan memori).
 * - Loop klaim otomatis tiap 20 detik.
 * - Poller job tabel (sinkronisasi manual dari dashboard).
 * - Heartbeat 10 detik (dipakai status worker di dashboard + healthcheck).
 * - Pemulihan klaim yatim saat start, watchdog, backup harian, retensi 90 hari.
 * - Graceful shutdown SIGTERM: selesaikan attempt berjalan, simpan state, tutup DB.
 */
export function startWorker(deps: WorkerDeps): WorkerHandle {
  const { db, repo, cfg, notifier } = deps;
  const instanceId = crypto.randomUUID();
  let stopping = false;
  let currentSync: Promise<void> | null = null;
  let currentClaims: Promise<void> | null = null;

  // --- Pemulihan crash: klaim Processing yatim -> Verification Required (tanpa eksekusi ulang)
  const recovered = recoverStaleProcessing({ db, repo, notifier, claimAdapter: null }, cfg.claimTimeoutMs);
  if (recovered > 0) {
    logger.warn("Klaim Processing yatim dipulihkan saat worker start", { recovered });
  }

  repo.settings.set("worker_heartbeat", { at: new Date().toISOString(), instance: instanceId, running: false });
  repo.logs.createEvent({
    event_type: "system",
    description: `Worker aktif (instance ${instanceId.slice(0, 8)}). Pemulihan klaim yatim: ${recovered}.`,
    status: "Info",
  });

  const syncOnce = async (trigger: "schedule" | "manual"): Promise<void> => {
    if (stopping) return;
    const adapters = deps.adapters();
    const promise = runSync(
      { db, repo, source: adapters.source, notifier, owner: instanceId },
      trigger,
      // Terjadwal: hanya saat Monitoring aktif. Manual (job dari dashboard):
      // tetap dicek Emergency Stop tapi boleh berjalan walau Monitoring mati.
      { respectMonitoring: trigger === "schedule", respectEmergencyStop: true }
    ).then(() => undefined);
    currentSync = promise.finally(() => {
      currentSync = null;
    });
    await currentSync;
  };

  const claimsOnce = async (checkSchedule: boolean): Promise<void> => {
    if (stopping) return;
    const adapters = deps.adapters();
    const promise = processDueClaims(
      { db, repo, notifier, claimAdapter: adapters.claim },
      { limit: 10, checkSchedule }
    ).then((result) => {
      if (result.skipped && result.skipped !== "outside_schedule" && result.processed === 0) {
        logger.info("Loop klaim dilewati", { reason: result.skipped });
      }
    });
    currentClaims = promise.finally(() => {
      currentClaims = null;
    });
    await currentClaims;
  };

  // --- Cron: sinkronisasi tiap 1 menit hanya saat Monitoring aktif
  const syncCron = cron.schedule("* * * * *", () => {
    void syncOnce("schedule");
  });

  // --- Loop klaim otomatis (prosesDueClaims mengecek emergency stop, mode, adapter, jadwal)
  const claimsTimer = setInterval(() => {
    void claimsOnce(true);
  }, 20_000);

  // --- Poller job dari app API (sinkronisasi manual, proses klaim manual)
  const jobsTimer = setInterval(() => {
    if (stopping || currentSync) return;
    const job = repo.logs.claimNextJob();
    if (!job) return;
    logger.info("Job diambil worker", { id: job.id, type: job.type });
    if (job.type === "sync_manual") {
      void syncOnce("manual")
        .then(() => repo.logs.finishJob(job.id, true, { note: "sync done" }))
        .catch((err: Error) => repo.logs.finishJob(job.id, false, { error: err.message }));
    } else if (job.type === "process_claims") {
      void claimsOnce(false)
        .then(() => repo.logs.finishJob(job.id, true, { note: "claims done" }))
        .catch((err: Error) => repo.logs.finishJob(job.id, false, { error: err.message }));
    }
  }, 3_000);

  // --- Heartbeat
  const heartbeatTimer = setInterval(() => {
    if (stopping) return;
    repo.settings.set("worker_heartbeat", {
      at: new Date().toISOString(),
      instance: instanceId,
      running: currentSync !== null,
    });
  }, 10_000);

  // --- Watchdog: klaim Processing yang membusuk (worker mati di tengah eksekusi)
  const watchdogTimer = setInterval(() => {
    if (stopping) return;
    const recoveredNow = recoverStaleProcessing({ db, repo, notifier, claimAdapter: null }, cfg.claimTimeoutMs);
    if (recoveredNow > 0) {
      logger.warn("Watchdog memulihkan klaim Processing yatim", { recoveredNow });
    }
  }, 60_000);

  // --- Backup harian 02:30 + retensi 90 hari
  const backupCron = cron.schedule("30 2 * * *", () => {
    runBackup(db, cfg.backupDir);
    applyRetention(repo);
    repo.users.deleteExpiredRefreshTokens();
  });

  logger.info("Worker dimulai", { instanceId, claimTimeoutMs: cfg.claimTimeoutMs });

  const stop = async (): Promise<void> => {
    if (stopping) return;
    stopping = true;
    logger.info("Worker menerima sinyal berhenti: graceful shutdown dimulai");
    syncCron.stop();
    backupCron.stop();
    clearInterval(claimsTimer);
    clearInterval(jobsTimer);
    clearInterval(heartbeatTimer);
    clearInterval(watchdogTimer);

    // Tunggu attempt yang berjalan selesai (maksimal 25 detik).
    const waitWithTimeout = async (p: Promise<void> | null, ms: number): Promise<void> => {
      if (!p) return;
      await Promise.race([
        p.catch(() => undefined),
        new Promise<void>((resolve) => setTimeout(resolve, ms)),
      ]);
    };
    await waitWithTimeout(currentSync, 25_000);
    await waitWithTimeout(currentClaims, 25_000);

    repo.settings.set("worker_heartbeat", { at: new Date().toISOString(), instance: instanceId, running: false, stopped: true });
    repo.logs.createEvent({
      event_type: "worker_stopped",
      description: `Worker berhenti dengan graceful shutdown (instance ${instanceId.slice(0, 8)})`,
      status: "Warning",
    });
    notifier.notify({
      eventType: "worker_stopped",
      title: "Worker berhenti",
      message: "Service worker melakukan graceful shutdown. Monitoring tidak akan berjalan sampai worker aktif kembali.",
      eventStatus: "Warning",
    });
    db.close();
    logger.info("Worker berhenti dengan bersih");
  };

  return {
    instanceId,
    stop,
    runSyncNow: async (trigger) => syncOnce(trigger),
    processClaimsNow: async () => claimsOnce(false),
  };
}
