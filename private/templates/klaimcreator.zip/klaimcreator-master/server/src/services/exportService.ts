import ExcelJS from "exceljs";
import type { Repository } from "../repository";
import type { ClaimStatus } from "../types";
import { buildCsv, sanitizeCell } from "../utils/sanitize";

export interface ExportFilters {
  statuses: ClaimStatus[];
  from: string | null;
  to: string | null;
}

export interface ExportRow {
  no: number;
  creatorId: string;
  username: string;
  claimStatus: string;
  claimDate: string | null;
}

/**
 * Baris export: klaim berstatus tertentu (default Success) tanpa username duplikat.
 * Dedup mempertahankan klaim terbaru per username.
 */
export function getExportRows(repo: Repository, filters: ExportFilters): ExportRow[] {
  const raw = repo.claims.listForExport(filters);
  const byUsername = new Map<string, (typeof raw)[number]>();
  for (const row of raw) {
    const existing = byUsername.get(row.username);
    if (!existing) {
      byUsername.set(row.username, row);
      continue;
    }
    const existingTime = existing.claimed_at ?? existing.created_at;
    const candidateTime = row.claimed_at ?? row.created_at;
    if (candidateTime > existingTime) byUsername.set(row.username, row);
  }
  const deduped = [...byUsername.values()];
  deduped.sort((a, b) => {
    const ta = a.claimed_at ?? a.created_at;
    const tb = b.claimed_at ?? b.created_at;
    return tb.localeCompare(ta);
  });
  return deduped.map((row, index) => ({
    no: index + 1,
    creatorId: row.external_id,
    username: row.username,
    claimStatus: row.status,
    claimDate: row.claimed_at,
  }));
}

export function buildCsvContent(rows: ExportRow[], usernamesOnly: boolean): string {
  if (usernamesOnly) {
    return buildCsv(["Username"], rows.map((r) => [r.username]));
  }
  return buildCsv(
    ["No", "Creator ID", "Username", "Claim Status", "Claim Date"],
    rows.map((r) => [String(r.no), r.creatorId, r.username, r.claimStatus, r.claimDate ?? ""])
  );
}

/** Excel .xlsx via exceljs; sel disanitasi terhadap formula injection. */
export async function buildExcelBuffer(rows: ExportRow[], usernamesOnly: boolean): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "KlaimCreator";
  const sheet = workbook.addWorksheet("Export");
  if (usernamesOnly) {
    sheet.columns = [{ header: "Username", key: "username", width: 32 }];
    for (const row of rows) {
      sheet.addRow({ username: sanitizeCell(row.username) });
    }
  } else {
    sheet.columns = [
      { header: "No", key: "no", width: 6 },
      { header: "Creator ID", key: "creatorId", width: 20 },
      { header: "Username", key: "username", width: 32 },
      { header: "Claim Status", key: "claimStatus", width: 22 },
      { header: "Claim Date", key: "claimDate", width: 24 },
    ];
    for (const row of rows) {
      sheet.addRow({
        no: row.no,
        creatorId: sanitizeCell(row.creatorId),
        username: sanitizeCell(row.username),
        claimStatus: sanitizeCell(row.claimStatus),
        claimDate: row.claimDate ? sanitizeCell(row.claimDate) : "",
      });
    }
  }
  const headerRow = sheet.getRow(1);
  headerRow.font = { bold: true };
  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer as ArrayBuffer);
}

export function exportFileName(prefix: string, ext: "csv" | "xlsx"): string {
  const date = new Date().toISOString().slice(0, 10);
  const safePrefix = prefix.replace(/[^a-zA-Z0-9-_]/g, "-") || "klaim-creator";
  return `${safePrefix}-${date}.${ext}`;
}
