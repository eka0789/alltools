import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import jwt from "jsonwebtoken";
import type { AppConfig } from "../config";
import { logger } from "../logger";
import type { Repository } from "../repository";
import type { AuthUser, Role, UserRow } from "../types";

export const BCRYPT_COST = 12;
export const ACCESS_TOKEN_TTL_SEC = 900; // 15 menit
export const REFRESH_TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 hari
export const MIN_PASSWORD_LENGTH = 8;

export class AuthError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public fields?: Record<string, string>
  ) {
    super(message);
    this.name = "AuthError";
  }
}

function toAuthUser(user: UserRow): AuthUser {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    mustChangePassword: user.must_change_password === 1,
  };
}

/** Service autentikasi: bcrypt cost 12, JWT access pendek, refresh token rotasi. */
export class AuthService {
  constructor(
    private repo: Repository,
    private cfg: AppConfig
  ) {}

  hashPassword(plain: string): string {
    return bcrypt.hashSync(plain, BCRYPT_COST);
  }

  verifyPassword(plain: string, hash: string): boolean {
    return bcrypt.compareSync(plain, hash);
  }

  validatePasswordPolicy(password: string): string | null {
    if (password.length < MIN_PASSWORD_LENGTH) {
      return `Password minimal ${MIN_PASSWORD_LENGTH} karakter`;
    }
    if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
      return "Password harus mengandung huruf dan angka";
    }
    return null;
  }

  login(email: string, password: string): { user: AuthUser; accessToken: string; refreshToken: string } {
    const user = this.repo.users.findByEmail(email);
    if (!user || !this.verifyPassword(password, user.password_hash)) {
      // Pesan generik: tidak membocorkan apakah email terdaftar.
      throw new AuthError(401, "INVALID_CREDENTIALS", "Email atau password salah");
    }
    if (user.is_active !== 1) {
      throw new AuthError(403, "ACCOUNT_DISABLED", "Akun ini dinonaktifkan. Hubungi Admin.");
    }
    const accessToken = this.signAccessToken(user);
    const refreshToken = crypto.randomBytes(48).toString("hex");
    this.repo.users.issueRefreshToken(user.id, refreshToken, REFRESH_TOKEN_TTL_MS);
    return { user: toAuthUser(user), accessToken, refreshToken };
  }

  signAccessToken(user: UserRow): string {
    return jwt.sign({ sub: user.id, email: user.email, name: user.name, role: user.role, epo: user.token_epoch }, this.cfg.jwtSecret, {
      expiresIn: ACCESS_TOKEN_TTL_SEC,
    });
  }

  /** Naikkan epoch sesi: access token lama milik user ini langsung ditolak server. */
  bumpSessionEpoch(userId: string): void {
    this.repo.users.setTokenEpoch(userId, `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`);
  }

  /** Verifikasi JWT + cocokkan epoch sesi + muat user terkini (akun nonaktif tertangkap). */
  verifyAccessToken(token: string): AuthUser {
    let payload: jwt.JwtPayload;
    try {
      payload = jwt.verify(token, this.cfg.jwtSecret) as jwt.JwtPayload;
    } catch {
      throw new AuthError(401, "SESSION_EXPIRED", "Sesi berakhir. Silakan login kembali.");
    }
    const userId = typeof payload.sub === "string" ? payload.sub : null;
    if (!userId) throw new AuthError(401, "SESSION_EXPIRED", "Sesi berakhir. Silakan login kembali.");
    const user = this.repo.users.findById(userId);
    if (!user || user.is_active !== 1) {
      throw new AuthError(401, "SESSION_EXPIRED", "Akun tidak aktif. Silakan login kembali.");
    }
    if (payload.epo !== user.token_epoch) {
      throw new AuthError(401, "SESSION_EXPIRED", "Sesi telah ditutup. Silakan login kembali.");
    }
    return toAuthUser(user);
  }

  /** Rotasi refresh token: token lama dicabut, pasangan baru diterbitkan. */
  refresh(refreshRaw: string): { user: AuthUser; accessToken: string; refreshToken: string } {
    const stored = this.repo.users.findValidRefreshToken(refreshRaw);
    if (!stored) {
      throw new AuthError(401, "SESSION_EXPIRED", "Sesi berakhir. Silakan login kembali.");
    }
    this.repo.users.revokeRefreshToken(stored.id);
    const user = this.repo.users.findById(stored.user_id);
    if (!user || user.is_active !== 1) {
      throw new AuthError(401, "SESSION_EXPIRED", "Akun tidak aktif. Silakan login kembali.");
    }
    const accessToken = this.signAccessToken(user);
    const refreshToken = crypto.randomBytes(48).toString("hex");
    this.repo.users.issueRefreshToken(user.id, refreshToken, REFRESH_TOKEN_TTL_MS);
    return { user: toAuthUser(user), accessToken, refreshToken };
  }

  logout(refreshRaw: string | undefined): void {
    if (!refreshRaw) return;
    const stored = this.repo.users.findValidRefreshToken(refreshRaw);
    if (!stored) return;
    this.repo.users.revokeRefreshToken(stored.id);
    // Access token milik user ini juga dimatikan seketika lewat epoch baru.
    this.bumpSessionEpoch(stored.user_id);
  }

  changePassword(userId: string, currentPassword: string, newPassword: string): AuthUser {
    const user = this.repo.users.findById(userId);
    if (!user) throw new AuthError(404, "NOT_FOUND", "Pengguna tidak ditemukan");
    if (!this.verifyPassword(currentPassword, user.password_hash)) {
      throw new AuthError(400, "VALIDATION", "Password saat ini salah", { currentPassword: "Password saat ini salah" });
    }
    const policyError = this.validatePasswordPolicy(newPassword);
    if (policyError) {
      throw new AuthError(400, "VALIDATION", policyError, { newPassword: policyError });
    }
    this.repo.users.updatePassword(user.id, this.hashPassword(newPassword), false);
    // Semua sesi lama dicabut setelah ganti password (refresh + access token).
    this.repo.users.revokeAllRefreshTokens(user.id);
    this.bumpSessionEpoch(user.id);
    logger.info("Password diganti", { userId: user.id });
    const updated = this.repo.users.findById(user.id) as UserRow;
    return toAuthUser(updated);
  }

  /** Seed admin awal dari env (hanya saat tabel users kosong). Idempotent terhadap race dua proses. */
  ensureSeedAdmin(): { seeded: boolean; email: string | null } {
    if (this.repo.users.countAll() > 0) return { seeded: false, email: null };
    const email = this.cfg.seedAdminEmail;
    const password = this.cfg.seedAdminPassword;
    if (email && password) {
      const policyError = this.validatePasswordPolicy(password);
      if (policyError) throw new Error(`SEED_ADMIN_PASSWORD tidak memenuhi kebijakan: ${policyError}`);
      const created = this.seedOne(email.trim(), "Admin", password, true);
      if (!created) return { seeded: false, email };
      this.repo.logs.createAudit({ action: "system.seed_admin", entity: "user", entity_id: created.id, details: { email: created.email } });
      logger.info("Admin awal di-seed dari environment (wajib ganti password saat login pertama)", { email: created.email });
      return { seeded: true, email: created.email };
    }
    if (this.cfg.isProduction) {
      throw new Error("Database kosong dan SEED_ADMIN_EMAIL/SEED_ADMIN_PASSWORD tidak diisi. Set keduanya di environment produksi.");
    }
    // Dev/test saja: akun sementara yang jelas bukan kredensial produksi.
    const devUser = this.seedOne("admin@klaimcreator.local", "Admin (dev)", "devadmin123", true);
    if (!devUser) return { seeded: false, email: null };
    logger.warn("Mode dev/test: admin sementara dibuat (admin@klaimcreator.local / devadmin123). Jangan pakai di produksi.", {
      userId: devUser.id,
    });
    return { seeded: true, email: devUser.email };
  }

  /**
   * Seed satu akun dengan aman: app dan worker bisa boot bersamaan pada database
   * kosong yang sama; proses kedua menyerang UNIQUE(email) dan menganggap sudah di-seed.
   */
  private seedOne(email: string, name: string, password: string, mustChange: boolean): UserRow | null {
    const existing = this.repo.users.findByEmail(email);
    if (existing) return null;
    try {
      return this.repo.users.create({
        email,
        name,
        passwordHash: this.hashPassword(password),
        role: "admin" as Role,
        mustChangePassword: mustChange,
      });
    } catch (err) {
      const code = (err as { code?: string }).code ?? "";
      if (code.includes("UNIQUE")) return null; // proses lain menang race seed
      throw err;
    }
  }
}
