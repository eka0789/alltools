export type Role = "admin" | "operator";

export type CreatorStatus = "Available" | "Claimed" | "Pending" | "Failed" | "Unavailable";

export type ClaimStatus =
  | "Pending"
  | "Processing"
  | "Success"
  | "Failed"
  | "Already Claimed"
  | "Verification Required";

export type ClaimMode = "automatic" | "assisted";

export interface UserRow {
  id: string;
  email: string;
  name: string;
  password_hash: string;
  role: Role;
  is_active: number;
  must_change_password: number;
  token_epoch: string;
  created_at: string;
  updated_at: string;
}

export interface CreatorRow {
  id: string;
  source: string;
  external_id: string;
  username: string;
  nickname: string | null;
  follower_count: number | null;
  status: CreatorStatus;
  raw_data: string | null;
  first_seen_at: string;
  last_updated_at: string;
}

export interface ClaimRow {
  id: string;
  creator_id: string;
  status: ClaimStatus;
  mode: ClaimMode;
  requested_by: string | null;
  attempt_count: number;
  next_retry_at: string | null;
  last_error: string | null;
  claimed_at: string | null;
  verified_at: string | null;
  verified_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ClaimAttemptRow {
  id: string;
  claim_id: string;
  attempt_number: number;
  result: string;
  message: string | null;
  executed_by: string | null;
  started_at: string;
  finished_at: string | null;
}

export interface CreatorStatusHistoryRow {
  id: string;
  creator_id: string;
  old_status: string | null;
  new_status: string;
  reason: string | null;
  changed_at: string;
}

export interface SyncLogRow {
  id: string;
  trigger: "schedule" | "manual";
  status: "Success" | "Failed";
  started_at: string;
  finished_at: string | null;
  pages_fetched: number;
  items_fetched: number;
  items_created: number;
  items_updated: number;
  available_detected: number;
  error: string | null;
}

export interface SystemEventRow {
  id: string;
  event_type: string;
  description: string;
  creator_id: string | null;
  status: "Info" | "Success" | "Warning" | "Error";
  metadata: string | null;
  created_at: string;
}

export interface AuditLogRow {
  id: string;
  user_id: string | null;
  user_email: string | null;
  action: string;
  entity: string | null;
  entity_id: string | null;
  details: string | null;
  ip: string | null;
  created_at: string;
}

export interface NotificationRow {
  id: string;
  event_type: string;
  title: string;
  message: string;
  is_read: number;
  created_at: string;
}

export interface JobRow {
  id: string;
  type: "sync_manual" | "process_claims";
  payload: string | null;
  status: "queued" | "running" | "done" | "failed";
  requested_by: string | null;
  result: string | null;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
}

export interface SyncLockRow {
  lock_name: string;
  owner: string;
  expires_at: string;
  renewed_at: string;
}

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: Role;
  mustChangePassword: boolean;
}

/** Event types notifikasi in-app (7 jenis inti PRD + pelengkap operasional). */
export const NOTIFICATION_EVENT_TYPES = [
  "creator_available",
  "claim_success",
  "claim_failed",
  "session_expired",
  "source_disconnected",
  "sync_failed",
  "worker_stopped",
] as const;
export type NotificationEventType = (typeof NOTIFICATION_EVENT_TYPES)[number];
