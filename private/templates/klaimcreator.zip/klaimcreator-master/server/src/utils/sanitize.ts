/**
 * Util keamanan export dan validasi username dari sumber eksternal.
 */

/** Whitelist username: huruf, angka, titik, underscore (pola TikTok), 2-30 karakter. */
export const USERNAME_REGEX = /^[A-Za-z0-9._]{2,30}$/;

export function isValidUsername(username: string): boolean {
  return USERNAME_REGEX.test(username);
}

/**
 * Sanitasi formula injection (CSV/Excel):
 * sel berawalan '=', '+', '-', '@', TAB, atau CR di-escape dengan prefix kutip
 * sehingga tidak pernah tereksekusi sebagai formula saat dibuka di Excel.
 */
export function sanitizeCell(value: string): string {
  if (value.length > 0 && /^[=+@\t\r-]/.test(value)) {
    return `'${value}`;
  }
  return value;
}

function csvEscape(value: string): string {
  if (/[",\n\r]/.test(value)) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

export interface CsvColumn {
  header: string;
  value: (row: string[]) => string;
}

/** Builder CSV dengan BOM UTF-8 (agar Excel membaca unicode dengan benar) + CRLF. */
export function buildCsv(headers: string[], rows: string[][]): string {
  const lines: string[] = [];
  lines.push(headers.map((h) => csvEscape(sanitizeCell(h))).join(","));
  for (const row of rows) {
    lines.push(row.map((cell) => csvEscape(sanitizeCell(String(cell ?? "")))).join(","));
  }
  return `\uFEFF${lines.join("\r\n")}\r\n`;
}
