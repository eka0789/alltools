import type { SqliteDb } from "../db/connection";

/**
 * Repository app_settings: key-value JSON.
 * Kredensial integrasi TIDAK PERNAH disimpan di sini, hanya nama referensi
 * variabel environment (PRD 3G).
 */
export function createSettingsRepository(db: SqliteDb) {
  const qGet = db.prepare(`SELECT value FROM app_settings WHERE key = ?`);
  const qUpsert = db.prepare(
    `INSERT INTO app_settings (key, value, updated_at, updated_by) VALUES (?, ?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at, updated_by = excluded.updated_by`
  );
  const qAll = db.prepare(`SELECT key, value FROM app_settings`);

  return {
    get<T>(key: string): T | null {
      const row = qGet.get(key) as { value: string } | undefined;
      if (!row) return null;
      try {
        return JSON.parse(row.value) as T;
      } catch {
        return null;
      }
    },
    set(key: string, value: unknown, updatedBy: string | null = null): void {
      qUpsert.run(key, JSON.stringify(value), new Date().toISOString(), updatedBy);
    },
    ensureDefaults(defaults: Record<string, unknown>): void {
      const insertMissing = db.prepare(
        `INSERT INTO app_settings (key, value, updated_at, updated_by) VALUES (?, ?, ?, NULL)
         ON CONFLICT(key) DO NOTHING`
      );
      const tx = db.transaction((entries: Array<[string, unknown]>) => {
        for (const [key, value] of entries) insertMissing.run(key, JSON.stringify(value), new Date().toISOString());
      });
      tx(Object.entries(defaults));
    },
    all(): Record<string, unknown> {
      const rows = qAll.all() as Array<{ key: string; value: string }>;
      const out: Record<string, unknown> = {};
      for (const row of rows) {
        try {
          out[row.key] = JSON.parse(row.value);
        } catch {
          out[row.key] = row.value;
        }
      }
      return out;
    },
  };
}

export type SettingsRepository = ReturnType<typeof createSettingsRepository>;
