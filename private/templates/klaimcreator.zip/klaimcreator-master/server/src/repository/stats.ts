import type { SqliteDb } from "../db/connection";

/** Agregat dashboard (dihitung di SQL, bukan di memori). */
export function createStatsRepository(db: SqliteDb) {
  const countCreators = db.prepare(`SELECT COUNT(*) AS n FROM creators`);
  const countCreatorsByStatus = db.prepare(`SELECT status, COUNT(*) AS n FROM creators GROUP BY status`);
  const countClaimsByStatus = db.prepare(`SELECT status, COUNT(*) AS n FROM claims GROUP BY status`);
  const lastSync = db.prepare(
    `SELECT started_at, finished_at, status FROM synchronization_logs ORDER BY started_at DESC LIMIT 1`
  );

  return {
    creatorCounts(): { total: number; byStatus: Record<string, number> } {
      const total = (countCreators.get() as { n: number }).n;
      const byStatus: Record<string, number> = {};
      for (const row of countCreatorsByStatus.all() as Array<{ status: string; n: number }>) {
        byStatus[row.status] = row.n;
      }
      return { total, byStatus };
    },
    claimCounts(): Record<string, number> {
      const out: Record<string, number> = {};
      for (const row of countClaimsByStatus.all() as Array<{ status: string; n: number }>) {
        out[row.status] = row.n;
      }
      return out;
    },
    lastSync(): { started_at: string; finished_at: string | null; status: string } | null {
      return (lastSync.get() as { started_at: string; finished_at: string | null; status: string } | undefined) ?? null;
    },
  };
}

export type StatsRepository = ReturnType<typeof createStatsRepository>;
