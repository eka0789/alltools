import crypto from "node:crypto";
import type { SqliteDb } from "../db/connection";
import type { AuditLogRow, JobRow, NotificationRow, SyncLockRow, SyncLogRow, SystemEventRow } from "../types";

/** Repository logs: synchronization_logs, system_events, audit_logs (append-only), notifications, jobs, sync_locks. */
export function createLogRepository(db: SqliteDb) {
  // --- synchronization_logs ---
  const slInsert = db.prepare(
    `INSERT INTO synchronization_logs (id, trigger, status, started_at, pages_fetched, items_fetched, items_created, items_updated, available_detected, error)
     VALUES (?, ?, 'Success', ?, 0, 0, 0, 0, 0, NULL)`
  );
  const slFinish = db.prepare(
    `UPDATE synchronization_logs SET status = ?, finished_at = ?, pages_fetched = ?, items_fetched = ?,
       items_created = ?, items_updated = ?, available_detected = ?, error = ?
     WHERE id = ?`
  );
  const slLatest = db.prepare(`SELECT * FROM synchronization_logs ORDER BY started_at DESC LIMIT ?`);
  const slPerDay = db.prepare(
    `SELECT substr(started_at, 1, 10) AS day, COUNT(*) AS n FROM synchronization_logs
     WHERE substr(started_at, 1, 10) >= ? GROUP BY day ORDER BY day ASC`
  );
  const slDeleteOlderThan = db.prepare(`DELETE FROM synchronization_logs WHERE started_at < ?`);

  // --- system_events ---
  const evInsert = db.prepare(
    `INSERT INTO system_events (id, event_type, description, creator_id, status, metadata, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  const evList = db.prepare(
    `SELECT e.*, c.username AS creator_username FROM system_events e
     LEFT JOIN creators c ON c.id = e.creator_id
     WHERE (@type IS NULL OR e.event_type = @type)
       AND (@status IS NULL OR e.status = @status)
       AND (@creatorId IS NULL OR e.creator_id = @creatorId)
     ORDER BY e.created_at DESC, e.rowid DESC
     LIMIT @limit OFFSET @offset`
  );
  const evCount = db.prepare(
    `SELECT COUNT(*) AS n FROM system_events e
     WHERE (@type IS NULL OR e.event_type = @type)
       AND (@status IS NULL OR e.status = @status)
       AND (@creatorId IS NULL OR e.creator_id = @creatorId)`
  );
  const evRecentOfType = db.prepare(
    `SELECT * FROM system_events WHERE event_type = ? AND created_at > ? ORDER BY created_at DESC LIMIT 1`
  );
  const evDeleteOlderThan = db.prepare(`DELETE FROM system_events WHERE created_at < ?`);

  // --- audit_logs (append-only; tidak ada fungsi update/delete) ---
  const auInsert = db.prepare(
    `INSERT INTO audit_logs (id, user_id, user_email, action, entity, entity_id, details, ip, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const auList = db.prepare(
    `SELECT * FROM audit_logs
     WHERE (@action IS NULL OR action LIKE @action)
       AND (@userId IS NULL OR user_id = @userId)
     ORDER BY created_at DESC, rowid DESC
     LIMIT @limit OFFSET @offset`
  );
  const auCount = db.prepare(
    `SELECT COUNT(*) AS n FROM audit_logs
     WHERE (@action IS NULL OR action LIKE @action)
       AND (@userId IS NULL OR user_id = @userId)`
  );

  // --- notifications ---
  const ntInsert = db.prepare(
    `INSERT INTO notifications (id, event_type, title, message, is_read, created_at) VALUES (?, ?, ?, ?, 0, ?)`
  );
  const ntList = db.prepare(`SELECT * FROM notifications ORDER BY created_at DESC, rowid DESC LIMIT ?`);
  const ntUnread = db.prepare(`SELECT COUNT(*) AS n FROM notifications WHERE is_read = 0`);
  const ntMarkRead = db.prepare(`UPDATE notifications SET is_read = 1 WHERE id = ?`);
  const ntMarkAllRead = db.prepare(`UPDATE notifications SET is_read = 1 WHERE is_read = 0`);
  const ntDeleteOlderThan = db.prepare(`DELETE FROM notifications WHERE created_at < ?`);

  // --- jobs (antrian berbasis tabel, pengganti Redis/Celery) ---
  const jobInsert = db.prepare(
    `INSERT INTO jobs (id, type, payload, status, requested_by, created_at) VALUES (?, ?, ?, 'queued', ?, ?)`
  );
  const jobClaimNext = db.prepare(`SELECT * FROM jobs WHERE status = 'queued' ORDER BY created_at ASC LIMIT 1`);
  const jobSetRunning = db.prepare(`UPDATE jobs SET status = 'running', started_at = ? WHERE id = ? AND status = 'queued'`);
  const jobFinish = db.prepare(`UPDATE jobs SET status = ?, result = ?, finished_at = ? WHERE id = ?`);
  const jobPendingCount = db.prepare(`SELECT COUNT(*) AS n FROM jobs WHERE status = 'queued'`);

  // --- sync_locks (lease) ---
  // Takeover hanya bila lease LAMA sudah kedaluwarsa dibanding WAKTU SEKARANG
  // (strftime menghasilkan format ISO-8601 UTC yang cocok dengan Date.toISOString).
  const lockGet = db.prepare(`SELECT * FROM sync_locks WHERE lock_name = ?`);
  const lockInsert = db.prepare(
    `INSERT INTO sync_locks (lock_name, owner, expires_at, renewed_at) VALUES (?, ?, ?, ?)
     ON CONFLICT(lock_name) DO UPDATE SET owner = excluded.owner, expires_at = excluded.expires_at, renewed_at = excluded.renewed_at
     WHERE sync_locks.expires_at < strftime('%Y-%m-%dT%H:%M:%fZ','now')`
  );
  const lockRenew = db.prepare(
    `UPDATE sync_locks SET expires_at = ?, renewed_at = ? WHERE lock_name = ? AND owner = ?`
  );
  const lockRelease = db.prepare(`DELETE FROM sync_locks WHERE lock_name = ? AND owner = ?`);

  return {
    // synchronization_logs
    startSyncLog(trigger: "schedule" | "manual"): string {
      const id = crypto.randomUUID();
      slInsert.run(id, trigger, new Date().toISOString());
      return id;
    },
    finishSyncLog(
      id: string,
      result: { status: "Success" | "Failed"; pages: number; items: number; created: number; updated: number; available: number; error?: string | null }
    ): void {
      slFinish.run(
        result.status,
        new Date().toISOString(),
        result.pages,
        result.items,
        result.created,
        result.updated,
        result.available,
        result.error ?? null,
        id
      );
    },
    listSyncLogs(limit: number): SyncLogRow[] {
      return slLatest.all(limit) as SyncLogRow[];
    },
    syncPerDay(days: number): Array<{ day: string; n: number }> {
      const since = new Date(Date.now() - (days - 1) * 86_400_000).toISOString().slice(0, 10);
      return slPerDay.all(since) as Array<{ day: string; n: number }>;
    },
    deleteOldSyncLogs(cutoffIso: string): void {
      slDeleteOlderThan.run(cutoffIso);
    },

    // system_events
    createEvent(input: {
      event_type: string;
      description: string;
      creator_id?: string | null;
      status?: "Info" | "Success" | "Warning" | "Error";
      metadata?: Record<string, unknown> | null;
    }): void {
      evInsert.run(
        crypto.randomUUID(),
        input.event_type,
        input.description,
        input.creator_id ?? null,
        input.status ?? "Info",
        input.metadata ? JSON.stringify(input.metadata) : null,
        new Date().toISOString()
      );
    },
    /** Mencegah event duplikat beruntun: hanya buat bila tidak ada event serupa dalam window. */
    createEventThrottled(
      input: { event_type: string; description: string; creator_id?: string | null; status?: "Info" | "Success" | "Warning" | "Error"; metadata?: Record<string, unknown> | null },
      throttleMs: number
    ): boolean {
      const cutoff = new Date(Date.now() - throttleMs).toISOString();
      const recent = evRecentOfType.get(input.event_type, cutoff) as SystemEventRow | undefined;
      if (recent) return false;
      this.createEvent(input);
      return true;
    },
    listEvents(opts: { type?: string | null; status?: string | null; creatorId?: string | null; page: number; pageSize: number }): {
      items: Array<SystemEventRow & { creator_username: string | null }>;
      total: number;
    } {
      const params = { type: opts.type ?? null, status: opts.status ?? null, creatorId: opts.creatorId ?? null };
      const total = (evCount.get(params) as { n: number }).n;
      const items = evList.all({ ...params, limit: opts.pageSize, offset: (opts.page - 1) * opts.pageSize }) as Array<
        SystemEventRow & { creator_username: string | null }
      >;
      return { items, total };
    },
    deleteOldEvents(cutoffIso: string): void {
      evDeleteOlderThan.run(cutoffIso);
    },

    // audit_logs (append-only)
    createAudit(input: {
      user_id?: string | null;
      user_email?: string | null;
      action: string;
      entity?: string | null;
      entity_id?: string | null;
      details?: Record<string, unknown> | null;
      ip?: string | null;
    }): void {
      auInsert.run(
        crypto.randomUUID(),
        input.user_id ?? null,
        input.user_email ?? null,
        input.action,
        input.entity ?? null,
        input.entity_id ?? null,
        input.details ? JSON.stringify(input.details) : null,
        input.ip ?? null,
        new Date().toISOString()
      );
    },
    listAudit(opts: { action?: string | null; userId?: string | null; page: number; pageSize: number }): {
      items: AuditLogRow[];
      total: number;
    } {
      const params = { action: opts.action ? `${opts.action}%` : null, userId: opts.userId ?? null };
      const total = (auCount.get(params) as { n: number }).n;
      const items = auList.all({ ...params, limit: opts.pageSize, offset: (opts.page - 1) * opts.pageSize }) as AuditLogRow[];
      return { items, total };
    },

    // notifications
    createNotification(eventType: string, title: string, message: string): void {
      ntInsert.run(crypto.randomUUID(), eventType, title, message, new Date().toISOString());
    },
    listNotifications(limit: number): NotificationRow[] {
      return ntList.all(limit) as NotificationRow[];
    },
    unreadCount(): number {
      return (ntUnread.get() as { n: number }).n;
    },
    markRead(ids: string[]): void {
      const tx = db.transaction((list: string[]) => {
        for (const id of list) ntMarkRead.run(id);
      });
      tx(ids);
    },
    markAllRead(): void {
      ntMarkAllRead.run();
    },
    deleteOldNotifications(cutoffIso: string): void {
      ntDeleteOlderThan.run(cutoffIso);
    },

    // jobs
    enqueueJob(type: "sync_manual" | "process_claims", requestedBy: string | null, payload?: Record<string, unknown>): string {
      const id = crypto.randomUUID();
      jobInsert.run(id, type, payload ? JSON.stringify(payload) : null, requestedBy, new Date().toISOString());
      return id;
    },
    /** Ambil satu job queued secara atomik (transaksi) untuk diproses worker. */
    claimNextJob(): JobRow | null {
      const claim = db.transaction((): JobRow | null => {
        const job = jobClaimNext.get() as JobRow | undefined;
        if (!job) return null;
        const info = jobSetRunning.run(new Date().toISOString(), job.id);
        if (info.changes === 0) return null;
        return { ...job, status: "running" };
      });
      return claim();
    },
    finishJob(id: string, ok: boolean, result?: Record<string, unknown>): void {
      jobFinish.run(ok ? "done" : "failed", result ? JSON.stringify(result) : null, new Date().toISOString(), id);
    },
    queuedJobCount(): number {
      return (jobPendingCount.get() as { n: number }).n;
    },

    // sync_locks (lease-based lock)
    getLock(name: string): SyncLockRow | null {
      return (lockGet.get(name) as SyncLockRow | undefined) ?? null;
    },
    /** Ambil lock bila bebas atau lease-nya sudah kedaluwarsa (takeover setelah crash). */
    acquireLock(name: string, owner: string, ttlMs: number): { acquired: boolean; expiresAt: string } {
      const now = Date.now();
      const expiresAt = new Date(now + ttlMs).toISOString();
      const info = lockInsert.run(name, owner, expiresAt, new Date(now).toISOString());
      if (info.changes > 0) {
        const row = this.getLock(name);
        // INSERT OR CONFLICT-UPDATE hanya menimpa bila lease lama kedaluwarsa;
        // bila update terjadi, owner sekarang pasti milik kita. Validasi lagi untuk kepastian.
        if (row && row.owner === owner) return { acquired: true, expiresAt: row.expires_at };
        return { acquired: false, expiresAt: row ? row.expires_at : expiresAt };
      }
      const row = this.getLock(name);
      return { acquired: false, expiresAt: row ? row.expires_at : expiresAt };
    },
    renewLock(name: string, owner: string, ttlMs: number): boolean {
      const info = lockRenew.run(new Date(Date.now() + ttlMs).toISOString(), new Date().toISOString(), name, owner);
      return info.changes > 0;
    },
    releaseLock(name: string, owner: string): void {
      lockRelease.run(name, owner);
    },

    // Retensi 90 hari (hanya log operasional dan notifikasi; data bisnis tidak pernah dihapus)
    applyRetention(nowIso: string): { notifications: number; events: number; syncLogs: number; refreshTokens: number } {
      const beforeN = (db.prepare(`SELECT COUNT(*) AS n FROM notifications WHERE created_at < ?`).get(nowIso) as { n: number }).n;
      const beforeE = (db.prepare(`SELECT COUNT(*) AS n FROM system_events WHERE created_at < ?`).get(nowIso) as { n: number }).n;
      const beforeS = (db.prepare(`SELECT COUNT(*) AS n FROM synchronization_logs WHERE started_at < ?`).get(nowIso) as { n: number }).n;
      ntDeleteOlderThan.run(nowIso);
      evDeleteOlderThan.run(nowIso);
      slDeleteOlderThan.run(nowIso);
      db.prepare(`DELETE FROM refresh_tokens WHERE expires_at < ?`).run(nowIso);
      return { notifications: beforeN, events: beforeE, syncLogs: beforeS, refreshTokens: 0 };
    },
  };
}

export type LogRepository = ReturnType<typeof createLogRepository>;
