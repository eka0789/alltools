import crypto from "node:crypto";
import type { SqliteDb } from "../db/connection";
import type { Role, UserRow } from "../types";

/**
 * Repository users + refresh tokens. Semua akses data users wajib lewat modul ini.
 * Setiap query memakai prepared statement parameterized (tidak ada konkatenasi SQL).
 */
export function createUserRepository(db: SqliteDb) {
  const qFindById = db.prepare(`SELECT * FROM users WHERE id = ?`);
  const qFindByEmail = db.prepare(`SELECT * FROM users WHERE email = ? COLLATE NOCASE`);
  const qListAll = db.prepare(`SELECT * FROM users ORDER BY created_at ASC`);
  const qCountAll = db.prepare(`SELECT COUNT(*) AS n FROM users`);
  const qInsert = db.prepare(
    `INSERT INTO users (id, email, name, password_hash, role, is_active, must_change_password, created_at, updated_at)
     VALUES (@id, @email, @name, @password_hash, @role, @is_active, @must_change_password, @created_at, @updated_at)`
  );
  const qUpdateProfile = db.prepare(`UPDATE users SET name = ?, role = ?, updated_at = ? WHERE id = ?`);
  const qUpdatePassword = db.prepare(
    `UPDATE users SET password_hash = ?, must_change_password = ?, updated_at = ? WHERE id = ?`
  );
  const qSetActive = db.prepare(`UPDATE users SET is_active = ?, updated_at = ? WHERE id = ?`);
  const qSetTokenEpoch = db.prepare(`UPDATE users SET token_epoch = ?, updated_at = ? WHERE id = ?`);
  const qCountActiveAdmins = db.prepare(
    `SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND is_active = 1 AND id != ?`
  );

  const rtInsert = db.prepare(
    `INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)`
  );
  const rtFindByHash = db.prepare(`SELECT * FROM refresh_tokens WHERE token_hash = ? AND revoked_at IS NULL`);
  const rtRevoke = db.prepare(`UPDATE refresh_tokens SET revoked_at = ? WHERE id = ?`);
  const rtRevokeAllForUser = db.prepare(
    `UPDATE refresh_tokens SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL`
  );
  const rtDeleteExpired = db.prepare(`DELETE FROM refresh_tokens WHERE expires_at < ?`);

  return {
    countAll(): number {
      return (qCountAll.get() as { n: number }).n;
    },
    findById(id: string): UserRow | null {
      return (qFindById.get(id) as UserRow | undefined) ?? null;
    },
    findByEmail(email: string): UserRow | null {
      return (qFindByEmail.get(email) as UserRow | undefined) ?? null;
    },
    listAll(): Omit<UserRow, "password_hash">[] {
      return (qListAll.all() as UserRow[]).map(({ password_hash: _ph, ...rest }) => rest);
    },
    create(input: { email: string; name: string; passwordHash: string; role: Role; mustChangePassword?: boolean }): UserRow {
      const now = new Date().toISOString();
      const row: UserRow = {
        id: crypto.randomUUID(),
        email: input.email.trim(),
        name: input.name.trim(),
        password_hash: input.passwordHash,
        role: input.role,
        is_active: 1,
        must_change_password: input.mustChangePassword ? 1 : 0,
        token_epoch: "0",
        created_at: now,
        updated_at: now,
      };
      qInsert.run(row);
      return row;
    },
    updateProfile(id: string, name: string, role: Role): void {
      qUpdateProfile.run(name.trim(), role, new Date().toISOString(), id);
    },
    updatePassword(id: string, passwordHash: string, mustChange: boolean): void {
      qUpdatePassword.run(passwordHash, mustChange ? 1 : 0, new Date().toISOString(), id);
    },
    setActive(id: string, active: boolean): void {
      qSetActive.run(active ? 1 : 0, new Date().toISOString(), id);
    },
    /** Epoch sesi baru: semua access token JWT lama milik user ini menjadi invalid. */
    setTokenEpoch(id: string, epoch: string): void {
      qSetTokenEpoch.run(epoch, new Date().toISOString(), id);
    },
    countOtherActiveAdmins(excludeUserId: string): number {
      return (qCountActiveAdmins.get(excludeUserId) as { n: number }).n;
    },

    // --- Refresh tokens (disimpan sebagai SHA-256 hash, bukan nilai mentah) ---
    issueRefreshToken(userId: string, tokenRaw: string, ttlMs: number): void {
      const tokenHash = crypto.createHash("sha256").update(tokenRaw).digest("hex");
      rtInsert.run(crypto.randomUUID(), userId, tokenHash, new Date(Date.now() + ttlMs).toISOString(), new Date().toISOString());
    },
    findValidRefreshToken(tokenRaw: string): { id: string; user_id: string } | null {
      const tokenHash = crypto.createHash("sha256").update(tokenRaw).digest("hex");
      const row = rtFindByHash.get(tokenHash) as { id: string; user_id: string; expires_at: string } | undefined;
      if (!row) return null;
      if (new Date(row.expires_at).getTime() < Date.now()) return null;
      return { id: row.id, user_id: row.user_id };
    },
    revokeRefreshToken(id: string): void {
      rtRevoke.run(new Date().toISOString(), id);
    },
    revokeAllRefreshTokens(userId: string): void {
      rtRevokeAllForUser.run(new Date().toISOString(), userId);
    },
    deleteExpiredRefreshTokens(): void {
      rtDeleteExpired.run(new Date().toISOString());
    },
  };
}

export type UserRepository = ReturnType<typeof createUserRepository>;
