import type { SqliteDb } from "../db/connection";
import { createClaimRepository, type ClaimRepository } from "./claims";
import { createCreatorRepository, type CreatorRepository } from "./creators";
import { createLogRepository, type LogRepository } from "./logs";
import { createSettingsRepository, type SettingsRepository } from "./settings";
import { createStatsRepository, type StatsRepository } from "./stats";
import { createUserRepository, type UserRepository } from "./users";

/**
 * SATU modul repository untuk seluruh akses data KlaimCreator.
 * Tidak ada modul lain yang boleh menjalankan SQL langsung.
 * Semua query di sini memakai prepared statements parameterized.
 */
export interface Repository {
  users: UserRepository;
  creators: CreatorRepository;
  claims: ClaimRepository;
  settings: SettingsRepository;
  logs: LogRepository;
  stats: StatsRepository;
}

export function makeRepository(db: SqliteDb): Repository {
  return {
    users: createUserRepository(db),
    creators: createCreatorRepository(db),
    claims: createClaimRepository(db),
    settings: createSettingsRepository(db),
    logs: createLogRepository(db),
    stats: createStatsRepository(db),
  };
}

export const DEFAULT_SETTINGS: Record<string, unknown> = {
  monitoring_active: false,
  emergency_stop: false,
  claim_mode: "assisted",
  automation: {
    refreshIntervalSeconds: 60,
    maxRetries: 3,
    retryBaseDelaySeconds: 30,
    claimSchedule: { startHour: 0, endHour: 23, days: [0, 1, 2, 3, 4, 5, 6] },
    notifications: { inApp: true, telegram: false, email: false },
    export: { filenamePrefix: "klaim-creator", usernamesOnlyDefault: false },
  },
  integration: {
    adapter: "mock",
    official: {
      enabled: false,
      baseUrlEnv: "OFFICIAL_API_BASE_URL",
      apiKeyEnv: "OFFICIAL_API_KEY",
      claimPath: "/v1/claims",
    },
    mock: {
      pages: 3,
      itemsPerPage: 15,
      newItemsPerCycle: 2,
      faultMode: "none",
    },
  },
  source_last_check: null,
  worker_heartbeat: null,
};
