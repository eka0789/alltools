import crypto from "node:crypto";
import type { SqliteDb } from "../db/connection";
import type { CreatorRow, CreatorStatus, CreatorStatusHistoryRow } from "../types";

/** Repository creators + riwayat status. Semua query parameterized. */
export function createCreatorRepository(db: SqliteDb) {
  const qById = db.prepare(`SELECT * FROM creators WHERE id = ?`);
  const qByExternalId = db.prepare(`SELECT * FROM creators WHERE source = ? AND external_id = ?`);
  const qByUsername = db.prepare(`SELECT * FROM creators WHERE source = ? AND username = ?`);
  const qInsert = db.prepare(
    `INSERT INTO creators (id, source, external_id, username, nickname, follower_count, status, raw_data, first_seen_at, last_updated_at)
     VALUES (@id, @source, @external_id, @username, @nickname, @follower_count, @status, @raw_data, @first_seen_at, @last_updated_at)`
  );
  const qUpdateFromSource = db.prepare(
    `UPDATE creators SET username = @username, nickname = @nickname, follower_count = @follower_count,
       status = @status, raw_data = @raw_data, last_updated_at = @last_updated_at
     WHERE id = @id`
  );
  const qTouch = db.prepare(`UPDATE creators SET last_updated_at = ? WHERE id = ?`);
  const qHistoryInsert = db.prepare(
    `INSERT INTO creator_status_histories (id, creator_id, old_status, new_status, reason, changed_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  );
  const qHistoryByCreator = db.prepare(
    `SELECT * FROM creator_status_histories WHERE creator_id = ? ORDER BY changed_at DESC, rowid DESC LIMIT ?`
  );
  const qCountAll = db.prepare(`SELECT COUNT(*) AS n FROM creators`);

  return {
    countAll(): number {
      return (qCountAll.get() as { n: number }).n;
    },
    findById(id: string): CreatorRow | null {
      return (qById.get(id) as CreatorRow | undefined) ?? null;
    },
    findByExternalId(source: string, externalId: string): CreatorRow | null {
      return (qByExternalId.get(source, externalId) as CreatorRow | undefined) ?? null;
    },
    findByUsername(source: string, username: string): CreatorRow | null {
      return (qByUsername.get(source, username) as CreatorRow | undefined) ?? null;
    },
    insertFromSource(input: {
      source: string;
      external_id: string;
      username: string;
      nickname: string | null;
      follower_count: number | null;
      status: CreatorStatus;
      raw_data: string | null;
    }): CreatorRow {
      const now = new Date().toISOString();
      const row: CreatorRow = {
        id: crypto.randomUUID(),
        ...input,
        first_seen_at: now,
        last_updated_at: now,
      };
      qInsert.run(row);
      return row;
    },
    updateFromSource(id: string, input: {
      username: string;
      nickname: string | null;
      follower_count: number | null;
      status: CreatorStatus;
      raw_data: string | null;
    }): void {
      qUpdateFromSource.run({
        id,
        username: input.username,
        nickname: input.nickname,
        follower_count: input.follower_count,
        status: input.status,
        raw_data: input.raw_data,
        last_updated_at: new Date().toISOString(),
      });
    },
    /** Dedup sinkronisasi: baris lama yang datanya sama hanya di-update last_updated_at. */
    touch(id: string): void {
      qTouch.run(new Date().toISOString(), id);
    },
    insertStatusHistory(creatorId: string, oldStatus: CreatorStatus | null, newStatus: CreatorStatus, reason: string): void {
      qHistoryInsert.run(crypto.randomUUID(), creatorId, oldStatus, newStatus, reason, new Date().toISOString());
    },
    statusHistory(creatorId: string, limit = 50): CreatorStatusHistoryRow[] {
      return qHistoryByCreator.all(creatorId, limit) as CreatorStatusHistoryRow[];
    },

    /**
     * Daftar creator dengan pencarian + filter status + pagination + sorting.
     * Parameter placeholders murni (nilai tidak pernah disisipkan ke string SQL).
     */
    listFiltered(opts: {
      search?: string;
      status?: CreatorStatus | null;
      page: number;
      pageSize: number;
      sort: "newest" | "oldest" | "username";
    }): { items: CreatorRow[]; total: number } {
      const where: string[] = [];
      const params: Record<string, unknown> = {};
      if (opts.search && opts.search.length > 0) {
        where.push(`(username LIKE @search OR COALESCE(nickname, '') LIKE @search OR external_id LIKE @search)`);
        params.search = `%${opts.search}%`;
      }
      if (opts.status) {
        where.push(`status = @status`);
        params.status = opts.status;
      }
      const whereSql = where.length > 0 ? `WHERE ${where.join(" AND ")}` : "";
      const orderBy =
        opts.sort === "username" ? `ORDER BY username ASC` : opts.sort === "oldest" ? `ORDER BY last_updated_at ASC` : `ORDER BY last_updated_at DESC`;
      const total = (db.prepare(`SELECT COUNT(*) AS n FROM creators ${whereSql}`).get(params) as { n: number }).n;
      const items = db
        .prepare(`SELECT * FROM creators ${whereSql} ${orderBy} LIMIT @limit OFFSET @offset`)
        .all({ ...params, limit: opts.pageSize, offset: (opts.page - 1) * opts.pageSize }) as CreatorRow[];
      return { items, total };
    },

    /** Available Creators: status Available dan belum memiliki klaim aktif, terbaru lebih dulu. */
    listAvailableWithoutActiveClaim(page: number, pageSize: number): { items: CreatorRow[]; total: number } {
      const base = `FROM creators c
        LEFT JOIN claims cl ON cl.creator_id = c.id AND cl.status IN ('Pending','Processing')
        WHERE c.status = 'Available' AND cl.id IS NULL`;
      const total = (db.prepare(`SELECT COUNT(*) AS n ${base}`).get() as { n: number }).n;
      const items = db
        .prepare(`SELECT c.* ${base} ORDER BY c.first_seen_at DESC LIMIT ? OFFSET ?`)
        .all(pageSize, (page - 1) * pageSize) as CreatorRow[];
      return { items, total };
    },
    countByStatus(status: CreatorStatus): number {
      return (db.prepare(`SELECT COUNT(*) AS n FROM creators WHERE status = ?`).get(status) as { n: number }).n;
    },
    recent(limit: number): CreatorRow[] {
      return db.prepare(`SELECT * FROM creators ORDER BY first_seen_at DESC LIMIT ?`).all(limit) as CreatorRow[];
    },
  };
}

export type CreatorRepository = ReturnType<typeof createCreatorRepository>;
