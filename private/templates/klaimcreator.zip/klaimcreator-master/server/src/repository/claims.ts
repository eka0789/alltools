import crypto from "node:crypto";
import type { SqliteDb } from "../db/connection";
import type { ClaimAttemptRow, ClaimRow, ClaimStatus } from "../types";

/** Repository claims + attempt. Idempotensi klaim juga dijaga unique partial index di DB. */
export function createClaimRepository(db: SqliteDb) {
  const qById = db.prepare(`SELECT * FROM claims WHERE id = ?`);
  const qInsert = db.prepare(
    `INSERT INTO claims (id, creator_id, status, mode, requested_by, attempt_count, next_retry_at, last_error, claimed_at, verified_at, verified_by, created_at, updated_at)
     VALUES (@id, @creator_id, @status, @mode, @requested_by, @attempt_count, @next_retry_at, @last_error, @claimed_at, @verified_at, @verified_by, @created_at, @updated_at)`
  );
  const qActiveByCreator = db.prepare(
    `SELECT * FROM claims WHERE creator_id = ? AND status IN ('Pending','Processing') LIMIT 1`
  );
  const qUpdate = db.prepare(
    `UPDATE claims SET status = @status, next_retry_at = @next_retry_at, last_error = @last_error,
       claimed_at = @claimed_at, verified_at = @verified_at, verified_by = @verified_by,
       attempt_count = @attempt_count, updated_at = @updated_at
     WHERE id = @id`
  );
  const qAttemptInsert = db.prepare(
    `INSERT INTO claim_attempts (id, claim_id, attempt_number, result, message, executed_by, started_at, finished_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const qAttempts = db.prepare(
    `SELECT * FROM claim_attempts WHERE claim_id = ? ORDER BY attempt_number ASC`
  );
  const qMaxAttempt = db.prepare(`SELECT MAX(attempt_number) AS n FROM claim_attempts WHERE claim_id = ?`);

  return {
    findById(id: string): ClaimRow | null {
      return (qById.get(id) as ClaimRow | undefined) ?? null;
    },
    findActiveByCreator(creatorId: string): ClaimRow | null {
      return (qActiveByCreator.get(creatorId) as ClaimRow | undefined) ?? null;
    },
    /** Klaim yang MEMBLOKIR klaim baru: aktif maupun terminal (Success, Already Claimed, Verification Required). */
    findBlockingByCreator(creatorId: string): ClaimRow | null {
      const row = db
        .prepare(
          `SELECT * FROM claims WHERE creator_id = ?
             AND status IN ('Pending','Processing','Success','Already Claimed','Verification Required')
           ORDER BY CASE status WHEN 'Pending' THEN 0 WHEN 'Processing' THEN 1 ELSE 2 END
           LIMIT 1`
        )
        .get(creatorId) as ClaimRow | undefined;
      return row ?? null;
    },
    insert(input: {
      creator_id: string;
      status: ClaimStatus;
      mode: "automatic" | "assisted";
      requested_by: string | null;
      next_retry_at?: string | null;
      last_error?: string | null;
    }): ClaimRow {
      const now = new Date().toISOString();
      const row: ClaimRow = {
        id: crypto.randomUUID(),
        creator_id: input.creator_id,
        status: input.status,
        mode: input.mode,
        requested_by: input.requested_by,
        attempt_count: 0,
        next_retry_at: input.next_retry_at ?? null,
        last_error: input.last_error ?? null,
        claimed_at: null,
        verified_at: null,
        verified_by: null,
        created_at: now,
        updated_at: now,
      };
      qInsert.run(row);
      return row;
    },
    update(id: string, patch: Partial<Omit<ClaimRow, "id" | "creator_id" | "created_at">>): void {
      const current = this.findById(id);
      if (!current) throw new Error(`Klaim ${id} tidak ditemukan`);
      qUpdate.run({
        id,
        status: patch.status ?? current.status,
        next_retry_at: patch.next_retry_at !== undefined ? patch.next_retry_at : current.next_retry_at,
        last_error: patch.last_error !== undefined ? patch.last_error : current.last_error,
        claimed_at: patch.claimed_at !== undefined ? patch.claimed_at : current.claimed_at,
        verified_at: patch.verified_at !== undefined ? patch.verified_at : current.verified_at,
        verified_by: patch.verified_by !== undefined ? patch.verified_by : current.verified_by,
        attempt_count: patch.attempt_count ?? current.attempt_count,
        updated_at: new Date().toISOString(),
      });
    },
    insertAttempt(input: {
      claim_id: string;
      attempt_number: number;
      result: string;
      message?: string | null;
      executed_by?: string | null;
      started_at: string;
      finished_at?: string | null;
    }): void {
      qAttemptInsert.run(
        crypto.randomUUID(),
        input.claim_id,
        input.attempt_number,
        input.result,
        input.message ?? null,
        input.executed_by ?? null,
        input.started_at,
        input.finished_at ?? new Date().toISOString()
      );
    },
    attempts(claimId: string): ClaimAttemptRow[] {
      return qAttempts.all(claimId) as ClaimAttemptRow[];
    },
    nextAttemptNumber(claimId: string): number {
      const row = qMaxAttempt.get(claimId) as { n: number | null };
      return (row.n ?? 0) + 1;
    },

    /** Antrian eksekusi: Pending yang jatuh tempo retry (atau belum pernah dijadwalkan). */
    pendingDue(nowIso: string, limit: number): ClaimRow[] {
      return db
        .prepare(
          `SELECT * FROM claims
           WHERE status = 'Pending' AND (next_retry_at IS NULL OR next_retry_at <= ?)
           ORDER BY created_at ASC LIMIT ?`
        )
        .all(nowIso, limit) as ClaimRow[];
    },
    processingStale(cutoffIso: string): ClaimRow[] {
      return db
        .prepare(`SELECT * FROM claims WHERE status = 'Processing' AND updated_at < ? ORDER BY updated_at ASC`)
        .all(cutoffIso) as ClaimRow[];
    },
    /** Emergency stop: seluruh Processing langsung menjadi Verification Required. */
    flipProcessingToVerificationRequired(reason: string): number {
      const info = db
        .prepare(
          `UPDATE claims SET status = 'Verification Required', last_error = ?, updated_at = ? WHERE status = 'Processing'`
        )
        .run(reason, new Date().toISOString());
      return info.changes;
    },
    countByStatus(status: ClaimStatus): number {
      return (db.prepare(`SELECT COUNT(*) AS n FROM claims WHERE status = ?`).get(status) as { n: number }).n;
    },
    countAll(): number {
      return (db.prepare(`SELECT COUNT(*) AS n FROM claims`).get() as { n: number }).n;
    },

    listFiltered(opts: {
      status?: ClaimStatus | null;
      search?: string;
      page: number;
      pageSize: number;
    }): { items: Array<ClaimRow & { username: string; nickname: string | null; source: string; external_id: string }>; total: number } {
      const where: string[] = [];
      const params: Record<string, unknown> = {};
      if (opts.status) {
        where.push(`cl.status = @status`);
        params.status = opts.status;
      }
      if (opts.search && opts.search.length > 0) {
        where.push(`(cr.username LIKE @search OR COALESCE(cr.nickname,'') LIKE @search OR cr.external_id LIKE @search)`);
        params.search = `%${opts.search}%`;
      }
      const whereSql = where.length > 0 ? `WHERE ${where.join(" AND ")}` : "";
      const total = (
        db.prepare(`SELECT COUNT(*) AS n FROM claims cl JOIN creators cr ON cr.id = cl.creator_id ${whereSql}`).get(params) as { n: number }
      ).n;
      const items = db
        .prepare(
          `SELECT cl.*, cr.username, cr.nickname, cr.source, cr.external_id
           FROM claims cl JOIN creators cr ON cr.id = cl.creator_id
           ${whereSql}
           ORDER BY cl.updated_at DESC
           LIMIT @limit OFFSET @offset`
        )
        .all({ ...params, limit: opts.pageSize, offset: (opts.page - 1) * opts.pageSize }) as Array<
        ClaimRow & { username: string; nickname: string | null; source: string; external_id: string }
      >;
      return { items, total };
    },

    /** Sumber data export: klaim berstatus tertentu (default Success) beserta info creator. */
    listForExport(opts: { statuses: ClaimStatus[]; from?: string | null; to?: string | null }): Array<{
      claim_id: string;
      username: string;
      external_id: string;
      status: ClaimStatus;
      claimed_at: string | null;
      created_at: string;
    }> {
      const statuses = opts.statuses.length > 0 ? opts.statuses : (["Success"] as ClaimStatus[]);
      const placeholders = statuses.map(() => `?`).join(", ");
      let sql = `SELECT cl.id AS claim_id, cr.username, cr.external_id, cl.status, cl.claimed_at, cl.created_at
                 FROM claims cl JOIN creators cr ON cr.id = cl.creator_id
                 WHERE cl.status IN (${placeholders})`;
      const params: unknown[] = [...statuses];
      if (opts.from) {
        sql += ` AND COALESCE(cl.claimed_at, cl.created_at) >= ?`;
        params.push(opts.from);
      }
      if (opts.to) {
        sql += ` AND COALESCE(cl.claimed_at, cl.created_at) <= ?`;
        params.push(opts.to);
      }
      sql += ` ORDER BY COALESCE(cl.claimed_at, cl.created_at) DESC`;
      return db.prepare(sql).all(...params) as Array<{
        claim_id: string;
        username: string;
        external_id: string;
        status: ClaimStatus;
        claimed_at: string | null;
        created_at: string;
      }>;
    },

    /** Klaim per hari untuk grafik dashboard (14 hari terakhir). */
    perDay(days: number): Array<{ day: string; status: string; n: number }> {
      const since = new Date(Date.now() - (days - 1) * 86_400_000).toISOString().slice(0, 10);
      return db
        .prepare(
          `SELECT substr(COALESCE(claimed_at, created_at), 1, 10) AS day, status, COUNT(*) AS n
           FROM claims
           WHERE substr(COALESCE(claimed_at, created_at), 1, 10) >= ?
           GROUP BY day, status ORDER BY day ASC`
        )
        .all(since) as Array<{ day: string; status: string; n: number }>;
    },
  };
}

export type ClaimRepository = ReturnType<typeof createClaimRepository>;
