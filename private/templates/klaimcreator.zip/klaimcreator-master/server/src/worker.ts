import http from "node:http";
import { loadConfig } from "./config";
import { logger } from "./logger";
import { bootstrap } from "./bootstrap";
import { NotificationService } from "./services/notificationService";
import { startWorker } from "./services/schedulerService";
import { resolveAdapters } from "./adapters/registry";
import type { ClaimDeps } from "./services/claimService";

/**
 * Entry point service worker: SATU-SATUNYA pemilik node-cron, eksekusi
 * sinkronisasi, dan eksekusi klaim. Menyediakan endpoint heartbeat /health
 * yang dipakai Docker healthcheck.
 */
function main(): void {
  const cfg = loadConfig();
  const boot = bootstrap(cfg);
  const notifier = new NotificationService(boot.repo, cfg);

  const handle = startWorker({
    db: boot.db,
    repo: boot.repo,
    cfg,
    notifier,
    adapters: () => resolveAdapters(boot.repo, cfg),
  });

  const server = http.createServer((req, res) => {
    if (req.url?.startsWith("/health")) {
      const heartbeat = boot.repo.settings.get<{ at: string }>("worker_heartbeat");
      const fresh = heartbeat ? Date.now() - new Date(heartbeat.at).getTime() < 45_000 : false;
      res.statusCode = fresh ? 200 : 503;
      res.setHeader("Content-Type", "application/json");
      res.end(
        JSON.stringify({
          status: fresh ? "ok" : "stale",
          service: "worker",
          instance: handle.instanceId,
          lastHeartbeatAt: heartbeat?.at ?? null,
          timestamp: new Date().toISOString(),
        })
      );
      return;
    }
    res.statusCode = 404;
    res.end(JSON.stringify({ error: { code: "NOT_FOUND", message: "Endpoint worker hanya /health" } }));
  });

  server.listen(cfg.workerPort, () => {
    logger.info("KlaimCreator worker heartbeat siap", { port: cfg.workerPort });
  });

  const shutdown = (signal: string) => {
    logger.info(`Worker menerima ${signal}`);
    server.close();
    void handle.stop().finally(() => {
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 30_000).unref();
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

main();
