import type { NextFunction, Request, Response } from "express";
import type { AuthUser } from "../types";
import { AuthError, type AuthService } from "../services/authService";
import { ClaimError } from "../services/claimService";

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public fields?: Record<string, string>
  ) {
    super(message);
    this.name = "ApiError";
  }
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AuthUser;
    }
  }
}

export function errorResponse(res: Response, status: number, code: string, message: string, fields?: Record<string, string>): void {
  res.status(status).json({ error: { code, message, ...(fields ? { fields } : {}) } });
}

/** Handler error terpusat: bentuk respons konsisten { error: { code, message, fields? } }. */
export function centralErrorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction): void {
  if (err instanceof ApiError || err instanceof AuthError || err instanceof ClaimError) {
    errorResponse(res, err.status, err.code, err.message, err.fields);
    return;
  }
  if (err instanceof SyntaxError) {
    errorResponse(res, 400, "BAD_JSON", "Body request bukan JSON yang valid");
    return;
  }
  const message = err instanceof Error ? err.message : "Kesalahan server internal";
  errorResponse(res, 500, "INTERNAL", message);
}

/** Middleware auth: verifikasi JWT dari cookie httpOnly dan muat user terkini. */
export function makeRequireAuth(authService: AuthService) {
  return function requireAuth(req: Request, res: Response, next: NextFunction): void {
    const token = req.cookies?.kc_at as string | undefined;
    if (!token) {
      errorResponse(res, 401, "UNAUTHENTICATED", "Silakan login terlebih dahulu");
      return;
    }
    try {
      req.auth = authService.verifyAccessToken(token);
      next();
    } catch (err) {
      if (err instanceof AuthError) {
        errorResponse(res, err.status, err.code, err.message);
        return;
      }
      errorResponse(res, 401, "UNAUTHENTICATED", "Sesi tidak valid");
    }
  };
}

/** RBAC ditegakkan di server per endpoint, bukan hanya di UI. */
export function requireRole(...roles: Array<"admin" | "operator">) {
  return function (req: Request, res: Response, next: NextFunction): void {
    if (!req.auth) {
      errorResponse(res, 401, "UNAUTHENTICATED", "Silakan login terlebih dahulu");
      return;
    }
    if (!roles.includes(req.auth.role)) {
      errorResponse(res, 403, "FORBIDDEN", "Anda tidak memiliki izin untuk aksi ini");
      return;
    }
    next();
  };
}

/**
 * Proteksi CSRF: semua mutasi wajib membawa custom header X-Requested-With.
 * Cookie SameSite=Strict + pemeriksaan header ini memperkuat pertahanan CSRF.
 */
export function csrfGuard(req: Request, res: Response, next: NextFunction): void {
  const method = req.method.toUpperCase();
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") {
    next();
    return;
  }
  if (req.headers["x-requested-with"] !== "XMLHttpRequest") {
    errorResponse(res, 403, "CSRF", "Request mutasi wajib menyertakan header X-Requested-With");
    return;
  }
  next();
}
