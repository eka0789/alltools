import type { NextFunction, Request, Response } from "express";
import type { ZodTypeAny, z } from "zod";
import { errorResponse } from "./auth";

/**
 * Validasi input dengan skema Zod di server.
 * Pesan error spesifik per field dikembalikan ke klien: fields[path] = pesan.
 */
export function validate<S extends ZodTypeAny>(schema: S, source: "body" | "query" = "body") {
  return function (req: Request, res: Response, next: NextFunction): void {
    const input = source === "body" ? req.body : req.query;
    const parsed = schema.safeParse(input);
    if (!parsed.success) {
      const fields: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const path = issue.path.join(".") || "_";
        if (!fields[path]) fields[path] = issue.message;
      }
      errorResponse(res, 400, "VALIDATION", "Data yang dikirim tidak valid", fields);
      return;
    }
    if (source === "body") {
      (req as Request & { validatedBody?: z.infer<S> }).validatedBody = parsed.data;
    } else {
      (req as Request & { validatedQuery?: z.infer<S> }).validatedQuery = parsed.data;
    }
    next();
  };
}

export function body<S extends ZodTypeAny>(req: Request): z.infer<S> {
  return (req as unknown as { validatedBody: z.infer<S> }).validatedBody;
}

export function query<S extends ZodTypeAny>(req: Request): z.infer<S> {
  return (req as unknown as { validatedQuery: z.infer<S> }).validatedQuery;
}
