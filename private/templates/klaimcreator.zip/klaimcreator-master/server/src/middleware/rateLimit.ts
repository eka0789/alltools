import rateLimit from "express-rate-limit";
import type { AppConfig } from "../config";

export interface RateLimiters {
  authLimiter: ReturnType<typeof rateLimit>;
  apiLimiter: ReturnType<typeof rateLimit>;
}

/**
 * Rate limiting: ketat di auth (5 percobaan/menit), moderat di API umum.
 * trust proxy dikonfigurasi sesuai hop reverse proxy agar IP klien asli yang dihitung.
 */
export function makeLimiters(cfg: AppConfig): RateLimiters {
  const standard = {
    windowMs: cfg.rateLimit.windowMs,
    standardHeaders: true,
    legacyHeaders: false,
  } as const;
  return {
    authLimiter: rateLimit({
      ...standard,
      limit: cfg.rateLimit.authMax,
      message: { error: { code: "RATE_LIMITED", message: "Terlalu banyak percobaan login. Coba lagi dalam 1 menit." } },
    }),
    apiLimiter: rateLimit({
      ...standard,
      limit: cfg.rateLimit.apiMax,
      message: { error: { code: "RATE_LIMITED", message: "Terlalu banyak permintaan. Perlambat dan coba lagi sebentar." } },
    }),
  };
}
