import helmet from "helmet";
import type { AppConfig } from "../config";

/**
 * Header keamanan dasar: CSP ketat yang memungkinkan, nosniff, frame-ancestors none.
 * Route /api/docs mendapat CSP longgar terkendali (Swagger UI butuh inline bootstrap).
 */
export function applySecurityHeaders(app: import("express").Express, cfg: AppConfig): void {
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        directives: {
          "default-src": ["'self'"],
          "script-src": ["'self'"],
          "style-src": ["'self'", "'unsafe-inline'"],
          "img-src": ["'self'", "data:", "blob:"],
          "font-src": ["'self'", "data:"],
          "connect-src": ["'self'"],
          "object-src": ["'none'"],
          "base-uri": ["'self'"],
          "form-action": ["'self'"],
          "frame-ancestors": ["'none'"],
          ...(cfg.isProduction ? { "upgrade-insecure-requests": [] as string[] } : {}),
        },
      },
      crossOriginEmbedderPolicy: false,
      referrerPolicy: { policy: "same-origin" },
      strictTransportSecurity: cfg.isProduction
        ? { maxAge: 15552000, includeSubDomains: true }
        : false,
    })
  );
}

/** CSP khusus halaman Swagger (hanya pada path /api/docs*). */
export function swaggerCsp(_req: import("express").Request, res: import("express").Response, next: import("express").NextFunction): void {
  res.setHeader(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data:",
      "connect-src 'self'",
      "frame-ancestors 'none'",
      "base-uri 'self'",
    ].join("; ")
  );
  next();
}
