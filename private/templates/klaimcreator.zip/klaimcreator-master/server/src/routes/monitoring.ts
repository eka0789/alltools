import { Router } from "express";
import { requireRole, ApiError } from "../middleware/auth";
import type { AppContext } from "../context";
import { getClaimMode, releaseEmergencyStop, triggerEmergencyStop } from "../services/claimService";
import { getAutomation } from "../services/notificationService";

const WORKER_STALE_MS = 45_000;

export function buildMonitoringStatus(ctx: AppContext) {
  const repo = ctx.repo;
  const heartbeat = repo.settings.get<{ at: string; instance: string; running?: boolean; stopped?: boolean }>("worker_heartbeat");
  const workerOnline = heartbeat ? Date.now() - new Date(heartbeat.at).getTime() < WORKER_STALE_MS : false;
  const adapters = ctx.adapters();
  const automation = getAutomation(repo);
  const lastSync = repo.stats.lastSync();
  const lease = repo.logs.getLock("sync");
  return {
    monitoringActive: repo.settings.get<boolean>("monitoring_active") === true,
    emergencyStop: repo.settings.get<boolean>("emergency_stop") === true,
    claimMode: getClaimMode(repo),
    automaticPossible: adapters.officialReady,
    sourceAdapter: adapters.source.name,
    sourceLabel: adapters.source.label,
    worker: {
      online: workerOnline,
      lastHeartbeatAt: heartbeat?.at ?? null,
      running: heartbeat?.running === true,
      instance: heartbeat?.instance ?? null,
    },
    lastSync,
    lease: lease ? { owner: lease.owner, expiresAt: lease.expires_at, renewedAt: lease.renewed_at } : null,
    queuedJobs: repo.logs.queuedJobCount(),
    refreshIntervalSeconds: automation.refreshIntervalSeconds,
  };
}

/** Kontrol monitoring: Start/Stop, sinkronisasi manual, Emergency Stop. */
export function monitoringRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/status", (_req, res) => {
    res.json(buildMonitoringStatus(ctx));
  });

  router.post("/start", (req, res) => {
    if (ctx.repo.settings.get<boolean>("emergency_stop") === true) {
      throw new ApiError(409, "EMERGENCY_STOP", "Emergency Stop masih aktif. Minta Admin membukanya terlebih dahulu.");
    }
    ctx.repo.settings.set("monitoring_active", true, req.auth!.id);
    ctx.repo.logs.createEvent({
      event_type: "system",
      description: `Monitoring diaktifkan oleh ${req.auth!.name}`,
      status: "Success",
    });
    ctx.repo.logs.createAudit({ user_id: req.auth!.id, user_email: req.auth!.email, action: "monitoring.start" });
    res.json({ ok: true, monitoringActive: true });
  });

  router.post("/stop", (req, res) => {
    ctx.repo.settings.set("monitoring_active", false, req.auth!.id);
    ctx.repo.logs.createEvent({
      event_type: "system",
      description: `Monitoring dihentikan oleh ${req.auth!.name}`,
      status: "Info",
    });
    ctx.repo.logs.createAudit({ user_id: req.auth!.id, user_email: req.auth!.email, action: "monitoring.stop" });
    res.json({ ok: true, monitoringActive: false });
  });

  router.post("/sync", (req, res) => {
    if (ctx.repo.settings.get<boolean>("emergency_stop") === true) {
      throw new ApiError(409, "EMERGENCY_STOP", "Emergency Stop aktif. Sinkronisasi manual diblokir.");
    }
    if (ctx.repo.logs.queuedJobCount() > 0) {
      throw new ApiError(409, "JOB_ALREADY_QUEUED", "Sinkronisasi sudah dijadwalkan dan sedang menunggu worker.");
    }
    const jobId = ctx.repo.logs.enqueueJob("sync_manual", req.auth!.id);
    ctx.repo.logs.createAudit({ user_id: req.auth!.id, user_email: req.auth!.email, action: "monitoring.manual_sync", details: { jobId } });
    res.status(202).json({ jobId, message: "Sinkronisasi dijadwalkan. Worker akan menjalankannya sebentar lagi." });
  });

  router.post("/emergency-stop", (req, res) => {
    const result = triggerEmergencyStop(ctx.claimDeps(), req.auth!);
    ctx.notifier.notify({
      eventType: "worker_stopped",
      title: "Emergency Stop diaktifkan",
      message: `Emergency Stop diaktifkan oleh ${req.auth!.name}. ${result.flipped} klaim Processing menjadi Verification Required.`,
      eventStatus: "Warning",
    });
    res.json({ ok: true, flipped: result.flipped });
  });

  // Hanya Admin yang dapat membuka (release) Emergency Stop.
  router.post("/emergency-release", requireRole("admin"), (req, res) => {
    releaseEmergencyStop(ctx.claimDeps(), req.auth!);
    res.json({ ok: true });
  });

  return router;
}
