import { Router } from "express";
import { z } from "zod";
import { query, validate } from "../middleware/validate";
import { requireRole } from "../middleware/auth";
import type { AppContext } from "../context";

const eventsQuerySchema = z.object({
  type: z.string().max(40).optional(),
  status: z.enum(["Info", "Success", "Warning", "Error"]).optional(),
  creatorId: z.uuid().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

const auditQuerySchema = z.object({
  action: z.string().max(60).optional(),
  userId: z.uuid().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

/** System Logs + Audit Trail (Admin). Audit log bersifat append-only. */
export function logRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/events", validate(eventsQuerySchema, "query"), (req, res) => {
    const q = query<typeof eventsQuerySchema>(req);
    const result = ctx.repo.logs.listEvents({
      type: q.type ?? null,
      status: q.status ?? null,
      creatorId: q.creatorId ?? null,
      page: q.page,
      pageSize: q.pageSize,
    });
    res.json({
      items: result.items.map((e) => ({
        id: e.id,
        eventType: e.event_type,
        description: e.description,
        creatorId: e.creator_id,
        creatorUsername: e.creator_username,
        status: e.status,
        createdAt: e.created_at,
      })),
      page: q.page,
      pageSize: q.pageSize,
      total: result.total,
      totalPages: Math.max(1, Math.ceil(result.total / q.pageSize)),
    });
  });

  router.get("/sync", (req, res) => {
    const parsed = z.coerce.number().int().min(1).max(200).default(50).safeParse(req.query.limit);
    const limit = parsed.success ? parsed.data : 50;
    res.json({
      items: ctx.repo.logs.listSyncLogs(limit).map((s) => ({
        id: s.id,
        trigger: s.trigger,
        status: s.status,
        startedAt: s.started_at,
        finishedAt: s.finished_at,
        pagesFetched: s.pages_fetched,
        itemsFetched: s.items_fetched,
        itemsCreated: s.items_created,
        itemsUpdated: s.items_updated,
        availableDetected: s.available_detected,
        error: s.error,
      })),
    });
  });

  // Audit Trail: khusus Admin.
  router.get("/audit", requireRole("admin"), validate(auditQuerySchema, "query"), (req, res) => {
    const q = query<typeof auditQuerySchema>(req);
    const result = ctx.repo.logs.listAudit({
      action: q.action ?? null,
      userId: q.userId ?? null,
      page: q.page,
      pageSize: q.pageSize,
    });
    res.json({
      items: result.items.map((a) => ({
        id: a.id,
        userId: a.user_id,
        userEmail: a.user_email,
        action: a.action,
        entity: a.entity,
        entityId: a.entity_id,
        details: a.details ? (JSON.parse(a.details) as unknown) : null,
        ip: a.ip,
        createdAt: a.created_at,
      })),
      page: q.page,
      pageSize: q.pageSize,
      total: result.total,
      totalPages: Math.max(1, Math.ceil(result.total / q.pageSize)),
    });
  });

  return router;
}
