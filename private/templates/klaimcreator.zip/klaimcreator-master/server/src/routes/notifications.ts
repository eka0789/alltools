import { Router } from "express";
import { z } from "zod";
import { body, validate } from "../middleware/validate";
import type { AppContext } from "../context";

const markReadSchema = z
  .object({
    ids: z.array(z.uuid()).optional(),
    all: z.boolean().optional(),
  })
  .refine((v) => v.all === true || Array.isArray(v.ids), {
    message: "Kirim ids[] atau all: true",
  });

/** Notifikasi in-app (7 jenis event inti). */
export function notificationRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/", (req, res) => {
    const parsed = z.coerce.number().int().min(1).max(100).default(30).safeParse(req.query.limit);
    const limit = parsed.success ? parsed.data : 30;
    res.json({
      items: ctx.repo.logs.listNotifications(limit).map((n) => ({
        id: n.id,
        eventType: n.event_type,
        title: n.title,
        message: n.message,
        isRead: n.is_read === 1,
        createdAt: n.created_at,
      })),
      unread: ctx.repo.logs.unreadCount(),
    });
  });

  router.post("/mark-read", validate(markReadSchema), (req, res) => {
    const input = body<typeof markReadSchema>(req);
    if (input.all) {
      ctx.repo.logs.markAllRead();
    } else if (input.ids && input.ids.length > 0) {
      ctx.repo.logs.markRead(input.ids);
    }
    res.json({ ok: true, unread: ctx.repo.logs.unreadCount() });
  });

  return router;
}
