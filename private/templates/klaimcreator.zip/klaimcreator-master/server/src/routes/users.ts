import { Router } from "express";
import { z } from "zod";
import { body, validate } from "../middleware/validate";
import { ApiError, requireRole } from "../middleware/auth";
import type { AppContext } from "../context";

const createSchema = z.object({
  email: z.email({
    error: (issue) => (issue.input === undefined ? "Email wajib diisi" : "Format email tidak valid"),
  }),
  name: z.string({ error: "Nama wajib diisi" }).min(2, "Nama minimal 2 karakter").max(80, "Nama maksimal 80 karakter"),
  role: z.enum(["admin", "operator"], { error: "Peran harus admin atau operator" }),
  password: z
    .string({ error: "Password wajib diisi" })
    .min(8, "Password minimal 8 karakter")
    .regex(/[A-Za-z]/, "Password harus mengandung huruf")
    .regex(/[0-9]/, "Password harus mengandung angka"),
});

const updateSchema = z.object({
  name: z.string().min(2, "Nama minimal 2 karakter").max(80, "Nama maksimal 80 karakter").optional(),
  role: z.enum(["admin", "operator"]).optional(),
  isActive: z.boolean().optional(),
});

const resetPasswordSchema = z.object({
  newPassword: z
    .string({ error: "Password baru wajib diisi" })
    .min(8, "Password minimal 8 karakter")
    .regex(/[A-Za-z]/, "Password harus mengandung huruf")
    .regex(/[0-9]/, "Password harus mengandung angka"),
});

const idSchema = z.uuid("ID pengguna tidak valid");

/** User Management: hanya Admin (RBAC di middleware, bukan hanya UI). */
export function userRoutes(ctx: AppContext): Router {
  const router = Router();
  const adminOnly = requireRole("admin");

  router.get("/", adminOnly, (_req, res) => {
    res.json({ items: ctx.repo.users.listAll() });
  });

  router.post("/", adminOnly, validate(createSchema), (req, res) => {
    const input = body<typeof createSchema>(req);
    if (ctx.repo.users.findByEmail(input.email)) {
      throw new ApiError(409, "CONFLICT", "Email sudah terdaftar", { email: "Email sudah terdaftar" });
    }
    const user = ctx.repo.users.create({
      email: input.email,
      name: input.name,
      role: input.role,
      passwordHash: ctx.authService.hashPassword(input.password),
      mustChangePassword: true,
    });
    ctx.repo.logs.createAudit({
      user_id: req.auth!.id,
      user_email: req.auth!.email,
      action: "user.create",
      entity: "user",
      entity_id: user.id,
      details: { email: user.email, role: user.role },
    });
    res.status(201).json({ user: { id: user.id, email: user.email, name: user.name, role: user.role, is_active: user.is_active, must_change_password: user.must_change_password, created_at: user.created_at, updated_at: user.updated_at } });
  });

  router.put("/:id", adminOnly, validate(updateSchema), (req, res) => {
    const id = idSchema.parse(req.params.id);
    const target = ctx.repo.users.findById(id);
    if (!target) throw new ApiError(404, "NOT_FOUND", "Pengguna tidak ditemukan");
    const input = body<typeof updateSchema>(req);

    if (input.role === "operator" && target.role === "admin") {
      // Cegah mendemosi admin aktif terakhir.
      if (target.is_active === 1 && ctx.repo.users.countOtherActiveAdmins(id) === 0) {
        throw new ApiError(409, "CONFLICT", "Tidak bisa menurunkan peran admin aktif terakhir");
      }
    }
    if (input.isActive === false && target.id === req.auth!.id) {
      throw new ApiError(409, "CONFLICT", "Tidak bisa menonaktifkan akun sendiri");
    }
    if (input.isActive === false && target.role === "admin" && target.is_active === 1 && ctx.repo.users.countOtherActiveAdmins(id) === 0) {
      throw new ApiError(409, "CONFLICT", "Tidak bisa menonaktifkan admin aktif terakhir");
    }

    if (input.name !== undefined || input.role !== undefined) {
      ctx.repo.users.updateProfile(id, input.name ?? target.name, input.role ?? target.role);
    }
    if (input.isActive !== undefined) {
      ctx.repo.users.setActive(id, input.isActive);
      if (!input.isActive) {
        ctx.repo.users.revokeAllRefreshTokens(id);
        ctx.authService.bumpSessionEpoch(id); // access token nonaktif juga langsung mati
      }
    }
    ctx.repo.logs.createAudit({
      user_id: req.auth!.id,
      user_email: req.auth!.email,
      action: "user.update",
      entity: "user",
      entity_id: id,
      details: { ...input },
    });
    const updated = ctx.repo.users.findById(id)!;
    res.json({ user: { id: updated.id, email: updated.email, name: updated.name, role: updated.role, is_active: updated.is_active, must_change_password: updated.must_change_password, created_at: updated.created_at, updated_at: updated.updated_at } });
  });

  router.post("/:id/reset-password", adminOnly, validate(resetPasswordSchema), (req, res) => {
    const id = idSchema.parse(req.params.id);
    const target = ctx.repo.users.findById(id);
    if (!target) throw new ApiError(404, "NOT_FOUND", "Pengguna tidak ditemukan");
    const input = body<typeof resetPasswordSchema>(req);
    ctx.repo.users.updatePassword(id, ctx.authService.hashPassword(input.newPassword), true);
    ctx.repo.users.revokeAllRefreshTokens(id);
    ctx.authService.bumpSessionEpoch(id); // seluruh sesi target langsung ditutup
    ctx.repo.logs.createAudit({
      user_id: req.auth!.id,
      user_email: req.auth!.email,
      action: "user.reset_password",
      entity: "user",
      entity_id: id,
      details: { targetEmail: target.email },
    });
    res.json({ ok: true });
  });

  return router;
}
