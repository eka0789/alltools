import { Router } from "express";
import { z } from "zod";
import { query, validate } from "../middleware/validate";
import { ApiError } from "../middleware/auth";
import type { AppContext } from "../context";
import type { CreatorStatus } from "../types";

const listQuerySchema = z.object({
  search: z.string().max(80).optional(),
  status: z.enum(["Available", "Claimed", "Pending", "Failed", "Unavailable"]).optional(),
  page: z.coerce.number().int().min(1, "Halaman minimal 1").default(1),
  pageSize: z.coerce.number().int().min(1).max(100, "Ukuran halaman maksimal 100").default(20),
  sort: z.enum(["newest", "oldest", "username"]).default("newest"),
});

const availableQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

const idParamSchema = z.uuid("ID creator tidak valid");

function publicCreator(row: import("../types").CreatorRow) {
  return {
    id: row.id,
    source: row.source,
    externalId: row.external_id,
    username: row.username,
    nickname: row.nickname,
    followerCount: row.follower_count,
    status: row.status,
    firstSeenAt: row.first_seen_at,
    lastUpdatedAt: row.last_updated_at,
  };
}

/** Creator Monitoring + Available Creators. */
export function creatorRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/", validate(listQuerySchema, "query"), (req, res) => {
    const q = query<typeof listQuerySchema>(req);
    const result = ctx.repo.creators.listFiltered({
      search: q.search,
      status: (q.status as CreatorStatus | undefined) ?? null,
      page: q.page,
      pageSize: q.pageSize,
      sort: q.sort,
    });
    res.json({
      items: result.items.map(publicCreator),
      page: q.page,
      pageSize: q.pageSize,
      total: result.total,
      totalPages: Math.max(1, Math.ceil(result.total / q.pageSize)),
    });
  });

  router.get("/available", validate(availableQuerySchema, "query"), (req, res) => {
    const q = query<typeof availableQuerySchema>(req);
    const result = ctx.repo.creators.listAvailableWithoutActiveClaim(q.page, q.pageSize);
    res.json({
      items: result.items.map(publicCreator),
      page: q.page,
      pageSize: q.pageSize,
      total: result.total,
      totalPages: Math.max(1, Math.ceil(result.total / q.pageSize)),
    });
  });

  router.get("/:id/history", (req, res) => {
    const parsed = idParamSchema.safeParse(req.params.id);
    if (!parsed.success) throw new ApiError(400, "VALIDATION", "ID creator tidak valid");
    const creator = ctx.repo.creators.findById(parsed.data);
    if (!creator) throw new ApiError(404, "NOT_FOUND", "Creator tidak ditemukan");
    const history = ctx.repo.creators.statusHistory(parsed.data, 100);
    res.json({
      creator: publicCreator(creator),
      items: history.map((h) => ({
        id: h.id,
        oldStatus: h.old_status,
        newStatus: h.new_status,
        reason: h.reason,
        changedAt: h.changed_at,
      })),
    });
  });

  return router;
}
