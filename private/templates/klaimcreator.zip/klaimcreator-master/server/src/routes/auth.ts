import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { ACCESS_TOKEN_TTL_SEC, REFRESH_TOKEN_TTL_MS, type AuthService } from "../services/authService";
import { body, validate } from "../middleware/validate";
import { errorResponse, makeRequireAuth } from "../middleware/auth";
import type { AppContext } from "../context";

const loginSchema = z.object({
  email: z.email({
    error: (issue) => (issue.input === undefined ? "Email wajib diisi" : "Format email tidak valid"),
  }),
  password: z.string({ error: "Password wajib diisi" }).min(1, "Password wajib diisi"),
});

const changePasswordSchema = z.object({
  currentPassword: z.string({ error: "Password saat ini wajib diisi" }).min(1, "Password saat ini wajib diisi"),
  newPassword: z
    .string({ error: "Password baru wajib diisi" })
    .min(8, "Password minimal 8 karakter")
    .regex(/[A-Za-z]/, "Password harus mengandung huruf")
    .regex(/[0-9]/, "Password harus mengandung angka"),
});

export function authCookieOptions(cfg: AppContext["cfg"], path: string) {
  return {
    httpOnly: true,
    sameSite: "strict" as const,
    secure: cfg.isProduction,
    path,
  };
}

export function setAuthCookies(ctx: AppContext, res: Response, accessToken: string, refreshToken: string): void {
  res.cookie("kc_at", accessToken, { ...authCookieOptions(ctx.cfg, "/"), maxAge: ACCESS_TOKEN_TTL_SEC * 1000 });
  res.cookie("kc_rt", refreshToken, { ...authCookieOptions(ctx.cfg, "/api/auth"), maxAge: REFRESH_TOKEN_TTL_MS });
}

export function clearAuthCookies(ctx: AppContext, res: Response): void {
  res.clearCookie("kc_at", authCookieOptions(ctx.cfg, "/"));
  res.clearCookie("kc_rt", authCookieOptions(ctx.cfg, "/api/auth"));
}

export function authRoutes(ctx: AppContext): Router {
  const router = Router();
  const requireAuth = makeRequireAuth(ctx.authService);

  router.post("/login", ctx.limiters.authLimiter, validate(loginSchema), (req, res) => {
    const { email, password } = body<typeof loginSchema>(req);
    const ip = req.ip ?? null;
    try {
      const result = ctx.authService.login(email, password);
      setAuthCookies(ctx, res, result.accessToken, result.refreshToken);
      ctx.repo.logs.createAudit({ user_id: result.user.id, user_email: result.user.email, action: "auth.login", ip });
      res.json({ user: result.user });
    } catch (err) {
      ctx.repo.logs.createAudit({ action: "auth.login_failed", details: { email: String(email).slice(0, 120) }, ip });
      const e = err as unknown as { status?: number; code?: string; message?: string };
      if (e && typeof e.status === "number") {
        errorResponse(res, e.status, e.code ?? "ERROR", e.message ?? "Login gagal");
        return;
      }
      errorResponse(res, 401, "INVALID_CREDENTIALS", "Email atau password salah");
    }
  });

  router.post("/refresh", (req, res) => {
    const refreshRaw = req.cookies?.kc_rt as string | undefined;
    if (!refreshRaw) {
      errorResponse(res, 401, "SESSION_EXPIRED", "Sesi berakhir. Silakan login kembali.");
      return;
    }
    try {
      const result = ctx.authService.refresh(refreshRaw);
      setAuthCookies(ctx, res, result.accessToken, result.refreshToken);
      res.json({ user: result.user });
    } catch {
      // Event session_expired (throttle 5 menit agar tidak membanjiri log).
      ctx.repo.logs.createEventThrottled(
        {
          event_type: "session_expired",
          description: "Sesi pengguna berakhir dan refresh token tidak valid. Login ulang diperlukan.",
          status: "Warning",
        },
        5 * 60_000
      );
      clearAuthCookies(ctx, res);
      errorResponse(res, 401, "SESSION_EXPIRED", "Sesi berakhir. Silakan login kembali.");
    }
  });

  router.post("/logout", (req, res) => {
    const refreshRaw = req.cookies?.kc_rt as string | undefined;
    ctx.authService.logout(refreshRaw);
    if (req.auth) {
      ctx.repo.logs.createAudit({ user_id: req.auth.id, user_email: req.auth.email, action: "auth.logout" });
    }
    clearAuthCookies(ctx, res);
    res.json({ ok: true });
  });

  router.get("/me", requireAuth, (req, res) => {
    res.json({ user: req.auth });
  });

  router.post("/change-password", requireAuth, validate(changePasswordSchema), (req, res) => {
    const { currentPassword, newPassword } = body<typeof changePasswordSchema>(req);
    try {
      const user = ctx.authService.changePassword(req.auth!.id, currentPassword, newPassword);
      ctx.repo.logs.createAudit({ user_id: user.id, user_email: user.email, action: "auth.change_password" });
      clearAuthCookies(ctx, res);
      res.json({ user });
    } catch (err) {
      const e = err as unknown as { status?: number; code?: string; message?: string; fields?: Record<string, string> };
      if (e && typeof e.status === "number") {
        errorResponse(res, e.status, e.code ?? "ERROR", e.message ?? "Gagal mengganti password", e.fields);
        return;
      }
      errorResponse(res, 500, "INTERNAL", "Gagal mengganti password");
    }
  });

  return router;
}
