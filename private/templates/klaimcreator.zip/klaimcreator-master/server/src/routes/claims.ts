import { Router } from "express";
import { z } from "zod";
import { body, query, validate } from "../middleware/validate";
import { ApiError, requireRole } from "../middleware/auth";
import type { AppContext } from "../context";
import { ClaimError, enqueueIfEligible, recordAssistedResult, retryClaim, verifyClaim } from "../services/claimService";
import type { ClaimRow, ClaimStatus } from "../types";

const listQuerySchema = z.object({
  status: z
    .enum(["Pending", "Processing", "Success", "Failed", "Already Claimed", "Verification Required"])
    .optional(),
  search: z.string().max(80).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

const queueSchema = z.object({
  creatorId: z.uuid("Creator ID tidak valid"),
});

const resultSchema = z.object({
  result: z.enum(["success", "already_claimed", "failed"], {
    error: "Hasil harus success, already_claimed, atau failed",
  }),
});

function publicClaim(row: ClaimRow & { username?: string; nickname?: string | null; source?: string; external_id?: string }) {
  return {
    id: row.id,
    creatorId: row.creator_id,
    status: row.status,
    mode: row.mode,
    attemptCount: row.attempt_count,
    nextRetryAt: row.next_retry_at,
    lastError: row.last_error,
    claimedAt: row.claimed_at,
    verifiedAt: row.verified_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    username: row.username,
    nickname: row.nickname,
    source: row.source,
    externalId: row.external_id,
  };
}

function mapClaimError(res: import("express").Response, err: unknown): void {
  if (err instanceof ClaimError) {
    res.status(err.status).json({ error: { code: err.code, message: err.message, ...(err.fields ? { fields: err.fields } : {}) } });
    return;
  }
  throw err;
}

/** Antrian dan eksekusi klaim. Verifikasi manual khusus Admin (RBAC per endpoint). */
export function claimRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/", validate(listQuerySchema, "query"), (req, res) => {
    const q = query<typeof listQuerySchema>(req);
    const result = ctx.repo.claims.listFiltered({
      status: (q.status as ClaimStatus | undefined) ?? null,
      search: q.search,
      page: q.page,
      pageSize: q.pageSize,
    });
    res.json({
      items: result.items.map(publicClaim),
      page: q.page,
      pageSize: q.pageSize,
      total: result.total,
      totalPages: Math.max(1, Math.ceil(result.total / q.pageSize)),
    });
  });

  // Antrikan klaim baru (Operator & Admin).
  router.post("/", validate(queueSchema), (req, res) => {
    try {
      const { creatorId } = body<typeof queueSchema>(req);
      const outcome = enqueueIfEligible(ctx.claimDeps(), creatorId, req.auth!.id);
      if (!outcome.ok) {
        const messages: Record<string, { status: number; message: string }> = {
          CREATOR_NOT_FOUND: { status: 404, message: "Creator tidak ditemukan" },
          NOT_AVAILABLE: { status: 409, message: "Hanya creator berstatus Available yang bisa masuk antrian klaim" },
          ALREADY_QUEUED: { status: 409, message: "Creator ini sudah memiliki klaim aktif di antrian" },
          TERMINAL_SUCCESS: { status: 409, message: "Creator ini sudah berhasil diklaim sebelumnya" },
          TERMINAL_ALREADY_CLAIMED: { status: 409, message: "Creator ini sudah tercatat terklaim pihak lain" },
          TERMINAL_VERIFICATION_REQUIRED: { status: 409, message: "Klaim sebelumnya menunggu verifikasi Admin" },
        };
        const mapped = messages[outcome.reason ?? ""] ?? { status: 409, message: "Creator tidak dapat masuk antrian klaim" };
        throw new ApiError(mapped.status, "CLAIM_QUEUE_REJECTED", mapped.message);
      }
      ctx.repo.logs.createAudit({
        user_id: req.auth!.id,
        user_email: req.auth!.email,
        action: "claim.queue",
        entity: "claim",
        entity_id: outcome.claim!.id,
        details: { creatorId },
      });
      res.status(201).json({ claim: publicClaim(outcome.claim!) });
    } catch (err) {
      mapClaimError(res, err);
    }
  });

  // Catat hasil klaim assisted (Operator & Admin).
  router.post("/:id/assisted-result", validate(resultSchema), (req, res) => {
    try {
      const { result } = body<typeof resultSchema>(req);
      const claimId = z.uuid("ID klaim tidak valid").parse(req.params.id);
      const final = recordAssistedResult(ctx.claimDeps(), claimId, result, req.auth!);
      res.json({ status: final });
    } catch (err) {
      mapClaimError(res, err);
    }
  });

  // Verifikasi manual (khusus Admin).
  router.post("/:id/verify", requireRole("admin"), validate(resultSchema), (req, res) => {
    try {
      const { result } = body<typeof resultSchema>(req);
      const claimId = z.uuid("ID klaim tidak valid").parse(req.params.id);
      const final = verifyClaim(ctx.claimDeps(), claimId, result, req.auth!);
      res.json({ status: final });
    } catch (err) {
      mapClaimError(res, err);
    }
  });

  // Retry manual klaim Failed.
  router.post("/:id/retry", (req, res) => {
    try {
      const claimId = z.uuid("ID klaim tidak valid").parse(req.params.id);
      const claim = retryClaim(ctx.claimDeps(), claimId, req.auth!);
      res.json({ claim: publicClaim(claim) });
    } catch (err) {
      mapClaimError(res, err);
    }
  });

  router.get("/:id/attempts", (req, res) => {
    const parsed = z.uuid("ID klaim tidak valid").safeParse(req.params.id);
    if (!parsed.success) throw new ApiError(400, "VALIDATION", "ID klaim tidak valid");
    const claim = ctx.repo.claims.findById(parsed.data);
    if (!claim) throw new ApiError(404, "NOT_FOUND", "Klaim tidak ditemukan");
    res.json({
      items: ctx.repo.claims.attempts(parsed.data).map((a) => ({
        id: a.id,
        attemptNumber: a.attempt_number,
        result: a.result,
        message: a.message,
        executedBy: a.executed_by,
        startedAt: a.started_at,
        finishedAt: a.finished_at,
      })),
    });
  });

  return router;
}
