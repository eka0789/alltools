import { Router } from "express";
import { z } from "zod";
import { body, validate } from "../middleware/validate";
import { requireRole, ApiError } from "../middleware/auth";
import type { AppContext } from "../context";
import { getClaimMode } from "../services/claimService";
import { getAutomation } from "../services/notificationService";

const automationSchema = z.object({
  claimMode: z.enum(["automatic", "assisted"]).optional(),
  refreshIntervalSeconds: z.coerce.number().int().min(15, "Interval minimal 15 detik").max(3600, "Interval maksimal 1 jam").optional(),
  maxRetries: z.coerce.number().int().min(0, "Retry minimal 0").max(10, "Retry maksimal 10").optional(),
  retryBaseDelaySeconds: z.coerce.number().int().min(5, "Delay dasar minimal 5 detik").max(3600, "Delay dasar maksimal 1 jam").optional(),
  claimSchedule: z
    .object({
      startHour: z.coerce.number().int().min(0).max(23),
      endHour: z.coerce.number().int().min(0).max(23),
      days: z.array(z.coerce.number().int().min(0).max(6)).max(7),
    })
    .optional(),
  notifications: z
    .object({
      inApp: z.boolean(),
      telegram: z.boolean(),
      email: z.boolean(),
    })
    .optional(),
  export: z
    .object({
      filenamePrefix: z.string().min(1, "Prefix nama file wajib diisi").max(50, "Prefix maksimal 50 karakter").regex(/^[a-zA-Z0-9\-_]+$/, "Prefix hanya boleh huruf, angka, tanda hubung, dan underscore"),
      usernamesOnlyDefault: z.boolean(),
    })
    .optional(),
});

const integrationSchema = z.object({
  adapter: z.enum(["mock", "official"]),
  official: z.object({
    enabled: z.boolean(),
    baseUrlEnv: z.string().regex(/^[A-Z][A-Z0-9_]*$/, "Nama variabel environment tidak valid"),
    apiKeyEnv: z.string().regex(/^[A-Z][A-Z0-9_]*$/, "Nama variabel environment tidak valid"),
    claimPath: z.string().regex(/^\/[A-Za-z0-9\-._/]*$/, "Path harus dimulai dengan / dan hanya berisi karakter aman"),
  }),
  mock: z.object({
    pages: z.coerce.number().int().min(1).max(50),
    itemsPerPage: z.coerce.number().int().min(1).max(500),
    newItemsPerCycle: z.coerce.number().int().min(0).max(50),
    faultMode: z.enum(["none", "disconnected"]),
  }),
});

function currentIntegration(ctx: AppContext) {
  const stored = ctx.repo.settings.get<Record<string, unknown>>("integration");
  return {
    adapter: (stored?.adapter as string) ?? "mock",
    official: {
      enabled: Boolean((stored?.official as { enabled?: boolean } | undefined)?.enabled ?? false),
      baseUrlEnv: (stored?.official as { baseUrlEnv?: string } | undefined)?.baseUrlEnv ?? "OFFICIAL_API_BASE_URL",
      apiKeyEnv: (stored?.official as { apiKeyEnv?: string } | undefined)?.apiKeyEnv ?? "OFFICIAL_API_KEY",
      claimPath: (stored?.official as { claimPath?: string } | undefined)?.claimPath ?? "/v1/claims",
    },
    mock: (stored?.mock as Record<string, unknown>) ?? { pages: 3, itemsPerPage: 15, newItemsPerCycle: 2, faultMode: "none" },
    // Prinsip 3G: yang terekspos hanya NAMA variabel env, tidak pernah nilainya.
    officialConfigured: ctx.adapters().officialReady,
    sourceLabel: ctx.adapters().source.label,
    lastCheck: ctx.repo.settings.get<{ ok: boolean; message: string; checkedAt: string } | null>("source_last_check"),
  };
}

/** Integration & Automation Settings. Pembacaan untuk semua role, perubahan Admin saja. */
export function settingsRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/automation", (_req, res) => {
    res.json({
      automation: getAutomation(ctx.repo),
      claimMode: getClaimMode(ctx.repo),
      automaticPossible: ctx.adapters().officialReady,
      monitoringActive: ctx.repo.settings.get<boolean>("monitoring_active") === true,
      emergencyStop: ctx.repo.settings.get<boolean>("emergency_stop") === true,
    });
  });

  router.put("/automation", requireRole("admin"), validate(automationSchema), (req, res) => {
    const input = body<typeof automationSchema>(req);
    const current = getAutomation(ctx.repo);
    if (input.claimMode === "automatic" && !ctx.adapters().officialReady) {
      throw new ApiError(
        409,
        "OFFICIAL_NOT_CONFIGURED",
        "Mode klaim otomatis hanya dapat diaktifkan setelah adapter integrasi resmi terkonfigurasi dan teruji. Saat ini sistem berjalan pada Assisted Claim Mode."
      );
    }
    const next = {
      refreshIntervalSeconds: input.refreshIntervalSeconds ?? current.refreshIntervalSeconds,
      maxRetries: input.maxRetries ?? current.maxRetries,
      retryBaseDelaySeconds: input.retryBaseDelaySeconds ?? current.retryBaseDelaySeconds,
      claimSchedule: input.claimSchedule ?? current.claimSchedule,
      notifications: input.notifications ?? current.notifications,
      export: input.export ?? current.export,
    };
    ctx.repo.settings.set("automation", next, req.auth!.id);
    if (input.claimMode) {
      ctx.repo.settings.set("claim_mode", input.claimMode, req.auth!.id);
    }
    ctx.repo.logs.createAudit({
      user_id: req.auth!.id,
      user_email: req.auth!.email,
      action: "settings.automation_update",
      entity: "settings",
      details: { ...input },
    });
    res.json({ automation: next, claimMode: input.claimMode ?? getClaimMode(ctx.repo) });
  });

  router.get("/integration", (_req, res) => {
    res.json(currentIntegration(ctx));
  });

  router.put("/integration", requireRole("admin"), validate(integrationSchema), (req, res) => {
    const input = body<typeof integrationSchema>(req);
    ctx.repo.settings.set("integration", input, req.auth!.id);
    ctx.repo.logs.createAudit({
      user_id: req.auth!.id,
      user_email: req.auth!.email,
      action: "settings.integration_update",
      entity: "settings",
      details: { adapter: input.adapter, officialEnabled: input.official.enabled, mockFaultMode: input.mock.faultMode },
    });
    res.json(currentIntegration(ctx));
  });

  // Uji koneksi ke sumber data (Admin).
  router.post("/integration/test", requireRole("admin"), async (req, res) => {
    const adapters = ctx.adapters();
    const result = await adapters.source.testConnection();
    ctx.repo.settings.set("source_last_check", result, req.auth!.id);
    if (!result.ok) {
      ctx.repo.logs.createEventThrottled(
        { event_type: "source_disconnected", description: `Uji koneksi gagal: ${result.message}`, status: "Error" },
        60_000
      );
    } else {
      ctx.repo.logs.createEvent({
        event_type: "system",
        description: `Uji koneksi sumber berhasil: ${result.message}`,
        status: "Success",
      });
    }
    ctx.repo.logs.createAudit({
      user_id: req.auth!.id,
      user_email: req.auth!.email,
      action: "settings.integration_test",
      details: { ok: result.ok },
    });
    res.json({ ...result, adapter: adapters.source.name, label: adapters.source.label });
  });

  return router;
}
