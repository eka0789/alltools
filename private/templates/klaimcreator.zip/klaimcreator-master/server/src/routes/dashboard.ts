import { Router } from "express";
import type { AppContext } from "../context";
import { getClaimMode } from "../services/claimService";
import { getAutomation } from "../services/notificationService";
import { buildMonitoringStatus } from "./monitoring";

/** Dashboard: 7 kartu statistik, grafik, tabel, status sumber/worker, refresh interval. */
export function dashboardRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/", (_req, res) => {
    const repo = ctx.repo;
    const creatorCounts = repo.stats.creatorCounts();
    const claimCounts = repo.stats.claimCounts();
    const automation = getAutomation(repo);
    const days = 14;

    // Grafik klaim per hari per status
    const claimsPerDayRaw = repo.claims.perDay(days);
    const daySet = new Set<string>();
    for (let i = days - 1; i >= 0; i--) {
      daySet.add(new Date(Date.now() - i * 86_400_000).toISOString().slice(0, 10));
    }
    const claimsPerDay = [...daySet].map((day) => {
      const rows = claimsPerDayRaw.filter((r) => r.day === day);
      const byStatus: Record<string, number> = {};
      for (const r of rows) byStatus[r.status] = r.n;
      return {
        day,
        success: byStatus["Success"] ?? 0,
        failed: (byStatus["Failed"] ?? 0) + (byStatus["Already Claimed"] ?? 0),
        total: rows.reduce((acc, r) => acc + r.n, 0),
      };
    });

    const syncPerDayRaw = repo.logs.syncPerDay(days);
    const syncPerDay = [...daySet].map((day) => ({
      day,
      count: syncPerDayRaw.find((r) => r.day === day)?.n ?? 0,
    }));

    const recentCreators = repo.creators.recent(8);
    const recentClaims = repo.claims.listFiltered({ page: 1, pageSize: 8 });

    res.json({
      stats: {
        totalCreators: creatorCounts.total,
        availableCreators: creatorCounts.byStatus["Available"] ?? 0,
        totalClaimed: creatorCounts.byStatus["Claimed"] ?? 0,
        claimsSuccess: claimCounts["Success"] ?? 0,
        claimsFailed: (claimCounts["Failed"] ?? 0) + (claimCounts["Already Claimed"] ?? 0),
        claimsPending: (claimCounts["Pending"] ?? 0) + (claimCounts["Processing"] ?? 0),
        lastSyncAt: repo.stats.lastSync()?.finished_at ?? repo.stats.lastSync()?.started_at ?? null,
      },
      charts: { claimsPerDay, syncPerDay },
      recentCreators: recentCreators.map((c) => ({
        id: c.id,
        username: c.username,
        nickname: c.nickname,
        status: c.status,
        followerCount: c.follower_count,
        firstSeenAt: c.first_seen_at,
      })),
      recentClaims: recentClaims.items.map((c) => ({
        id: c.id,
        username: c.username,
        status: c.status,
        mode: c.mode,
        claimedAt: c.claimed_at,
        createdAt: c.created_at,
        lastError: c.last_error,
      })),
      monitoring: buildMonitoringStatus(ctx),
      claimMode: getClaimMode(repo),
      refreshIntervalSeconds: automation.refreshIntervalSeconds,
    });
  });

  return router;
}
