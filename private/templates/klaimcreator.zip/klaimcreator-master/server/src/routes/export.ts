import { Router } from "express";
import { z } from "zod";
import { query, validate } from "../middleware/validate";
import type { AppContext } from "../context";
import { buildCsvContent, buildExcelBuffer, exportFileName, getExportRows } from "../services/exportService";
import { getAutomation } from "../services/notificationService";
import type { ClaimStatus } from "../types";

const exportQuerySchema = z.object({
  status: z
    .enum(["Success", "Failed", "Pending", "Processing", "Already Claimed", "Verification Required"])
    .optional(),
  from: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Format tanggal mulai harus YYYY-MM-DD")
    .optional(),
  to: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Format tanggal akhir harus YYYY-MM-DD")
    .optional(),
  usernamesOnly: z
    .union([z.literal("1"), z.literal("true"), z.literal("0"), z.literal("false")])
    .optional(),
});

function parseFilters(q: { status?: string; from?: string; to?: string; usernamesOnly?: string }) {
  return {
    statuses: (q.status ? [q.status as ClaimStatus] : ["Success"]) as ClaimStatus[],
    from: q.from ? `${q.from}T00:00:00.000Z` : null,
    to: q.to ? `${q.to}T23:59:59.999Z` : null,
    usernamesOnly: q.usernamesOnly === "1" || q.usernamesOnly === "true",
  };
}

/** Username Export: preview, CSV, dan Excel tersanitasi (formula injection di-escape). */
export function exportRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/preview", validate(exportQuerySchema, "query"), (req, res) => {
    const q = query<typeof exportQuerySchema>(req);
    const filters = parseFilters(q);
    const rows = getExportRows(ctx.repo, filters);
    res.json({
      rows: rows.slice(0, 500),
      total: rows.length,
      usernamesOnly: filters.usernamesOnly,
      statuses: filters.statuses,
    });
  });

  router.get("/csv", validate(exportQuerySchema, "query"), (req, res) => {
    const q = query<typeof exportQuerySchema>(req);
    const filters = parseFilters(q);
    const rows = getExportRows(ctx.repo, filters);
    const automation = getAutomation(ctx.repo);
    const csv = buildCsvContent(rows, filters.usernamesOnly);
    ctx.repo.logs.createAudit({
      user_id: req.auth!.id,
      user_email: req.auth!.email,
      action: "export.csv",
      details: { total: rows.length, statuses: filters.statuses, usernamesOnly: filters.usernamesOnly },
    });
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${exportFileName(automation.export.filenamePrefix, "csv")}"`);
    res.send(csv);
  });

  router.get("/excel", validate(exportQuerySchema, "query"), async (req, res) => {
    const q = query<typeof exportQuerySchema>(req);
    const filters = parseFilters(q);
    const rows = getExportRows(ctx.repo, filters);
    const automation = getAutomation(ctx.repo);
    const buffer = await buildExcelBuffer(rows, filters.usernamesOnly);
    ctx.repo.logs.createAudit({
      user_id: req.auth!.id,
      user_email: req.auth!.email,
      action: "export.excel",
      details: { total: rows.length, statuses: filters.statuses, usernamesOnly: filters.usernamesOnly },
    });
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename="${exportFileName(automation.export.filenamePrefix, "xlsx")}"`);
    res.send(buffer);
  });

  return router;
}
