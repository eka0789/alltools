import { Router } from "express";
import type { AppContext } from "../context";

/** Healthcheck app (dipakai Docker HEALTHCHECK). */
export function healthRoutes(ctx: AppContext): Router {
  const router = Router();

  router.get("/health", (_req, res) => {
    let dbOk = true;
    try {
      ctx.db.prepare("SELECT 1").get();
    } catch {
      dbOk = false;
    }
    res.status(dbOk ? 200 : 503).json({
      status: dbOk ? "ok" : "degraded",
      service: "app",
      db: dbOk ? "ok" : "error",
      uptimeSec: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
    });
  });

  return router;
}
