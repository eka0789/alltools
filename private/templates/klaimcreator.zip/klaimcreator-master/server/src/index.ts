import http from "node:http";
import type { Express } from "express";
import { loadConfig } from "./config";
import { logger } from "./logger";
import { bootstrap } from "./bootstrap";
import { makeLimiters } from "./middleware/rateLimit";
import { createApp } from "./app";
import { resolveAdapters } from "./adapters/registry";
import type { ClaimDeps } from "./services/claimService";

/**
 * Entry point service app: API + static frontend.
 * Service ini TIDAK memiliki scheduler; semua pekerjaan berat di service worker.
 */
function main(): void {
  const cfg = loadConfig();
  const boot = bootstrap(cfg);
  const limiters = makeLimiters(cfg);

  const ctx = {
    db: boot.db,
    repo: boot.repo,
    cfg,
    authService: boot.authService,
    notifier: boot.notifier,
    adapters: () => resolveAdapters(boot.repo, cfg),
    claimDeps: (): ClaimDeps => ({ db: boot.db, repo: boot.repo, notifier: boot.notifier, claimAdapter: resolveAdapters(boot.repo, cfg).claim }),
    limiters,
  };

  const app: Express = createApp(ctx, { serveClient: true });
  const server = http.createServer(app);
  server.listen(cfg.port, () => {
    logger.info("KlaimCreator app siap", { port: cfg.port, env: cfg.env, dbFile: cfg.dbFile });
  });

  const shutdown = (signal: string) => {
    logger.info(`App menerima ${signal}, mematikan HTTP server`);
    server.close(() => {
      try {
        boot.db.close();
      } catch {
        // db mungkin sudah tertutup
      }
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 8000).unref();
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

main();
