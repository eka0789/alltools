import path from "node:path";

/** Root folder server (bekerja baik dari src via tsx maupun dari dist hasil tsc). */
export const SERVER_ROOT = path.resolve(__dirname, "..");

const envSchema = {
  NODE_ENV: (v: string | undefined, d: string) => v ?? d,
  PORT: (v: string | undefined, d: string) => v ?? d,
  WORKER_PORT: (v: string | undefined, d: string) => v ?? d,
  DATA_DIR: (v: string | undefined) => v,
  BACKUP_DIR: (v: string | undefined) => v,
  JWT_SECRET: (v: string | undefined) => v,
  TRUST_PROXY: (v: string | undefined, d: string) => v ?? d,
  RATE_LIMIT_AUTH_MAX: (v: string | undefined, d: string) => v ?? d,
  RATE_LIMIT_API_MAX: (v: string | undefined, d: string) => v ?? d,
  CLAIM_TIMEOUT_MS: (v: string | undefined, d: string) => v ?? d,
  SEED_ADMIN_EMAIL: (v: string | undefined) => v,
  SEED_ADMIN_PASSWORD: (v: string | undefined) => v,
  MOCK_SOURCE_PAGES: (v: string | undefined, d: string) => v ?? d,
  MOCK_SOURCE_ITEMS_PER_PAGE: (v: string | undefined, d: string) => v ?? d,
  OFFICIAL_API_BASE_URL: (v: string | undefined) => v,
  OFFICIAL_API_KEY: (v: string | undefined) => v,
  OFFICIAL_API_TIMEOUT_MS: (v: string | undefined, d: string) => v ?? d,
  TELEGRAM_BOT_TOKEN: (v: string | undefined) => v,
  TELEGRAM_CHAT_ID: (v: string | undefined) => v,
  SMTP_HOST: (v: string | undefined) => v,
  SMTP_PORT: (v: string | undefined) => v,
  SMTP_USER: (v: string | undefined) => v,
  SMTP_PASS: (v: string | undefined) => v,
  SMTP_FROM: (v: string | undefined) => v,
} as const;

function readEnv(defaults: Record<string, string>): Record<string, string | undefined> {
  const out: Record<string, string | undefined> = {};
  for (const key of Object.keys(envSchema) as (keyof typeof envSchema)[]) {
    out[key] = envSchema[key](process.env[key], defaults[key]);
  }
  return out;
}

export interface AppConfig {
  env: "development" | "test" | "production";
  isProduction: boolean;
  port: number;
  workerPort: number;
  dbFile: string;
  dataDir: string;
  backupDir: string;
  jwtSecret: string;
  trustProxy: number;
  claimTimeoutMs: number;
  rateLimit: { windowMs: number; authMax: number; apiMax: number };
  seedAdminEmail: string | null;
  seedAdminPassword: string | null;
  mockSourcePages: number;
  mockSourceItemsPerPage: number;
  officialApiBaseUrl: string | null;
  officialApiKey: string | null;
  officialApiTimeoutMs: number;
  telegram: { botToken: string | null; chatId: string | null };
  smtp: { host: string | null; port: number | null; user: string | null; pass: string | null; from: string | null };
  clientDistDir: string;
}

export function loadConfig(overrides: Partial<Record<string, string | undefined>> = {}): AppConfig {
  const defaults: Record<string, string> = {
    NODE_ENV: "development",
    PORT: "4173",
    WORKER_PORT: "3001",
    TRUST_PROXY: "0",
    RATE_LIMIT_AUTH_MAX: "5",
    RATE_LIMIT_API_MAX: "300",
    CLAIM_TIMEOUT_MS: "600000",
    MOCK_SOURCE_PAGES: "3",
    MOCK_SOURCE_ITEMS_PER_PAGE: "15",
    OFFICIAL_API_TIMEOUT_MS: "15000",
  };
  const raw = { ...readEnv(defaults), ...overrides };
  const env = (raw.NODE_ENV as AppConfig["env"]) ?? "development";
  const isProduction = env === "production";

  const dataDir = raw.DATA_DIR && raw.DATA_DIR.length > 0 ? path.resolve(raw.DATA_DIR) : path.join(SERVER_ROOT, "data");
  const backupDir =
    raw.BACKUP_DIR && raw.BACKUP_DIR.length > 0 ? path.resolve(raw.BACKUP_DIR) : path.join(SERVER_ROOT, "backups");

  let jwtSecret = raw.JWT_SECRET ?? "";
  if (!jwtSecret) {
    if (isProduction) {
      throw new Error(
        "JWT_SECRET wajib diisi di produksi. Set variabel environment JWT_SECRET (min 32 karakter acak)."
      );
    }
    // Dev/test: secret acak per proses (sesi invalid saat restart). Bukan kredensial produksi.
    jwtSecret = `dev-only-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }

  const officialBase = raw.OFFICIAL_API_BASE_URL && raw.OFFICIAL_API_BASE_URL.length > 0 ? raw.OFFICIAL_API_BASE_URL : null;
  const officialKey = raw.OFFICIAL_API_KEY && raw.OFFICIAL_API_KEY.length > 0 ? raw.OFFICIAL_API_KEY : null;

  return {
    env,
    isProduction,
    port: Number(raw.PORT),
    workerPort: Number(raw.WORKER_PORT),
    dbFile: path.join(dataDir, "klaimcreator.db"),
    dataDir,
    backupDir,
    jwtSecret,
    trustProxy: Number(raw.TRUST_PROXY) || 0,
    claimTimeoutMs: Number(raw.CLAIM_TIMEOUT_MS) || 600000,
    rateLimit: {
      windowMs: 60_000,
      authMax: Number(raw.RATE_LIMIT_AUTH_MAX) || 5,
      apiMax: Number(raw.RATE_LIMIT_API_MAX) || 300,
    },
    seedAdminEmail: raw.SEED_ADMIN_EMAIL && raw.SEED_ADMIN_EMAIL.length > 0 ? raw.SEED_ADMIN_EMAIL : null,
    seedAdminPassword: raw.SEED_ADMIN_PASSWORD && raw.SEED_ADMIN_PASSWORD.length > 0 ? raw.SEED_ADMIN_PASSWORD : null,
    mockSourcePages: Math.max(1, Number(raw.MOCK_SOURCE_PAGES) || 3),
    mockSourceItemsPerPage: Math.max(1, Number(raw.MOCK_SOURCE_ITEMS_PER_PAGE) || 15),
    officialApiBaseUrl: officialBase,
    officialApiKey: officialKey,
    officialApiTimeoutMs: Number(raw.OFFICIAL_API_TIMEOUT_MS) || 15000,
    telegram: {
      botToken: raw.TELEGRAM_BOT_TOKEN && raw.TELEGRAM_BOT_TOKEN.length > 0 ? raw.TELEGRAM_BOT_TOKEN : null,
      chatId: raw.TELEGRAM_CHAT_ID && raw.TELEGRAM_CHAT_ID.length > 0 ? raw.TELEGRAM_CHAT_ID : null,
    },
    smtp: {
      host: raw.SMTP_HOST || null,
      port: raw.SMTP_PORT ? Number(raw.SMTP_PORT) : null,
      user: raw.SMTP_USER || null,
      pass: raw.SMTP_PASS || null,
      from: raw.SMTP_FROM || null,
    },
    clientDistDir: path.resolve(SERVER_ROOT, "..", "client", "dist"),
  };
}

/** Konfigurasi aplikasi global (satu instance per proses). */
let current: AppConfig | null = null;
export function config(): AppConfig {
  if (!current) current = loadConfig();
  return current;
}
export function setConfig(c: AppConfig): void {
  current = c;
}
