/**
 * Logger terpusat dengan sanitizer field sensitif.
 * Tidak ada password, token, atau kredensial yang boleh tercatat (PRD 3I).
 */

const SENSITIVE_KEYS = new Set([
  "password",
  "password_hash",
  "passwordhash",
  "newpassword",
  "currentpassword",
  "token",
  "access_token",
  "refresh_token",
  "accesstoken",
  "refreshtoken",
  "authorization",
  "cookie",
  "secret",
  "api_key",
  "apikey",
  "bot_token",
  "session",
]);

export type LogMeta = Record<string, unknown>;

function sanitizeValue(value: unknown, depth = 0): unknown {
  if (depth > 4) return "[truncated]";
  if (value === null || value === undefined) return value;
  if (Array.isArray(value)) return value.map((v) => sanitizeValue(v, depth + 1));
  if (typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (SENSITIVE_KEYS.has(k.toLowerCase())) out[k] = "[redacted]";
      else out[k] = sanitizeValue(v, depth + 1);
    }
    return out;
  }
  if (typeof value === "string") {
    // Sanitasi pola token yang tidak sengaja terlewat dalam string
    return value
      .replace(/(Bearer\s+)[A-Za-z0-9\-._~+/]+=*/gi, "$1[redacted]")
      .replace(/(eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})/g, "[redacted-jwt]");
  }
  return value;
}

export function sanitizeMeta(meta: LogMeta): LogMeta {
  return sanitizeValue(meta) as LogMeta;
}

function emit(level: "info" | "warn" | "error", message: string, meta?: LogMeta): void {
  const entry = {
    ts: new Date().toISOString(),
    level,
    msg: message,
    ...(meta ? sanitizeMeta(meta) : {}),
  };
  const line = JSON.stringify(entry);
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export const logger = {
  info: (msg: string, meta?: LogMeta) => emit("info", msg, meta),
  warn: (msg: string, meta?: LogMeta) => emit("warn", msg, meta),
  error: (msg: string, meta?: LogMeta) => emit("error", msg, meta),
};
