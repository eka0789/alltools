/**
 * Skema database KlaimCreator (SQLite).
 * Primary key UUID (TEXT), unique constraint dedup, index pada kolom pencarian.
 * SQL disimpan sebagai string agar tidak perlu langkah copy aset saat build.
 */
export interface Migration {
  id: string;
  name: string;
  sql: string;
}

export const MIGRATIONS: Migration[] = [
  {
    id: "001",
    name: "init_schema",
    sql: `
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','operator')),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  must_change_password INTEGER NOT NULL DEFAULT 0 CHECK (must_change_password IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user ON refresh_tokens(user_id);

CREATE TABLE IF NOT EXISTS creators (
  id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  external_id TEXT NOT NULL,
  username TEXT NOT NULL,
  nickname TEXT,
  follower_count INTEGER,
  status TEXT NOT NULL CHECK (status IN ('Available','Claimed','Pending','Failed','Unavailable')),
  raw_data TEXT,
  first_seen_at TEXT NOT NULL,
  last_updated_at TEXT NOT NULL,
  UNIQUE (source, external_id),
  UNIQUE (source, username)
);
CREATE INDEX IF NOT EXISTS idx_creators_status ON creators(status);
CREATE INDEX IF NOT EXISTS idx_creators_username ON creators(username);
CREATE INDEX IF NOT EXISTS idx_creators_external_id ON creators(external_id);
CREATE INDEX IF NOT EXISTS idx_creators_last_updated ON creators(last_updated_at);
CREATE INDEX IF NOT EXISTS idx_creators_first_seen ON creators(first_seen_at);

CREATE TABLE IF NOT EXISTS creator_status_histories (
  id TEXT PRIMARY KEY,
  creator_id TEXT NOT NULL REFERENCES creators(id) ON DELETE CASCADE,
  old_status TEXT,
  new_status TEXT NOT NULL,
  reason TEXT,
  changed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csh_creator ON creator_status_histories(creator_id, changed_at);

CREATE TABLE IF NOT EXISTS claims (
  id TEXT PRIMARY KEY,
  creator_id TEXT NOT NULL REFERENCES creators(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('Pending','Processing','Success','Failed','Already Claimed','Verification Required')),
  mode TEXT NOT NULL CHECK (mode IN ('automatic','assisted')),
  requested_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  attempt_count INTEGER NOT NULL DEFAULT 0,
  next_retry_at TEXT,
  last_error TEXT,
  claimed_at TEXT,
  verified_at TEXT,
  verified_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
-- Idempotensi eksekusi klaim ditegakkan database: satu klaim aktif per creator.
CREATE UNIQUE INDEX IF NOT EXISTS idx_claims_active_per_creator
  ON claims(creator_id) WHERE status IN ('Pending','Processing');
CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(status);
CREATE INDEX IF NOT EXISTS idx_claims_created ON claims(created_at);
CREATE INDEX IF NOT EXISTS idx_claims_creator ON claims(creator_id);

CREATE TABLE IF NOT EXISTS claim_attempts (
  id TEXT PRIMARY KEY,
  claim_id TEXT NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  attempt_number INTEGER NOT NULL,
  result TEXT NOT NULL CHECK (result IN ('Success','Failed','Already Claimed','Verification Required','Error')),
  message TEXT,
  executed_by TEXT,
  started_at TEXT NOT NULL,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ca_claim ON claim_attempts(claim_id, attempt_number);

CREATE TABLE IF NOT EXISTS sync_locks (
  lock_name TEXT PRIMARY KEY,
  owner TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  renewed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS synchronization_logs (
  id TEXT PRIMARY KEY,
  trigger TEXT NOT NULL CHECK (trigger IN ('schedule','manual')),
  status TEXT NOT NULL CHECK (status IN ('Success','Failed')),
  started_at TEXT NOT NULL,
  finished_at TEXT,
  pages_fetched INTEGER NOT NULL DEFAULT 0,
  items_fetched INTEGER NOT NULL DEFAULT 0,
  items_created INTEGER NOT NULL DEFAULT 0,
  items_updated INTEGER NOT NULL DEFAULT 0,
  available_detected INTEGER NOT NULL DEFAULT 0,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_synclog_started ON synchronization_logs(started_at);

CREATE TABLE IF NOT EXISTS system_events (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  description TEXT NOT NULL,
  creator_id TEXT REFERENCES creators(id) ON DELETE SET NULL,
  status TEXT NOT NULL CHECK (status IN ('Info','Success','Warning','Error')),
  metadata TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_type ON system_events(event_type, created_at);
CREATE INDEX IF NOT EXISTS idx_events_creator ON system_events(creator_id);
CREATE INDEX IF NOT EXISTS idx_events_created ON system_events(created_at);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  user_email TEXT,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id TEXT,
  details TEXT,
  ip TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);

CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  updated_by TEXT
);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  is_read INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_created ON notifications(created_at);

CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('sync_manual','process_claims')),
  payload TEXT,
  status TEXT NOT NULL CHECK (status IN ('queued','running','done','failed')),
  requested_by TEXT,
  result TEXT,
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status, created_at);
`,
  },
  {
    id: "002",
    name: "user_token_epoch",
    // Epoch sesi: dinaikkan saat logout/ganti password/nonaktif agar seluruh
    // access token JWT lama langsung ditolak, bukan menunggu kedaluwarsa 15 menit.
    sql: `
ALTER TABLE users ADD COLUMN token_epoch TEXT NOT NULL DEFAULT '0';
`,
  },
];
