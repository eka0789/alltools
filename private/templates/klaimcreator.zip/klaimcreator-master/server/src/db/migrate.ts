import type { SqliteDb } from "./connection";
import { MIGRATIONS } from "./migrations";

/** Migration runner bawaan: menerapkan migrasi berurutan sekali, tercatat di _migrations. */
export function runMigrations(db: SqliteDb): void {
  db.exec(
    `CREATE TABLE IF NOT EXISTS _migrations (id TEXT PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL)`
  );
  const appliedRows = db.prepare(`SELECT id FROM _migrations`).all() as Array<{ id: string }>;
  const applied = new Set(appliedRows.map((r) => r.id));

  for (const migration of MIGRATIONS) {
    if (applied.has(migration.id)) continue;
    const apply = db.transaction(() => {
      db.exec(migration.sql);
      db.prepare(`INSERT INTO _migrations (id, name, applied_at) VALUES (?, ?, ?)`).run(
        migration.id,
        migration.name,
        new Date().toISOString()
      );
    });
    apply();
  }
}
