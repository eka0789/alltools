import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

/**
 * Satu-satunya titik pembukaan koneksi SQLite.
 * Mode WAL + busy_timeout agar app API dan worker dapat berbagi file database
 * tanpa saling memblokir pembacaan (single-writer ditangani transaksi singkat).
 */
export function openDatabase(file: string): Database.Database {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new Database(file);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.pragma("busy_timeout = 5000");
  db.pragma("synchronous = NORMAL");
  return db;
}

export type SqliteDb = Database.Database;
