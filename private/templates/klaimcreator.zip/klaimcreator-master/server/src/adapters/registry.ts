import type { AppConfig } from "../config";
import type { Repository } from "../repository";
import { MockClaimAdapter, MockSourceAdapter, type MockCycleStateStore, type MockSourceConfig } from "./mock";
import { OfficialHttpClaimAdapter, OfficialHttpSourceAdapter } from "./official";
import type { ClaimExecutionAdapter, SourceAdapter } from "./types";

export interface IntegrationSettings {
  adapter: "mock" | "official";
  official: { enabled: boolean; baseUrlEnv: string; apiKeyEnv: string; claimPath: string };
  mock: { pages: number; itemsPerPage: number; newItemsPerCycle: number; faultMode: "none" | "disconnected" };
}

export interface AdapterBundle {
  source: SourceAdapter;
  claim: ClaimExecutionAdapter | null;
  /** true bila integrasi resmi aktif dan kredensial tersedia (syarat mode otomatis). */
  officialReady: boolean;
}

function readIntegration(repo: Repository): IntegrationSettings {
  const stored = repo.settings.get<IntegrationSettings>("integration");
  const officialDefaults: IntegrationSettings["official"] = {
    enabled: false,
    baseUrlEnv: "OFFICIAL_API_BASE_URL",
    apiKeyEnv: "OFFICIAL_API_KEY",
    claimPath: "/v1/claims",
  };
  const mockDefaults: IntegrationSettings["mock"] = { pages: 3, itemsPerPage: 15, newItemsPerCycle: 2, faultMode: "none" };
  const base = stored ?? { adapter: "mock" as const, official: officialDefaults, mock: mockDefaults };
  return {
    ...base,
    official: { ...officialDefaults, ...base.official },
    mock: { ...mockDefaults, ...base.mock },
  };
}

function envValue(name: string): string | null {
  const value = process.env[name];
  return value && value.length > 0 ? value : null;
}

/**
 * Satu tempat membangun adapter dari pengaturan.
 * Mode klaim otomatis hanya mungkin bila officialReady === true.
 */
export function resolveAdapters(repo: Repository, cfg: AppConfig): AdapterBundle {
  const integration = readIntegration(repo);
  const officialBase = envValue(integration.official.baseUrlEnv);
  const officialKey = envValue(integration.official.apiKeyEnv);
  const officialReady = integration.official.enabled === true && officialBase !== null && officialKey !== null;

  if (integration.adapter === "official" && officialReady) {
    return {
      source: new OfficialHttpSourceAdapter(officialBase as string, officialKey as string, cfg.officialApiTimeoutMs),
      claim: new OfficialHttpClaimAdapter(officialBase as string, officialKey as string, integration.official.claimPath, cfg.officialApiTimeoutMs),
      officialReady: true,
    };
  }

  const settingsMock = integration.mock;
  const mockCfg: MockSourceConfig = {
    pages: Math.max(1, settingsMock.pages ?? cfg.mockSourcePages),
    itemsPerPage: Math.max(1, settingsMock.itemsPerPage ?? cfg.mockSourceItemsPerPage),
    newItemsPerCycle: Math.max(0, settingsMock.newItemsPerCycle ?? 2),
    faultMode: settingsMock.faultMode === "disconnected" ? "disconnected" : "none",
  };
  const stateStore: MockCycleStateStore = {
    get: () => repo.settings.get<number>("mock_source_cycle") ?? 0,
    set: (cycle) => repo.settings.set("mock_source_cycle", cycle),
  };
  return { source: new MockSourceAdapter(mockCfg, stateStore), claim: null, officialReady: false };
}

export type MockClaimOutcome = "success" | "already_claimed" | "transient_error" | "uncertain" | "hard_error";

/** Adapter klaim Mock untuk worker/test (mode otomatis dengan backend simulasi). */
export function buildMockClaimAdapter(
  script?: { defaultOutcome?: MockClaimOutcome; perUsername?: Record<string, MockClaimOutcome> }
): ClaimExecutionAdapter {
  return new MockClaimAdapter({ defaultOutcome: script?.defaultOutcome ?? "success", perUsername: script?.perUsername });
}
