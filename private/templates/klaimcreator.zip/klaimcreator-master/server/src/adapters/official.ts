import { SourceUnavailableError, type ClaimExecutionAdapter, type ClaimExecutionResult, type ConnectionTestResult, type CreatorItem, type FetchPageResult, type SourceAdapter } from "./types";

/**
 * Adapter integrasi resmi berotorisasi (HTTP).
 * Kredensial HANYA dari environment variables; tanpa itu adapter tidak aktif
 * dan sistem berjalan pada Assisted Claim Mode.
 */
export class OfficialHttpSourceAdapter implements SourceAdapter {
  readonly name = "official";
  readonly label = "Sumber: Integrasi Resmi";
  constructor(
    private baseUrl: string,
    private apiKey: string,
    private timeoutMs: number
  ) {}

  private async request(pathname: string, init?: RequestInit): Promise<Response> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      return await fetch(`${this.baseUrl.replace(/\/$/, "")}${pathname}`, {
        ...init,
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          Accept: "application/json",
          ...(init?.headers ?? {}),
        },
      });
    } catch (err) {
      throw new SourceUnavailableError(`Sumber resmi tidak dapat dihubungi: ${(err as Error).message}`);
    } finally {
      clearTimeout(timer);
    }
  }

  async testConnection(): Promise<ConnectionTestResult> {
    try {
      const res = await this.request("/health");
      if (!res.ok) {
        return { ok: false, message: `Sumber merespons dengan status ${res.status}`, checkedAt: new Date().toISOString() };
      }
      return { ok: true, message: "Koneksi ke sumber resmi sehat", checkedAt: new Date().toISOString() };
    } catch (err) {
      return { ok: false, message: (err as Error).message, checkedAt: new Date().toISOString() };
    }
  }

  async fetchCreatorsPage(page: number, pageSize: number): Promise<FetchPageResult> {
    const res = await this.request(`/creators?page=${encodeURIComponent(page)}&pageSize=${encodeURIComponent(pageSize)}`);
    if (!res.ok) {
      if (res.status >= 500) throw new SourceUnavailableError(`Sumber merespons ${res.status}`);
      throw new Error(`Sumber menolak permintaan dengan status ${res.status}`);
    }
    const body = (await res.json()) as {
      items?: Array<{ externalId?: string; id?: string; username?: string; nickname?: string | null; followerCount?: number | null; status?: string }>;
      totalPages?: number;
      totalItems?: number;
    };
    const items: CreatorItem[] = (body.items ?? []).map((raw) => ({
      externalId: String(raw.externalId ?? raw.id ?? ""),
      username: String(raw.username ?? ""),
      nickname: raw.nickname ?? null,
      followerCount: typeof raw.followerCount === "number" ? raw.followerCount : null,
      status: (raw.status === "Claimed" || raw.status === "Unavailable" ? raw.status : "Available") as CreatorItem["status"],
    }));
    return {
      page,
      pageSize,
      totalPages: Math.max(1, Number(body.totalPages) || 1),
      totalItems: Math.max(items.length, Number(body.totalItems) || items.length),
      items,
    };
  }
}

export class OfficialHttpClaimAdapter implements ClaimExecutionAdapter {
  readonly name = "official-claim";
  constructor(
    private baseUrl: string,
    private apiKey: string,
    private claimPath: string,
    private timeoutMs: number
  ) {}

  async claim(username: string): Promise<ClaimExecutionResult> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl.replace(/\/$/, "")}${this.claimPath}`, {
        method: "POST",
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username }),
      });
      if (res.status === 409 || res.status === 422) {
        const body = (await res.json().catch(() => ({}))) as { code?: string };
        if (body.code === "already_claimed" || res.status === 409) {
          return { outcome: "already_claimed", message: "Username sudah diklaim pihak lain" };
        }
        return { outcome: "hard_error", message: `Sumber menolak klaim dengan status ${res.status}` };
      }
      if (res.status >= 500) {
        return { outcome: "transient_error", message: `Sumber mengalami gangguan (${res.status})` };
      }
      if (!res.ok) {
        return { outcome: "hard_error", message: `Sumber menolak permintaan (${res.status})` };
      }
      const body = (await res.json().catch(() => ({}))) as { result?: string; status?: string };
      const result = String(body.result ?? body.status ?? "success");
      if (result === "already_claimed") return { outcome: "already_claimed", message: "Username sudah diklaim pihak lain" };
      if (result === "uncertain" || result === "pending_review") return { outcome: "uncertain", message: "Hasil klaim belum pasti, perlu verifikasi" };
      if (result === "failed") return { outcome: "transient_error", message: "Sumber melaporkan kegagalan sementara" };
      if (result === "success") return { outcome: "success", message: "Klaim berhasil dikonfirmasi sumber" };
      return { outcome: "uncertain", message: `Sumber melaporkan status tidak dikenal: ${result}` };
    } catch (err) {
      // Timeout/abort di tengah request = hasil tidak pasti, JANGAN pernah di-retry buta.
      if ((err as Error).name === "AbortError") {
        return { outcome: "uncertain", message: "Timeout menunggu konfirmasi sumber, hasil tidak pasti" };
      }
      return { outcome: "transient_error", message: `Gangguan jaringan ke sumber: ${(err as Error).message}` };
    } finally {
      clearTimeout(timer);
    }
  }
}
