import type {
  ConnectionTestResult,
  CreatorItem,
  FetchPageResult,
  SourceAdapter,
  SourceCreatorStatus,
} from "./types";

export interface MockSourceConfig {
  pages: number;
  itemsPerPage: number;
  /** Jumlah creator baru yang "muncul" tiap siklus sinkronisasi. */
  newItemsPerCycle: number;
  /** Injeksi gangguan untuk pengujian: 'none' | 'disconnected'. */
  faultMode: "none" | "disconnected";
}

export interface MockCycleStateStore {
  get(): number;
  set(cycle: number): void;
}

const STATUSES: SourceCreatorStatus[] = ["Available", "Available", "Available", "Claimed", "Unavailable", "Available"];

/**
 * Adapter Mock (berlabel jelas "Sumber: Mock" di UI).
 * Deterministik: username creator_0001..creator_NNNN; tiap siklus menambah
 * newItemsPerCycle creator baru agar deteksi "creator baru available" dapat diuji.
 */
export class MockSourceAdapter implements SourceAdapter {
  readonly name = "mock";
  readonly label = "Sumber: Mock";
  private cycle: number;

  constructor(
    private cfg: MockSourceConfig,
    private state: MockCycleStateStore = { get: () => 0, set: () => undefined }
  ) {
    this.cycle = state.get();
  }

  /** Dipanggil sinkronisasi setelah siklus selesai agar creator baru muncul di siklus berikutnya. */
  advanceCycle(): void {
    this.cycle += 1;
    this.state.set(this.cycle);
  }

  totalItems(): number {
    const base = this.cfg.pages * this.cfg.itemsPerPage;
    return base + this.cfg.newItemsPerCycle * this.cycle;
  }

  async testConnection(): Promise<ConnectionTestResult> {
    if (this.cfg.faultMode === "disconnected") {
      return { ok: false, message: "Mock source sedang dalam mode gangguan (disconnected)", checkedAt: new Date().toISOString() };
    }
    return { ok: true, message: "Koneksi ke Mock source sehat", checkedAt: new Date().toISOString() };
  }

  async fetchCreatorsPage(page: number, pageSize: number): Promise<FetchPageResult> {
    if (this.cfg.faultMode === "disconnected") {
      throw new Error("Mock source tidak dapat dihubungi (faultMode=disconnected)");
    }
    const total = this.totalItems();
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const items: CreatorItem[] = [];
    const start = (page - 1) * pageSize;
    for (let i = start; i < Math.min(start + pageSize, total); i++) {
      const n = i + 1;
      items.push({
        externalId: `mock-${String(n).padStart(5, "0")}`,
        username: `creator_${String(n).padStart(4, "0")}`,
        nickname: `Creator ${String(n).padStart(4, "0")}`,
        followerCount: 1200 + ((n * 7919) % 240_000),
        status: STATUSES[n % STATUSES.length] as SourceCreatorStatus,
        rawData: { mock: true, index: n },
      });
    }
    return { page, pageSize, totalPages, totalItems: total, items };
  }
}

export interface MockClaimScript {
  defaultOutcome: "success" | "already_claimed" | "transient_error" | "uncertain" | "hard_error";
  /** Pengecualian per username untuk skenario pengujian. */
  perUsername?: Record<string, "success" | "already_claimed" | "transient_error" | "uncertain" | "hard_error">;
}

/** Adapter klaim Mock: dipakai worker/test untuk simulasi eksekusi klaim otomatis. */
export class MockClaimAdapter {
  readonly name = "mock-claim";
  constructor(private script: MockClaimScript) {}
  async claim(username: string): Promise<{ outcome: MockClaimScript["defaultOutcome"]; message: string }> {
    const outcome = this.script.perUsername?.[username] ?? this.script.defaultOutcome;
    const messages: Record<MockClaimScript["defaultOutcome"], string> = {
      success: "Klaim berhasil (mock)",
      already_claimed: "Username ternyata sudah diklaim pihak lain (mock)",
      transient_error: "Gateway sumber sedang sibuk, coba lagi (mock)",
      uncertain: "Hasil tidak pasti: request terkirim tanpa konfirmasi (mock)",
      hard_error: "Permintaan ditolak sumber: payload tidak valid (mock)",
    };
    return { outcome, message: messages[outcome] };
  }
}
