import type { CreatorStatus } from "../types";

/** Status seperti yang dilaporkan sumber (Pending/Failed adalah status internal klaim). */
export type SourceCreatorStatus = "Available" | "Claimed" | "Unavailable";

export interface CreatorItem {
  externalId: string;
  username: string;
  nickname: string | null;
  followerCount: number | null;
  status: SourceCreatorStatus;
  rawData?: Record<string, unknown>;
}

export interface FetchPageResult {
  page: number;
  pageSize: number;
  totalPages: number;
  totalItems: number;
  items: CreatorItem[];
}

export interface ConnectionTestResult {
  ok: boolean;
  message: string;
  checkedAt: string;
}

export interface SourceAdapter {
  /** Nama teknis adapter (mock | official). */
  readonly name: string;
  /** Label human-readable, selalu ditampilkan di UI (mis. "Sumber: Mock"). */
  readonly label: string;
  testConnection(): Promise<ConnectionTestResult>;
  fetchCreatorsPage(page: number, pageSize: number): Promise<FetchPageResult>;
}

export type ClaimOutcome = "success" | "already_claimed" | "transient_error" | "uncertain" | "hard_error";

export interface ClaimExecutionResult {
  outcome: ClaimOutcome;
  message: string;
}

/** Adapter eksekusi klaim otomatis (hanya tersedia saat integrasi resmi aktif). */
export interface ClaimExecutionAdapter {
  readonly name: string;
  claim(username: string): Promise<ClaimExecutionResult>;
}

/** Error khusus: sumber tidak dapat dihubungi (memicu event source_disconnected). */
export class SourceUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SourceUnavailableError";
  }
}

export function toInternalStatus(status: SourceCreatorStatus): CreatorStatus {
  return status;
}
