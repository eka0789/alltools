/** Spesifikasi OpenAPI 3 yang dilayani di /api/docs (Swagger UI). */
export const openApiSpec = {
  openapi: "3.0.3",
  info: {
    title: "KlaimCreator API",
    version: "1.0.0",
    description:
      "API dashboard monitoring dan klaim username TikTok Affiliate. Autentikasi via cookie httpOnly (JWT access + refresh rotasi). Semua mutasi wajib header X-Requested-With: XMLHttpRequest.",
  },
  servers: [{ url: "/" }],
  tags: [
    { name: "Auth" },
    { name: "Dashboard" },
    { name: "Creators" },
    { name: "Claims" },
    { name: "Monitoring" },
    { name: "Export" },
    { name: "Settings" },
    { name: "Logs" },
    { name: "Users" },
    { name: "Health" },
  ],
  components: {
    securitySchemes: {
      cookieAuth: { type: "apiKey", in: "cookie", name: "kc_at" },
    },
    schemas: {
      Error: {
        type: "object",
        properties: {
          error: {
            type: "object",
            properties: {
              code: { type: "string" },
              message: { type: "string" },
              fields: { type: "object", additionalProperties: { type: "string" } },
            },
          },
        },
      },
      User: {
        type: "object",
        properties: {
          id: { type: "string", format: "uuid" },
          email: { type: "string" },
          name: { type: "string" },
          role: { type: "string", enum: ["admin", "operator"] },
          mustChangePassword: { type: "boolean" },
        },
      },
      Creator: {
        type: "object",
        properties: {
          id: { type: "string", format: "uuid" },
          source: { type: "string" },
          externalId: { type: "string" },
          username: { type: "string" },
          nickname: { type: "string", nullable: true },
          followerCount: { type: "integer", nullable: true },
          status: { type: "string", enum: ["Available", "Claimed", "Pending", "Failed", "Unavailable"] },
          firstSeenAt: { type: "string", format: "date-time" },
          lastUpdatedAt: { type: "string", format: "date-time" },
        },
      },
      Claim: {
        type: "object",
        properties: {
          id: { type: "string", format: "uuid" },
          creatorId: { type: "string", format: "uuid" },
          username: { type: "string" },
          status: { type: "string", enum: ["Pending", "Processing", "Success", "Failed", "Already Claimed", "Verification Required"] },
          mode: { type: "string", enum: ["automatic", "assisted"] },
          attemptCount: { type: "integer" },
          nextRetryAt: { type: "string", format: "date-time", nullable: true },
          claimedAt: { type: "string", format: "date-time", nullable: true },
          createdAt: { type: "string", format: "date-time" },
        },
      },
    },
  },
  paths: {
    "/api/auth/login": {
      post: {
        tags: ["Auth"],
        summary: "Login dengan email dan password (rate limit 5/menit)",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email", "password"],
                properties: { email: { type: "string" }, password: { type: "string" } },
              },
            },
          },
        },
        responses: {
          "200": { description: "Login berhasil, cookie httpOnly di-set" },
          "401": { description: "Kredensial salah", content: { "application/json": { schema: { $ref: "#/components/schemas/Error" } } } },
          "429": { description: "Terlalu banyak percobaan" },
        },
      },
    },
    "/api/auth/me": {
      get: {
        tags: ["Auth"],
        summary: "Pulihkan sesi dari cookie access token",
        security: [{ cookieAuth: [] }],
        responses: {
          "200": { description: "User saat ini" },
          "401": { description: "Tidak terautentikasi" },
        },
      },
    },
    "/api/auth/refresh": {
      post: {
        tags: ["Auth"],
        summary: "Rotasi refresh token",
        responses: { "200": { description: "Pasangan token baru" }, "401": { description: "Sesi berakhir" } },
      },
    },
    "/api/auth/logout": {
      post: {
        tags: ["Auth"],
        summary: "Logout dan cabut refresh token",
        responses: { "200": { description: "OK" } },
      },
    },
    "/api/auth/change-password": {
      post: {
        tags: ["Auth"],
        summary: "Ganti password sendiri (wajib pada login pertama)",
        security: [{ cookieAuth: [] }],
        responses: { "200": { description: "Password diganti" }, "400": { description: "Validasi gagal" } },
      },
    },
    "/api/dashboard": {
      get: {
        tags: ["Dashboard"],
        summary: "Statistik 7 kartu, grafik, tabel terbaru, status sumber/worker",
        security: [{ cookieAuth: [] }],
        responses: { "200": { description: "Data dashboard" } },
      },
    },
    "/api/creators": {
      get: {
        tags: ["Creators"],
        summary: "Daftar creator dengan pencarian, filter status, pagination, sorting",
        security: [{ cookieAuth: [] }],
        parameters: [
          { name: "search", in: "query", schema: { type: "string" } },
          { name: "status", in: "query", schema: { type: "string", enum: ["Available", "Claimed", "Pending", "Failed", "Unavailable"] } },
          { name: "page", in: "query", schema: { type: "integer", default: 1 } },
          { name: "pageSize", in: "query", schema: { type: "integer", default: 20 } },
          { name: "sort", in: "query", schema: { type: "string", enum: ["newest", "oldest", "username"] } },
        ],
        responses: { "200": { description: "Daftar creator" } },
      },
    },
    "/api/creators/available": {
      get: {
        tags: ["Creators"],
        summary: "Creator Available tanpa klaim aktif, terbaru lebih dulu",
        security: [{ cookieAuth: [] }],
        responses: { "200": { description: "Daftar creator tersedia" } },
      },
    },
    "/api/creators/{id}/history": {
      get: {
        tags: ["Creators"],
        summary: "Riwayat perubahan status creator",
        security: [{ cookieAuth: [] }],
        parameters: [{ name: "id", in: "path", required: true, schema: { type: "string", format: "uuid" } }],
        responses: { "200": { description: "Riwayat status" }, "404": { description: "Tidak ditemukan" } },
      },
    },
    "/api/claims": {
      get: {
        tags: ["Claims"],
        summary: "Daftar klaim dengan filter status (termasuk Already Claimed)",
        security: [{ cookieAuth: [] }],
        responses: { "200": { description: "Daftar klaim" } },
      },
      post: {
        tags: ["Claims"],
        summary: "Antrikan creator Available ke claim queue",
        security: [{ cookieAuth: [] }],
        responses: { "201": { description: "Klaim Pending dibuat" }, "409": { description: "Ditolak (duplikat/terminal/bukan Available)" } },
      },
    },
    "/api/claims/{id}/assisted-result": {
      post: {
        tags: ["Claims"],
        summary: "Catat hasil klaim assisted (Operator/Admin)",
        security: [{ cookieAuth: [] }],
        parameters: [{ name: "id", in: "path", required: true, schema: { type: "string", format: "uuid" } }],
        responses: { "200": { description: "Hasil dicatat" }, "409": { description: "Status klaim tidak valid" } },
      },
    },
    "/api/claims/{id}/verify": {
      post: {
        tags: ["Claims"],
        summary: "Verifikasi manual klaim Verification Required (khusus Admin)",
        security: [{ cookieAuth: [] }],
        parameters: [{ name: "id", in: "path", required: true, schema: { type: "string", format: "uuid" } }],
        responses: { "200": { description: "Hasil verifikasi dicatat" }, "403": { description: "Hanya Admin" } },
      },
    },
    "/api/claims/{id}/retry": {
      post: {
        tags: ["Claims"],
        summary: "Jadwalkan ulang klaim Failed",
        security: [{ cookieAuth: [] }],
        parameters: [{ name: "id", in: "path", required: true, schema: { type: "string", format: "uuid" } }],
        responses: { "200": { description: "Klaim kembali Pending" }, "409": { description: "Status tidak dapat di-retry" } },
      },
    },
    "/api/monitoring/status": {
      get: {
        tags: ["Monitoring"],
        summary: "Status monitoring, emergency stop, worker, lease, last sync",
        security: [{ cookieAuth: [] }],
        responses: { "200": { description: "Status monitoring" } },
      },
    },
    "/api/monitoring/start": {
      post: { tags: ["Monitoring"], summary: "Mulai monitoring", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" }, "409": { description: "Emergency stop aktif" } } },
    },
    "/api/monitoring/stop": {
      post: { tags: ["Monitoring"], summary: "Hentikan monitoring", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
    },
    "/api/monitoring/sync": {
      post: { tags: ["Monitoring"], summary: "Jadwalkan sinkronisasi manual (via job worker)", security: [{ cookieAuth: [] }], responses: { "202": { description: "Job dijadwalkan" }, "409": { description: "Sudah ada job / emergency stop" } } },
    },
    "/api/monitoring/emergency-stop": {
      post: { tags: ["Monitoring"], summary: "Emergency Stop: hentikan scheduler+worker, Processing menjadi Verification Required", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
    },
    "/api/monitoring/emergency-release": {
      post: { tags: ["Monitoring"], summary: "Buka Emergency Stop (khusus Admin)", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" }, "403": { description: "Hanya Admin" } } },
    },
    "/api/export/preview": {
      get: {
        tags: ["Export"],
        summary: "Preview baris export (default klaim Success, tanpa duplikat username)",
        security: [{ cookieAuth: [] }],
        parameters: [
          { name: "status", in: "query", schema: { type: "string", enum: ["Success", "Failed", "Already Claimed", "Verification Required", "Pending", "Processing"] } },
          { name: "from", in: "query", schema: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" } },
          { name: "to", in: "query", schema: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" } },
        ],
        responses: { "200": { description: "Baris export" } },
      },
    },
    "/api/export/csv": {
      get: {
        tags: ["Export"],
        summary: "Unduh CSV tersanitasi (No, Creator ID, Username, Claim Status, Claim Date)",
        security: [{ cookieAuth: [] }],
        responses: { "200": { description: "File CSV", content: { "text/csv": { schema: { type: "string" } } } } },
      },
    },
    "/api/export/excel": {
      get: {
        tags: ["Export"],
        summary: "Unduh Excel .xlsx tersanitasi",
        security: [{ cookieAuth: [] }],
        responses: { "200": { description: "File xlsx" } },
      },
    },
    "/api/settings/automation": {
      get: { tags: ["Settings"], summary: "Baca Automation Settings", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
      put: {
        tags: ["Settings"],
        summary: "Ubah Automation Settings (Admin): interval, retry, mode klaim, jadwal, notifikasi, export",
        security: [{ cookieAuth: [] }],
        responses: { "200": { description: "OK" }, "403": { description: "Hanya Admin" }, "409": { description: "Mode otomatis butuh integrasi resmi" } },
      },
    },
    "/api/settings/integration": {
      get: { tags: ["Settings"], summary: "Baca Integration Settings (hanya nama referensi env)", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
      put: { tags: ["Settings"], summary: "Ubah Integration Settings (Admin)", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
    },
    "/api/settings/integration/test": {
      post: { tags: ["Settings"], summary: "Uji koneksi sumber data (Admin)", security: [{ cookieAuth: [] }], responses: { "200": { description: "Hasil uji koneksi" } } },
    },
    "/api/logs/events": {
      get: { tags: ["Logs"], summary: "System logs dengan filter tipe/status/creator", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
    },
    "/api/logs/sync": {
      get: { tags: ["Logs"], summary: "Log sinkronisasi (halaman, item, hasil)", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
    },
    "/api/logs/audit": {
      get: { tags: ["Logs"], summary: "Audit Trail (Admin, append-only)", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" }, "403": { description: "Hanya Admin" } } },
    },
    "/api/users": {
      get: { tags: ["Users"], summary: "Daftar akun (Admin)", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" }, "403": { description: "Hanya Admin" } } },
      post: { tags: ["Users"], summary: "Buat akun (Admin)", security: [{ cookieAuth: [] }], responses: { "201": { description: "Dibuat" } } },
    },
    "/api/users/{id}": {
      put: { tags: ["Users"], summary: "Edit profil/peran/aktif (Admin)", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
    },
    "/api/users/{id}/reset-password": {
      post: { tags: ["Users"], summary: "Reset password (Admin; wajib ganti saat login berikutnya)", security: [{ cookieAuth: [] }], responses: { "200": { description: "OK" } } },
    },
    "/api/health": {
      get: { tags: ["Health"], summary: "Healthcheck service app", responses: { "200": { description: "Sehat" }, "503": { description: "DB tidak sehat" } } },
    },
  },
} as const;
