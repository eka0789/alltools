import { describe, expect, it } from "vitest";
import { buildCsv, isValidUsername, sanitizeCell } from "../src/utils/sanitize";

describe("sanitasi export & validasi username", () => {
  it("sanitizeCell meng-escape sel berawalan =, +, -, @, tab, dan CR", () => {
    expect(sanitizeCell("=cmd()")).toBe("'=cmd()");
    expect(sanitizeCell("+628123")).toBe("'+628123");
    expect(sanitizeCell("-2days")).toBe("'-2days");
    expect(sanitizeCell("@risk")).toBe("'@risk");
    expect(sanitizeCell("\t=SUM(A1)")).toBe("'\t=SUM(A1)");
    expect(sanitizeCell("\r=1")).toBe("'\r=1");
  });

  it("sanitizeCell membiarkan sel normal tetap utuh", () => {
    expect(sanitizeCell("creator_0001")).toBe("creator_0001");
    expect(sanitizeCell("Success")).toBe("Success");
    expect(sanitizeCell("2026-01-05T02:00:00.000Z")).toBe("2026-01-05T02:00:00.000Z");
    expect(sanitizeCell("")).toBe("");
  });

  it("buildCsv menghasilkan header, BOM, CRLF, dan quoting yang benar", () => {
    const csv = buildCsv(["No", "Username"], [["1", "creator_0001"], ["2", 'halo,"dunia"']]);
    expect(csv.startsWith("\uFEFF")).toBe(true);
    expect(csv).toContain("No,Username\r\n");
    expect(csv).toContain("1,creator_0001\r\n");
    // Sel berisi koma/kutip dibungkus kutip dan kutip internal di-dobble.
    expect(csv).toContain('2,"halo,""dunia"""\r\n');
  });

  it("buildCsv menyisipkan prefix kutip untuk nilai berbahaya", () => {
    const csv = buildCsv(["Username"], [["=HYPERLINK(\"http://evil\")"]]);
    expect(csv).toContain("'=HYPERLINK");
  });

  it("isValidUsername menegakkan whitelist ingest", () => {
    expect(isValidUsername("creator_0001")).toBe(true);
    expect(isValidUsername("user.name")).toBe(true);
    expect(isValidUsername("a")).toBe(false); // terlalu pendek
    expect(isValidUsername("bad name")).toBe(false); // spasi
    expect(isValidUsername("injeksi=cmd")).toBe(false); // karakter '='
    expect(isValidUsername(" Username")).toBe(false);
  });
});
