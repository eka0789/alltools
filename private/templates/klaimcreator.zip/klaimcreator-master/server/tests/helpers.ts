import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import supertest, { type Agent } from "supertest";
import type { Express } from "express";
import { loadConfig, type AppConfig } from "../src/config";
import { bootstrap } from "../src/bootstrap";
import { makeLimiters } from "../src/middleware/rateLimit";
import { createApp } from "../src/app";
import { resolveAdapters } from "../src/adapters/registry";
import type { ClaimExecutionAdapter } from "../src/adapters/types";
import type { AppContext } from "../src/context";
import type { ClaimDeps } from "../src/services/claimService";
import type { Repository } from "../src/repository";
import type { SqliteDb } from "../src/db/connection";

export const ADMIN_EMAIL = "admin@klaimcreator.local";
export const ADMIN_PASSWORD = "devadmin123";

export interface TestHarness {
  dir: string;
  cfg: AppConfig;
  ctx: AppContext;
  app: Express;
  repo: Repository;
  db: SqliteDb;
  cleanup: () => void;
}

export function createHarness(opts?: { claimAdapter?: ClaimExecutionAdapter | null; authMax?: number }): TestHarness {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "kc-test-"));
  const cfg = loadConfig({
    NODE_ENV: "test",
    DATA_DIR: path.join(dir, "data"),
    BACKUP_DIR: path.join(dir, "backups"),
    RATE_LIMIT_AUTH_MAX: String(opts?.authMax ?? 1000),
    RATE_LIMIT_API_MAX: "100000",
    JWT_SECRET: "test-secret-yang-cukup-panjang-untuk-hmac-1234567890",
  });
  const boot = bootstrap(cfg);
  const limiters = makeLimiters(cfg);
  const claimAdapter = opts?.claimAdapter ?? null;
  const ctx: AppContext = {
    db: boot.db,
    repo: boot.repo,
    cfg,
    authService: boot.authService,
    notifier: boot.notifier,
    adapters: () => resolveAdapters(boot.repo, cfg),
    claimDeps: (): ClaimDeps => ({ db: boot.db, repo: boot.repo, notifier: boot.notifier, claimAdapter }),
    limiters,
  };
  const app = createApp(ctx, { serveClient: false });
  return {
    dir,
    cfg,
    ctx,
    app,
    repo: boot.repo,
    db: boot.db,
    cleanup: () => {
      try {
        boot.db.close();
      } catch {
        // sudah tertutup
      }
      fs.rmSync(dir, { recursive: true, force: true });
    },
  };
}

/** Agent dengan header CSRF (X-Requested-With) + cookie sesi. */
export async function loginAs(
  app: Express,
  email: string,
  password: string
): Promise<{ agent: Agent; status: number; body: Record<string, unknown> }> {
  const agent = supertest.agent(app);
  const res = await agent
    .post("/api/auth/login")
    .set("X-Requested-With", "XMLHttpRequest")
    .send({ email, password });
  return { agent, status: res.status, body: res.body as Record<string, unknown> };
}

export async function adminAgent(app: Express): Promise<Agent> {
  const { agent } = await loginAs(app, ADMIN_EMAIL, ADMIN_PASSWORD);
  return agent;
}

export function csrf(agent: Agent): Agent {
  // supertest agent tidak punya default header global; helper ini hanya dokumentasi.
  return agent;
}

export async function createOperator(h: TestHarness, email = "operator@test.local", password = "operator123"): Promise<{ id: string; email: string; password: string }> {
  const hash = h.ctx.authService.hashPassword(password);
  const user = h.repo.users.create({ email, name: "Operator Uji", passwordHash: hash, role: "operator" });
  return { id: user.id, email, password };
}

/** Buat creator langsung lewat repository (fixture test). */
export function makeCreator(
  h: TestHarness,
  n: number,
  status: "Available" | "Claimed" | "Pending" | "Failed" | "Unavailable" = "Available"
): { id: string; username: string } {
  const row = h.repo.creators.insertFromSource({
    source: "mock",
    external_id: `mock-${String(n).padStart(5, "0")}`,
    username: `creator_${String(n).padStart(4, "0")}`,
    nickname: `Creator ${n}`,
    follower_count: 1000 + n,
    status,
    raw_data: null,
  });
  return { id: row.id, username: row.username };
}
