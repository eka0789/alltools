import supertest from "supertest";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { ADMIN_EMAIL, ADMIN_PASSWORD, createHarness, type TestHarness } from "./helpers";

let h: TestHarness;

beforeAll(() => {
  h = createHarness();
});

afterAll(() => {
  h.cleanup();
});

describe("autentikasi (area 1 PRD)", () => {
  it("login gagal dengan kredensial salah, pesan generik + 401", async () => {
    const res = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: "salah@contoh.id", password: "bukan-password" });
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe("INVALID_CREDENTIALS");
    // Terdogoki email tidak boleh bocor lewat pesan.
    expect(res.body.error.message).not.toContain("salah@contoh.id");
  });

  it("login sukses mengembalikan user dan cookie httpOnly", async () => {
    const res = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    expect(res.status).toBe(200);
    expect(res.body.user.email).toBe(ADMIN_EMAIL);
    expect(res.body.user.role).toBe("admin");
    expect(res.body.user.mustChangePassword).toBe(true); // seed wajib ganti password
    const setCookie = res.headers["set-cookie"] as unknown as string[];
    const joined = Array.isArray(setCookie) ? setCookie.join("; ") : String(setCookie);
    expect(joined).toContain("HttpOnly");
    expect(joined).toContain("SameSite=Strict");
    expect(joined).toContain("kc_at");
  });

  it("GET /api/auth/me memulihkan sesi; tanpa sesi 401", async () => {
    const anon = await supertest(h.app).get("/api/auth/me");
    expect(anon.status).toBe(401);

    const login = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    const cookies = login.headers["set-cookie"];
    const me = await supertest(h.app).get("/api/auth/me").set("Cookie", cookies);
    expect(me.status).toBe(200);
    expect(me.body.user.email).toBe(ADMIN_EMAIL);
  });

  it("refresh token berotasi: token lama dicabut, token baru valid", async () => {
    const login = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    const cookies = login.headers["set-cookie"];
    const refresh1 = await supertest(h.app)
      .post("/api/auth/refresh")
      .set("Cookie", cookies)
      .set("X-Requested-With", "XMLHttpRequest");
    expect(refresh1.status).toBe(200);
    const newCookies = refresh1.headers["set-cookie"];
    // Token lama sudah dicabut: refresh ulang dengan cookie lama harus 401.
    const replay = await supertest(h.app)
      .post("/api/auth/refresh")
      .set("Cookie", cookies)
      .set("X-Requested-With", "XMLHttpRequest");
    expect(replay.status).toBe(401);
    expect(replay.body.error.code).toBe("SESSION_EXPIRED");
    // Cookie baru masih valid.
    const refresh2 = await supertest(h.app)
      .post("/api/auth/refresh")
      .set("Cookie", newCookies)
      .set("X-Requested-With", "XMLHttpRequest");
    expect(refresh2.status).toBe(200);
  });

  it("logout mencabut sesi", async () => {
    const login = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    const cookies = login.headers["set-cookie"];
    const out = await supertest(h.app).post("/api/auth/logout").set("Cookie", cookies).set("X-Requested-With", "XMLHttpRequest");
    expect(out.status).toBe(200);
    const me = await supertest(h.app).get("/api/auth/me").set("Cookie", cookies);
    expect(me.status).toBe(401);
  });

  it("ganti password: policy gagal per field, sukses lalu semua sesi dicabut", async () => {
    const login = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    const cookies = login.headers["set-cookie"];

    const weak = await supertest(h.app)
      .post("/api/auth/change-password")
      .set("Cookie", cookies)
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ currentPassword: ADMIN_PASSWORD, newPassword: "pendek" });
    expect(weak.status).toBe(400);
    expect(weak.body.error.fields.newPassword).toBeDefined();

    const wrong = await supertest(h.app)
      .post("/api/auth/change-password")
      .set("Cookie", cookies)
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ currentPassword: "salah-banget-1", newPassword: "passwordBaru1" });
    expect(wrong.status).toBe(400);
    expect(wrong.body.error.fields.currentPassword).toBe("Password saat ini salah");

    const ok = await supertest(h.app)
      .post("/api/auth/change-password")
      .set("Cookie", cookies)
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ currentPassword: ADMIN_PASSWORD, newPassword: "PasswordBaru1" });
    expect(ok.status).toBe(200);
    expect(ok.body.user.mustChangePassword).toBe(false);

    // Sesi lama dicabut setelah ganti password.
    const me = await supertest(h.app).get("/api/auth/me").set("Cookie", cookies);
    expect(me.status).toBe(401);

    // Login dengan password baru berhasil; login lama gagal.
    const relogin = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: ADMIN_EMAIL, password: "PasswordBaru1" });
    expect(relogin.status).toBe(200);
    const oldLogin = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    expect(oldLogin.status).toBe(401);
  });

  it("mutasi tanpa header X-Requested-With ditolak CSRF guard", async () => {
    const res = await supertest(h.app).post("/api/auth/login").send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe("CSRF");
  });

  it("rate limit login 5 percobaan/menit, percobaan ke-6 terblokir 429", async () => {
    h.cleanup();
    const { createHarness: fresh } = await import("./helpers");
    const limited = fresh({ authMax: 5 });
    try {
      let lastStatus = 0;
      for (let i = 0; i < 6; i++) {
        const res = await supertest(limited.app)
          .post("/api/auth/login")
          .set("X-Requested-With", "XMLHttpRequest")
          .send({ email: "rate@contoh.id", password: "salah-terus-1" });
        lastStatus = res.status;
      }
      expect(lastStatus).toBe(429);
      // Tercatat di audit log (login gagal dibatasi dan tercatat).
      const audits = limited.repo.logs.listAudit({ action: "auth.login_failed", page: 1, pageSize: 50 });
      expect(audits.total).toBeGreaterThanOrEqual(5);
    } finally {
      limited.cleanup();
    }
  });
});
