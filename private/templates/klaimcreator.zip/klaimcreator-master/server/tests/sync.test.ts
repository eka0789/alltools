import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { MockSourceAdapter } from "../src/adapters/mock";
import { runSync } from "../src/services/syncService";
import { createHarness, type TestHarness } from "./helpers";

let h: TestHarness;

beforeAll(() => {
  h = createHarness();
});

afterAll(() => {
  h.cleanup();
});

function notifierFor() {
  return h.ctx.notifier;
}

describe("sinkronisasi (area 2, 3, 4, 5 PRD)", () => {
  it("menelusuri seluruh halaman sumber (pagination-aware) dan mencatat jumlah halaman/item", async () => {
    // Adapter yang memaksakan halamannya sendiri (maks 10 item per halaman, total 45)
    // untuk membuktikan runSync mengikuti totalPages sumber, bukan sekali ambil.
    const dataset = Array.from({ length: 45 }, (_, i) => ({
      externalId: `page-${String(i + 1).padStart(5, "0")}`,
      username: `paged_${String(i + 1).padStart(4, "0")}`,
      nickname: null,
      followerCount: null,
      status: "Available" as const,
    }));
    const paginatedSource = {
      name: "paginated-mock",
      label: "Sumber: Mock",
      testConnection: async () => ({ ok: true, message: "ok", checkedAt: new Date().toISOString() }),
      fetchCreatorsPage: async (page: number, _pageSize: number) => {
        const start = (page - 1) * 10;
        const items = dataset.slice(start, start + 10);
        return {
          page,
          pageSize: 10,
          totalPages: Math.ceil(dataset.length / 10),
          totalItems: dataset.length,
          items,
        };
      },
    };
    const result = await runSync({ db: h.db, repo: h.repo, source: paginatedSource, notifier: notifierFor(), owner: "worker-test-1" }, "schedule");
    expect(result.ok).toBe(true);
    expect(result.pages).toBe(5); // 45 item / 10 per halaman = 5 halaman sumber
    expect(result.items).toBe(45);
    expect(h.repo.creators.countAll()).toBe(45);

    const logs = h.repo.logs.listSyncLogs(1);
    expect(logs[0].status).toBe("Success");
    expect(logs[0].pages_fetched).toBe(5);
    expect(logs[0].items_fetched).toBe(45);
    expect(logs[0].trigger).toBe("schedule");
  });

  it("sinkronisasi berulang tidak menciptakan baris baru (dedup), hanya update last_updated_at", async () => {
    const source = new MockSourceAdapter({ pages: 1, itemsPerPage: 10, newItemsPerCycle: 0, faultMode: "none" });
    await runSync({ db: h.db, repo: h.repo, source, notifier: notifierFor(), owner: "worker-test-2" }, "schedule");
    const countAfterFirst = h.repo.creators.countAll();
    const before = h.repo.creators.listFiltered({ page: 1, pageSize: 1, sort: "newest" }).items[0];
    await new Promise((r) => setTimeout(r, 30));
    const second = await runSync({ db: h.db, repo: h.repo, source, notifier: notifierFor(), owner: "worker-test-2" }, "schedule");
    expect(second.ok).toBe(true);
    expect(second.created).toBe(0);
    expect(h.repo.creators.countAll()).toBe(countAfterFirst); // tidak ada duplikat
    const after = h.repo.creators.findById(before.id);
    expect(after!.last_updated_at >= before.last_updated_at).toBe(true); // last_updated_at di-update
  });

  it("unique constraint (source, external_id) dan (source, username) ditegakkan database", async () => {
    const first = h.repo.creators.insertFromSource({
      source: "mock",
      external_id: "dup-1",
      username: "dupuser1",
      nickname: null,
      follower_count: null,
      status: "Available",
      raw_data: null,
    });
    expect(() =>
      h.repo.creators.insertFromSource({
        source: "mock",
        external_id: "dup-1",
        username: "dupuser2",
        nickname: null,
        follower_count: null,
        status: "Available",
        raw_data: null,
      })
    ).toThrowError();
    expect(() =>
      h.repo.creators.insertFromSource({
        source: "mock",
        external_id: "dup-2",
        username: "dupuser1",
        nickname: null,
        follower_count: null,
        status: "Available",
        raw_data: null,
      })
    ).toThrowError();
    expect(first.username).toBe("dupuser1");
  });

  it("deteksi availability: creator Available terdeteksi, masuk status history, dan event notifikasi dibuat", async () => {
    // Adapter dengan nama sumber unik agar terisolasi dari test lain pada file ini.
    const items = Array.from({ length: 6 }, (_, i) => ({
      externalId: `avail-${i + 1}`,
      username: `availuser_${i + 1}`,
      nickname: null,
      followerCount: 5000 + i,
      status: i % 2 === 0 ? ("Available" as const) : ("Claimed" as const),
    }));
    const source = {
      name: "mock-avail",
      label: "Sumber: Mock",
      testConnection: async () => ({ ok: true, message: "ok", checkedAt: new Date().toISOString() }),
      fetchCreatorsPage: async (page: number, pageSize: number) => ({
        page,
        pageSize,
        totalPages: 1,
        totalItems: items.length,
        items,
      }),
    };
    const result = await runSync({ db: h.db, repo: h.repo, source, notifier: notifierFor(), owner: "worker-test-3" }, "manual");
    expect(result.ok).toBe(true);
    expect(result.created).toBe(6);
    expect(result.available).toBe(3); // i genap = Available

    // Semua creator sumber mock-avail tercatat; yang Available otomatis masuk antrian
    // sehingga status lokalnya berubah menjadi Pending.
    const fromSource = h.repo.creators.listFiltered({ page: 1, pageSize: 100, sort: "newest" }).items.filter((c) => c.source === "mock-avail");
    expect(fromSource.length).toBe(6);
    const pending = fromSource.filter((c) => c.status === "Pending");
    expect(pending.length).toBe(3);

    const first = pending[0];
    const history = h.repo.creators.statusHistory(first.id);
    expect(history.length).toBeGreaterThan(0);
    const earliest = history[history.length - 1];
    expect(earliest.old_status).toBeNull(); // entri pertama: pertama kali terdeteksi
    expect(earliest.new_status).toBe("Available");

    // Auto-enqueue: creator Available masuk antrian klaim berstatus Pending.
    const claim = h.repo.claims.findActiveByCreator(first.id);
    expect(claim).not.toBeNull();
    expect(claim!.status).toBe("Pending");

    // Notifikasi in-app untuk creator baru available.
    const notifs = h.repo.logs.listNotifications(20);
    expect(notifs.some((n) => n.event_type === "creator_available")).toBe(true);
  });

  it("perubahan status creator dari sumber tercatat sebagai baris baru di creator_status_histories", async () => {
    const creator = h.repo.creators.insertFromSource({
      source: "mock",
      external_id: "hist-1",
      username: "histuser1",
      nickname: null,
      follower_count: null,
      status: "Available",
      raw_data: null,
    });
    h.repo.creators.updateFromSource(creator.id, {
      username: "histuser1",
      nickname: null,
      follower_count: null,
      status: "Claimed",
      raw_data: null,
    });
    h.repo.creators.insertStatusHistory(creator.id, "Available", "Claimed", "Perubahan status dari sinkronisasi");
    const history = h.repo.creators.statusHistory(creator.id);
    expect(history.length).toBe(1);
    expect(history[0].new_status).toBe("Claimed");
    expect(history[0].old_status).toBe("Available");
    expect(history[0].reason).toContain("Perubahan status");
  });

  it("username di luar whitelist ditolak server-side (tidak masuk database)", async () => {
    const sneaky = {
      name: "mock",
      label: "Sumber: Mock",
      testConnection: async () => ({ ok: true, message: "ok", checkedAt: new Date().toISOString() }),
      fetchCreatorsPage: async (page: number, pageSize: number) => ({
        page,
        pageSize,
        totalPages: 1,
        totalItems: 2,
        items: [
          { externalId: "evil-1", username: "=cmd()", nickname: null, followerCount: null, status: "Available" as const },
          { externalId: "evil-2", username: "spasi aneh", nickname: null, followerCount: null, status: "Available" as const },
        ],
      }),
    };
    const result = await runSync({ db: h.db, repo: h.repo, source: sneaky, notifier: notifierFor(), owner: "worker-test-4" }, "manual");
    expect(result.ok).toBe(true);
    expect(result.items).toBe(2);
    expect(result.created).toBe(0); // dua-duanya ditolak whitelist
    expect(h.repo.creators.findByUsername("mock", "=cmd()")).toBeNull();
  });

  it("kegagalan sumber menghasilkan sync log Failed, event sync_failed, dan source_disconnected", async () => {
    const failing = {
      name: "mock",
      label: "Sumber: Mock",
      testConnection: async () => ({ ok: false, message: "down", checkedAt: new Date().toISOString() }),
      fetchCreatorsPage: async () => {
        throw new Error("Sumber tidak dapat dihubungi (simulasi)");
      },
    };
    const result = await runSync({ db: h.db, repo: h.repo, source: failing, notifier: notifierFor(), owner: "worker-test-5" }, "schedule");
    expect(result.ok).toBe(false);
    expect(result.error).toContain("simulasi");

    const logs = h.repo.logs.listSyncLogs(1);
    expect(logs[0].status).toBe("Failed");
    expect(logs[0].error).toContain("simulasi");

    const events = h.repo.logs.listEvents({ type: "sync_failed", page: 1, pageSize: 5 });
    expect(events.total).toBeGreaterThan(0);
  });

  it("Available Creators hanya menampilkan Available tanpa klaim aktif, terbaru dulu", async () => {
    const c1 = h.repo.creators.insertFromSource({
      source: "mock",
      external_id: "avail-1",
      username: "availuser1",
      nickname: null,
      follower_count: null,
      status: "Available",
      raw_data: null,
    });
    h.repo.creators.insertFromSource({
      source: "mock",
      external_id: "avail-2",
      username: "availuser2",
      nickname: null,
      follower_count: null,
      status: "Available",
      raw_data: null,
    });
    // availuser1 diklaim aktif -> keluar dari daftar Available.
    h.repo.claims.insert({ creator_id: c1.id, status: "Pending", mode: "assisted", requested_by: null });
    const page = h.repo.creators.listAvailableWithoutActiveClaim(1, 50);
    const usernames = page.items.map((c) => c.username);
    expect(usernames).not.toContain("availuser1");
    expect(usernames).toContain("availuser2");
  });
});
