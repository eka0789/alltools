import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { adminAgent, createHarness, makeCreator, type TestHarness } from "./helpers";

let h: TestHarness;

beforeAll(() => {
  h = createHarness();
});

afterAll(() => {
  h.cleanup();
});

describe("kontrol monitoring & dashboard", () => {
  it("start/stop monitoring memperbarui state yang dipersistenkan di database", async () => {
    const agent = await adminAgent(h.app);
    const start = await agent.post("/api/monitoring/start").set("X-Requested-With", "XMLHttpRequest");
    expect(start.status).toBe(200);
    expect(h.repo.settings.get<boolean>("monitoring_active")).toBe(true);

    const status = await agent.get("/api/monitoring/status");
    expect(status.body.monitoringActive).toBe(true);
    expect(status.body.sourceLabel).toBe("Sumber: Mock"); // adapter mock selalu berlabel jelas

    const stop = await agent.post("/api/monitoring/stop").set("X-Requested-With", "XMLHttpRequest");
    expect(stop.status).toBe(200);
    expect(h.repo.settings.get<boolean>("monitoring_active")).toBe(false);
  });

  it("sinkronisasi manual masuk antrian job (202) dan tidak boleh dobel", async () => {
    const agent = await adminAgent(h.app);
    const first = await agent.post("/api/monitoring/sync").set("X-Requested-With", "XMLHttpRequest");
    expect(first.status).toBe(202);
    expect(first.body.jobId).toBeDefined();
    expect(h.repo.logs.queuedJobCount()).toBe(1);

    const second = await agent.post("/api/monitoring/sync").set("X-Requested-With", "XMLHttpRequest");
    expect(second.status).toBe(409);
  });

  it("sinkronisasi manual diblokir saat emergency stop aktif", async () => {
    const agent = await adminAgent(h.app);
    await agent.post("/api/monitoring/emergency-stop").set("X-Requested-With", "XMLHttpRequest");
    const res = await agent.post("/api/monitoring/sync").set("X-Requested-With", "XMLHttpRequest");
    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe("EMERGENCY_STOP");
    await agent.post("/api/monitoring/emergency-release").set("X-Requested-With", "XMLHttpRequest");
  });

  it("dashboard mengembalikan 7 kartu statistik dan chart 14 hari", async () => {
    makeCreator(h, 301, "Available");
    const agent = await adminAgent(h.app);
    const res = await agent.get("/api/dashboard");
    expect(res.status).toBe(200);
    const stats = res.body.stats;
    for (const key of ["totalCreators", "availableCreators", "totalClaimed", "claimsSuccess", "claimsFailed", "claimsPending", "lastSyncAt"]) {
      expect(stats).toHaveProperty(key);
    }
    expect(res.body.charts.claimsPerDay).toHaveLength(14);
    expect(res.body.charts.syncPerDay).toHaveLength(14);
    expect(res.body.monitoring.refreshIntervalSeconds).toBeGreaterThan(0);
  });

  it("worker dianggap offline saat heartbeat kedaluwarsa", async () => {
    const agent = await adminAgent(h.app);
    const res = await agent.get("/api/monitoring/status");
    expect(res.body.worker.online).toBe(false); // worker uji tidak berjalan
  });

  it("emergency stop endpoint membalikkan Processing menjadi Verification Required", async () => {
    const creator = makeCreator(h, 302, "Available");
    const claim = h.repo.claims.insert({ creator_id: creator.id, status: "Pending", mode: "assisted", requested_by: null });
    h.repo.claims.update(claim.id, { status: "Processing" });

    const agent = await adminAgent(h.app);
    const res = await agent.post("/api/monitoring/emergency-stop").set("X-Requested-With", "XMLHttpRequest");
    expect(res.status).toBe(200);
    expect(res.body.flipped).toBeGreaterThanOrEqual(1);
    expect(h.repo.claims.findById(claim.id)!.status).toBe("Verification Required");
    await agent.post("/api/monitoring/emergency-release").set("X-Requested-With", "XMLHttpRequest");
  });
});
