import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { buildMockClaimAdapter } from "../src/adapters/registry";
import {
  enqueueIfEligible,
  processDueClaims,
  recoverStaleProcessing,
  triggerEmergencyStop,
  releaseEmergencyStop,
} from "../src/services/claimService";
import { createHarness, makeCreator, type TestHarness } from "./helpers";

let h: TestHarness;

beforeAll(() => {
  h = createHarness({ claimAdapter: buildMockClaimAdapter({ defaultOutcome: "success" }) });
});

afterAll(() => {
  h.cleanup();
});

function deps() {
  return h.ctx.claimDeps();
}

describe("antrian & validasi klaim (area 6 PRD)", () => {
  it("hanya creator Available yang bisa masuk antrian", () => {
    const claimed = makeCreator(h, 101, "Claimed");
    const rejected = enqueueIfEligible(deps(), claimed.id, null);
    expect(rejected.ok).toBe(false);
    expect(rejected.reason).toBe("NOT_AVAILABLE");
  });

  it("creator Available masuk antrian berstatus Pending tanpa duplikat", () => {
    const creator = makeCreator(h, 102, "Available");
    const first = enqueueIfEligible(deps(), creator.id, null);
    expect(first.ok).toBe(true);
    expect(first.claim!.status).toBe("Pending");

    // Duplikat aktif ditolak (transaksi) dan ditegakkan partial unique index database.
    const second = enqueueIfEligible(deps(), creator.id, null);
    expect(second.ok).toBe(false);
    // Alasan bisa ALREADY_QUEUED (klaim aktif) atau NOT_AVAILABLE (creator berubah Pending) - keduanya menolak duplikasi.
    expect(["ALREADY_QUEUED", "NOT_AVAILABLE"]).toContain(second.reason ?? "");
    expect(() =>
      h.repo.claims.insert({ creator_id: creator.id, status: "Pending", mode: "assisted", requested_by: null })
    ).toThrowError(); // unique partial index
  });

  it("klaim terminal Success memblokir klaim baru (idempotency, area 7 PRD)", async () => {
    const creator = makeCreator(h, 103, "Available");
    h.repo.settings.set("claim_mode", "automatic");
    const queued = enqueueIfEligible(deps(), creator.id, null);
    expect(queued.ok).toBe(true);

    const run = await processDueClaims(deps(), { limit: 10 });
    // Klaim dari test sebelumnya di file ini juga ikut terproses; yang penting klaim creator ini tereksekusi tepat sekali.
    expect(run.processed).toBeGreaterThanOrEqual(1);
    expect(run.success).toBeGreaterThanOrEqual(1);

    const claim = h.repo.claims.findBlockingByCreator(creator.id)!;
    expect(claim.status).toBe("Success");
    expect(claim.claimed_at).not.toBeNull();

    // Creator berstatus Claimed + klaim terminal: tidak bisa menghasilkan klaim baru.
    const again = enqueueIfEligible(deps(), creator.id, null);
    expect(again.ok).toBe(false);
    const totalClaims = h.repo.claims.listFiltered({ page: 1, pageSize: 100 });
    expect(totalClaims.items.filter((c) => c.creator_id === creator.id).length).toBe(1);
  });

  it("Already Claimed berstatus terminal tanpa retry dan muncul di filter", async () => {
    h.repo.settings.set("claim_mode", "automatic");
    const creator = makeCreator(h, 104, "Available");
    // Adapter mock dengan pengecualian per username.
    const depsAlready = h.ctx.claimDeps;
    void depsAlready;
    const { buildMockClaimAdapter: freshAdapter } = await import("../src/adapters/registry");
    const localDeps = { db: h.db, repo: h.repo, notifier: h.ctx.notifier, claimAdapter: freshAdapter({ defaultOutcome: "success", perUsername: { [creator.username]: "already_claimed" } }) };
    const queued = enqueueIfEligible(localDeps, creator.id, null);
    expect(queued.ok).toBe(true);
    const run = await processDueClaims(localDeps, { limit: 10 });
    expect(run.alreadyClaimed).toBe(1);

    const claim = h.repo.claims.findBlockingByCreator(creator.id)!;
    expect(claim.status).toBe("Already Claimed");
    // Tidak ada retry terjadwal dan tidak ada klaim baru.
    expect(claim.next_retry_at).toBeNull();
    const again = enqueueIfEligible(localDeps, creator.id, null);
    expect(again.ok).toBe(false);

    // Status muncul di filter daftar klaim.
    const filtered = h.repo.claims.listFiltered({ status: "Already Claimed", page: 1, pageSize: 10 });
    expect(filtered.items.some((c) => c.creator_id === creator.id)).toBe(true);
    // Creator ikut berstatus Claimed.
    expect(h.repo.creators.findById(creator.id)!.status).toBe("Claimed");
  });

  it("error sementara di-retry dengan exponential backoff hingga Maximum Retry", async () => {
    h.repo.settings.set("claim_mode", "automatic");
    h.repo.settings.set("automation", {
      refreshIntervalSeconds: 60,
      maxRetries: 2,
      retryBaseDelaySeconds: 30,
      claimSchedule: { startHour: 0, endHour: 23, days: [0, 1, 2, 3, 4, 5, 6] },
      notifications: { inApp: true, telegram: false, email: false },
      export: { filenamePrefix: "klaim-creator", usernamesOnlyDefault: false },
    });
    const creator = makeCreator(h, 105, "Available");
    const localDeps = { db: h.db, repo: h.repo, notifier: h.ctx.notifier, claimAdapter: buildMockClaimAdapter({ defaultOutcome: "transient_error" }) };
    const queued = enqueueIfEligible(localDeps, creator.id, null);
    expect(queued.ok).toBe(true);

    // Percobaan 1 gagal sementara -> tetap Pending dengan next_retry_at (backoff 30s).
    const run1 = await processDueClaims(localDeps, { limit: 10 });
    expect(run1.failed).toBe(1);
    const claim1 = h.repo.claims.findById(queued.claim!.id)!;
    expect(claim1.status).toBe("Pending");
    expect(claim1.attempt_count).toBe(1);
    expect(claim1.next_retry_at).not.toBeNull();
    const firstDelay = new Date(claim1.next_retry_at!).getTime() - Date.now();
    expect(firstDelay).toBeGreaterThan(20_000);
    expect(firstDelay).toBeLessThanOrEqual(31_000);

    // Paksa jatuh tempo, percobaan 2 (attempt terakhir, maxRetries=2) -> Failed permanen.
    h.db.prepare(`UPDATE claims SET next_retry_at = ? WHERE id = ?`).run(new Date(Date.now() - 1000).toISOString(), claim1.id);
    const run2 = await processDueClaims(localDeps, { limit: 10 });
    expect(run2.failed).toBe(1);
    const claim2 = h.repo.claims.findById(claim1.id)!;
    expect(claim2.status).toBe("Failed");
    expect(claim2.attempt_count).toBe(2);
    // Klaim Failed tidak dieksekusi ulang otomatis.
    const run3 = await processDueClaims(localDeps, { limit: 10 });
    expect(run3.processed).toBe(0);
    expect(claim2.status).toBe("Failed");
  });
});

describe("verifikasi hasil klaim & pemulihan (area 8 PRD)", () => {
  it("hasil uncertain menjadi Verification Required dan TIDAK pernah dieksekusi ulang otomatis", async () => {
    h.repo.settings.set("claim_mode", "automatic");
    const creator = makeCreator(h, 106, "Available");
    const localDeps = { db: h.db, repo: h.repo, notifier: h.ctx.notifier, claimAdapter: buildMockClaimAdapter({ defaultOutcome: "uncertain" }) };
    const queued = enqueueIfEligible(localDeps, creator.id, null);
    const run = await processDueClaims(localDeps, { limit: 10 });
    expect(run.verificationRequired).toBe(1);
    const claim = h.repo.claims.findById(queued.claim!.id)!;
    expect(claim.status).toBe("Verification Required");

    // Berulang kali dijalankan: tidak pernah dieksekusi ulang.
    for (let i = 0; i < 3; i++) {
      const again = await processDueClaims(localDeps, { limit: 10 });
      expect(again.processed).toBe(0);
    }
    const attempts = h.repo.claims.attempts(claim.id);
    expect(attempts.length).toBe(1); // hanya attempt pertama, tanpa retry
  });

  it("Emergency Stop dipersistenkan, memblokir eksekusi, dan Processing menjadi Verification Required", async () => {
    h.repo.settings.set("claim_mode", "automatic");
    const creator = makeCreator(h, 107, "Available");
    const localDeps = { db: h.db, repo: h.repo, notifier: h.ctx.notifier, claimAdapter: buildMockClaimAdapter({ defaultOutcome: "success" }) };
    const queued = enqueueIfEligible(localDeps, creator.id, null);
    // Set ke Processing (simulasi sedang dieksekusi).
    h.repo.claims.update(queued.claim!.id, { status: "Processing" });

    const actor = { id: "u-1", email: "op@test.local", name: "Operator", role: "operator" as const, mustChangePassword: false };
    const stop = triggerEmergencyStop(localDeps, actor);
    expect(stop.flipped).toBe(1);
    expect(h.repo.claims.findById(queued.claim!.id)!.status).toBe("Verification Required");
    expect(h.repo.settings.get<boolean>("emergency_stop")).toBe(true);

    // Eksekusi diblokir selama emergency stop.
    const creator2 = makeCreator(h, 108, "Available");
    const queued2 = enqueueIfEligible(localDeps, creator2.id, null);
    const run = await processDueClaims(localDeps, { limit: 10 });
    expect(run.skipped).toBe("emergency_stop");
    expect(run.processed).toBe(0);
    expect(h.repo.claims.findById(queued2.claim!.id)!.status).toBe("Pending"); // tidak diproses

    releaseEmergencyStop(localDeps, actor);
    expect(h.repo.settings.get<boolean>("emergency_stop")).toBe(false);
  });

  it("pemulihan crash: klaim Processing yatim melewati batas waktu menjadi Verification Required tanpa eksekusi ulang", () => {
    const creator = makeCreator(h, 109, "Available");
    const claim = h.repo.claims.insert({ creator_id: creator.id, status: "Pending", mode: "automatic", requested_by: null });
    h.repo.claims.update(claim.id, { status: "Processing" });
    // Backdate updated_at agar dianggap yatim (fixture langsung via prepared statement).
    h.db.prepare(`UPDATE claims SET updated_at = ? WHERE id = ?`).run(new Date(Date.now() - 3_600_000).toISOString(), claim.id);

    const recovered = recoverStaleProcessing(deps(), 600_000);
    expect(recovered).toBe(1);
    const after = h.repo.claims.findById(claim.id)!;
    expect(after.status).toBe("Verification Required");
    expect(after.verified_at).toBeNull(); // belum diverifikasi siapa pun
    // Attempt tetap 0: tidak ada eksekusi ulang yang terjadi.
    expect(h.repo.claims.attempts(claim.id).length).toBe(0);
  });

  it("loop klaim tidak berjalan pada mode assisted maupun tanpa adapter", async () => {
    h.repo.settings.set("claim_mode", "assisted");
    const creator = makeCreator(h, 110, "Available");
    const queued = enqueueIfEligible(deps(), creator.id, null);
    expect(queued.ok).toBe(true);
    const run = await processDueClaims(deps(), { limit: 10 });
    expect(run.skipped).toBe("assisted_mode");
    expect(h.repo.claims.findById(queued.claim!.id)!.status).toBe("Pending");
  });
});
