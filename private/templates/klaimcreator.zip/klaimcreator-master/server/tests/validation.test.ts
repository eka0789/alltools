import supertest from "supertest";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { ADMIN_EMAIL, ADMIN_PASSWORD, adminAgent, createHarness, type TestHarness } from "./helpers";

let h: TestHarness;

beforeAll(() => {
  h = createHarness();
});

afterAll(() => {
  h.cleanup();
});

describe("validasi input & penanganan error (area 11 PRD)", () => {
  it("login dengan body kosong: 400 dengan pesan spesifik per field", async () => {
    const res = await supertest(h.app).post("/api/auth/login").set("X-Requested-With", "XMLHttpRequest").send({});
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("VALIDATION");
    expect(res.body.error.fields.email).toBe("Email wajib diisi");
    expect(res.body.error.fields.password).toBe("Password wajib diisi");
  });

  it("login dengan email format salah: pesan per field", async () => {
    const res = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ email: "bukan-email", password: "x" });
    expect(res.status).toBe(400);
    expect(res.body.error.fields.email).toBe("Format email tidak valid");
  });

  it("pagination tidak valid ditolak (pageSize > 100, page < 1)", async () => {
    const agent = await adminAgent(h.app);
    const resBig = await agent.get("/api/creators?pageSize=500");
    expect(resBig.status).toBe(400);
    expect(resBig.body.error.fields.pageSize).toContain("maksimal");
    const resSmall = await agent.get("/api/creators?page=0");
    expect(resSmall.status).toBe(400);
    expect(resSmall.body.error.fields.page).toBeDefined();
  });

  it("query status yang tidak dikenal ditolak dengan enum yang jelas", async () => {
    const agent = await adminAgent(h.app);
    const res = await agent.get("/api/creators?status=Bebas");
    expect(res.status).toBe(400);
    expect(res.body.error.fields.status).toBeDefined();
  });

  it("endpoint API tidak dikenal mengembalikan 404 JSON konsisten", async () => {
    const res = await supertest(h.app).get("/api/endpoint-tidak-ada");
    expect(res.status).toBe(404);
    expect(res.body.error.code).toBe("NOT_FOUND");
    expect(res.body.error.message).toBe("Endpoint tidak ditemukan");
  });

  it("bad JSON di body ditangani error handler (400, bukan crash 500)", async () => {
    const res = await supertest(h.app)
      .post("/api/auth/login")
      .set("X-Requested-With", "XMLHttpRequest")
      .set("Content-Type", "application/json")
      .send('{"email": ');
    expect([400, 401]).toContain(res.status);
    expect(res.body.error).toBeDefined();
  });

  it("user create (admin) memvalidasi password policy per field", async () => {
    const agent = await adminAgent(h.app);
    const res = await agent.post("/api/users").set("X-Requested-With", "XMLHttpRequest").send({
      email: "baru@test.local",
      name: "Baru",
      role: "operator",
      password: "abc",
    });
    expect(res.status).toBe(400);
    expect(res.body.error.fields.password).toContain("8 karakter");
  });

  it("UUID tidak valid pada path param ditolak", async () => {
    const agent = await adminAgent(h.app);
    const res = await agent.get("/api/creators/bukan-uuid/history");
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe("VALIDATION");
  });

  it("health endpoint publik mengembalikan status sehat", async () => {
    const res = await supertest(h.app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
    expect(res.body.service).toBe("app");
    expect(res.body.db).toBe("ok");
  });

  it("CSP ketat dikirim di response, termasuk frame-ancestors none dan nosniff", async () => {
    const res = await supertest(h.app).get("/api/health");
    const csp = res.headers["content-security-policy"] as string;
    expect(csp).toContain("default-src 'self'");
    expect(csp).toContain("frame-ancestors 'none'");
    expect(res.headers["x-content-type-options"]).toBe("nosniff");
    void ADMIN_EMAIL;
    void ADMIN_PASSWORD;
  });
});
