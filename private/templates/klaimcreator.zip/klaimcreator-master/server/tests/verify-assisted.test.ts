import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { buildMockClaimAdapter } from "../src/adapters/registry";
import { enqueueIfEligible, processDueClaims, recordAssistedResult, retryClaim, verifyClaim, ClaimError } from "../src/services/claimService";
import { createHarness, createOperator, loginAs, makeCreator, type TestHarness } from "./helpers";

let h: TestHarness;
let operator: { id: string; email: string; password: string };
let admin: { id: string; email: string; name: string; role: "admin" | "operator"; mustChangePassword: boolean };

beforeAll(async () => {
  h = createHarness();
  operator = await createOperator(h);
  // Gunakan ID admin yang benar-benar ada di database (verified_by adalah FK ke users).
  const adminRow = h.repo.users.findByEmail("admin@klaimcreator.local");
  if (!adminRow) throw new Error("Admin seed tidak ditemukan");
  admin = { id: adminRow.id, email: adminRow.email, name: adminRow.name, role: "admin", mustChangePassword: false };
});

afterAll(() => {
  h.cleanup();
});

function deps() {
  return h.ctx.claimDeps();
}

describe("Assisted Claim Mode (pencatatan operator)", () => {
  it("operator mencatat hasil klaim assisted: Success", async () => {
    const actor = { id: operator.id, email: operator.email, name: "Operator Uji", role: "operator" as const, mustChangePassword: false };
    const creator = makeCreator(h, 201, "Available");
    const queued = enqueueIfEligible(deps(), creator.id, actor.id);
    expect(queued.ok).toBe(true);
    const final = recordAssistedResult(deps(), queued.claim!.id, "success", actor);
    expect(final).toBe("Success");
    const claim = h.repo.claims.findById(queued.claim!.id)!;
    expect(claim.claimed_at).not.toBeNull();
    expect(h.repo.creators.findById(creator.id)!.status).toBe("Claimed");
    const attempts = h.repo.claims.attempts(claim.id);
    expect(attempts.length).toBe(1);
    expect(attempts[0].executed_by).toBe(operator.id);
  });

  it("operator mencatat Already Claimed: terminal tanpa retry", async () => {
    const actor = { id: operator.id, email: operator.email, name: "Operator Uji", role: "operator" as const, mustChangePassword: false };
    const creator = makeCreator(h, 202, "Available");
    const queued = enqueueIfEligible(deps(), creator.id, actor.id);
    const final = recordAssistedResult(deps(), queued.claim!.id, "already_claimed", actor);
    expect(final).toBe("Already Claimed");
    const claim = h.repo.claims.findById(queued.claim!.id)!;
    expect(claim.next_retry_at).toBeNull();
  });

  it("pencatatan ulang pada klaim non-Pending ditolak (409)", async () => {
    const actor = { id: operator.id, email: operator.email, name: "Operator Uji", role: "operator" as const, mustChangePassword: false };
    const creator = makeCreator(h, 203, "Available");
    const queued = enqueueIfEligible(deps(), creator.id, actor.id);
    recordAssistedResult(deps(), queued.claim!.id, "success", actor);
    expect(() => recordAssistedResult(deps(), queued.claim!.id, "failed", actor)).toThrowError(ClaimError);
  });
});

describe("verifikasi manual klaim (endpoint khusus Admin)", () => {
  it("verify hanya menerima klaim Verification Required (409 untuk status lain)", async () => {
    const creator = makeCreator(h, 204, "Available");
    const queued = enqueueIfEligible(deps(), creator.id, null);
    expect(() =>
      verifyClaim(deps(), queued.claim!.id, "success", admin)
    ).toThrowError(ClaimError);
  });

  it("verify oleh Admin mengubah Verification Required menjadi Success + tercatat verified_at/by", async () => {
    h.repo.settings.set("claim_mode", "automatic");
    const creator = makeCreator(h, 205, "Available");
    const localDeps = { db: h.db, repo: h.repo, notifier: h.ctx.notifier, claimAdapter: buildMockClaimAdapter({ defaultOutcome: "uncertain" }) };
    const queued = enqueueIfEligible(localDeps, creator.id, null);
    await processDueClaims(localDeps, { limit: 10 });
    const claim = h.repo.claims.findById(queued.claim!.id)!;
    expect(claim.status).toBe("Verification Required");

    const final = verifyClaim(deps(), claim.id, "success", admin);
    expect(final).toBe("Success");
    const after = h.repo.claims.findById(claim.id)!;
    expect(after.status).toBe("Success");
    expect(after.verified_at).not.toBeNull();
    expect(after.verified_by).toBe(admin.id);
    expect(h.repo.creators.findById(creator.id)!.status).toBe("Claimed");
  });

  it("verify via API ditolak untuk operator (403) dan diizinkan untuk admin", async () => {
    // Siapkan klaim Verification Required.
    h.repo.settings.set("claim_mode", "automatic");
    const creator = makeCreator(h, 206, "Available");
    const localDeps = { db: h.db, repo: h.repo, notifier: h.ctx.notifier, claimAdapter: buildMockClaimAdapter({ defaultOutcome: "uncertain" }) };
    const queued = enqueueIfEligible(localDeps, creator.id, null);
    await processDueClaims(localDeps, { limit: 10 });

    const { agent: opAgent } = await loginAs(h.app, operator.email, operator.password);
    const forbidden = await opAgent
      .post(`/api/claims/${queued.claim!.id}/verify`)
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ result: "success" });
    expect(forbidden.status).toBe(403);

    const { agent: admAgent } = await loginAs(h.app, "admin@klaimcreator.local", "devadmin123");
    const allowed = await admAgent
      .post(`/api/claims/${queued.claim!.id}/verify`)
      .set("X-Requested-With", "XMLHttpRequest")
      .send({ result: "already_claimed" });
    expect(allowed.status).toBe(200);
    expect(allowed.body.status).toBe("Already Claimed");
  });

  it("retry hanya untuk klaim Failed", async () => {
    const actor = { id: operator.id, email: operator.email, name: "Operator Uji", role: "operator" as const, mustChangePassword: false };
    const creator = makeCreator(h, 207, "Available");
    const queued = enqueueIfEligible(deps(), creator.id, actor.id);
    recordAssistedResult(deps(), queued.claim!.id, "failed", actor); // 1 attempt gagal -> masih Pending (max 3)
    const claim = h.repo.claims.findById(queued.claim!.id)!;
    // Paksa Failed permanen.
    h.repo.claims.update(claim.id, { status: "Failed", next_retry_at: null });

    const retried = retryClaim(deps(), claim.id, actor);
    expect(retried.status).toBe("Pending");

    // Retry klaim non-Failed ditolak.
    expect(() => retryClaim(deps(), claim.id, actor)).toThrowError(ClaimError);
  });
});
