import supertest from "supertest";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { ADMIN_EMAIL, ADMIN_PASSWORD, createHarness, createOperator, loginAs, type TestHarness } from "./helpers";

let h: TestHarness;
let operator: { id: string; email: string; password: string };

beforeAll(async () => {
  h = createHarness();
  operator = await createOperator(h);
});

afterAll(() => {
  h.cleanup();
});

describe("kontrol akses per endpoint (RBAC di server)", () => {
  it("endpoint terproteksi menolak tanpa sesi (401)", async () => {
    for (const path of ["/api/users", "/api/settings/automation", "/api/logs/audit", "/api/dashboard"]) {
      const res = await supertest(h.app).get(path);
      expect(res.status).toBe(401);
      expect(res.body.error.code).toBe("UNAUTHENTICATED");
    }
  });

  it("operator diblokir dari endpoint khusus Admin (403), bukan hanya disembunyikan di UI", async () => {
    const { agent } = await loginAs(h.app, operator.email, operator.password);
    const resUsers = await agent.get("/api/users");
    expect(resUsers.status).toBe(403);
    expect(resUsers.body.error.code).toBe("FORBIDDEN");

    const resAudit = await agent.get("/api/logs/audit");
    expect(resAudit.status).toBe(403);

    const resSettings = await agent.put("/api/settings/automation").send({ refreshIntervalSeconds: 30 });
    expect(resSettings.status).toBe(403);

    const resIntegration = await agent.put("/api/settings/integration").send({ adapter: "mock" });
    expect(resIntegration.status).toBe(403);

    const resRelease = await agent.post("/api/monitoring/emergency-release");
    expect(resRelease.status).toBe(403);

    // Verifikasi klaim juga khusus Admin (butuh klaim Verification Required untuk cek RBAC murni).
    const resVerify = await agent.post(`/api/claims/00000000-0000-0000-0000-000000000001/verify`).send({ result: "success" });
    expect(resVerify.status).toBe(403);
  });

  it("operator boleh endpoint monitoring/operasional yang memang untuknya", async () => {
    const { agent } = await loginAs(h.app, operator.email, operator.password);
    const status = await agent.get("/api/monitoring/status");
    expect(status.status).toBe(200);

    const stop = await agent.post("/api/monitoring/stop").set("X-Requested-With", "XMLHttpRequest");
    expect(stop.status).toBe(200);
    const start = await agent.post("/api/monitoring/start").set("X-Requested-With", "XMLHttpRequest");
    expect(start.status).toBe(200);
    expect(start.body.monitoringActive).toBe(true);

    // Operator bisa memicu Emergency Stop (tombol darurat), tapi tidak bisa membukanya.
    const estop = await agent.post("/api/monitoring/emergency-stop").set("X-Requested-With", "XMLHttpRequest");
    expect(estop.status).toBe(200);
    const release = await agent.post("/api/monitoring/emergency-release").set("X-Requested-With", "XMLHttpRequest");
    expect(release.status).toBe(403);

    // Admin membuka kembali.
    const { agent: admin } = await loginAs(h.app, ADMIN_EMAIL, ADMIN_PASSWORD);
    const releaseAdmin = await admin.post("/api/monitoring/emergency-release").set("X-Requested-With", "XMLHttpRequest");
    expect(releaseAdmin.status).toBe(200);
  });

  it("admin memiliki akses penuh ke endpoint manajemen", async () => {
    const { agent } = await loginAs(h.app, ADMIN_EMAIL, ADMIN_PASSWORD);
    const users = await agent.get("/api/users");
    expect(users.status).toBe(200);
    expect(Array.isArray(users.body.items)).toBe(true);
    const audit = await agent.get("/api/logs/audit");
    expect(audit.status).toBe(200);
    expect(audit.body.items.length).toBeGreaterThan(0);
  });

  it("IDOR dicegah: operator tidak bisa membaca daftar user lewat filter action audit", async () => {
    const { agent } = await loginAs(h.app, operator.email, operator.password);
    const res = await agent.get("/api/logs/audit?action=auth");
    expect(res.status).toBe(403);
  });
});
