import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { MockSourceAdapter } from "../src/adapters/mock";
import { runSync } from "../src/services/syncService";
import { createHarness, type TestHarness } from "./helpers";

let h: TestHarness;

beforeAll(() => {
  h = createHarness();
});

afterAll(() => {
  h.cleanup();
});

describe("scheduler locking (lease-based, area 10 PRD)", () => {
  it("lock tidak bisa dipegang dua proses sekaligus", () => {
    const first = h.repo.logs.acquireLock("sync", "worker-A", 60_000);
    expect(first.acquired).toBe(true);
    const second = h.repo.logs.acquireLock("sync", "worker-B", 60_000);
    expect(second.acquired).toBe(false);
    h.repo.logs.releaseLock("sync", "worker-A");
  });

  it("owner berbeda tidak bisa me-renew lock milik proses lain", () => {
    h.repo.logs.acquireLock("sync", "worker-A", 60_000);
    const renewedByB = h.repo.logs.renewLock("sync", "worker-B", 60_000);
    expect(renewedByB).toBe(false);
    const renewedByA = h.repo.logs.renewLock("sync", "worker-A", 60_000);
    expect(renewedByA).toBe(true);
    h.repo.logs.releaseLock("sync", "worker-A");
  });

  it("lease kedaluwarsa dapat diambil alih worker baru (pemulihan crash)", () => {
    h.repo.logs.acquireLock("sync", "worker-crash", 50);
    // Tunggu lease kedaluwarsa.
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        const takeover = h.repo.logs.acquireLock("sync", "worker-baru", 60_000);
        expect(takeover.acquired).toBe(true);
        h.repo.logs.releaseLock("sync", "worker-baru");
        resolve();
      }, 80);
    });
  });

  it("release hanya oleh owner: owner lain tidak menghapus lock", () => {
    h.repo.logs.acquireLock("sync", "worker-A", 60_000);
    h.repo.logs.releaseLock("sync", "worker-B"); // bukan owner
    expect(h.repo.logs.getLock("sync")).not.toBeNull();
    h.repo.logs.releaseLock("sync", "worker-A");
    expect(h.repo.logs.getLock("sync")).toBeNull();
  });

  it("runSync bersamaan: proses kedua dilewati karena lock dipegang proses pertama", async () => {
    const source = new MockSourceAdapter({ pages: 1, itemsPerPage: 5, newItemsPerCycle: 0, faultMode: "none" });
    const deps = { db: h.db, repo: h.repo, source, notifier: h.ctx.notifier, owner: "worker-paralel-1", lockTtlMs: 60_000 };
    // Proses pertama memegang lock manual (simulasi sedang berjalan).
    h.repo.logs.acquireLock("sync", "worker-paralel-1", 60_000);
    const other = await runSync({ ...deps, owner: "worker-paralel-2" }, "schedule");
    expect(other.ok).toBe(false);
    expect(other.skipped).toBe("locked");
    h.repo.logs.releaseLock("sync", "worker-paralel-1");
  });

  it("runSync melepas lock setelah selesai maupun gagal (finally)", async () => {
    const okSource = new MockSourceAdapter({ pages: 1, itemsPerPage: 5, newItemsPerCycle: 0, faultMode: "none" });
    await runSync({ db: h.db, repo: h.repo, source: okSource, notifier: h.ctx.notifier, owner: "worker-fin-1" }, "manual");
    const afterOk = h.repo.logs.getLock("sync");
    expect(afterOk === null || new Date(afterOk.expires_at).getTime() < Date.now()).toBe(true);

    const failSource = {
      name: "mock",
      label: "Sumber: Mock",
      testConnection: async () => ({ ok: true, message: "ok", checkedAt: new Date().toISOString() }),
      fetchCreatorsPage: async () => {
        throw new Error("boom");
      },
    };
    await runSync({ db: h.db, repo: h.repo, source: failSource, notifier: h.ctx.notifier, owner: "worker-fin-2" }, "manual");
    expect(h.repo.logs.getLock("sync")).toBeNull();
  });
});
