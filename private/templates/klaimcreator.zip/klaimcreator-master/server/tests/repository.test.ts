import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { bootstrap } from "../src/bootstrap";
import { DEFAULT_SETTINGS } from "../src/repository";
import { createHarness, type TestHarness } from "./helpers";

let h: TestHarness;

beforeAll(() => {
  h = createHarness();
});

afterAll(() => {
  h.cleanup();
});

describe("modul repository & constraint database", () => {
  it("ensureDefaults tidak menimpa nilai yang sudah ada", () => {
    h.repo.settings.set("monitoring_active", true);
    h.repo.settings.ensureDefaults({ ...DEFAULT_SETTINGS, monitoring_active: false });
    expect(h.repo.settings.get<boolean>("monitoring_active")).toBe(true);
  });

  it("unique (source, external_id) menolak duplikat", () => {
    h.repo.creators.insertFromSource({
      source: "mock",
      external_id: "repo-1",
      username: "repouser1",
      nickname: null,
      follower_count: null,
      status: "Available",
      raw_data: null,
    });
    expect(() =>
      h.repo.creators.insertFromSource({
        source: "mock",
        external_id: "repo-1",
        username: "repouser9",
        nickname: null,
        follower_count: null,
        status: "Available",
        raw_data: null,
      })
    ).toThrowError(/UNIQUE/i);
  });

  it("unique partial index menolak dua klaim aktif untuk creator yang sama", () => {
    const creator = h.repo.creators.insertFromSource({
      source: "mock",
      external_id: "repo-2",
      username: "repouser2",
      nickname: null,
      follower_count: null,
      status: "Available",
      raw_data: null,
    });
    h.repo.claims.insert({ creator_id: creator.id, status: "Pending", mode: "assisted", requested_by: null });
    expect(() =>
      h.repo.claims.insert({ creator_id: creator.id, status: "Processing", mode: "assisted", requested_by: null })
    ).toThrowError(/UNIQUE/i);
  });

  it("klaim terminal boleh berdampingan dengan klaim baru setelah Failed lama", () => {
    const creator = h.repo.creators.insertFromSource({
      source: "mock",
      external_id: "repo-3",
      username: "repouser3",
      nickname: null,
      follower_count: null,
      status: "Available",
      raw_data: null,
    });
    const first = h.repo.claims.insert({ creator_id: creator.id, status: "Pending", mode: "assisted", requested_by: null });
    h.repo.claims.update(first.id, { status: "Failed" }); // terminal retryable
    const second = h.repo.claims.insert({ creator_id: creator.id, status: "Pending", mode: "assisted", requested_by: null });
    expect(second.status).toBe("Pending");
  });

  it("jobs queue: claimNextJob atomik (queued -> running) dan finishJob menutup", () => {
    const id1 = h.repo.logs.enqueueJob("sync_manual", null);
    const id2 = h.repo.logs.enqueueJob("process_claims", null);
    const job1 = h.repo.logs.claimNextJob();
    expect(job1!.id).toBe(id1);
    expect(job1!.status).toBe("running");
    h.repo.logs.finishJob(id1, true, { pages: 1 });
    const job2 = h.repo.logs.claimNextJob();
    expect(job2!.id).toBe(id2);
    h.repo.logs.finishJob(id2, false, { error: "x" });
    expect(h.repo.logs.claimNextJob()).toBeNull();
    expect(h.repo.logs.queuedJobCount()).toBe(0);
  });

  it("audit log append-only: hanya create dan list, tidak ada jalur update/hapus", () => {
    h.repo.logs.createAudit({ action: "test.audit", user_email: "x@y.z" });
    const list = h.repo.logs.listAudit({ page: 1, pageSize: 10 });
    expect(list.total).toBeGreaterThan(0);
    // Repository tidak mengekspos fungsi mutasi audit (cek tipe: tidak ada di objek).
    expect((h.repo.logs as unknown as Record<string, unknown>)["updateAudit"]).toBeUndefined();
    expect((h.repo.logs as unknown as Record<string, unknown>)["deleteAudit"]).toBeUndefined();
  });

  it("retensi 90 hari hanya membersihkan log operasional dan notifikasi, bukan data bisnis", () => {
    const creator = h.repo.creators.insertFromSource({
      source: "mock",
      external_id: "repo-4",
      username: "repouser4",
      nickname: null,
      follower_count: null,
      status: "Available",
      raw_data: null,
    });
    const old = new Date(Date.now() - 91 * 86_400_000).toISOString();
    h.db.prepare(`INSERT INTO notifications (id, event_type, title, message, is_read, created_at) VALUES (?, 'claim_success', 't', 'm', 0, ?)`).run("notif-old", old);
    h.db.prepare(`INSERT INTO system_events (id, event_type, description, status, created_at) VALUES ('ev-old', 'system', 'x', 'Info', ?)`).run(old);
    h.db.prepare(`INSERT INTO synchronization_logs (id, trigger, status, started_at) VALUES ('sl-old', 'schedule', 'Success', ?)`).run(old);
    const claim = h.repo.claims.insert({ creator_id: creator.id, status: "Pending", mode: "assisted", requested_by: null });
    h.db.prepare(`UPDATE claims SET created_at = ? WHERE id = ?`).run(old, claim.id);

    h.repo.logs.applyRetention(new Date(Date.now() - 90 * 86_400_000).toISOString());

    expect(h.db.prepare(`SELECT COUNT(*) AS n FROM notifications WHERE id = 'notif-old'`).get()).toEqual({ n: 0 });
    expect(h.db.prepare(`SELECT COUNT(*) AS n FROM system_events WHERE id = 'ev-old'`).get()).toEqual({ n: 0 });
    expect(h.db.prepare(`SELECT COUNT(*) AS n FROM synchronization_logs WHERE id = 'sl-old'`).get()).toEqual({ n: 0 });
    // Data bisnis permanen: claims, creators, status histories, audit tidak pernah dihapus.
    expect(h.repo.claims.findById(claim.id)).not.toBeNull();
    expect(h.repo.creators.findById(creator.id)).not.toBeNull();
  });
});

describe("persistence antar restart (state di database, bukan memori)", () => {
  it("monitoring aktif dan emergency stop tetap saat proses baru membuka database yang sama", () => {
    h.repo.settings.set("monitoring_active", true);
    h.repo.settings.set("emergency_stop", true);
    // Simulasi restart: bootstrap baru pada DATA_DIR yang sama (proses berbeda).
    const cfg2 = { ...h.cfg };
    const boot2 = bootstrap(cfg2);
    expect(boot2.repo.settings.get<boolean>("monitoring_active")).toBe(true);
    expect(boot2.repo.settings.get<boolean>("emergency_stop")).toBe(true);
    // Bootstrap kedua tidak boleh men-seed user tambahan.
    const userCount = boot2.repo.users.countAll();
    boot2.db.close();
    expect(userCount).toBe(h.repo.users.countAll());
  });
});
