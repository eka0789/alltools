import supertest from "supertest";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { buildCsvContent, buildExcelBuffer, getExportRows } from "../src/services/exportService";
import { createHarness, adminAgent, type TestHarness } from "./helpers";

let h: TestHarness;

beforeAll(() => {
  h = createHarness();
});

afterAll(() => {
  h.cleanup();
});

function seedClaim(username: string, externalId: string, status: "Success" | "Failed" | "Already Claimed", claimedAt: string | null, source = "mock"): void {
  const creator = h.repo.creators.insertFromSource({
    source,
    external_id: externalId,
    username,
    nickname: null,
    follower_count: null,
    status: status === "Success" || status === "Already Claimed" ? "Claimed" : "Failed",
    raw_data: null,
  });
  const claim = h.repo.claims.insert({ creator_id: creator.id, status: "Pending", mode: "assisted", requested_by: null });
  h.repo.claims.update(claim.id, { status, claimed_at: claimedAt, last_error: null });
}

describe("export CSV/Excel (area 9 PRD)", () => {
  beforeAll(() => {
    seedClaim("okuser1", "ex-1", "Success", "2026-01-05T02:00:00.000Z");
    seedClaim("=cmd()", "ex-2", "Success", "2026-01-05T03:00:00.000Z");
    seedClaim("+628123", "ex-3", "Success", "2026-01-06T03:00:00.000Z");
    seedClaim("-273", "ex-4", "Success", "2026-01-06T04:00:00.000Z");
    seedClaim("@risk", "ex-5", "Success", "2026-01-07T04:00:00.000Z");
    seedClaim("dupuser", "ex-6", "Success", "2026-01-08T04:00:00.000Z");
    // Username sama lintas sumber (UNIQUE(source, username) tetap mengizinkan) -> export dedup.
    seedClaim("dupuser", "ex-7", "Success", "2026-01-09T04:00:00.000Z", "official");
    seedClaim("gagaluser", "ex-8", "Failed", "2026-01-10T04:00:00.000Z");
    seedClaim("sudahklaim", "ex-9", "Already Claimed", "2026-01-10T05:00:00.000Z");
  });

  it("default export hanya klaim Success, kolom lengkap, tanpa username duplikat", () => {
    const rows = getExportRows(h.repo, { statuses: ["Success"], from: null, to: null });
    const usernames = rows.map((r) => r.username);
    expect(usernames).toContain("okuser1");
    expect(usernames).not.toContain("gagaluser");
    expect(usernames).not.toContain("sudahklaim");
    expect(usernames.filter((u) => u === "dupuser").length).toBe(1);
    // Dedup mempertahankan klaim terbaru (ex-7, 2026-01-09).
    const dup = rows.find((r) => r.username === "dupuser")!;
    expect(dup.creatorId).toBe("ex-7");
    expect(rows[0].no).toBe(1);
  });

  it("CSV menyertakan kolom No, Creator ID, Username, Claim Status, Claim Date dan menyembunyikan formula injection", () => {
    const rows = getExportRows(h.repo, { statuses: ["Success"], from: null, to: null });
    const csv = buildCsvContent(rows, false);
    expect(csv.startsWith("\uFEFF")).toBe(true);
    // Header tanpa karakter khusus tidak perlu di-quote.
    expect(csv).toContain("No,Creator ID,Username,Claim Status,Claim Date\r\n");
    expect(csv).toContain("okuser1");
    expect(csv).toContain("Success");
    // Formula injection di-escape dengan prefix kutip.
    expect(csv).toContain("'=cmd()");
    expect(csv).toContain("'+628123");
    expect(csv).toContain("'-273");
    expect(csv).toContain("'@risk");
    // Tidak ada sel mentah berawalan berbahaya yang lolos.
    expect(csv).not.toMatch(/(^|,)"?=cmd\(\)/);
    expect(csv).not.toMatch(/(^|,)"?\+628123/);
  });

  it("opsi usernames-only menghasilkan satu kolom Username", () => {
    const rows = getExportRows(h.repo, { statuses: ["Success"], from: null, to: null });
    const csv = buildCsvContent(rows, true);
    expect(csv).toContain("Username\r\n");
    expect(csv).not.toContain("Creator ID");
    expect(csv).toContain("okuser1");
  });

  it("Excel berupa .xlsx valid (ZIP magic bytes) dengan sel tersanitasi", async () => {
    const rows = getExportRows(h.repo, { statuses: ["Success"], from: null, to: null });
    const buffer = await buildExcelBuffer(rows, false);
    expect(buffer.length).toBeGreaterThan(1000);
    expect(buffer[0]).toBe(0x50); // P
    expect(buffer[1]).toBe(0x4b); // K
  });

  it("filter tanggal membatasi baris berdasarkan claimed_at", () => {
    const rowsJan5 = getExportRows(h.repo, { statuses: ["Success"], from: "2026-01-05T00:00:00.000Z", to: "2026-01-05T23:59:59.999Z" });
    expect(rowsJan5.map((r) => r.username).sort()).toEqual(["=cmd()", "okuser1"].sort());
  });

  it("filter status mendukung Already Claimed di preview/export", () => {
    const rows = getExportRows(h.repo, { statuses: ["Already Claimed"], from: null, to: null });
    expect(rows.map((r) => r.username)).toContain("sudahklaim");
    expect(rows.every((r) => r.claimStatus === "Already Claimed")).toBe(true);
  });

  it("endpoint CSV/Excel terproteksi sesi dan mengembalikan header attachment", async () => {
    const agent = await adminAgent(h.app);
    const csv = await agent.get("/api/export/csv").set("X-Requested-With", "XMLHttpRequest");
    expect(csv.status).toBe(200);
    expect(csv.headers["content-type"]).toContain("text/csv");
    expect(csv.headers["content-disposition"]).toContain("attachment; filename=");
    expect(csv.text).toContain("okuser1");

    // Ambil xlsx sebagai buffer mentah (superagent tidak tahu tipe konten spreadsheet).
    const excel = await agent
      .get("/api/export/excel")
      .set("X-Requested-With", "XMLHttpRequest")
      .buffer(true)
      .parse((res, callback) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk: Buffer) => chunks.push(chunk));
        res.on("end", () => callback(null, Buffer.concat(chunks)));
      });
    expect(excel.status).toBe(200);
    expect(excel.headers["content-type"]).toContain("spreadsheetml");
    const excelBytes = excel.body as unknown as Buffer;
    expect(excelBytes[0]).toBe(0x50); // P
    expect(excelBytes[1]).toBe(0x4b); // K

    const anon = await supertest(h.app).get("/api/export/preview");
    expect(anon.status).toBe(401);
  });

  it("paramater tanggal tidak valid ditolak dengan pesan per field", async () => {
    const agent = await adminAgent(h.app);
    const res = await agent.get("/api/export/preview?from=01-01-2026").set("X-Requested-With", "XMLHttpRequest");
    expect(res.status).toBe(400);
    expect(res.body.error.fields.from).toContain("YYYY-MM-DD");
  });
});
