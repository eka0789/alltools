import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["tests/**/*.test.ts"],
    testTimeout: 30_000,
    hookTimeout: 30_000,
    // Non-interaktif: selalu "vitest run" via npm test, tidak pernah watch.
    watch: false,
    reporters: ["default"],
  },
});
