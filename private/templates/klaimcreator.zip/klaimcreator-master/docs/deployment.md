# Panduan Deploy Produksi KlaimCreator (VPS Linux)

Target: satu VPS Linux (Ubuntu 22.04/24.04), Docker Compose, Nginx sebagai reverse proxy dengan TLS, backup harian otomatis, dan prosedur restore.

## 1. Prasyarat

- VPS Linux 1 vCPU / 1 GB RAM (cukup untuk skala tim kecil), port 80/443 terbuka.
- Domain mengarah ke IP VPS (mis. `klaim.perusahaan.id`).
- Docker Engine + Docker Compose plugin terpasang.

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker "$USER"   # login ulang setelah ini
```

## 2. Siapkan Aplikasi

```bash
git clone <repo-anda> /opt/klaimcreator
cd /opt/klaimcreator

# Generate secret lalu isi .env
cp .env.example .env
chmod 600 .env
echo "JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")" >> /dev/null
# buka .env dan isi minimal:
#   JWT_SECRET=<hasil generate di atas>
#   SEED_ADMIN_EMAIL=admin@perusahaan.id
#   SEED_ADMIN_PASSWORD=<password sementara min 8 char, huruf+angka>
#   NODE_ENV=production
#   TRUST_PROXY=1        <- penting di balik Nginx (1 hop)
#   PORT=4173
```

> `NODE_ENV=production` menuntut `JWT_SECRET` terisi dan menyalakan flag `Secure` pada cookie
> (menuntut HTTPS dari TLS termination di Nginx). Admin awal di-seed saat database masih kosong
> dan **wajib mengganti password pada login pertama**.

## 3. Jalankan 2 Service

```bash
docker compose up -d --build
docker ps    # app: STATUS healthy (healthcheck /api/health), worker: healthy (healthcheck /health)
```

- `app` : API + frontend statis di port `4173` (hanya di-bind internal; publik lewat Nginx).
- `worker` : satu-satunya pemilik node-cron, eksekusi sinkronisasi/klaim; heartbeat di `3001` (internal).
- Keduanya berbagi volume `kc_data:/data`; backup ditulis ke `kc_backups:/backups` (volume terpisah agar kegagalan disk tidak menghapus database dan backup sekaligus).

## 4. Nginx Reverse Proxy + TLS

```bash
sudo apt install -y nginx certbot python3-certbot-nginx
sudo tee /etc/nginx/sites-available/klaimcreator >/dev/null <<'NGINX'
server {
    listen 80;
    server_name klaim.perusahaan.id;

    # Rate limit sederhana di edge (pembatas utama tetap di aplikasi)
    location / {
        proxy_pass http://127.0.0.1:4173;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        client_max_body_size 2m;
        proxy_read_timeout 60s;
    }
}
NGINX
sudo ln -s /etc/nginx/sites-available/klaimcreator /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# TLS gratis (Let's Encrypt) + redirect otomatis ke 443
sudo certbot --nginx -d klaim.perusahaan.id --redirect
```

Aplikasi dikonfigurasi dengan `TRUST_PROXY=1` agar rate limit dan audit log memakai IP klien asli
(dari `X-Forwarded-For`), bukan IP Nginx. Cookie `Secure` aktif karena `NODE_ENV=production` dan
sudah ada HTTPS. HSTS diaktifkan otomatis di produksi.

## 5. Backup Harian

Worker menjalankan backup otomatis pukul 02:30 (`VACUUM INTO`, konsisten terhadap mode WAL)
ke `/backups/klaimcreator-<timestamp>.db`, menyimpan maksimal 14 file terbaru. Backup berada di
volume terpisah dari database sehingga kegagalan disk tidak menghapus keduanya sekaligus.

Backup manual on-demand:

```bash
docker compose exec app sh -c 'node -e "
const Database = require(\"better-sqlite3\");
const db = new Database(\"/data/klaimcreator.db\");
db.prepare(\"VACUUM INTO ?\").run(\"/backups/manual-\" + Date.now() + \".db\");
db.close();
console.log(\"backup ok\");
"'
```

Salin backup keluar VPS secara berkala (contoh cron rsync ke storage lain):

```bash
0 3 * * * rsync -a /var/lib/docker/volumes/klaimcreator_kc_backups/_data/ backup-host:/srv/klaimcreator-backups/
```

## 6. Restore Database

```bash
# 1. Hentikan kedua service (tanpa menghapus volume)
docker compose stop app worker

# 2. Pulihkan file database dari backup ke volume data
docker run --rm -v klaimcreator_kc_data:/data -v klaimcreator_kc_backups:/backups alpine \
  sh -c "cp /backups/klaimcreator-<timestamp>.db /data/klaimcreator.db && rm -f /data/klaimcreator.db-wal /data/klaimcreator.db-shm"

# 3. Jalankan kembali; migrasi berjalan otomatis bila ada yang belum diterapkan
docker compose up -d
curl -fsS http://127.0.0.1:4173/api/health   # harus {"status":"ok"}
```

## 7. Pembaruan Aplikasi (Rolling, Tanpa Downtime Berarti)

```bash
cd /opt/klaimcreator
git pull
docker compose build
docker compose up -d          # hanya container yang berubah yang di-recreate
docker image prune -f
```

Skema database dimigrasi otomatis saat start (runner bawaan, urutan id tersimpan di `_migrations`).

## 8. Monitoring Operasional

| Sinyal | Cara memeriksa |
| --- | --- |
| Health app | `curl -fsS https://klaim.perusahaan.id/api/health` |
| Health worker | `docker compose exec worker wget -qO- http://127.0.0.1:3001/health` |
| Status worker + sumber | Halaman Dashboard (kartu Status Worker / Status Koneksi Sumber) |
| Log | `docker compose logs -f app worker` (JSON terstruktur, field sensitif tersanitasi) |
| Audit trail | Halaman System Logs, tab Audit Trail (Admin) |
| Notifikasi kejadian | Lonceng notifikasi in-app; Telegram/email dapat diaktifkan di Automation Settings (default nonaktif) |

Rekomendasi tambahan: pasang uptime monitor eksternal yang memanggil `/api/health` dan alert bila
`docker ps` menampilkan health `unhealthy`.

## 9. Checklist Keamanan Produksi

- [ ] `.env` berisi `JWT_SECRET` acak (min 32 karakter) dan izin file `600`.
- [ ] `SEED_ADMIN_PASSWORD` adalah password sementara; admin menggantinya saat login pertama.
- [ ] `TRUST_PROXY=1` di balik Nginx (sesuaikan jumlah hop bila arsitektur berbeda).
- [ ] TLS aktif (certbot) dan HTTP dialihkan ke HTTPS.
- [ ] Port 4173/3001 TIDAK dipublikasikan ke internet (hanya Nginx yang menjangkau app).
- [ ] Backup harian diverifikasi dengan mencoba restore di lingkungan staging minimal sekali.
- [ ] Mode klaim otomatis hanya diaktifkan setelah integrasi resmi teruji dan diizinkan platform.
- [ ] Audit trail diperiksa berkala; Emergency Stop diuji oleh tim sebelum masa operasi ramai.

## 10. Pemecahan Masalah Cepat

| Gejala | Penyebab umum | Tindakan |
| --- | --- | --- |
| `unhealthy` pada app | DB rusak / disk penuh | cek `docker compose logs app`; jalankan restore (bagian 6) |
| Worker offline di dashboard | Container worker mati / heartbeat kedaluwarsa | `docker compose restart worker`; cek log graceful shutdown |
| Sinkronisasi gagal | Sumber terputus / kredensial kedaluwarsa | Halaman Integrasi: Uji Koneksi; periksa env vars sumber |
| Login diblokir 429 | Rate limit 5/menit per IP | tunggu 1 menit; pastikan `TRUST_PROXY` benar agar IP asli yang dihitung |
| Klaim macet Processing | Crash di tengah eksekusi | worker memulihkannya otomatis menjadi Verification Required saat start/watchdog; Admin memverifikasi manual |
