# ERD Database KlaimCreator (SQLite)

Primary key UUID (TEXT). Timestamp disimpan sebagai ISO-8601 UTC (TEXT) dan ditampilkan dalam zona waktu Asia/Jakarta (WIB).

```mermaid
erDiagram
    users ||--o{ refresh_tokens : "memiliki sesi"
    users ||--o{ claims : "mengantrikan/memverifikasi"
    users ||--o{ audit_logs : "melakukan aksi"
    creators ||--o{ creator_status_histories : "mencatat perubahan status"
    creators ||--o{ claims : "menjadi subjek klaim"
    creators ||--o{ system_events : "direferensikan event"
    claims ||--o{ claim_attempts : "mencatat tiap percobaan"

    users {
        TEXT id PK
        TEXT email UK "unique, case-insensitive"
        TEXT name
        TEXT password_hash "bcrypt cost 12"
        TEXT role "admin | operator"
        INTEGER is_active "0 | 1"
        INTEGER must_change_password "0 | 1"
        TEXT token_epoch "epoch sesi; logout/ganti password menaikkannya"
        TEXT created_at
        TEXT updated_at
    }

    refresh_tokens {
        TEXT id PK
        TEXT user_id FK
        TEXT token_hash UK "SHA-256 dari token mentah"
        TEXT expires_at
        TEXT revoked_at
        TEXT created_at
    }

    creators {
        TEXT id PK
        TEXT source "mock | official"
        TEXT external_id "ID di sumber"
        TEXT username
        TEXT nickname
        INTEGER follower_count
        TEXT status "Available | Claimed | Pending | Failed | Unavailable"
        TEXT raw_data "JSON"
        TEXT first_seen_at
        TEXT last_updated_at
    }

    creator_status_histories {
        TEXT id PK
        TEXT creator_id FK
        TEXT old_status
        TEXT new_status
        TEXT reason
        TEXT changed_at
    }

    claims {
        TEXT id PK
        TEXT creator_id FK
        TEXT status "Pending | Processing | Success | Failed | Already Claimed | Verification Required"
        TEXT mode "automatic | assisted"
        TEXT requested_by FK
        INTEGER attempt_count
        TEXT next_retry_at "exponential backoff"
        TEXT last_error
        TEXT claimed_at
        TEXT verified_at
        TEXT verified_by FK
        TEXT created_at
        TEXT updated_at
    }

    claim_attempts {
        TEXT id PK
        TEXT claim_id FK
        INTEGER attempt_number
        TEXT result "Success | Failed | Already Claimed | Verification Required | Error"
        TEXT message
        TEXT executed_by
        TEXT started_at
        TEXT finished_at
    }

    sync_locks {
        TEXT lock_name PK
        TEXT owner "instance id worker"
        TEXT expires_at "lease; kedaluwarsa dapat diambil alih"
        TEXT renewed_at
    }

    synchronization_logs {
        TEXT id PK
        TEXT trigger "schedule | manual"
        TEXT status "Success | Failed"
        TEXT started_at
        TEXT finished_at
        INTEGER pages_fetched
        INTEGER items_fetched
        INTEGER items_created
        INTEGER items_updated
        INTEGER available_detected
        TEXT error
    }

    system_events {
        TEXT id PK
        TEXT event_type "creator_available | claim_success | claim_failed | session_expired | source_disconnected | sync_failed | worker_stopped | emergency_stop | system"
        TEXT description
        TEXT creator_id FK
        TEXT status "Info | Success | Warning | Error"
        TEXT metadata "JSON"
        TEXT created_at
    }

    audit_logs {
        TEXT id PK
        TEXT user_id
        TEXT user_email
        TEXT action
        TEXT entity
        TEXT entity_id
        TEXT details "JSON"
        TEXT ip
        TEXT created_at "append-only"
    }

    app_settings {
        TEXT key PK
        TEXT value "JSON: monitoring_active, emergency_stop, claim_mode, automation, integration, worker_heartbeat, source_last_check"
        TEXT updated_at
        TEXT updated_by
    }

    notifications {
        TEXT id PK
        TEXT event_type
        TEXT title
        TEXT message
        INTEGER is_read
        TEXT created_at "retensi 90 hari"
    }

    jobs {
        TEXT id PK
        TEXT type "sync_manual | process_claims"
        TEXT payload "JSON"
        TEXT status "queued | running | done | failed"
        TEXT requested_by
        TEXT result "JSON"
        TEXT created_at
        TEXT started_at
        TEXT finished_at
    }
```

## Constraint & Index Penting

| Objek | Tujuan |
| --- | --- |
| `UNIQUE (source, external_id)` pada `creators` | Dedup sinkronisasi: creator sama dari siklus berulang tidak menciptakan baris baru |
| `UNIQUE (source, username)` pada `creators` | Satu username per sumber; konflik ditolak di transaksi ingest |
| `CREATE UNIQUE INDEX idx_claims_active_per_creator ON claims(creator_id) WHERE status IN ('Pending','Processing')` | **Idempotensi klaim**: maksimal satu klaim aktif per creator, ditegakkan database |
| `idx_creators_status`, `idx_creators_username`, `idx_creators_external_id`, `idx_creators_last_updated`, `idx_creators_first_seen` | Pencarian/filter/pagination creator |
| `idx_claims_status`, `idx_claims_created`, `idx_claims_creator` | Filter status klaim, export, riwayat |
| `idx_events_type/creator/created`, `idx_audit_created`, `idx_notif_created`, `idx_jobs_status`, `idx_synclog_started` | Halaman logs, audit, notifikasi, dan poller job |

## Catatan Perilaku

1. **Klaim terminal pemblokir** : `Success`, `Already Claimed`, dan `Verification Required` memblokir klaim baru untuk creator yang sama; `Failed` tidak memblokir (jalur retry membuat percobaan baru).
2. **Emergency Stop** disimpan di `app_settings.emergency_stop` (bukan memori). Aktivasi membalik semua klaim `Processing` menjadi `Verification Required` dan menghentikan scheduler/worker.
3. **Lease lock sinkronisasi** disimpan di `sync_locks`; owner memperpanjang lease berkala selama siklus berjalan dan melepasnya di `finally`. Lease kedaluwarsa dapat diambil alih worker baru (pemulihan crash).
4. **Retensi 90 hari** hanya untuk `notifications`, `system_events`, `synchronization_logs`, dan refresh token kedaluwarsa. Tabel data bisnis tidak pernah dibersihkan.
5. **Audit log append-only**: hanya `INSERT` dan `SELECT`; tidak ada jalur update/delete di repository maupun endpoint.
