import { useMemo, useState, type JSX } from 'react';
import type {
  BacklogStatus,
  Comment,
  Label,
  LabelAssignment,
  Priority,
  Sprint,
  Subtask,
  Task,
  WorkspaceMember,
  WorkspaceRoster,
} from '@devflow/shared';
import { VALID_TRANSITIONS } from '@devflow/shared';
import { api } from '../lib/api';
import { formatRelative, titleCase, useApi, useAuth, useProjectRequired, useToast } from '../lib/hooks';
import {
  normalizeBacklogTree,
  normalizeTaskDetail,
  type BacklogTree,
  type BoardPayload,
  type BoardTask,
  type TaskDetailPayload,
} from '../lib/types';
import { PriorityBadge, StatusBadge } from '../components/Badge';
import { DueChip, InitialsChip, LabelDots } from '../components/Chips';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { Drawer } from '../components/Drawer';
import { EmptyState } from '../components/EmptyState';
import { ErrorState } from '../components/ErrorState';
import { Field, Input, Select, Textarea } from '../components/Field';
import { Skeleton } from '../components/Skeleton';
import { IconPlus, IconX, IconZap } from '../components/icons';

const COLUMNS: Array<{ status: BacklogStatus; dot: string }> = [
  { status: 'backlog', dot: 'var(--text-faint)' },
  { status: 'todo', dot: 'var(--info)' },
  { status: 'in_progress', dot: 'var(--accent)' },
  { status: 'in_review', dot: 'var(--warning)' },
  { status: 'blocked', dot: 'var(--danger)' },
  { status: 'done', dot: 'var(--success)' },
];

const PRIORITIES: Priority[] = ['low', 'medium', 'high', 'critical'];

/** Renders comment bodies with @handles highlighted in the accent color. */
function CommentBody({ body }: { body: string }): JSX.Element {
  const parts = body.split(/(@[A-Za-z0-9._-]+)/g);
  return (
    <div className="text-sm" style={{ whiteSpace: 'pre-wrap', marginTop: 2 }}>
      {parts.map((part, i) =>
        /^@[A-Za-z0-9._-]+$/.test(part) ? (
          <span key={i} className="weight-600" style={{ color: 'var(--accent-strong)' }}>
            {part}
          </span>
        ) : (
          <span key={i}>{part}</span>
        ),
      )}
    </div>
  );
}

// ---------- task drawer ----------

function TaskDrawer({
  taskId,
  projectId,
  boardTasks,
  members,
  projectLabels,
  onClose,
  onChanged,
  onMetaChanged,
}: {
  taskId: string | null;
  projectId: string;
  boardTasks: BoardTask[];
  members: WorkspaceMember[];
  projectLabels: Label[];
  onClose: () => void;
  onChanged: () => void;
  onMetaChanged: () => void;
}): JSX.Element {
  const toast = useToast();
  const { data, loading, error, reload } = useApi<TaskDetailPayload | null>(
    () => (taskId ? api.get<unknown>(`/projects/${projectId}/tasks/${taskId}`).then(normalizeTaskDetail) : Promise.resolve(null)),
    [taskId, projectId],
  );
  const [editingDesc, setEditingDesc] = useState(false);
  const [desc, setDesc] = useState('');
  const [newSub, setNewSub] = useState('');
  const [executing, setExecuting] = useState(false);
  const [confirmExecute, setConfirmExecute] = useState(false);

  const task = data?.task;
  const story = data?.story;
  const subtasks: Subtask[] = data?.subtasks ?? [];
  const timeline = data?.timeline ?? [];
  const taskLabels: LabelAssignment[] = data?.labels ?? [];

  const patchTask = async (body: Record<string, unknown>): Promise<void> => {
    if (!task) return;
    try {
      await api.patch(`/projects/${projectId}/tasks/${task.id}`, body);
      reload();
      onChanged();
      onMetaChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update task');
    }
  };

  const setTaskLabels = async (labelIds: string[]): Promise<void> => {
    if (!task) return;
    try {
      await api.put(`/projects/${projectId}/tasks/${task.id}/labels`, { labelIds });
      reload();
      onChanged();
      onMetaChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update labels');
    }
  };

  const transition = async (next: BacklogStatus): Promise<void> => {
    if (!task) return;
    try {
      await api.post(`/projects/${projectId}/tasks/${task.id}/transition`, { status: next });
      toast.success(`Moved to ${titleCase(next)}`);
      reload();
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Transition failed');
      reload();
    }
  };

  const addSub = async (): Promise<void> => {
    const t = newSub.trim();
    if (!task || t.length < 2) return;
    try {
      await api.post(`/projects/${projectId}/tasks/${task.id}/subtasks`, { title: t });
      setNewSub('');
      reload();
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to add subtask');
    }
  };

  const toggleSub = async (sub: Subtask): Promise<void> => {
    if (!task) return;
    try {
      await api.patch(`/projects/${projectId}/tasks/${task.id}/subtasks/${sub.id}`, { done: !sub.done });
      reload();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update subtask');
    }
  };

  const deleteSub = async (subId: string): Promise<void> => {
    if (!task) return;
    try {
      await api.del(`/projects/${projectId}/tasks/${task.id}/subtasks/${subId}`);
      reload();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete subtask');
    }
  };

  const comments: Comment[] = data?.comments ?? [];
  const { user: authUser } = useAuth();
  const [newComment, setNewComment] = useState('');
  const [commentBusy, setCommentBusy] = useState(false);

  const addComment = async (): Promise<void> => {
    const body = newComment.trim();
    if (!task || body.length === 0) return;
    setCommentBusy(true);
    try {
      await api.post(`/projects/${projectId}/tasks/${task.id}/comments`, { body });
      setNewComment('');
      reload();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to post comment');
    } finally {
      setCommentBusy(false);
    }
  };

  const deleteComment = async (commentId: string): Promise<void> => {
    if (!task) return;
    try {
      await api.del(`/projects/${projectId}/tasks/${task.id}/comments/${commentId}`);
      reload();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete comment');
    }
  };

  const execute = async (): Promise<void> => {
    if (!task) return;
    setExecuting(true);
    try {
      await api.post(`/tasks/${task.id}/execute`, { createPR: true });
      toast.success('AI execution queued — follow it in the executions page');
      setExecuting(false);
      onClose();
      onChanged();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to start execution');
      setExecuting(false);
    }
  };

  const depNames = (data?.dependencies ?? [])
    .map(([, depId]) => boardTasks.find((t) => t.id === depId)?.title ?? 'Unknown task')
    .filter(Boolean);

  return (
    <Drawer
      open={taskId !== null}
      onClose={onClose}
      title={loading && !task ? 'Loading task…' : (task?.title ?? 'Task')}
      subtitle={story ? `Story: ${story.title}` : undefined}
      footer={
        task ? (
          <>
            <button className="btn btn-ghost" onClick={onClose}>
              Close
            </button>
            <div className="spacer" />
            <button className="btn btn-primary" onClick={() => setConfirmExecute(true)} disabled={executing}>
              {executing ? <span className="spinner" style={{ borderTopColor: '#fff' }} /> : <IconZap size={14} />}
              Run AI execution
            </button>
          </>
        ) : null
      }
    >
      {error ? <ErrorState error={error} onRetry={reload} compact /> : null}
      {!error && loading && !task ? <Skeleton height={200} /> : null}
      {task ? (
        <>
          <div className="row gap-2 wrap">
            <StatusBadge status={task.status} />
            <PriorityBadge priority={task.priority} />
          </div>

          <div className="row gap-2 wrap">
            <Select
              value={task.status}
              onChange={(e) => void transition(e.target.value as BacklogStatus)}
              style={{ width: 170 }}
              aria-label="Change task status"
            >
              {Array.from(new Set<BacklogStatus>([task.status, ...(VALID_TRANSITIONS[task.status] ?? [])])).map((s) => (
                <option key={s} value={s}>
                  {titleCase(s)}
                </option>
              ))}
            </Select>
            <Select
              value={task.priority}
              onChange={(e) => void patchTask({ priority: e.target.value })}
              style={{ width: 150 }}
              aria-label="Change task priority"
            >
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {titleCase(p)}
                </option>
              ))}
            </Select>
          </div>

          <Field label="Title">
            <Input
              defaultValue={task.title}
              key={`title-${task.id}`}
              onBlur={(e) => {
                const v = e.target.value.trim();
                if (v && v !== task.title) void patchTask({ title: v });
              }}
              maxLength={200}
            />
          </Field>

          <Field label="Description">
            {editingDesc ? (
              <div className="stack gap-2">
                <Textarea
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  rows={5}
                  autoFocus
                  maxLength={8000}
                />
                <div className="row gap-2">
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => {
                      void patchTask({ description: desc.trim() });
                      setEditingDesc(false);
                    }}
                  >
                    Save
                  </button>
                  <button className="btn btn-sm" onClick={() => setEditingDesc(false)}>
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div
                className="muted clickable"
                style={{ whiteSpace: 'pre-wrap', fontSize: 13, lineHeight: 1.6, minHeight: 40 }}
                onClick={() => {
                  setDesc(task.description);
                  setEditingDesc(true);
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    setDesc(task.description);
                    setEditingDesc(true);
                  }
                }}
                title="Click to edit"
              >
                {task.description || 'No description — click to add one.'}
              </div>
            )}
          </Field>

          <div className="grid grid-2">
            <Field label="Assignee">
              <Select
                value={task.assigneeUserId ?? ''}
                onChange={(e) => void patchTask({ assigneeUserId: e.target.value || null })}
                aria-label="Assignee"
              >
                <option value="">Unassigned</option>
                {members.map((m) => (
                  <option key={m.userId} value={m.userId}>
                    {m.userName ?? m.userEmail ?? 'Unknown member'}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Due date">
              <div className="row gap-2">
                <Input
                  type="date"
                  value={task.dueDate ? task.dueDate.slice(0, 10) : ''}
                  onChange={(e) => void patchTask({ dueDate: e.target.value || null })}
                  aria-label="Due date"
                />
                {task.dueDate ? (
                  <button className="btn btn-ghost btn-sm" onClick={() => void patchTask({ dueDate: null })}>
                    Clear
                  </button>
                ) : null}
              </div>
            </Field>
          </div>

          <Field label="Labels">
            {projectLabels.length === 0 ? (
              <div className="faint text-sm">No labels in this project yet — create them in the backlog.</div>
            ) : (
              <div className="stack gap-1" style={{ maxHeight: 160, overflowY: 'auto' }}>
                {projectLabels.map((l) => {
                  const checked = taskLabels.some((t) => t.labelId === l.id);
                  return (
                    <label key={l.id} className="row gap-2 text-sm" style={{ cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        className="checkbox"
                        checked={checked}
                        onChange={() =>
                          void setTaskLabels(
                            checked ? taskLabels.filter((t) => t.labelId !== l.id).map((t) => t.labelId) : [...taskLabels.map((t) => t.labelId), l.id],
                          )
                        }
                        aria-label={`Label ${l.name}`}
                      />
                      <span className="chip-dot" style={{ background: l.color }} />
                      {l.name}
                    </label>
                  );
                })}
              </div>
            )}
          </Field>

          <div className="stack gap-2">
            <div className="uppercase-label">Subtasks</div>
            {subtasks.map((sub) => (
              <div key={sub.id} className={`subtask-row ${sub.done ? 'done' : ''}`}>
                <input
                  type="checkbox"
                  className="checkbox"
                  checked={sub.done}
                  onChange={() => void toggleSub(sub)}
                  aria-label={sub.title}
                />
                <span className="subtask-title flex-1">{sub.title}</span>
                <button className="chip-remove" onClick={() => void deleteSub(sub.id)} aria-label="Delete subtask">
                  <IconX size={9} />
                </button>
              </div>
            ))}
            <div className="row gap-2">
              <Input
                value={newSub}
                onChange={(e) => setNewSub(e.target.value)}
                placeholder="Add a subtask…"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') void addSub();
                }}
                maxLength={200}
              />
              <button className="btn btn-sm" onClick={() => void addSub()} disabled={newSub.trim().length < 2}>
                <IconPlus size={13} />
              </button>
            </div>
          </div>

          <div className="stack gap-2">
            <div className="uppercase-label">Depends on</div>
            {depNames.length === 0 ? (
              <div className="faint text-sm">No task dependencies.</div>
            ) : (
              <div className="row gap-2 wrap">
                {depNames.map((name, i) => (
                  <span key={i} className="dep-tag">
                    <span className="truncate" style={{ maxWidth: 240 }}>
                      {name}
                    </span>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="stack gap-2">
            <div className="uppercase-label">History</div>
            {timeline.length === 0 ? (
              <div className="faint text-sm">No activity yet.</div>
            ) : (
              <div className="stack gap-2">
                {timeline.map((entry, i) => (
                  <div key={i} className="row gap-2 text-sm">
                    <span className={`timeline-kind-dot ${entry.kind}`} aria-hidden="true" />
                    <span className="flex-1">{entry.label}</span>
                    <span className="faint" title={entry.at}>
                      {formatRelative(entry.at)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="stack gap-2">
            <div className="uppercase-label">Comments ({comments.length})</div>
            {comments.length === 0 ? (
              <div className="faint text-sm">No comments yet — start the discussion.</div>
            ) : (
              <div className="stack gap-2">
                {comments.map((c) => (
                  <div key={c.id} className="card" style={{ padding: '8px 12px' }}>
                    <div className="row gap-2" style={{ justifyContent: 'space-between', alignItems: 'baseline' }}>
                      <span className="weight-600 text-sm">{c.userName ?? 'Unknown'}</span>
                      <span className="faint text-sm">{formatRelative(c.createdAt)}</span>
                    </div>
                    <CommentBody body={c.body} />
                    {authUser && c.userId === authUser.id ? (
                      <div className="row justify-end" style={{ marginTop: 4 }}>
                        <button
                          className="btn btn-ghost btn-sm"
                          style={{ color: 'var(--danger)' }}
                          onClick={() => void deleteComment(c.id)}
                          aria-label="Delete comment"
                        >
                          Delete
                        </button>
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            )}
            <div className="stack gap-2">
              <textarea
                className="input"
                rows={2}
                placeholder="Add a comment…"
                value={newComment}
                maxLength={4000}
                onChange={(e) => setNewComment(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                    e.preventDefault();
                    void addComment();
                  }
                }}
              />
              <div className="row justify-end">
                <button
                  className="btn btn-primary btn-sm"
                  onClick={() => void addComment()}
                  disabled={commentBusy || newComment.trim().length === 0}
                >
                  {commentBusy ? <span className="spinner" /> : null}
                  Comment
                </button>
              </div>
            </div>
          </div>

        </>
      ) : null}
      <ConfirmDialog
        open={confirmExecute}
        title="Run AI execution"
        message={
          <>
            The AI developer agent will attempt to implement <strong>{task?.title}</strong>: it plans the change, edits
            the code in the connected repository, runs tests, and — if everything passes — pushes a branch and opens a
            pull request for your review. You can cancel while it is queued or running.
          </>
        }
        confirmLabel="Start execution"
        busy={executing}
        onConfirm={() => void execute()}
        onCancel={() => setConfirmExecute(false)}
      />
    </Drawer>
  );
}

// ---------- board ----------

export function SprintBoard(): JSX.Element {
  const ctx = useProjectRequired();
  const projectId = ctx.projectId;
  const toast = useToast();
  const { data, loading, error, reload } = useApi<BoardPayload>(
    () => api.get<unknown>(`/projects/${projectId}/board`) as Promise<BoardPayload>,
    [projectId],
  );
  // The board payload is lean; the backlog tree provides assignee/due/label metadata per task.
  const backlog = useApi<BacklogTree | null>(
    () => api.get<unknown>(`/projects/${projectId}/backlog`).then(normalizeBacklogTree),
    [projectId],
  );
  const roster = useApi<WorkspaceRoster>(() => api.get<WorkspaceRoster>('/workspace/roster'), []);
  const [dragTaskId, setDragTaskId] = useState<string | null>(null);
  const [dragOverCol, setDragOverCol] = useState<BacklogStatus | null>(null);
  const [openTaskId, setOpenTaskId] = useState<string | null>(null);

  const tasks = data?.tasks ?? [];
  const activeSprint: Sprint | null = data?.activeSprint ?? null;
  const members = roster.data?.members ?? [];
  const projectLabels = useMemo(
    () => [...(backlog.data?.labels ?? [])].sort((a, b) => a.name.localeCompare(b.name)),
    [backlog.data],
  );

  const taskMeta = useMemo(() => {
    const map = new Map<string, { assigneeName: string | null; dueDate: string | null; labels: LabelAssignment[] }>();
    const labelById = new Map((backlog.data?.labels ?? []).map((l) => [l.id, l]));
    for (const t of backlog.data?.tasks ?? []) {
      map.set(t.id, { assigneeName: t.assigneeName, dueDate: t.dueDate, labels: [] });
    }
    for (const link of backlog.data?.taskLabels ?? []) {
      const meta = map.get(link.taskId);
      const label = labelById.get(link.labelId);
      if (meta && label) meta.labels.push({ labelId: label.id, name: label.name, color: label.color });
    }
    return map;
  }, [backlog.data]);

  const drop = async (status: BacklogStatus): Promise<void> => {
    setDragOverCol(null);
    const id = dragTaskId;
    setDragTaskId(null);
    if (!id) return;
    const task = tasks.find((t) => t.id === id);
    if (!task || task.status === status) return;
    try {
      await api.post(`/projects/${projectId}/tasks/${id}/transition`, { status });
      toast.success(`"${task.title}" moved to ${titleCase(status)}`);
      reload();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Transition failed');
    }
  };

  if (loading && !data)
    return (
      <div className="page" style={{ maxWidth: 'none' }}>
        <Skeleton height={40} style={{ marginBottom: 16 }} />
        <div className="kanban-board">
          {COLUMNS.map((c) => (
            <div key={c.status} className="kanban-column">
              <Skeleton height={200} style={{ margin: 10, borderRadius: 8 }} />
            </div>
          ))}
        </div>
      </div>
    );

  if (error)
    return (
      <div className="page">
        <ErrorState error={error} onRetry={reload} title="Failed to load board" />
      </div>
    );

  return (
    <div className="page" style={{ maxWidth: 'none' }}>
      <div className="page-header">
        <div>
          <div className="page-title">Sprint Board</div>
          <div className="page-sub">
            {activeSprint ? (
              <span className="row gap-2">
                Active sprint: <strong>{activeSprint.name}</strong>
              </span>
            ) : (
              'No active sprint — activate one from the Sprints page.'
            )}
          </div>
        </div>
      </div>

      {tasks.length === 0 ? (
        <EmptyState
          title="No tasks on the board"
          description="Create stories and break them down into tasks in the backlog, then drag cards between columns here."
        />
      ) : (
        <div className="kanban-board">
          {COLUMNS.map((col) => {
            const colTasks = tasks.filter((t) => t.status === col.status);
            return (
              <div
                key={col.status}
                className={`kanban-column ${dragOverCol === col.status ? 'drag-over' : ''}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOverCol(col.status);
                }}
                onDragLeave={(e) => {
                  if (!(e.currentTarget instanceof Element) || !e.currentTarget.contains(e.relatedTarget as Node)) {
                    setDragOverCol(null);
                  }
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  void drop(col.status);
                }}
              >
                <div className="kanban-column-header">
                  <span className="kanban-dot" style={{ background: col.dot }} />
                  <span>{titleCase(col.status)}</span>
                  <span className="spacer" />
                  <span className="kanban-count">{colTasks.length}</span>
                </div>
                <div className="kanban-cards">
                  {colTasks.length === 0 ? (
                    <div className="kanban-empty">Drop tasks here</div>
                  ) : (
                    colTasks.map((task) => {
                      const meta = taskMeta.get(task.id);
                      return (
                        <div
                          key={task.id}
                          className={`kanban-card ${dragTaskId === task.id ? 'dragging' : ''}`}
                          draggable
                          onDragStart={(e) => {
                            setDragTaskId(task.id);
                            e.dataTransfer.effectAllowed = 'move';
                            e.dataTransfer.setData('text/plain', task.id);
                          }}
                          onDragEnd={() => {
                            setDragTaskId(null);
                            setDragOverCol(null);
                          }}
                          onClick={() => setOpenTaskId(task.id)}
                          role="button"
                          tabIndex={0}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') setOpenTaskId(task.id);
                          }}
                          aria-label={`Task: ${task.title}`}
                        >
                          <div className="kanban-card-title">{task.title}</div>
                          {meta && (meta.assigneeName || meta.dueDate || meta.labels.length > 0) ? (
                            <div className="row gap-2 wrap">
                              <LabelDots labels={meta.labels} />
                              <InitialsChip name={meta.assigneeName} />
                              <DueChip dueDate={meta.dueDate} status={task.status} />
                            </div>
                          ) : null}
                          <div className="kanban-card-meta">
                            <PriorityBadge priority={task.priority} />
                            <span className="faint text-sm truncate" style={{ maxWidth: 160 }}>
                              {task.storyTitle}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <TaskDrawer
        taskId={openTaskId}
        projectId={projectId}
        boardTasks={tasks}
        members={members}
        projectLabels={projectLabels}
        onClose={() => setOpenTaskId(null)}
        onChanged={reload}
        onMetaChanged={backlog.reload}
      />
    </div>
  );
}
