/**
 * Sprint lifecycle and metrics. All metrics are computed from real data:
 * stories, status_events and sprint completion snapshots.
 */
import { getDb, newId, nowIso, withTransaction } from '../db/database.js';
import { AppError } from '../util/appError.js';
import { ErrorCodes } from '@devflow/shared';
import { recordActivity, notify } from './events.service.js';
import { requireProject, requireProjectWrite } from './projects.service.js';
import { readSprintSnapshot } from './mappers.js';
import type {
  BacklogStatus,
  BurndownPoint,
  CreateSprintInput,
  Sprint,
  SprintMetrics,
  SprintStatus,
  VelocityPoint,
} from '@devflow/shared';

interface SprintRow {
  id: string;
  project_id: string;
  name: string;
  goal: string;
  status: string;
  starts_at: string | null;
  ends_at: string | null;
  created_at: string;
  completed_at: string | null;
  metrics_snapshot: string | null;
}

function toSprint(row: SprintRow): Sprint {
  return {
    id: row.id,
    projectId: row.project_id,
    name: row.name,
    goal: row.goal,
    status: row.status as SprintStatus,
    startsAt: row.starts_at,
    endsAt: row.ends_at,
    createdAt: row.created_at,
    completedAt: row.completed_at,
  };
}

function getSprintRow(sprintId: string, projectId: string): SprintRow {
  const row = getDb()
    .prepare('SELECT * FROM sprints WHERE id = ? AND project_id = ?')
    .get(sprintId, projectId) as unknown as unknown as SprintRow | undefined;
  if (!row) throw AppError.notFound('Sprint');
  return row;
}

export function listSprints(projectId: string, userId: string): Sprint[] {
  requireProject(projectId, userId);
  const rows = getDb()
    .prepare(
      "SELECT * FROM sprints WHERE project_id = ? ORDER BY CASE status WHEN 'active' THEN 0 WHEN 'planned' THEN 1 ELSE 2 END, created_at DESC"
    )
    .all(projectId) as unknown as SprintRow[];
  return rows.map(toSprint);
}

export function createSprint(projectId: string, userId: string, input: CreateSprintInput): Sprint {
  requireProjectWrite(projectId, userId);
  const db = getDb();
  const id = newId();
  db.prepare(
    'INSERT INTO sprints (id, project_id, name, goal, status, starts_at, ends_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(id, projectId, input.name, input.goal, 'planned', input.startsAt ?? null, input.endsAt ?? null, nowIso());
  recordActivity(projectId, userId, 'sprint.created', `Sprint "${input.name}" created`);
  return toSprint(getSprintRow(id, projectId));
}

export function updateSprint(
  projectId: string,
  sprintId: string,
  userId: string,
  input: { name?: string; goal?: string; startsAt?: string | null; endsAt?: string | null }
): Sprint {
  requireProjectWrite(projectId, userId);
  const row = getSprintRow(sprintId, projectId);
  if (row.status === 'completed' || row.status === 'cancelled') {
    throw AppError.conflict(ErrorCodes.CONFLICT, `Cannot edit a ${row.status} sprint`);
  }
  getDb()
    .prepare('UPDATE sprints SET name = ?, goal = ?, starts_at = ?, ends_at = ? WHERE id = ?')
    .run(
      input.name ?? row.name,
      input.goal ?? row.goal,
      input.startsAt !== undefined ? input.startsAt : row.starts_at,
      input.endsAt !== undefined ? input.endsAt : row.ends_at,
      sprintId
    );
  return toSprint(getSprintRow(sprintId, projectId));
}

export function assignStory(projectId: string, sprintId: string, storyId: string, userId: string): void {
  requireProjectWrite(projectId, userId);
  getSprintRow(sprintId, projectId);
  const story = getDb()
    .prepare('SELECT id, title, status FROM stories WHERE id = ? AND project_id = ?')
    .get(storyId, projectId) as { id: string; title: string; status: string } | undefined;
  if (!story) throw AppError.notFound('Story');
  if (story.status === 'done') {
    throw AppError.conflict(ErrorCodes.CONFLICT, 'Cannot assign a completed story to a sprint');
  }
  getDb().prepare('UPDATE stories SET sprint_id = ?, updated_at = ? WHERE id = ?').run(sprintId, nowIso(), storyId);
  recordActivity(projectId, userId, 'sprint.story_added', `Story "${story.title}" added to sprint`);
}

export function unassignStory(projectId: string, sprintId: string, storyId: string, userId: string): void {
  requireProjectWrite(projectId, userId);
  getSprintRow(sprintId, projectId);
  getDb().prepare('UPDATE stories SET sprint_id = NULL, updated_at = ? WHERE id = ? AND sprint_id = ?').run(nowIso(), storyId, sprintId);
}

export function activateSprint(projectId: string, sprintId: string, userId: string): Sprint {
  requireProjectWrite(projectId, userId);
  const row = getSprintRow(sprintId, projectId);
  if (row.status !== 'planned') {
    throw AppError.conflict(ErrorCodes.CONFLICT, `Only planned sprints can be activated (current: ${row.status})`);
  }
  const db = getDb();
  const storyCount = db
    .prepare('SELECT COUNT(*) AS c FROM stories WHERE sprint_id = ?')
    .get(sprintId) as { c: number };
  if (storyCount.c === 0) {
    throw AppError.conflict(ErrorCodes.CONFLICT, 'Cannot activate an empty sprint — assign stories first');
  }
  const active = db
    .prepare("SELECT id FROM sprints WHERE project_id = ? AND status = 'active' AND id != ?")
    .get(projectId, sprintId) as { id: string } | undefined;
  if (active) {
    throw AppError.conflict(ErrorCodes.CONFLICT, 'Another sprint is already active. Complete it first.');
  }
  withTransaction(() => {
    db.prepare("UPDATE sprints SET status = 'active', starts_at = COALESCE(starts_at, ?) WHERE id = ?").run(nowIso(), sprintId);
    // stories in the sprint that are still in backlog move to todo
    const backlogStories = db
      .prepare("SELECT id FROM stories WHERE sprint_id = ? AND status = 'backlog'")
      .all(sprintId) as Array<{ id: string }>;
    for (const s of backlogStories) {
      db.prepare("UPDATE stories SET status = 'todo', updated_at = ? WHERE id = ?").run(nowIso(), s.id);
      db.prepare(
        'INSERT INTO status_events (id, project_id, entity_type, entity_id, from_status, to_status, actor_user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      ).run(newId(), projectId, 'story', s.id, 'backlog', 'todo', userId, nowIso());
    }
  });
  recordActivity(projectId, userId, 'sprint.activated', `Sprint "${row.name}" activated`);
  return toSprint(getSprintRow(sprintId, projectId));
}

// ---------- metrics ----------

interface SprintStoryRow {
  id: string;
  points: number;
  status: string;
}

function firstDoneAtMap(storyIds: string[]): Map<string, string> {
  const map = new Map<string, string>();
  if (storyIds.length === 0) return map;
  const placeholders = storyIds.map(() => '?').join(',');
  const rows = getDb()
    .prepare(
      `SELECT entity_id, MIN(created_at) AS firstDone FROM status_events
       WHERE entity_type = 'story' AND to_status = 'done' AND entity_id IN (${placeholders})
       GROUP BY entity_id`
    )
    .all(...storyIds) as Array<{ entity_id: string; firstDone: string }>;
  for (const r of rows) map.set(r.entity_id, r.firstDone);
  return map;
}

export function computeSprintMetrics(sprintRow: SprintRow): SprintMetrics {
  const db = getDb();
  const stories = db
    .prepare('SELECT id, points, status FROM stories WHERE sprint_id = ?')
    .all(sprintRow.id) as unknown as SprintStoryRow[];

  const totalPoints = stories.reduce((sum, s) => sum + s.points, 0);
  const doneStories = stories.filter((s) => s.status === 'done');
  const donePoints = doneStories.reduce((sum, s) => sum + s.points, 0);
  const openTasks = (
    db
      .prepare(
        "SELECT COUNT(*) AS c FROM tasks t JOIN stories s ON s.id = t.story_id WHERE s.sprint_id = ? AND t.status NOT IN ('done', 'cancelled')"
      )
      .get(sprintRow.id) as { c: number }
  ).c;

  const startStr = sprintRow.starts_at ?? sprintRow.created_at;
  const start = new Date(startStr);
  const endRaw = sprintRow.ends_at ?? sprintRow.completed_at;
  const end = endRaw ? new Date(endRaw) : new Date();
  const sprintDays = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / 86400000) || 14);
  const days = Math.min(90, Math.max(sprintDays, 1));

  const doneAt = firstDoneAtMap(stories.map((s) => s.id));
  // pre-parse done timestamps once and walk the days with a cursor instead of
  // re-filtering/re-parsing the whole story list for every day
  const donePointsByMs = doneStories
    .map((s) => ({ ms: new Date(doneAt.get(s.id) ?? 0).getTime(), points: s.points }))
    .sort((a, b) => a.ms - b.ms);
  const burndown: BurndownPoint[] = [];
  const dayMs = 86400000;
  const startDay = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate()));
  let cursor = 0;
  let burnedSoFar = 0;
  for (let i = 0; i <= days; i++) {
    const dayEnd = startDay.getTime() + i * dayMs + dayMs - 1;
    while (cursor < donePointsByMs.length && donePointsByMs[cursor]!.ms <= dayEnd) {
      burnedSoFar += donePointsByMs[cursor]!.points;
      cursor++;
    }
    const label = new Date(dayEnd).toISOString().slice(0, 10);
    const ideal = Math.max(0, Math.round((totalPoints * (days - i)) / days));
    burndown.push({ date: label, remaining: totalPoints - burnedSoFar, ideal });
  }

  return {
    sprint: toSprint(sprintRow),
    totalPoints,
    donePoints,
    totalStories: stories.length,
    doneStories: doneStories.length,
    openTasks,
    burndown,
    completionRate: totalPoints > 0 ? Math.round((donePoints / totalPoints) * 100) : 0,
  };
}

export function getSprintMetrics(projectId: string, sprintId: string, userId: string): SprintMetrics {
  requireProject(projectId, userId);
  const row = getSprintRow(sprintId, projectId);
  if (row.metrics_snapshot) {
    const snap = JSON.parse(row.metrics_snapshot) as SprintMetrics;
    // refresh sprint identity fields (name etc.) from the row
    return { ...snap, sprint: toSprint(row) };
  }
  return computeSprintMetrics(row);
}

export function completeSprint(projectId: string, sprintId: string, userId: string): SprintMetrics {
  requireProjectWrite(projectId, userId);
  const row = getSprintRow(sprintId, projectId);
  if (row.status !== 'active') {
    throw AppError.conflict(ErrorCodes.CONFLICT, `Only active sprints can be completed (current: ${row.status})`);
  }
  const db = getDb();
  const ts = nowIso();

  // snapshot metrics BEFORE the carry-over: unfinished stories lose their
  // sprint_id below, which would otherwise shrink the totals permanently
  const metrics = computeSprintMetrics(row);

  withTransaction(() => {
    db.prepare("UPDATE sprints SET status = 'completed', completed_at = ? WHERE id = ?").run(ts, sprintId);
    // snapshot lands atomically with the completion flag — a crash between the
    // two would leave the sprint completed with no frozen metrics
    db.prepare('UPDATE sprints SET metrics_snapshot = ? WHERE id = ?').run(JSON.stringify(metrics), sprintId);
    // carry over: stories that did not finish return to the backlog
    const unfinished = db
      .prepare("SELECT id FROM stories WHERE sprint_id = ? AND status != 'done'")
      .all(sprintId) as Array<{ id: string }>;
    for (const s of unfinished) {
      const current = db.prepare('SELECT status FROM stories WHERE id = ?').get(s.id) as { status: string };
      db.prepare('UPDATE stories SET sprint_id = NULL, status = ?, updated_at = ? WHERE id = ?').run('backlog', ts, s.id);
      if (current.status !== 'backlog') {
        db.prepare(
          'INSERT INTO status_events (id, project_id, entity_type, entity_id, from_status, to_status, actor_user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        ).run(newId(), projectId, 'story', s.id, current.status, 'backlog', userId, ts);
      }
    }
  });

  recordActivity(projectId, userId, 'sprint.completed', `Sprint "${row.name}" completed — ${metrics.donePoints}/${metrics.totalPoints} pts done`);
  notify(userId, 'sprint.completed', 'Sprint completed', `"${row.name}" finished with ${metrics.completionRate}% completion.`);
  // return the snapshot with the completed sprint identity
  return { ...metrics, sprint: toSprint(getSprintRow(sprintId, projectId)) };
}

export function getVelocity(projectId: string, userId: string): VelocityPoint[] {
  requireProject(projectId, userId);
  const db = getDb();
  const rows = db
    .prepare(
      "SELECT * FROM sprints WHERE project_id = ? AND status IN ('completed', 'active') ORDER BY COALESCE(starts_at, created_at) ASC LIMIT 12"
    )
    .all(projectId) as unknown as SprintRow[];

  return rows.map((row) => {
    if (row.metrics_snapshot) {
      const snap = JSON.parse(row.metrics_snapshot) as SprintMetrics;
      return { sprint: row.name, sprintId: row.id, committed: snap.totalPoints, completed: snap.donePoints };
    }
    const m = computeSprintMetrics(row);
    return { sprint: row.name, sprintId: row.id, committed: m.totalPoints, completed: m.donePoints };
  });
}

// ---------- roadmap (lightweight gantt) ----------

export interface RoadmapRow {
  id: string;
  title: string;
  kind: 'epic' | 'sprint';
  start: string;
  end: string;
  status: string;
  totalPoints: number;
  donePoints: number;
}

/** Computes Gantt rows: epics span their stories (created → max due date),
 *  sprints span their windows. Never invents dates — missing ends use starts. */
export function getRoadmap(projectId: string, userId: string): {
  items: RoadmapRow[];
  minDate: string;
  maxDate: string;
} {
  requireProject(projectId, userId);
  const db = getDb();

  const items: RoadmapRow[] = [];
  const epicRows = db
    .prepare('SELECT id, title, created_at FROM epics WHERE project_id = ? ORDER BY position')
    .all(projectId) as Array<{ id: string; title: string; created_at: string }>;
  for (const epic of epicRows) {
    const stories = db
      .prepare("SELECT created_at, due_date, points, status FROM stories WHERE epic_id = ? AND status != 'cancelled'")
      .all(epic.id) as Array<{ created_at: string; due_date: string | null; points: number; status: string }>;
    const total = stories.reduce((n, x) => n + x.points, 0);
    const done = stories.filter((x) => x.status === 'done').reduce((n, x) => n + x.points, 0);
    const starts = stories.map((x) => x.created_at).concat(epic.created_at);
    const ends = stories.map((x) => x.due_date).filter((d): d is string => Boolean(d));
    const start = starts.sort()[0] ?? epic.created_at;
    const end = ends.sort().pop() ?? epic.created_at;
    items.push({ id: epic.id, title: epic.title, kind: 'epic', start, end, status: total > 0 && done === total ? 'done' : 'open', totalPoints: total, donePoints: done });
  }

  const sprintRows = db
    .prepare('SELECT * FROM sprints WHERE project_id = ? ORDER BY COALESCE(starts_at, created_at)')
    .all(projectId) as unknown as Array<{
    id: string;
    name: string;
    status: string;
    starts_at: string | null;
    ends_at: string | null;
    completed_at: string | null;
    created_at: string;
    metrics_snapshot: string | null;
  }>;
  for (const sp of sprintRows) {
    const snap = readSprintSnapshot(sp);
    const start = sp.starts_at ?? sp.created_at;
    const end = sp.ends_at ?? sp.completed_at ?? start;
    items.push({
      id: sp.id,
      title: sp.name,
      kind: 'sprint',
      start,
      end,
      status: sp.status,
      totalPoints: snap?.totalPoints ?? 0,
      donePoints: snap?.donePoints ?? 0,
    });
  }

  const dates = items.flatMap((i) => [i.start, i.end]).sort();
  return { items, minDate: dates[0] ?? new Date().toISOString(), maxDate: dates[dates.length - 1] ?? new Date().toISOString() };
}

// ---------- kanban board ----------

export interface BoardTask {
  id: string;
  projectId: string;
  storyId: string;
  title: string;
  description: string;
  status: BacklogStatus;
  priority: string;
  position: number;
  storyTitle: string;
  epicTitle: string | null;
  updatedAt: string;
}

export interface BoardPayload {
  tasks: BoardTask[];
  sprints: Sprint[];
  activeSprint: Sprint | null;
}

export function getBoard(projectId: string, userId: string): BoardPayload {
  requireProject(projectId, userId);
  const db = getDb();
  const tasks = db
    .prepare(
      `SELECT t.*, s.title AS story_title, e.title AS epic_title
       FROM tasks t JOIN stories s ON s.id = t.story_id LEFT JOIN epics e ON e.id = s.epic_id
       WHERE t.project_id = ? AND t.status != 'cancelled'
       ORDER BY t.position, t.created_at`
    )
    .all(projectId) as Array<{
    id: string;
    project_id: string;
    story_id: string;
    title: string;
    description: string;
    status: string;
    priority: string;
    position: number;
    story_title: string;
    epic_title: string | null;
    updated_at: string;
  }>;

  const sprints = listSprints(projectId, userId);
  return {
    tasks: tasks.map((t) => ({
      id: t.id,
      projectId: t.project_id,
      storyId: t.story_id,
      title: t.title,
      description: t.description,
      status: t.status as BacklogStatus,
      priority: t.priority,
      position: t.position,
      storyTitle: t.story_title,
      epicTitle: t.epic_title,
      updatedAt: t.updated_at,
    })),
    sprints,
    activeSprint: sprints.find((s) => s.status === 'active') ?? null,
  };
}
