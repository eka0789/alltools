<p align="center">
  <img src="docs/assets/jawara-logo.jpg" alt="JAWARA - Jaringan Bisnis B2B Indonesia" width="520" />
</p>

<p align="center">
  <strong>Connecting Businesses. Empowering Opportunities. Building the Future.</strong>
</p>

<p align="center">
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-0B1F3A.svg?style=flat-square" alt="License: MIT" /></a>
  <img src="https://img.shields.io/badge/Next.js-16-000000.svg?style=flat-square" alt="Next.js 16" />
  <img src="https://img.shields.io/badge/Laravel-12-FF2D20.svg?style=flat-square" alt="Laravel 12" />
  <img src="https://img.shields.io/badge/TypeScript-5-3178C6.svg?style=flat-square" alt="TypeScript 5" />
  <img src="https://img.shields.io/badge/Tailwind_CSS-v4-06B6D4.svg?style=flat-square" alt="Tailwind CSS v4" />
</p>

---

**JAWARA** adalah platform ekosistem bisnis B2B multi-tenant untuk UMKM, distributor, manufaktur, dan enterprise di Jawa Tengah (Salatiga, Semarang, Solo) dan Indonesia. JAWARA menyatukan direktori bisnis terindeks SEO, verifikasi dokumen legal, katalog produk & storefront supplier, serta alur pengadaan terstruktur (**RFQ -> Quotation -> Purchase Order**) dalam satu aplikasi web modern.

## Fitur Utama

- **Direktori Bisnis & Profil Publik (SEO Server-First)**: Pencarian perusahaan berdasarkan kata kunci, kategori, lokasi, dan status verifikasi dengan structured data (`schema.org/Organization`).
- **Verifikasi Legal Perusahaan**: Unggah dokumen legal (NIB, SIUP, Akta) yang ditinjau oleh moderator platform melalui Portal Admin sebelum status terverifikasi diberikan.
- **Katalog Produk, Jasa & Storefront**: Pengelolaan produk dengan satuan, MOQ, varian SKU, serta fleksibilitas visibilitas harga (publik, harga minta, anggota saja).
- **Mesin Pengadaan (State Machine Eksplisit)**: Pembuatan RFQ, pengiriman dan perbandingan penawaran (Quotation), hingga penerbitan dan pelacakan status Purchase Order dalam transaksi database yang aman.
- **Pesan, Notifikasi & Langganan**: Komunikasi langsung antar organisasi (pembeli & supplier), pusat notifikasi transaksi, serta manajemen paket langganan & invoice.
- **Keamanan Multi-Tenant & RBAC**: Isolasi tenant ketat melalui Laravel Policies, Sanctum httpOnly cookie auth, audit log aksi kritis, dan idempotency key.

---

## Pratinjau Antarmuka

### Beranda & Pencarian Supplier (Desktop)

<p align="center">
  <img src="docs/screenshots/home-desktop.png" alt="Beranda JAWARA Desktop" width="100%" />
</p>

### Direktori Bisnis & Autentikasi

| Direktori Bisnis | Halaman Masuk (Auth) |
| :---: | :---: |
| <img src="docs/screenshots/directory-desktop.png" alt="Direktori Bisnis JAWARA" width="100%" /> | <img src="docs/screenshots/login-desktop.png" alt="Halaman Masuk JAWARA" width="100%" /> |

### Tampilan Responsif Mobile

<p align="center">
  <img src="docs/screenshots/home-mobile.png" alt="Beranda JAWARA Mobile 375px" width="320" />
</p>

---

## Struktur Monorepo

```text
jawara/
├── backend/            # Laravel 12 API (modular monolith, Sanctum, Policies, State Machine)
├── frontend/           # Next.js 16 App Router (React 19, TypeScript, Tailwind CSS v4, TanStack Query)
├── infrastructure/     # Docker Compose & konfigurasi deployment
├── docs/               # Dokumentasi arsitektur, API, schema, aset merek & screenshot
│   ├── assets/         # Logo wordmark & emblem resmi JAWARA
│   └── screenshots/    # Pratinjau antarmuka aplikasi
├── scripts/            # Helper script pengembangan
└── LICENSE             # Lisensi MIT
```

---

## Pengembangan Lokal (Windows / XAMPP, tanpa Docker)

**Prasyarat**: PHP 8.2+, Composer, Node.js 20+, dan MariaDB/MySQL (XAMPP) berjalan. Redis bersifat opsional (fallback ke file cache).

```bash
# 1. Jalankan Backend API
cd backend
composer install
cp .env.example .env            # Sesuaikan DB_DATABASE=jawara, DB_USERNAME=root, DB_PASSWORD=
php artisan key:generate
php artisan migrate --seed
php artisan serve               # http://localhost:8000

# 2. Jalankan Frontend (terminal baru)
cd frontend
npm install
cp .env.example .env.local      # NEXT_PUBLIC_API_URL=http://localhost:8000
npm run dev                     # http://localhost:3000
```

Health check API: `http://localhost:8000/api/v1/health`

---

## Perintah Kualitas & Verifikasi

| Perintah | Direktori | Fungsi |
|---|---|---|
| `composer test` / `php artisan test` | `backend` | Menjalankan test suite (feature & unit) |
| `composer lint` / `composer analyse` | `backend` | Laravel Pint style check & Larastan static analysis |
| `npm run lint` | `frontend` | ESLint check (zero warnings) |
| `npm run build` | `frontend` | TypeScript check & production build Next.js |

---

## Dokumentasi & Arsitektur

Seluruh dokumen spesifikasi dan arsitektur tersedia di folder [`docs/`](docs/):

- [Product Requirements](docs/PRODUCT_REQUIREMENTS.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Database Schema](docs/DATABASE_SCHEMA.md)
- [API Contract](docs/API_CONTRACT.md)
- [Security](docs/SECURITY.md)
- [Roadmap](docs/ROADMAP.md)
- [Deployment](docs/DEPLOYMENT.md)
- [Testing](docs/TESTING.md)
- [Architecture Decisions](docs/DECISIONS.md)
- [Metodologi Pengembangan](METHODOLOGY.md)

---

## Lisensi

Proyek ini dilisensikan di bawah **MIT License**. Lihat berkas [LICENSE](LICENSE) untuk ketentuan lengkap penggunaan, modifikasi, dan distribusi.

Copyright (c) 2026 **JAWARA**.
