---
title: Epics & Stories — JAWARA MVP
status: final
implemented: E1-E6 (2026-11-21)
created: 2026-11-21
updated: 2026-11-21
prd: ../prds/prd-jawara-2026-11-21/prd.md
architecture: ../architecture/architecture-jawara-2026-11-21/ARCHITECTURE-SPINE.md
---

# Epics & Stories — JAWARA MVP

Setiap story dieksekusi dengan disiplin Superpowers (TDD untuk logika bisnis inti, verification sebelum klaim selesai). Engineering Gate: migrasi/tests gagal, cross-tenant bocor, atau authorization bolong → milestone tidak lanjut.

## E1 — Foundation (Phase 01)

**S1.1 Monorepo scaffold**: struktur `backend/ frontend/ infrastructure/ docs/ scripts/`; git; `.gitignore`; `.env.example` keduanya; README + AGENTS.md; dokumen wajib spec (11 file di docs/). AC: struktur sesuai spec Phase 01; tidak ada secret ter-commit.
**S1.2 Backend Laravel init**: Laravel 12 + Sanctum, CORS frontend origin, health-check `/api/v1/health`, konfigurasi MariaDB + Redis cache, Pint + Larastan, test bootstrap. AC: `php artisan migrate` sukses; `/api/v1/health` 200; pint & tests jalan.
**S1.3 Frontend Next.js init**: Next.js 15 App Router + TS strict + Tailwind + shadcn/ui init + ESLint; halaman home placeholder; health proxy/env. AC: `npm run dev` jalan; lint pass.
**S1.4 Infra docs**: `infrastructure/docker-compose.yml` + Dockerfile (authored, parity produksi), `docs/DEPLOYMENT.md`. AC: dokumentasi menjelaskan dev lokal tanpa Docker dan path deploy Docker.

## E2 — Database & Multi-Tenancy (Phase 02)

**S2.1 Migrasi inti**: users, user_profiles, roles/permissions/role_permissions, organizations, organization_members, organization_invitations, business_profiles, business_categories, business_locations, business_verifications. UUID (AD-2), FK lengkap, index query umum, unique membership (AD-1).
**S2.2 Migrasi katalog & procurement**: products/product_categories/product_variants/product_images/services/product_inquiries; rfqs/rfq_items/rfq_invitations/quotations/quotation_items/purchase_orders/purchase_order_items; conversations/conversation_participants/messages/message_attachments/notifications; plans (skim, untuk masa depan); audit_logs/reports/moderation_actions.
**S2.3 Models & relationships**: Eloquent models + trait `BelongsToOrganization` (AD-1) + relasi + factory + seeder (11 kategori lokasi awal Salatiga/Semarang/Solo, roles).
**S2.4 ERD & schema doc**: `docs/DATABASE_SCHEMA.md` + ERD mermaid; test feature: FK invalid, duplikat membership, cross-tenant unauthorized. AC: `migrate:fresh` sukses di DB bersih; test hijau.

## E3 — Auth, Organization & RBAC (Phase 03)

**S3.1 Auth API**: register/verify-email/login/logout/forgot/reset; Sanctum cookie; rate limit. Test: registrasi duplikat, password lemah ditolak, reset token expire.
**S3.2 Organization API**: CRUD organisasi, switch context (`X-Organization-Id` validasi keanggotaan), invite/accept/remove member, ganti peran.
**S3.3 RBAC**: 11 peran, Policies per resource, anti-escalation rules. Test: buyer org A tidak bisa akses org B; member tidak bisa promote diri.
**S3.4 Frontend auth & onboarding**: halaman register/login/verify/reset, onboarding organisasi multi-step, dashboard shell (layout navy/gold). AC: user baru bisa daftar→verifikasi→buat organisasi→invite member (manual happy-path via UI).

## E4 — Business Directory (Phase 04)

**S4.1 Public directory API**: list/search/filter kategori+lokasi+verifikasi, pagination, autocomplete; profil publik (slug SEO) + inquiry endpoint. Privacy: kontak pribadi tidak tampil tanpa consent.
**S4.2 Public pages (SEO)**: homepage, directory, detail perusahaan (metadata dinamis, canonical, structured data Organization), sitemap.xml, robots.txt. State loading/empty/error.
**S4.3 Profil bisnis management (org dashboard)**: edit profil, kategori, lokasi, logo upload (AD-11), kirim verifikasi. AC: perusahaan baru muncul di directory dengan status verification badge benar.

## E5 — Marketplace Catalog (Phase 05)

**S5.1 Catalog API**: CRUD produk (kategori, gambar, SKU, variasi, unit, MOQ, price visibility, stok) + services; status draft/published; paginasi+filter.
**S5.2 Storefront & search publik**: halaman produk per perusahaan, search produk, inquiry. Protect private pricing.
**S5.3 Dashboard katalog org**: kelola listing. AC: supplier publish produk → buyer menemukan via search & storefront → inquiry terkirim.

## E6 — Procurement RFQ Engine (Phase 06)

**S6.1 RFQ API (buyer)**: CRUD draft + items + publish + invite suppliers + close/cancel; eligibility & policy.
**S6.2 Quotation API (supplier)**: discover RFQ, submit/update/withdraw, transisi status (AD-4), idempotency submit (AD-12), notifications dasar.
**S6.3 Compare & award (buyer)**: perbandingan quotation, accept/reject (snapshot immutable), PO create (draft→approve→issue→acknowledge→complete), audit log.
**S6.4 Frontend procurement**: wizard RFQ, bandingkan penawaran, PO detail. Test: concurrent accept hanya 1 sukses; tenant isolation; financial snapshot konsisten.

## Backlog lanjutan (post-MVP, dari spec)

E7 Messaging (Phase 07), E8 Admin & Verification portal penuh (Phase 08), E9 Subscription & Monetization (Phase 09), E10 Growth/SEO penuh + referral (Phase 10), E11 QA/Production hardening (Phase 11).
