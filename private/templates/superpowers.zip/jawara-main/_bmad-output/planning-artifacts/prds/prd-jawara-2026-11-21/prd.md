---
title: PRD — JAWARA MVP (Business Network First)
status: final
created: 2026-11-21
updated: 2026-11-21
brief: ../briefs/brief-jawara-2026-11-21/brief.md
source: docs/spec-source/ (ChatGPT share 6b00c83c)
---

# PRD: JAWARA MVP (Business Network First)

## 0. Document Purpose

PRD ini memecah brief JAWARA menjadi fitur (FR) dan persyaratan non-fungsional (NFR) yang actionable untuk arsitektur dan epic/stories. Sumber kebenaran: spec asli ChatGPT share (Master Engineering Instructions + Phase 01–11), disimpan di `docs/spec-source/`. Keputusan adaptasi environment dicatat di `docs/DECISIONS.md` dan memlog.

## 1. Vision

JAWARA menjadi ekosistem bisnis B2B Jawa Tengah (→ nasional): tempat perusahaan **ditemukan**, **terhubung**, dan **bertransaksi** dengan proses pengadaan yang terdokumentasi dan terpercaya. MVP membangun fondasi: Network (directory + discovery) dan Procurement core (RFQ → quotation → PO).

## 2. Target User

### 2.1 Jobs To Be Done

| # | Aktor | Job | Ukuran sukses |
|---|---|---|---|
| JTJ-1 | Buyer (staf/manajer pengadaan) | Menemukan supplier terverifikasi untuk kebutuhan tertentu dengan cepat | Menemukan kandidat relevan < 5 menit |
| JTJ-2 | Buyer | Mengajukan RFQ ke banyak supplier & membandingkan penawaran secara adil | ≥2 penawaran bisa dibandingkan side-by-side |
| JTJ-3 | Supplier | Ditemukan oleh buyer yang benar (via Google & search internal) | Profil terindeks Google + inquiry masuk |
| JTJ-4 | Supplier | Merespons RFQ dengan penawaran terstruktur (harga, lead time, validitas) | Respons < 1x24 jam |
| JTJ-5 | Owner organisasi | Mengelola tim & peran (RBAC) tanpa berbagi akun | Anggota punya akses sesuai peran |
| JTJ-6 | Moderator platform | Memverifikasi bisnis & memoderasi konten dengan jejak audit | Keputusan verifikasi teraudit 100% |

### 2.2 Non-Users (v1)

- Marketplace retail (B2C) — bukan target; JAWARA khusus B2B.
- Perusahaan luar Jawa Tengah (v1) — bisa daftar tapi fokus akuisisi Salatiga/Semarang/Solo.

### 2.3 Key User Journeys

1. **Supplier onboarding**: registrasi → verifikasi email → buat organisasi + profil bisnis (kategori, lokasi, kontak, logo) → kirim dokumen verifikasi → profil tayang di directory.
2. **Buyer discovery**: visitor/buyer buka directory → filter kategori/lokasi/verifikasi → buka profil perusahaan → inquiry → (registrasi jika perlu) → kirim RFQ.
3. **Procurement core**: buyer buat RFQ (items, spesifikasi, lokasi kirim, deadline) → publish / invite supplier → supplier submit quotation (item, harga, lead time, validitas) → buyer bandingkan → accept 1 quotation → buat Purchase Order dengan snapshot finansial immutable.
4. **Moderasi**: admin memproses antrean verifikasi (pending → under_review → verified/rejected/resubmission_required) dengan alasan & audit log.

## 3. Glossary

| Istilah | Definisi |
|---|---|
| Organization (tenant) | Entitas bisnis pemilik data; unit isolasi utama |
| RFQ | Request for Quotation — permintaan penawaran dari buyer |
| Quotation | Penawaran supplier terhadap RFQ |
| PO | Purchase Order — dokumen pembelian berdiri sendiri, bukan otomatis dari accept |
| Verification | Proses review dokumen legal bisnis oleh moderator |
| Snapshot | Salinan data finansial yang tak boleh berubah setelah accept |

## 4. Features

### 4.1 FR-1 — Identity & Authentication
Registrasi user, verifikasi email, login/logout, lupa & reset password, session management (cookie Sanctum). NFR: rate limiting login, password hash bcrypt/argon2, email verifikasi wajib sebelum organisasi tayang.

### 4.2 FR-2 — Organization & Onboarding
Buat/edit organisasi, profil bisnis (kategori, alamat, kontak, logo), pilih tipe akun, kirim dokumen verifikasi, status onboarding completion, anggota: invite/accept/remove, ganti peran.

### 4.3 FR-3 — RBAC
11 peran dari spec: Super Admin, Moderator, Organization Owner, Organization Admin, Business Manager, Procurement Manager, Purchasing Staff, Sales Manager, Sales Staff, Finance Staff, Member. Backend policy-based authorization (Laravel Policies), anti privilege-escalation, proteksi organisasi-switching.

### 4.4 FR-4 — Business Directory (publik)
Homepage publik, directory bisnis, halaman profil perusahaan (URL kanonik & SEO), directory supplier, kategori bisnis (10 kategori awal dari spec), filter lokasi/kategori/verifikasi, search + autocomplete, business connections, follow perusahaan, inquiry publik. Geografis awal: Salatiga, Semarang, Solo.

### 4.5 FR-5 — Marketplace Catalog
Produk & jasa per organisasi: CRUD listing, kategori produk, gambar, SKU, variasi, satuan, MOQ, visibilitas harga, stok, storefront, search publik, inquiry produk. Tanpa checkout di MVP.

### 4.6 FR-6 — Procurement RFQ Engine
Buyer: buat RFQ + items (qty, unit, spesifikasi), lokasi & deadline kirim, deadline penawaran, publish/invite, bandingkan quotation, accept/reject, buat PO.
Supplier: discover RFQ eligible, terima invitation, submit/update/withdraw quotation (item, unit price, delivery cost, lead time, validitas).
State machine (dari spec): RFQ `draft, published, closed, cancelled, awarded`; Quotation `draft, submitted, revised, accepted, rejected, withdrawn, expired`; PO `draft, pending_approval, approved, issued, acknowledged, completed, cancelled`. Accept quotation ≠ transaksi selesai; PO lifecycle terpisah. Snapshot immutable + audit log + idempotency.

### 4.7 FR-7 — Messaging & Notifications (MVP ringan)
Conversasi buyer-supplier per konteks, pesan teks, status terbaca, hitungan unread, notifikasi in-app (email realtime via Reverb didefer). Channel private authorization ketat.

### 4.8 FR-8 — Verification & Admin Moderation
Antrean verifikasi dengan workflow 5 status, review dokumen privat, alasan penolakan, resubmission/appeal, suspension & reinstatement, audit log semua aksi moderasi, mencegah self-approval, kategori & moderasi produk/RFQ.

### 4.9 FR-9 — Growth & Analytics (ringan)
SEO: metadata dinamis, sitemap, robots, canonical, structured data profil & produk. Metrik terukur (tanpa fake metrics): organisasi terdaftar/terverifikasi, RFQ volume, response rate, dsb. Referral + Founding Partner ditandai untuk fase lanjut.

## 5. Non-Goals (Explicit)

- Checkout/pembayaran marketplace (Phase 09+).
- Subscription & billing infrastructure.
- Realtime websocket (Reverb) di MVP — polling + notifikasi in-app; antarmuka disiapkan.
- Meilisearch infra — search service abstraction dulu.
- Aplikasi mobile native; multi-bahasa penuh EN.
- AI features apa pun.

## 6. MVP Scope

### 6.1 In Scope
FR-1 s/d FR-8 penuh; FR-9 ringan (SEO + metrik dasar). Fase implementasi: Foundation → Database → Auth → Directory → Catalog → RFQ (Messaging & Admin menyusul).

### 6.2 Out of Scope for MVP
Lihat Non-Goals; plus: komisi transaksi, featured listings berbayar, blog CMS.

## 7. Success Metrics

- 100 organisasi aktif dalam 6 bulan (dari spec sumber).
- RFQ: ≥ 50 RFQ/bulan pada bulan ke-4; response rate ≥ 40%.
- Directory: ≥ 500 halaman profil terindeks Google.
- NFR pass: isolasi tenant teruji (cross-tenant test hijau), RBAC test hijau.

## 8. Open Questions

1. Payment provider (Midtrans/Xendit) — diputuskan saat Phase 09.
2. Domain produksi email (SES vs SMTP lokal) — saat deployment.

## 9. Assumptions Index

- [A1] MariaDB lokal sebagai dev DB, migrasi portabel ke PostgreSQL produksi.
- [A2] Bahasa UI Indonesia; kode & komentar Inggris.
- [A3] Upload file lokal (storage/app) dulu; S3-compatible saat produksi.
- [A4] Frontend Next.js separate repo-folder (monorepo), API Laravel di `backend/`.
- [A5] 10 kategori & lokasi awal sebagai seeder, bukan hardcoded UI.

## Cross-cutting NFR

| ID | Persyaratan |
|---|---|
| NFR-1 | Multi-tenant isolation: semua query org-scoped; cross-tenant test wajib |
| NFR-2 | RBAC policy di backend; frontend tidak pernah jadi gate utama |
| NFR-3 | UUID primary key entitas bisnis; timestamp & soft delete sesuai konteks |
| NFR-4 | Uang = decimal(18,2) + currency char(3); tidak pernah float |
| NFR-5 | Semua endpoint koleksi terpaginasi; error handling terstruktur |
| NFR-6 | Idempotency operasi kritis; transaksi DB untuk multi-write |
| NFR-7 | Audit log untuk aksi moderasi & finansial |
| NFR-8 | Responsive mobile-first; state loading/empty/error di semua halaman |
| NFR-9 | Rate limiting auth & submission; validasi input server-side |
| NFR-10 | Tests: unit + feature (API) + RBAC + cross-tenant |
