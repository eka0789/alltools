---
name: 'JAWARA Architecture Spine'
type: architecture-spine
purpose: build-substrate
altitude: initiative
paradigm: 'Modular Monolith dengan Domain Modules (Laravel) + App Router Feature Slices (Next.js)'
scope: 'JAWARA MVP: backend/, frontend/, infrastructure/, docs/'
status: final
created: 2026-11-21
updated: 2026-11-21
binds: [FR-1, FR-2, FR-3, FR-4, FR-5, FR-6, FR-7, FR-8, FR-9]
sources:
  - docs/spec-source/JAWARA-Master-Engineering-Instructions.md
  - _bmad-output/planning-artifacts/prds/prd-jawara-2026-11-21/prd.md
companions: []
---

# Architecture Spine — JAWARA

## Design Paradigm

**Modular Monolith, DDD pragmatis.** Backend Laravel dipartisi domain module di `backend/app/Domain/{Domain}` dengan Actions/Services (logika bisnis di luar controller), HTTP layer tipis (`app/Http/Controllers/Api/V1`), dan Policies (`app/Policies`) sebagai gate RBAC. Frontend Next.js App Router dengan feature slices per domain (`frontend/src/{app,components,lib,features}`), TanStack Query sebagai data-access layer, shadcn/ui sebagai design system. Keduanya komunikasi via REST `/api/v1` dengan kontrak terdokumentasi.

## Invariants & Rules

### AD-1 — Tenant isolation di layer aplikasi [ADOPTED]

- **Binds:** FR-2…FR-8, semua model ber-owner organisasi
- **Prevents:** cross-tenant data leak; query tanpa scope organisasi
- **Rule:** Setiap model ber-owner organisasi memakai trait `BelongsToOrganization`; akses via Policy yang selalu membandingkan `organization_id` dengan context organisasi aktif user. Query listing wajib lewat scope `forOrganization($orgId)`. Tidak ada endpoint yang menerima `organization_id` dari client untuk resource privat. RLS PostgreSQL hanya defense-in-depth opsional saat produksi (spec Phase 02); pada MariaDB, Policy Laravel adalah satu-satunya gate — cross-tenant test wajib hijau sebelum merge.

### AD-2 — UUID primary key entitas bisnis

- **Binds:** semua migrasi
- **Prevents:** integer auto-increment bocor sebagai enumerable ID publik
- **Rule:** `HasUuids` Laravel (char(36)). Tabel relasi dan lookup kecil boleh bigIncrements.

### AD-3 — Uang selalu decimal + currency

- **Binds:** FR-6, FR-5
- **Prevents:** float arithmetic pada harga; inkonsistensi total
- **Rule:** kolom `decimal(18,2)` + `currency char(3)` default `IDR`; total dihitung server-side; snapshot quotation/PO immutable setelah accept/issue.

### AD-4 — State machine eksplisit procurement

- **Binds:** FR-6
- **Prevents:** transisi status liar; accept = completed transaction
- **Rule:** Transisi valid dijadikan konstanta class + method guarded (mis. `RfqStatus`): RFQ `draft→published→closed|cancelled|awarded`; Quotation `draft→submitted→revised→accepted|rejected|withdrawn|expired`; PO `draft→pending_approval→approved→issued→acknowledged→completed|cancelled`. Transisi di luar grafik ditolak (exception). Mutasi berstatus di dalam DB transaction.

### AD-5 — API contract tunggal, versioned

- **Binds:** frontend ↔ backend
- **Prevents:** drift kontrak; breaking change diam-diam
- **Rule:** Semua endpoint di `/api/v1/*`, response JSON terstruktur `{ data | message | errors }`, paginasi `{ data, meta }`. Kontrak didokumentasikan di `docs/API_CONTRACT.md`. Frontend TIDAK boleh memanggil endpoint di luar kontrak; perubahan kontrak = update dokumen + versi.

### AD-6 — RBAC di backend, bukan UI

- **Binds:** FR-3, semua FR privat
- **Prevents:** privilege escalation via manipulasi UI/API
- **Rule:** Laravel Policies + middleware `auth:sanctum`; role di tabel `roles` (slug), permission via role-permission mapping; UI hanya menyembunyikan, bukan gate. Anti-escalation: penggantian peran hanya oleh Organization Owner/Admin dan tidak boleh memberi peran di atas perannya sendiri.

### AD-7 — Autentikasi Sanctum cookie

- **Binds:** FR-1
- **Prevents:** token di localStorage (XSS exposure); session lintas frontend ganda
- **Rule:** SPA authentication dengan Sanctum (cookie httpOnly, SameSite lax), CSRF cookie endpoint `/sanctum/csrf-cookie`. Cookie bersifat per-browser; CORS hanya whitelist frontend origin.

### AD-8 — Logika bisnis di Domain/Actions, bukan controller

- **Binds:** backend
- **Prevents:** fat controller, duplikasi business rule, test sulit
- **Rule:** Controller = validasi HTTP + delegasi ke Action/Service class + response. Aturan bisnis (eligibility supplier, transisi state, hitung total, notifikasi) hidup di `app/Domain/{Domain}/Actions`. Action dapat di-test unit tanpa HTTP.

### AD-9 — Frontend server-first dengan client islands

- **Binds:** FR-4, FR-9, FR-5
- **Prevents:** SPA penuh yang merusak SEO halaman publik; hydration berlebihan
- **Rule:** Halaman publik (directory, profil, produk) Server Components + metadata dinamis; interaksi privat (dashboard, form, RFQ) Client Components dengan TanStack Query. Semua state UI: loading/empty/error/success wajib ada.

### AD-10 — Search behind interface, storage behind disk abstraction

- **Binds:** FR-4, FR-5, FR-6, upload
- **Prevents:** vendor lock-in prematur
- **Rule:** `SearchService` interface di backend (implementasi DB LIKE/fulltext dulu; Meilisearch nanti), upload via Laravel Storage disk (local dulu, S3-compatible nanti). Konfigurasi via env, tanpa refactor domain.

### AD-11 — Keamanan upload & input

- **Binds:** FR-2, FR-5, FR-7, FR-8
- **Prevents:** upload berbahaya, XSS via file, path traversal
- **Rule:** Validasi mime+extension+size whitelist; nama file random; gambar dikonversi/limitasi ukuran; dokumen verifikasi disimpan di disk privat (bukan public). Semua input divalidasi FormRequest/`validate`.

### AD-12 — Audit & idempotency untuk operasi kritis

- **Binds:** FR-6, FR-8
- **Prevents:** duplikasi PO/quotation submit; aksi moderasi tanpa jejak
- **Rule:** `audit_logs` (actor, action, subject, before/after JSON) untuk moderasi & procurement kritis; idempotency key pada submit quotation & create PO; semua multi-write dalam `DB::transaction`.

## Consistency Conventions

| Concern | Convention |
| --- | --- |
| Naming (backend) | Model singular PascalCase, tabel plural snake_case, Action suffix `Action`, Policy `XPolicy`, FormRequest `StoreXRequest/UpdateXRequest` |
| Naming (frontend) | Komponen PascalCase, hook `useX`, api client `lib/api/`, halaman `app/(route)/` |
| Data & formats | ID UUID string; tanggal ISO-8601 UTC (frontend format lokal `id-ID`); uang decimal string + currency; error envelope `{ message, errors? }`; paginasi Laravel `lengthAware` |
| Status & enum | Status disimpan string snake_case; konstanta di class `*Status` (backend) / `lib/constants` (frontend); tidak ada magic string |
| State & cross-cutting | Context organisasi aktif via header `X-Organization-Id` + validasi keanggotaan; audit log via trait/event; config via env validated |
| Git & milestone | Monorepo; commit conventional (feat/fix/test/docs); milestone = fase BMAD; Engineering Gate dari spec dipertahankan |

## Stack

| Name | Version |
| --- | --- |
| PHP | 8.2 |
| Laravel | 12.x |
| MariaDB (dev) / PostgreSQL (prod target) | 10.4 / 16 |
| Redis | 3.0 (dev) |
| Node | 24 |
| Next.js | 15 |
| TypeScript | 5.x (strict) |
| Tailwind CSS | 4 |
| TanStack Query | 5 |
| Zod | 4 |
| Laravel Sanctum | 4 |

## Structural Seed

```text
jawara/
  backend/               # Laravel API (modular monolith)
    app/
      Domain/            # Business logic: Identity, Organization, Directory, Catalog, Procurement, Messaging, Moderation
      Http/Controllers/Api/V1
      Models/
      Policies/
    database/{migrations,seeders,factories}
    routes/api.php
    tests/{Feature,Unit}
  frontend/              # Next.js App Router
    src/{app,components,features,lib,types}
  infrastructure/        # docker-compose, nginx, deploy docs
  docs/                  # PRODUCT_REQUIREMENTS, ARCHITECTURE, DATABASE_SCHEMA, API_CONTRACT, SECURITY, ROADMAP, DEPLOYMENT, TESTING, DECISIONS
  scripts/               # helper scripts dev
```

Core entity diagram (referensi): `docs/spec-source/JAWARA-Reference-Schema.md` §4.

## Capability → Architecture Map

| Capability / Area | Lives in | Governed by |
| --- | --- | --- |
| FR-1 Auth | `Domain/Identity` + Sanctum | AD-7, AD-11, NFR-9 |
| FR-2 Org & onboarding | `Domain/Organization` | AD-1, AD-6 |
| FR-3 RBAC | `Policies` + `Domain/Identity/Roles` | AD-6 |
| FR-4 Directory | `Domain/Directory` + `frontend/src/app/(public)` | AD-9, AD-10 |
| FR-5 Catalog | `Domain/Catalog` | AD-3, AD-10, AD-11 |
| FR-6 RFQ Engine | `Domain/Procurement` | AD-3, AD-4, AD-12 |
| FR-7 Messaging | `Domain/Messaging` | AD-1, AD-11 |
| FR-8 Verification/Admin | `Domain/Moderation` | AD-12, AD-6 |
| FR-9 SEO/Analytics | `frontend/src/app` metadata + aggregated stats | AD-9 |

## Deferred

| Keputusan | Mengapa bisa menunggu |
| --- | --- |
| PostgreSQL + RLS + pgcrypto | produksi; migrasi tetap portabel (AD-1) |
| Docker Compose run lokal | Docker tidak tersedia; config tetap di-authored |
| Meilisearch implementasi | behind `SearchService` (AD-10) |
| Laravel Reverb realtime | FR-7 MVP polling; channel authorization desain sudah private |
| S3 storage | behind disk abstraction (AD-10) |
| Billing/subscription | Phase 09, setelah procurement core jalan (spec) |
