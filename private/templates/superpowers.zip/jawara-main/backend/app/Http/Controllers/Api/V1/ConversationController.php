<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Messaging\Actions\SendMessageAction;
use App\Domain\Messaging\Actions\StartConversationAction;
use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\ConversationParticipant;
use App\Models\Message;
use App\Models\MessageAttachment;
use App\Models\Notification;
use App\Models\Organization;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;

/**
 * Messaging endpoints (FR-7, MVP: in-app + notifications; websocket via
 * Reverb deferred per D-003). Channel authorization is enforced here:
 * the caller must be an active member of one of the two organizations and
 * a conversation participant (AD-1).
 */
class ConversationController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $conversations = Conversation::query()
            ->where('buyer_organization_id', $organization->id)
            ->orWhere('supplier_organization_id', $organization->id)
            ->with(['buyer:id,name,slug', 'supplier:id,name,slug'])
            ->orderByDesc('last_message_at')
            ->paginate(20);

        // H6 (audit fix): aggregate unread counts in ONE grouped join instead
        // of 2 queries per conversation (was N+1, ~401 queries @ 200 convs).
        $unreadCounts = Message::query()
            ->join('conversation_participants as cp', 'cp.conversation_id', '=', 'messages.conversation_id')
            ->where('cp.user_id', $request->user()->id)
            ->where('messages.sender_id', '!=', $request->user()->id)
            ->whereRaw('messages.created_at > COALESCE(cp.last_read_at, ?)', ['1970-01-01 00:00:00'])
            ->groupBy('messages.conversation_id')
            ->selectRaw('messages.conversation_id, COUNT(*) as unread')
            ->pluck('unread', 'conversation_id');

        return response()->json([
            'data' => collect($conversations->items())->map(fn ($c) => $this->present($c, $organization->id, $request->user()->id, (int) ($unreadCounts[$c->id] ?? 0))),
            'meta' => ['current_page' => $conversations->currentPage(), 'last_page' => $conversations->lastPage(), 'total' => $conversations->total()],
        ]);
    }

    public function show(Request $request, string $id): JsonResponse
    {
        $conversation = $this->authorizeConversation($request, $id);

        return response()->json(['data' => $this->present($conversation->load(['buyer:id,name,slug', 'supplier:id,name,slug']), $request->attributes->get('organization')->id, $request->user()->id)]);
    }

    public function store(Request $request, StartConversationAction $action): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $validated = $request->validate([
            'supplier_organization_id' => ['required', 'uuid', 'exists:organizations,id'],
        ]);

        $supplier = Organization::findOrFail($validated['supplier_organization_id']);

        try {
            $conversation = $action->execute($organization, $supplier, $request->user()->id);
        } catch (\DomainException $e) {
            throw ValidationException::withMessages(['conversation' => $e->getMessage()]);
        }

        return response()->json(['data' => $this->present($conversation, $organization->id, $request->user()->id)], 201);
    }

    public function messages(Request $request, string $id): JsonResponse
    {
        $conversation = $this->authorizeConversation($request, $id);

        $messages = $conversation->messages()
            ->with('sender:id,name', 'attachments')
            ->orderBy('created_at')
            ->paginate(50);

        return response()->json(['data' => $messages->items(), 'meta' => [
            'current_page' => $messages->currentPage(),
            'last_page' => $messages->lastPage(),
            'total' => $messages->total(),
        ]]);
    }

    /**
     * Audit UI/UX 2026-11-22: lampiran chat tersimpan di disk private tanpa
     * endpoint unduh — penerima tidak bisa membuka berkasnya. Hanya peserta
     * percakapan yang dapat mengunduh (AD-1), stream via Storage::download.
     */
    public function downloadAttachment(Request $request, string $id, string $attachmentId): Response
    {
        $conversation = $this->authorizeConversation($request, $id);

        $attachment = MessageAttachment::query()
            ->whereHas('message', fn ($q) => $q->where('conversation_id', $conversation->id))
            ->where('id', $attachmentId)
            ->firstOrFail();

        if (! Storage::disk('private')->exists($attachment->path)) {
            abort(404, 'Berkas lampiran tidak ditemukan.');
        }

        return Storage::disk('private')->download($attachment->path, $attachment->original_name);
    }

    public function send(Request $request, string $id, SendMessageAction $action): JsonResponse
    {
        $conversation = $this->authorizeConversation($request, $id);

        $validated = $request->validate([
            'body' => ['required', 'string', 'max:5000'],
            'attachment' => ['nullable', 'file', 'mimes:pdf,png,jpg,jpeg,webp,doc,docx,xls,xlsx', 'max:5120'], // AD-11
        ]);

        $attachment = null;
        if ($request->hasFile('attachment')) {
            $file = $request->file('attachment');
            $path = $file->store("chat-attachments/{$conversation->id}", 'private'); // AD-11
            $attachment = [
                'path' => $path,
                'original_name' => $file->getClientOriginalName(),
                'mime_type' => $file->getMimeType(),
                'size_bytes' => $file->getSize(),
            ];
        }

        try {
            $message = $action->execute($conversation, $request->user(), $validated['body'], $attachment);
        } catch (\DomainException $e) {
            throw ValidationException::withMessages(['message' => $e->getMessage()]);
        }

        return response()->json(['data' => $message, 'message' => 'Pesan terkirim.'], 201);
    }

    public function markRead(Request $request, string $id): JsonResponse
    {
        $this->authorizeConversation($request, $id);

        ConversationParticipant::where('conversation_id', $id)
            ->where('user_id', $request->user()->id)
            ->update(['last_read_at' => now()]);

        // Clear message notifications for this conversation.
        Notification::where('user_id', $request->user()->id)
            ->where('type', 'message.received')
            ->where('conversation_id', $id) // M12 (audit): indexed column, not JSON predicate
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        return response()->json(['message' => 'Ditandai terbaca.']);
    }

    private function authorizeConversation(Request $request, string $id): Conversation
    {
        $organization = $request->attributes->get('organization');

        $conversation = Conversation::where('id', $id)
            ->where(function ($q) use ($organization) {
                $q->where('buyer_organization_id', $organization->id)
                    ->orWhere('supplier_organization_id', $organization->id);
            })
            ->firstOrFail();

        $isParticipant = ConversationParticipant::where('conversation_id', $conversation->id)
            ->where('user_id', $request->user()->id)
            ->exists();

        if (! $isParticipant) {
            abort(403, 'Anda bukan peserta percakapan ini.');
        }

        return $conversation;
    }

    /** @return array<string, mixed> */
    private function present(Conversation $c, string $orgId, string $userId, ?int $unreadCount = null): array
    {
        $isBuyerSide = $c->buyer_organization_id === $orgId;
        $counterpart = $isBuyerSide ? $c->supplier : $c->buyer;

        return [
            'id' => $c->id,
            'counterpart' => $counterpart ? ['id' => $counterpart->id, 'name' => $counterpart->name, 'slug' => $counterpart->slug] : null,
            'side' => $isBuyerSide ? 'buyer' : 'supplier',
            'last_message_at' => $c->last_message_at?->toIso8601String(),
            'unread_count' => $unreadCount ?? 0,
        ];
    }
}
