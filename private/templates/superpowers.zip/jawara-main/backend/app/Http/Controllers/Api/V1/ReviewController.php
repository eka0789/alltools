<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\BusinessProfile;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/**
 * Tier 1: business reviews & ratings (FR trust — spec product principle
 * "trust and verification before marketplace growth"). One review per user
 * per business profile; only published profiles are reviewable.
 */
class ReviewController extends Controller
{
    public function index(Request $request, string $slug): JsonResponse
    {
        $profile = $this->publishedProfile($slug);

        $reviews = $profile->reviews()->with('author:id,name')
            ->latest()
            ->paginate(10);

        return response()->json([
            'data' => collect($reviews->items())->map(fn ($r) => [
                'id' => $r->id,
                'rating' => $r->rating,
                'comment' => $r->comment,
                'author_name' => $r->author?->name ?? 'Pengguna JAWARA',
                'created_at' => $r->created_at->toIso8601String(),
            ]),
            'meta' => [
                'current_page' => $reviews->currentPage(),
                'last_page' => $reviews->lastPage(),
                'total' => $reviews->total(),
                'rating_avg' => (float) ($profile->reviews()->avg('rating') ?? 0),
            ],
        ]);
    }

    public function store(Request $request, string $slug): JsonResponse
    {
        $profile = $this->publishedProfile($slug);

        $validated = $request->validate([
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
            'comment' => ['required', 'string', 'min:10', 'max:1000'],
        ]);

        if ($profile->organization_id === ($request->user()->memberships()->where('status', 'active')->first()?->organization_id)) {
            throw ValidationException::withMessages(['rating' => 'Tidak dapat mereview bisnis sendiri.']);
        }

        // One review per user per profile — resubmitting updates it.
        $review = $profile->reviews()->updateOrCreate(
            ['author_user_id' => $request->user()->id],
            ['rating' => $validated['rating'], 'comment' => $validated['comment']],
        );

        return response()->json([
            'data' => ['id' => $review->id, 'rating' => $review->rating],
            'message' => 'Review tersimpan.',
        ], 201);
    }

    public function destroy(Request $request, string $slug): JsonResponse
    {
        $profile = $this->publishedProfile($slug);

        $deleted = $profile->reviews()->where('author_user_id', $request->user()->id)->delete();

        if (! $deleted) {
            throw ValidationException::withMessages(['review' => 'Anda belum menulis review untuk bisnis ini.']);
        }

        return response()->json(['message' => 'Review dihapus.']);
    }

    private function publishedProfile(string $slug): BusinessProfile
    {
        return BusinessProfile::query()->published()->where('slug', $slug)->firstOrFail();
    }
}
