<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Billing\Actions\ConfirmPaymentAction;
use App\Domain\Billing\Contracts\PaymentProvider;
use App\Domain\Billing\Providers\ManualPaymentProvider;
use App\Http\Controllers\Controller;
use App\Models\SubscriptionInvoice;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

/**
 * Payment provider webhook (Phase 09). Signature verified BEFORE any state
 * change (spec: "Verify provider signatures", "Implement idempotent webhook
 * processing", "Store payment references"). Duplicate events are no-ops.
 */
class PaymentWebhookController extends Controller
{
    public function __invoke(Request $request, ConfirmPaymentAction $action): JsonResponse
    {
        /** @var PaymentProvider $provider */
        $provider = app()->bound(PaymentProvider::class) ? app(PaymentProvider::class) : new ManualPaymentProvider;

        $signature = $request->header($this->signatureHeader($provider->key()));

        if (! $provider->verifyWebhook($request->getContent(), $signature)) {
            Log::warning('payment.webhook_signature_invalid', ['provider' => $provider->key()]);

            return response()->json(['message' => 'Invalid signature.'], 401);
        }

        $payload = $request->json();

        $invoiceNumber = $payload->input('invoice_number')
            ?? $payload->input('external_id')
            ?? null;

        if (! $invoiceNumber) {
            return response()->json(['message' => 'invoice_number missing.'], 422);
        }

        $invoice = SubscriptionInvoice::where('number', $invoiceNumber)->first();

        if (! $invoice) {
            return response()->json(['message' => 'Invoice not found.'], 404);
        }

        // Idempotency: already paid → acknowledge without side effects.
        if ($invoice->status === 'paid') {
            return response()->json(['message' => 'Already processed.']);
        }

        // H2 (audit): NEVER write provider-controlled status strings directly.
        // Whitelist + normalize; anything unknown is rejected for inspection.
        $mapped = match ((string) $payload->input('status')) {
            'PAID' => 'paid',
            'FAILED' => 'failed',
            'EXPIRED' => 'expired',
            default => null,
        };

        if ($mapped === null) {
            Log::warning('payment.webhook_unknown_status', ['status' => $payload->input('status')]);

            return response()->json(['message' => 'Unknown status.'], 422);
        }

        if ($mapped !== 'paid') {
            if ($invoice->status === 'pending') {
                $invoice->update(['status' => $mapped]);
            }

            return response()->json(['message' => 'Status updated.']);
        }

        // Webhooks have no browser actor: attribute to the first platform admin.
        // Re-audit fix: a missing admin is a permanent condition — returning
        // 500 caused provider retry storms. The action tolerates a null actor
        // (audit_logs.actor_user_id is nullable) and logs loudly instead.
        $systemActor = User::whereHas('memberships.role', fn ($q) => $q->where('slug', 'super-admin')->where('scope', 'platform'))->first();

        if (! $systemActor) {
            Log::error('payment.webhook_no_system_actor', ['invoice' => $invoice->number]);
        }

        $action->execute($invoice, $systemActor, 'webhook:'.$provider->key());

        return response()->json(['message' => 'Payment processed.']);
    }

    private function signatureHeader(string $providerKey): string
    {
        return match ($providerKey) {
            'xendit' => 'X-Callback-Token',
            'midtrans' => 'X-Signature',
            default => 'X-Webhook-Signature',
        };
    }
}
