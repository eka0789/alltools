<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Billing\Actions\CancelSubscriptionAction;
use App\Domain\Billing\Actions\ConfirmPaymentAction;
use App\Domain\Billing\Actions\SubscribeOrganizationAction;
use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\SubscriptionInvoice;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/** Subscription & billing endpoints (Phase 09). Provider-abstracted (D-004). */
class BillingController extends Controller
{
    public function plans(): JsonResponse
    {
        $plans = Plan::where('is_active', true)->with('features:plan_id,feature_key,limit_value')->get();

        return response()->json(['data' => $plans->map(fn ($p) => [
            'id' => $p->id,
            'name' => $p->name,
            'slug' => $p->slug,
            'monthly_price' => $p->monthly_price,
            'currency' => $p->currency,
            'features' => $p->features->map(fn ($f) => ['key' => $f->feature_key, 'limit' => $f->limit_value]),
        ])]);
    }

    public function current(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $subscription = Subscription::with('plan')->where('organization_id', $organization->id)->first();
        $invoices = $subscription
            ? SubscriptionInvoice::where('subscription_id', $subscription->id)->latest()->get()
            : collect();

        return response()->json(['data' => [
            'subscription' => $subscription,
            'invoices' => $invoices->map(fn ($i) => [
                'id' => $i->id,
                'number' => $i->number,
                'amount' => $i->amount,
                'currency' => $i->currency,
                'status' => $i->status,
                'provider' => $i->provider,
                'provider_ref' => $i->provider_ref,
                'paid_at' => $i->paid_at?->toIso8601String(),
                'expires_at' => $i->expires_at?->toIso8601String(),
            ]),
        ]]);
    }

    public function subscribe(Request $request, SubscribeOrganizationAction $action): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $validated = $request->validate(['plan_slug' => ['required', 'string', 'exists:plans,slug']]);

        $plan = Plan::where('slug', $validated['plan_slug'])->where('is_active', true)->firstOrFail();

        $result = $action->execute($organization, $plan, $request->user());

        return response()->json([
            'data' => ['subscription' => $result['subscription'], 'invoice' => $result['invoice']],
            'instructions' => $result['instructions'],
            'message' => 'Langganan diproses.',
        ], 201);
    }

    public function cancel(Request $request, CancelSubscriptionAction $action): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $subscription = $action->execute($organization, $request->user());

        return response()->json(['data' => $subscription, 'message' => 'Langganan dibatalkan.']);
    }

    public function confirmInvoice(Request $request, string $invoiceId, ConfirmPaymentAction $action): JsonResponse
    {
        $membership = $request->attributes->get('membership');

        if ($membership->role->scope !== 'platform') {
            throw ValidationException::withMessages(['invoice' => 'Hanya admin platform.']);
        }

        $invoice = SubscriptionInvoice::findOrFail($invoiceId);

        try {
            $invoice = $action->execute($invoice, $request->user(), 'admin:'.$request->user()->id);
        } catch (\DomainException $e) {
            throw ValidationException::withMessages(['invoice' => $e->getMessage()]);
        }

        return response()->json(['data' => $invoice, 'message' => 'Pembayaran dikonfirmasi.']);
    }
}
