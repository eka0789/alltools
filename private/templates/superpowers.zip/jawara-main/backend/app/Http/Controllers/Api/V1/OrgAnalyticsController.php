<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\BusinessFollow;
use App\Models\BusinessProfile;
use App\Models\ProfileView;
use App\Models\Quotation;
use App\Models\Rfq;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Tier 3: organization-level analytics (spec Phase 10 — "JAWARA can measure
 * its network growth, procurement engagement"). Org-scoped (AD-1); counts
 * only, no personally identifiable viewer data (privacy principle).
 */
class OrgAnalyticsController extends Controller
{
    public function stats(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $profile = BusinessProfile::forOrganization($organization)->first();

        $views30d = $profile
            ? ProfileView::where('organization_id', $organization->id)->where('view_date', '>=', now()->subDays(30))->count()
            : 0;
        $viewsTotal = $profile ? ProfileView::where('organization_id', $organization->id)->count() : 0;

        $followers = BusinessFollow::where('organization_id', $organization->id)->count();

        $rfqStats = Rfq::forOrganization($organization->id)
            ->selectRaw("COUNT(*) as total, SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published, SUM(CASE WHEN status = 'awarded' THEN 1 ELSE 0 END) as awarded")
            ->first();

        // Quotation response rate on this org's RFQs (JTJ-2 metric).
        $publishedRfqs = (int) ($rfqStats->published ?? 0);
        $rfqsWithQuotations = Rfq::forOrganization($organization->id)
            ->where('status', 'published')
            ->has('quotations')
            ->count();
        $responseRate = $publishedRfqs > 0 ? round($rfqsWithQuotations / $publishedRfqs * 100, 1) : null;

        return response()->json(['data' => [
            'profile_views_30d' => $views30d,
            'profile_views_total' => $viewsTotal,
            'followers' => $followers,
            'rfq_total' => (int) ($rfqStats->total ?? 0),
            'rfq_published' => $publishedRfqs,
            'rfq_awarded' => (int) ($rfqStats->awarded ?? 0),
            'quotation_response_rate' => $responseRate,
            'completeness' => $profile?->completenessPercentage() ?? 0,
        ]]);
    }
}
