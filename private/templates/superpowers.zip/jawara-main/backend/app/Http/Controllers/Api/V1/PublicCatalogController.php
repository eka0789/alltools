<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Shared\Contracts\SearchService;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductInquiry;
use App\Models\Service;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Public catalog (FR-5): product/service search, storefronts, inquiries.
 * Only published listings are exposed; private pricing is protected (AD-3):
 * members_only price is never returned without org context, on_request hides
 * the amount but exposes negotiability.
 */
class PublicCatalogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'q' => ['nullable', 'string', 'max:120'],
            'category' => ['nullable', 'string', 'max:140'],
            'page' => ['nullable', 'integer', 'min:1'],
        ]);

        $query = Product::query()
            ->published()
            ->with(['category:id,name,slug', 'organization:id,name,slug'])
            ->select(['id', 'organization_id', 'category_id', 'name', 'slug', 'description', 'unit_of_measure', 'min_order_quantity', 'price', 'price_visibility', 'currency', 'featured_until']);

        if (! empty($validated['q'])) {
            // AD-10 (H7 audit fix): search behind SearchService interface.
            app(SearchService::class)
                ->apply($query, ['name', 'description'], $validated['q']);
        }

        if (! empty($validated['category'])) {
            $query->whereHas('category', fn ($q) => $q->where('slug', $validated['category']));
        }

        // Tier 2: featured products surface first (revenue stream #2).
        $products = $query->orderByRaw('featured_until IS NULL, featured_until DESC')
            ->orderBy('name')
            ->paginate(12)
            ->withQueryString();

        return response()->json([
            'data' => collect($products->items())->map(fn ($p) => $this->present($p)),
            'meta' => ['current_page' => $products->currentPage(), 'last_page' => $products->lastPage(), 'total' => $products->total()],
        ]);
    }

    public function show(string $slug): JsonResponse
    {
        $product = Product::query()->published()
            ->with(['category:id,name,slug', 'organization:id,name,slug', 'images', 'variants'])
            ->where('slug', $slug)
            ->firstOrFail();

        return response()->json(['data' => $this->present($product, full: true)]);
    }

    public function storefront(string $orgSlug): JsonResponse
    {
        $products = Product::query()->published()
            ->whereHas('organization', fn ($q) => $q->where('slug', $orgSlug))
            ->with('category:id,name,slug')
            ->orderBy('name')
            ->paginate(12);

        $services = Service::query()->published()
            ->whereHas('organization', fn ($q) => $q->where('slug', $orgSlug))
            ->orderBy('name')
            ->limit(12)
            ->get(['id', 'name', 'slug', 'description', 'starting_price', 'price_visibility', 'currency']);

        return response()->json(['data' => ['products' => collect($products->items())->map(fn ($p) => $this->present($p)), 'services' => $services->map(fn ($s) => $this->presentService($s))]]);
    }

    public function submitInquiry(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'product_id' => ['nullable', 'uuid', 'exists:products,id'],
            'service_id' => ['nullable', 'uuid', 'exists:services,id'],
            'sender_name' => ['required', 'string', 'max:120'],
            'sender_email' => ['required', 'email', 'max:255'],
            'sender_phone' => ['nullable', 'string', 'max:30'],
            'message' => ['required', 'string', 'max:2000'],
        ]);

        if (empty($validated['product_id']) && empty($validated['service_id'])) {
            return response()->json(['message' => 'Inquiry harus merujuk produk atau jasa.'], 422);
        }

        $orgId = $validated['product_id']
            ? Product::findOrFail($validated['product_id'])->organization_id
            : Service::findOrFail($validated['service_id'])->organization_id;

        $inquiry = ProductInquiry::create([
            'organization_id' => $orgId,
            'product_id' => $validated['product_id'] ?? null,
            'service_id' => $validated['service_id'] ?? null,
            'sender_user_id' => $request->user()?->id,
            'sender_name' => $validated['sender_name'],
            'sender_email' => $validated['sender_email'],
            'sender_phone' => $validated['sender_phone'] ?? null,
            'message' => $validated['message'],
        ]);

        return response()->json(['data' => ['id' => $inquiry->id], 'message' => 'Inquiry terkirim.'], 201);
    }

    /** @return array<string, mixed> */
    private function present(Product $product, bool $full = false): array
    {
        $base = [
            'id' => $product->id,
            'slug' => $product->slug,
            'name' => $product->name,
            'description' => $full ? $product->description : str($product->description)->limit(140),
            'unit_of_measure' => $product->unit_of_measure,
            'min_order_quantity' => $product->min_order_quantity,
            'price_visibility' => $product->price_visibility,
            'currency' => $product->currency,
            'featured' => $product->featured_until && $product->featured_until->isFuture(),
            'category' => $product->category?->name,
            'organization' => $product->organization ? ['name' => $product->organization->name, 'slug' => $product->organization->slug] : null,
        ];

        // AD-3: private pricing protection.
        $base['price'] = $product->price_visibility === 'public' ? $product->price : null;

        if ($full) {
            $base['variants'] = $product->variants->map(fn ($v) => [
                'id' => $v->id, 'name' => $v->name, 'sku' => $v->sku,
                'price' => $product->price_visibility === 'public' ? bcadd((string) $product->price, (string) $v->price_delta, 2) : null,
            ]);
            $base['images'] = $product->images->map(fn ($i) => ['path' => $i->path, 'is_primary' => $i->is_primary]);
        }

        return $base;
    }

    /** @return array<string, mixed> */
    private function presentService(Service $service): array
    {
        return [
            'id' => $service->id,
            'slug' => $service->slug,
            'name' => $service->name,
            'description' => str($service->description)->limit(140),
            'service_area' => $service->service_area,
            'starting_price' => $service->price_visibility === 'public' ? $service->starting_price : null,
            'price_visibility' => $service->price_visibility,
            'currency' => $service->currency,
        ];
    }
}
