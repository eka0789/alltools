<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Identity\RoleRank;
use App\Domain\Procurement\Actions\SubmitQuotationAction;
use App\Enums\QuotationStatus;
use App\Enums\RfqStatus;
use App\Http\Controllers\Controller;
use App\Models\Quotation;
use App\Models\Rfq;
use App\Models\RfqInvitation;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/**
 * Supplier-side quotation endpoints (FR-6). Suppliers see only RFQs that are
 * published or invited; quotations are scoped to the supplier organization (AD-1).
 */
class QuotationController extends Controller
{
    public function openRfqs(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $invitedRfqIds = RfqInvitation::where('supplier_organization_id', $organization->id)->pluck('rfq_id');

        $rfqs = Rfq::query()
            ->where('status', RfqStatus::Published)
            ->where('buyer_organization_id', '!=', $organization->id)
            ->where(function ($q) use ($invitedRfqIds) {
                $q->whereDoesntHave('invitations')->orWhereIn('id', $invitedRfqIds);
            })
            ->with('buyer:id,name', 'items')
            ->orderBy('quotation_deadline_at')
            ->paginate(15);

        return response()->json(['data' => $rfqs->items(), 'meta' => [
            'current_page' => $rfqs->currentPage(),
            'last_page' => $rfqs->lastPage(),
            'total' => $rfqs->total(),
        ]]);
    }

    public function index(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $quotations = Quotation::forOrganization($organization)
            ->with('rfq:id,title,status,quotation_deadline_at,buyer_organization_id')
            ->latest()
            ->paginate(15);

        return response()->json(['data' => $quotations->items(), 'meta' => [
            'current_page' => $quotations->currentPage(),
            'last_page' => $quotations->lastPage(),
            'total' => $quotations->total(),
        ]]);
    }

    public function show(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $quotation = Quotation::forOrganization($organization)->with('items', 'rfq')->findOrFail($id);

        return response()->json(['data' => $quotation]);
    }

    public function submit(Request $request, string $rfqId, SubmitQuotationAction $action): JsonResponse
    {
        $this->authorizeSales($request);
        $organization = $request->attributes->get('organization');

        $rfq = Rfq::published()->findOrFail($rfqId);

        // Supplier eligibility (spec Phase 06): invited OR open published RFQ.
        $invited = RfqInvitation::where('rfq_id', $rfq->id)
            ->where('supplier_organization_id', $organization->id)
            ->exists();

        $openCall = ! RfqInvitation::where('rfq_id', $rfq->id)->exists();

        if (! $invited && ! $openCall) {
            throw ValidationException::withMessages(['rfq' => 'Anda tidak diundang pada RFQ ini.']);
        }

        $validated = $request->validate([
            'items' => ['required', 'array', 'min:1'],
            'items.*.rfq_item_id' => ['required', 'uuid', 'distinct'],
            'items.*.unit_price' => ['required', 'numeric', 'min:0'],
            'items.*.description' => ['nullable', 'string', 'max:255'],
            'delivery_cost' => ['nullable', 'numeric', 'min:0'],
            'lead_time_days' => ['nullable', 'integer', 'min:0', 'max:365'],
            'valid_until' => ['nullable', 'date', 'after:now'],
            'terms' => ['nullable', 'string', 'max:2000'],
            'idempotency_key' => ['nullable', 'string', 'max:64'],
        ]);

        $quotation = $action->execute(
            $rfq,
            $organization->id,
            $request->user(),
            $validated['items'],
            (string) ($validated['delivery_cost'] ?? '0'),
            $validated['lead_time_days'] ?? null,
            $validated['valid_until'] ?? null,
            $validated['terms'] ?? null,
            $validated['idempotency_key'] ?? null,
        );

        return response()->json(['data' => $quotation->load('items'), 'message' => 'Penawaran terkirim.'], 201);
    }

    public function withdraw(Request $request, string $id): JsonResponse
    {
        $this->authorizeSales($request);
        $organization = $request->attributes->get('organization');

        $quotation = Quotation::forOrganization($organization)->findOrFail($id);

        if (! $quotation->status->canTransitionTo(QuotationStatus::Withdrawn)) {
            throw ValidationException::withMessages(['status' => "Penawaran tidak dapat ditarik dari status {$quotation->status->value}."]);
        }

        $quotation->update(['status' => QuotationStatus::Withdrawn]);

        return response()->json(['data' => $quotation, 'message' => 'Penawaran ditarik.']);
    }

    /** Re-audit: financially binding supplier mutations require rank >= staff. */
    private function authorizeSales(Request $request): void
    {
        $membership = $request->attributes->get('membership');

        if (RoleRank::rankOf($membership) < RoleRank::PROCUREMENT_MIN) {
            abort(403, 'Peran Anda tidak memiliki akses penjualan.');
        }
    }
}
