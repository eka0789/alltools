<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\AI\Actions\AnswerAssistantAction;
use App\Domain\AI\Actions\CompareQuotationsAction;
use App\Domain\AI\Actions\GenerateProductDescriptionAction;
use App\Domain\AI\Actions\GenerateRfqDraftAction;
use App\Domain\AI\Contracts\AiProvider;
use App\Domain\AI\Exceptions\AiInvalidOutputException;
use App\Domain\AI\Exceptions\AiQuotaExceededException;
use App\Domain\AI\Exceptions\AiUnavailableException;
use App\Domain\AI\Services\AiQuotaService;
use App\Domain\Identity\RoleRank;
use App\Http\Controllers\Controller;
use App\Models\Rfq;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Tier 5 (JAWARA Pintar): AI endpoints. Everything runs behind the
 * AiProvider abstraction with daily per-organization quotas (AiQuotaService).
 * Actions never write business data — AI output is always a draft the user
 * confirms through the regular endpoints.
 */
class AiController extends Controller
{
    public function __construct(private readonly AiQuotaService $quota) {}

    /** Feature flags + remaining quota so the frontend can hide AI affordances when off. */
    public function capabilities(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $features = [];
        foreach (AiQuotaService::FEATURES as $feature) {
            $enabled = $this->quota->featureEnabled($organization, $feature);
            $features[$feature] = [
                'enabled' => $enabled,
                'remaining_today' => $enabled ? $this->quota->remainingToday($organization, $feature) : 0,
                'daily_limit' => $this->quota->dailyQuota($organization, $feature),
            ];
        }

        return response()->json(['data' => [
            'enabled' => AiQuotaService::providerEnabled(),
            'provider' => app(AiProvider::class)->key(),
            'features' => $features,
        ]]);
    }

    public function rfqDraft(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $this->authorizeProcurement($request);

        $validated = $request->validate([
            'description' => ['required', 'string', 'max:2000'],
        ]);

        return $this->serve(function () use ($organization, $request, $validated) {
            return ['draft' => app(GenerateRfqDraftAction::class)
                ->execute($organization, $request->user(), $validated['description'])];
        });
    }

    public function productDescription(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'category' => ['nullable', 'string', 'max:120'],
            'keywords' => ['nullable', 'array', 'max:8'],
            'keywords.*' => ['string', 'max:60'],
        ]);

        return $this->serve(function () use ($organization, $request, $validated) {
            return app(GenerateProductDescriptionAction::class)->execute(
                $organization,
                $request->user(),
                $validated['name'],
                $validated['category'] ?? null,
                $validated['keywords'] ?? [],
            );
        });
    }

    public function assistantChat(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $validated = $request->validate([
            'message' => ['required', 'string', 'max:2000'],
            'history' => ['nullable', 'array', 'max:10'],
            'history.*.role' => ['required', 'in:user,assistant'],
            'history.*.content' => ['required', 'string', 'max:2000'],
        ]);

        return $this->serve(function () use ($organization, $request, $validated) {
            return app(AnswerAssistantAction::class)
                ->execute($organization, $request->user(), $validated['history'] ?? [], $validated['message']);
        });
    }

    public function quotationInsights(Request $request, string $rfqId): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $this->authorizeProcurement($request);

        // AD-1: analysis is only served for the context organization's own
        // RFQ — another org's RFQ resolves to 404.
        $rfq = Rfq::forOrganization($organization)->findOrFail($rfqId);

        return $this->serve(function () use ($organization, $request, $rfq) {
            return app(CompareQuotationsAction::class)
                ->execute($organization, $request->user(), $rfq);
        });
    }

    /** Shared exception → HTTP mapping for AI failures (fail-closed, Indonesian messages). */
    private function serve(callable $work): JsonResponse
    {
        try {
            return response()->json(['data' => $work(), 'message' => 'Berhasil.']);
        } catch (AiQuotaExceededException $e) {
            return response()->json(['message' => $e->getMessage()], 429);
        } catch (AiInvalidOutputException|AiUnavailableException $e) {
            return response()->json(['message' => $e->getMessage()], 503);
        }
    }

    /** H1 (audit) pattern: procurement-facing AI needs rank >= purchasing-staff. */
    private function authorizeProcurement(Request $request): void
    {
        $membership = $request->attributes->get('membership');

        if (RoleRank::rankOf($membership) < RoleRank::PROCUREMENT_MIN) {
            abort(403, 'Peran Anda tidak memiliki akses pengadaan.');
        }
    }
}
