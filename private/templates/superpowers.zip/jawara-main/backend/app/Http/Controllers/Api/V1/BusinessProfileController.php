<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Directory\Actions\UpsertBusinessProfileAction;
use App\Enums\VerificationStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Directory\UpdateBusinessProfileRequest;
use App\Models\BusinessProfile;
use App\Models\BusinessVerification;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;

/**
 * Organization-side business profile management (FR-4/S4.3):
 * view/update profile, upload logo, submit verification documents.
 * All actions resolve the organization from request context (AD-1).
 */
class BusinessProfileController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $profile = BusinessProfile::with(['category:id,name,slug', 'location:id,name,slug,city'])
            ->forOrganization($organization)
            ->first();

        $latestVerification = $profile
            ? BusinessVerification::where('business_profile_id', $profile->id)
                ->latest()
                ->first(['status', 'notes', 'reviewed_at'])
            : null;

        // H14 (audit): surface the moderator's notes so rejected orgs know why.
        return response()->json(['data' => $profile, 'latest_verification' => $latestVerification]);
    }

    public function update(UpdateBusinessProfileRequest $request, UpsertBusinessProfileAction $action): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $membership = $request->attributes->get('membership');

        if (! in_array($membership->role->slug, ['organization-owner', 'organization-admin', 'business-manager'], true)) {
            // Audit 2026-11-24: ini penolakan OTORISASI, bukan validasi input —
            // 403 (sebelumnya ValidationException → amplop 422 yang menyesatkan).
            abort(403, 'Peran Anda tidak dapat mengelola profil bisnis.');
        }

        $profile = $action->execute($organization, $request->validated());

        return response()->json(['data' => $profile, 'message' => 'Profil bisnis diperbarui.']);
    }

    public function uploadLogo(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $membership = $request->attributes->get('membership');

        if (! in_array($membership->role->slug, ['organization-owner', 'organization-admin', 'business-manager'], true)) {
            abort(403, 'Peran Anda tidak dapat mengelola profil bisnis.');
        }

        $request->validate([
            'logo' => ['required', 'image', 'mimes:png,jpg,jpeg,webp', 'max:2048'], // AD-11 whitelist
        ]);

        $profile = BusinessProfile::forOrganization($organization)->firstOrFail();

        $path = $request->file('logo')->store("logos/{$organization->id}", 'public');
        $profile->update(['logo_path' => $path]);

        return response()->json(['data' => ['logo_path' => $path], 'message' => 'Logo diperbarui.']);
    }

    public function submitVerification(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $request->validate([
            'document_type' => ['required', 'string', 'max:60'],
            'document' => ['required', 'file', 'mimes:pdf,png,jpg,jpeg', 'max:5120'], // AD-11
        ]);

        $profile = BusinessProfile::forOrganization($organization)->firstOrFail();

        $status = $profile->verification_status;

        if ($status === VerificationStatus::Verified) {
            throw ValidationException::withMessages(['document' => 'Profil sudah terverifikasi.']);
        }

        if ($status === VerificationStatus::Pending || $status === VerificationStatus::UnderReview) {
            throw ValidationException::withMessages(['document' => 'Verifikasi sudah dalam proses.']);
        }

        // Documents are stored on the PRIVATE disk (AD-11) — never publicly accessible.
        $path = $request->file('document')->store("verification-docs/{$organization->id}", 'private');

        $verification = BusinessVerification::create([
            'organization_id' => $organization->id,
            'business_profile_id' => $profile->id,
            'submitted_by' => $request->user()->id,
            'status' => 'pending',
            'document_type' => $request->input('document_type'),
            'document_path' => $path,
        ]);

        $profile->update(['verification_status' => 'pending']);

        return response()->json(['data' => $verification, 'message' => 'Dokumen verifikasi dikirim.'], 201);
    }

    public function downloadVerificationDocument(Request $request, string $verificationId): Response
    {
        // Platform moderators only (AD-6). Returns a signed-ish streaming response.
        $membership = $request->attributes->get('membership');

        if ($membership->role->scope !== 'platform') {
            throw ValidationException::withMessages(['document' => 'Hanya moderator platform.']);
        }

        $verification = BusinessVerification::findOrFail($verificationId);

        return Storage::disk('private')->download($verification->document_path);
    }
}
