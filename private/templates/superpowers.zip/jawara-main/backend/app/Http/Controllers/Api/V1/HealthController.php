<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class HealthController extends Controller
{
    /**
     * GET /api/v1/health
     *
     * Reports application, database, and cache health plus queue state
     * (informational — pending/failed counts, not a hard gate). Used by
     * monitoring and deployment health checks (docs/DEPLOYMENT.md).
     */
    public function __invoke(): JsonResponse
    {
        $checks = [
            'app' => 'ok',
            'database' => $this->checkDatabase(),
            'cache' => $this->checkCache(),
        ];

        $healthy = ! in_array('fail', $checks, true);

        return response()->json([
            'status' => $healthy ? 'ok' : 'degraded',
            'checks' => $checks,
            'queue' => $this->queueState(),
            'time' => now()->toIso8601String(),
        ], $healthy ? 200 : 503);
    }

    private function checkDatabase(): string
    {
        try {
            DB::select('select 1');

            return 'ok';
        } catch (\Throwable) {
            return 'fail';
        }
    }

    private function checkCache(): string
    {
        try {
            cache()->put('health_probe', true, 5);

            return cache()->get('health_probe') === true ? 'ok' : 'fail';
        } catch (\Throwable) {
            return 'fail';
        }
    }

    /**
     * Queue visibility for monitoring: pending jobs + failed jobs. Never
     * fails the health check by itself — a non-empty backlog is an alerting
     * signal, not an outage.
     *
     * @return array{pending_jobs: int, failed_jobs: int}|null
     */
    private function queueState(): ?array
    {
        try {
            return [
                'pending_jobs' => (int) DB::table('jobs')->count(),
                'failed_jobs' => (int) DB::table('failed_jobs')->count(),
            ];
        } catch (\Throwable) {
            return null;
        }
    }
}
