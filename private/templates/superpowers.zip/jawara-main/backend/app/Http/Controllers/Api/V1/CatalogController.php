<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\BusinessFollow;
use App\Models\Notification;
use App\Models\Product;
use App\Models\Service;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Organization-side catalog management (FR-5). Listings always belong to the
 * context organization (AD-1); pricing/visibility rules per AD-3.
 */
class CatalogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        // FR-5 gap closure: sertakan images & variants agar panel kelola
        // katalog (UI) bisa mengelolanya tanpa endpoint tambahan.
        $products = Product::forOrganization($organization)
            ->with(['category:id,name,slug', 'images', 'variants'])
            ->latest()
            ->paginate(12);
        $services = Service::forOrganization($organization)->with('category:id,name,slug')->latest()->paginate(12);

        return response()->json(['data' => ['products' => $products->items(), 'services' => $services->items()], 'meta' => [
            'products_total' => $products->total(),
            'services_total' => $services->total(),
        ]]);
    }

    public function storeProduct(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $validated = $this->validateProduct($request);

        $product = DB::transaction(function () use ($validated, $organization) {
            return Product::create([
                'organization_id' => $organization->id,
                'category_id' => $validated['category_id'] ?? null,
                'name' => $validated['name'],
                'slug' => Str::slug($validated['name']).'-'.Str::lower(Str::random(6)),
                'description' => $validated['description'] ?? null,
                'sku' => $validated['sku'] ?? null,
                'unit_of_measure' => $validated['unit_of_measure'] ?? 'pcs',
                'min_order_quantity' => $validated['min_order_quantity'] ?? 1,
                'price' => $validated['price'] ?? null,
                'currency' => 'IDR',
                'price_visibility' => $validated['price_visibility'] ?? 'public',
                'stock_quantity' => $validated['stock_quantity'] ?? null,
                'status' => $validated['status'] ?? 'draft',
            ]);
        });

        return response()->json(['data' => $product, 'message' => 'Produk dibuat.'], 201);
    }

    public function updateProduct(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $product = Product::forOrganization($organization)->findOrFail($id);
        $validated = $this->validateProduct($request, partial: true);

        $wasPublished = $product->status === 'published';
        $product->update($validated);

        // Tier 1: notify followers when a product goes live for the first time.
        if (! $wasPublished && $product->status === 'published') {
            $this->notifyFollowers($product);
        }

        return response()->json(['data' => $product, 'message' => 'Produk diperbarui.']);
    }

    public function archiveProduct(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $product = Product::forOrganization($organization)->findOrFail($id);
        $product->update(['status' => 'archived']);

        return response()->json(['data' => $product, 'message' => 'Produk diarsipkan.']);
    }

    /**
     * FR-5 gap closure: supplier-side product image upload (model lama
     * read-only). AD-11: whitelist gambar, cap ukuran, maks 6 gambar per
     * produk; gambar pertama otomatis primary.
     */
    public function storeProductImage(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $product = Product::forOrganization($organization)->findOrFail($id);

        $validated = $request->validate([
            'image' => ['required', 'image', 'mimes:png,jpg,jpeg,webp', 'max:2048'], // AD-11
        ]);

        if ($product->images()->count() >= 6) {
            throw ValidationException::withMessages([
                'image' => ['Maksimal 6 gambar per produk.'],
            ]);
        }

        $path = $validated['image']->store("products/{$organization->id}", 'public');

        $isPrimary = $product->images()->count() === 0;

        $image = $product->images()->create([
            'path' => $path,
            'sort_order' => (int) $product->images()->max('sort_order') + 1,
            'is_primary' => $isPrimary,
        ]);

        return response()->json(['data' => $image, 'message' => 'Gambar produk diunggah.'], 201);
    }

    public function destroyProductImage(Request $request, string $id, string $imageId): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $product = Product::forOrganization($organization)->findOrFail($id);
        $image = $product->images()->findOrFail($imageId);

        Storage::disk('public')->delete($image->path);
        $image->delete();

        // Promosikan gambar tersisa pertama sebagai primary.
        if ($image->is_primary) {
            $product->images()->first()?->update(['is_primary' => true]);
        }

        return response()->json(['message' => 'Gambar dihapus.']);
    }

    /**
     * FR-5 gap closure: variant management (write side sebelumnya dormant).
     */
    public function storeProductVariant(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $product = Product::forOrganization($organization)->findOrFail($id);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'sku' => ['nullable', 'string', 'max:80'],
            'price_delta' => ['nullable', 'numeric', 'min:0'],
            'stock_quantity' => ['nullable', 'integer', 'min:0'],
        ]);

        $variant = $product->variants()->create([
            'name' => $validated['name'],
            'sku' => $validated['sku'] ?? null,
            'price_delta' => $validated['price_delta'] ?? 0,
            'stock_quantity' => $validated['stock_quantity'] ?? null,
        ]);

        return response()->json(['data' => $variant, 'message' => 'Varian ditambahkan.'], 201);
    }

    public function destroyProductVariant(Request $request, string $id, string $variantId): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $product = Product::forOrganization($organization)->findOrFail($id);
        $product->variants()->findOrFail($variantId)->delete();

        return response()->json(['message' => 'Varian dihapus.']);
    }

    public function storeService(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'category_id' => ['nullable', 'integer', 'exists:product_categories,id'],
            'service_area' => ['nullable', 'string', 'max:255'],
            'starting_price' => ['nullable', 'numeric', 'min:0'],
            'price_visibility' => ['nullable', 'in:public,on_request,members_only'],
            'status' => ['nullable', 'in:draft,published,archived'],
        ]);

        $service = Service::create([
            'organization_id' => $organization->id,
            'category_id' => $validated['category_id'] ?? null,
            'name' => $validated['name'],
            'slug' => Str::slug($validated['name']).'-'.Str::lower(Str::random(6)),
            'description' => $validated['description'] ?? null,
            'service_area' => $validated['service_area'] ?? null,
            'starting_price' => $validated['starting_price'] ?? null,
            'currency' => 'IDR',
            'price_visibility' => $validated['price_visibility'] ?? 'public',
            'status' => $validated['status'] ?? 'draft',
        ]);

        return response()->json(['data' => $service, 'message' => 'Jasa dibuat.'], 201);
    }

    public function updateService(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $service = Service::forOrganization($organization)->findOrFail($id);
        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'service_area' => ['nullable', 'string', 'max:255'],
            'starting_price' => ['nullable', 'numeric', 'min:0'],
            'price_visibility' => ['nullable', 'in:public,on_request,members_only'],
            'status' => ['sometimes', 'in:draft,published,archived'],
        ]);

        $service->update($validated);

        return response()->json(['data' => $service, 'message' => 'Jasa diperbarui.']);
    }

    private function validateProduct(Request $request, bool $partial = false): array
    {
        $rules = [
            'name' => $partial ? ['sometimes', 'string', 'max:255'] : ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'category_id' => ['nullable', 'integer', 'exists:product_categories,id'],
            'sku' => ['nullable', 'string', 'max:80'],
            'unit_of_measure' => ['nullable', 'string', 'max:30'],
            'min_order_quantity' => ['nullable', 'integer', 'min:1'],
            'price' => ['nullable', 'numeric', 'min:0'],
            'price_visibility' => ['nullable', 'in:public,on_request,members_only'],
            'stock_quantity' => ['nullable', 'integer', 'min:0'],
            'status' => ['nullable', 'in:draft,published,archived'],
        ];

        $validated = $request->validate($rules);

        // Business rule (AD-3): a members_only or on_request listing cannot
        // expose a public price at the same time.
        if (($validated['price_visibility'] ?? null) === 'public' && ($validated['price'] ?? null) === null) {
            throw ValidationException::withMessages(['price' => 'Harga wajib untuk visibilitas publik, atau ubah visibilitas ke on_request.']);
        }

        return $validated;
    }

    /** Tier 1: fan out "produk baru" notifications to organization followers. */
    private function notifyFollowers(Product $product): void
    {
        $followers = BusinessFollow::where('organization_id', $product->organization_id)->pluck('user_id');

        if ($followers->isEmpty()) {
            return;
        }

        $now = now();
        $rows = $followers->map(fn ($userId) => [
            'id' => (string) Str::uuid(),
            'user_id' => $userId,
            'type' => 'product.published',
            'title' => 'Produk baru dari supplier yang Anda ikuti',
            'body' => $product->name,
            'link' => '/products/'.$product->slug,
            'data' => json_encode(['product_id' => $product->id]),
            'read_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ])->all();

        Notification::insert($rows);
    }
}
