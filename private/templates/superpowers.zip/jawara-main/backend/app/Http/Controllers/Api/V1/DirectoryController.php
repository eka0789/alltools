<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Shared\Contracts\SearchService;
use App\Http\Controllers\Controller;
use App\Models\BusinessCategory;
use App\Models\BusinessConnection;
use App\Models\BusinessFollow;
use App\Models\BusinessLocation;
use App\Models\BusinessProfile;
use App\Models\ProfileView;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Public business discovery (FR-4). Only published profiles are exposed.
 * Personal contact details are never exposed without consent: only the
 * explicit public_* fields are returned (spec Phase 04).
 */
class DirectoryController extends Controller
{
    public function categories(): JsonResponse
    {
        return response()->json(['data' => BusinessCategory::orderBy('name')->get(['id', 'name', 'slug'])]);
    }

    public function locations(): JsonResponse
    {
        return response()->json(['data' => BusinessLocation::orderBy('name')->get(['id', 'name', 'slug', 'city', 'province'])]);
    }

    public function index(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'q' => ['nullable', 'string', 'max:120'],
            'category' => ['nullable', 'string', 'max:140'],
            'location' => ['nullable', 'string', 'max:140'],
            'verified' => ['nullable', 'in:1,true'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:50'],
        ]);

        $query = BusinessProfile::query()
            ->published()
            ->with(['category:id,name,slug', 'location:id,name,slug,city']);

        if (! empty($validated['q'])) {
            // AD-10 (H7 audit fix): search behind SearchService interface.
            app(SearchService::class)
                ->apply($query, ['display_name', 'description'], $validated['q']);
        }

        if (! empty($validated['category'])) {
            $query->whereHas('category', fn ($q) => $q->where('slug', $validated['category']));
        }

        if (! empty($validated['location'])) {
            $query->whereHas('location', fn ($q) => $q->where('slug', $validated['location']));
        }

        if (! empty($validated['verified'])) {
            $query->where('verification_status', 'verified');
        }

        $profiles = $query->orderBy('display_name')
            ->paginate($validated['per_page'] ?? 12)
            ->withQueryString();

        return response()->json([
            'data' => collect($profiles->items())->map(fn ($p) => [
                'id' => $p->id,
                'slug' => $p->slug,
                'display_name' => $p->display_name,
                'description' => str($p->description)->limit(160),
                'logo_path' => $p->logo_path,
                'verification_status' => $p->verification_status,
                'category' => $p->category?->name,
                'location' => $p->location?->city ?? $p->location?->name,
            ]),
            'meta' => [
                'current_page' => $profiles->currentPage(),
                'last_page' => $profiles->lastPage(),
                'per_page' => $profiles->perPage(),
                'total' => $profiles->total(),
            ],
        ]);
    }

    public function show(Request $request, string $slug): JsonResponse
    {
        $profile = BusinessProfile::query()
            ->published()
            ->with(['category:id,name,slug', 'location:id,name,slug,city'])
            ->where('slug', $slug)
            ->firstOrFail();

        // Tier 3 analytics: privacy-preserving view tracking (1 row per
        // org + visitor + day). Anonymous viewers are hashed IP only.
        $ipHash = hash('sha256', $request->ip().'|'.$request->userAgent());
        ProfileView::firstOrCreate([
            'organization_id' => $profile->organization_id,
            'ip_hash' => $ipHash,
            'view_date' => now()->toDateString(),
        ], [
            'viewer_user_id' => $request->user()?->id,
        ]);

        $isFollowing = $request->user()
            ? BusinessFollow::where('user_id', $request->user()->id)->where('organization_id', $profile->organization_id)->exists()
            : null;

        return response()->json([
            'data' => [
                'id' => $profile->id,
                'slug' => $profile->slug,
                'display_name' => $profile->display_name,
                'description' => $profile->description,
                'logo_path' => $profile->logo_path,
                'website_url' => $profile->website_url,
                'public_email' => $profile->public_email,
                'public_phone' => $profile->public_phone,
                'full_address' => $profile->full_address,
                'verification_status' => $profile->verification_status,
                'founding_partner' => $profile->organization?->founding_partner ?? false,
                'category' => $profile->category?->name,
                'location' => $profile->location?->city ?? $profile->location?->name,
                'updated_at' => $profile->updated_at?->toIso8601String(),
                // Tier 1 trust widgets
                'rating_avg' => (float) ($profile->reviews()->avg('rating') ?? 0),
                'reviews_count' => $profile->reviews()->count(),
                'followers_count' => BusinessFollow::where('organization_id', $profile->organization_id)->count(),
                'connections_count' => BusinessConnection::where(fn ($q) => $q
                    ->where('requester_organization_id', $profile->organization_id)
                    ->orWhere('target_organization_id', $profile->organization_id))
                    ->where('status', 'accepted')->count(),
                'completeness' => $profile->completenessPercentage(),
                'is_following' => $isFollowing,
            ],
        ]);
    }

    public function autocomplete(Request $request): JsonResponse
    {
        $term = $request->validate(['q' => ['required', 'string', 'max:120']])['q'];

        return response()->json([
            'data' => app(SearchService::class)
                ->apply(BusinessProfile::query()->published(), ['display_name'], $term)
                ->limit(8)
                ->get(['id', 'slug', 'display_name']),
        ]);
    }
}
