<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Billing\Services\EntitlementService;
use App\Domain\Identity\RoleRank;
use App\Domain\Procurement\Actions\CloseRfqAction;
use App\Domain\Procurement\Actions\PublishRfqAction;
use App\Enums\RfqStatus;
use App\Http\Controllers\Controller;
use App\Models\Rfq;
use App\Models\RfqInvitation;
use App\Models\RfqItem;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Buyer-side RFQ endpoints (FR-6). Every listing is org-scoped (AD-1).
 * Mutations require procurement rank >= purchasing-staff (AD-6).
 */
class RfqController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $rfqs = Rfq::forOrganization($organization)
            ->withCount('items', 'quotations')
            ->latest()
            ->paginate(15);

        return response()->json(['data' => $rfqs->items(), 'meta' => [
            'current_page' => $rfqs->currentPage(),
            'last_page' => $rfqs->lastPage(),
            'total' => $rfqs->total(),
        ]]);
    }

    public function show(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $rfq = Rfq::forOrganization($organization)
            ->with([
                'items',
                // M10 (audit): exclude the immutable snapshot column — it embeds
                // every line item and bloats the detail payload.
                'quotations' => fn ($q) => $q->select([
                    'id', 'rfq_id', 'supplier_organization_id', 'status',
                    'total_amount', 'delivery_cost', 'currency',
                    'lead_time_days', 'valid_until', 'submitted_at', 'created_by',
                ]),
                'quotations.supplier:id,name',
            ])
            ->findOrFail($id);

        return response()->json(['data' => $rfq]);
    }

    public function store(Request $request): JsonResponse
    {
        $this->authorizeProcurement($request);
        $organization = $request->attributes->get('organization');

        // Phase 09 entitlement: plan monthly RFQ limit (free fallback).
        app(EntitlementService::class)->assertCanCreateRfq($organization);

        $validated = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'delivery_location' => ['nullable', 'array'],
            'delivery_deadline_at' => ['nullable', 'date', 'after:now'],
            'quotation_deadline_at' => ['nullable', 'date', 'after:now'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_name' => ['required', 'string', 'max:255'],
            'items.*.specification' => ['nullable', 'string', 'max:2000'],
            'items.*.quantity' => ['required', 'numeric', 'gt:0'],
            'items.*.unit_of_measure' => ['required', 'string', 'max:30'],
        ]);

        $rfq = DB::transaction(function () use ($validated, $request, $organization) {
            $rfq = Rfq::create([
                'buyer_organization_id' => $organization->id,
                'created_by' => $request->user()->id,
                'number' => 'RFQ-'.now()->format('Y').'-'.strtoupper(Str::random(8)),
                'title' => $validated['title'],
                'description' => $validated['description'] ?? null,
                'delivery_location' => $validated['delivery_location'] ?? null,
                'delivery_deadline_at' => $validated['delivery_deadline_at'] ?? null,
                'quotation_deadline_at' => $validated['quotation_deadline_at'] ?? null,
                'currency' => 'IDR',
            ]);

            foreach ($validated['items'] as $i => $item) {
                RfqItem::create([
                    'rfq_id' => $rfq->id,
                    'product_name' => $item['product_name'],
                    'specification' => $item['specification'] ?? null,
                    'quantity' => $item['quantity'],
                    'unit_of_measure' => $item['unit_of_measure'],
                    'sort_order' => $i,
                ]);
            }

            return $rfq;
        });

        return response()->json(['data' => $rfq->load('items'), 'message' => 'RFQ draft dibuat.'], 201);
    }

    public function update(Request $request, string $id): JsonResponse
    {
        $this->authorizeProcurement($request);
        $organization = $request->attributes->get('organization');

        $rfq = Rfq::forOrganization($organization)->findOrFail($id);

        if ($rfq->status !== RfqStatus::Draft) {
            throw ValidationException::withMessages(['status' => 'Hanya RFQ draft yang dapat diubah.']);
        }

        $validated = $request->validate([
            'title' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'delivery_location' => ['nullable', 'array'],
            'delivery_deadline_at' => ['nullable', 'date', 'after:now'],
            'quotation_deadline_at' => ['nullable', 'date', 'after:now'],
        ]);

        $rfq->update($validated);

        return response()->json(['data' => $rfq, 'message' => 'RFQ diperbarui.']);
    }

    public function publish(Request $request, string $id, PublishRfqAction $action): JsonResponse
    {
        $this->authorizeProcurement($request);
        $organization = $request->attributes->get('organization');

        $rfq = Rfq::forOrganization($organization)->findOrFail($id);
        $rfq = $action->execute($rfq, $request->user());

        return response()->json(['data' => $rfq, 'message' => 'RFQ dipublikasikan.']);
    }

    public function close(Request $request, string $id, CloseRfqAction $action): JsonResponse
    {
        $this->authorizeProcurement($request);
        $organization = $request->attributes->get('organization');

        $rfq = Rfq::forOrganization($organization)->findOrFail($id);
        $rfq = $action->execute($rfq, $request->user(), $request->input('action', 'close'));

        return response()->json(['data' => $rfq, 'message' => 'RFQ ditutup.']);
    }

    public function invite(Request $request, string $id): JsonResponse
    {
        $this->authorizeProcurement($request);
        $organization = $request->attributes->get('organization');

        $rfq = Rfq::forOrganization($organization)->findOrFail($id);

        if ($rfq->status !== RfqStatus::Published && $rfq->status !== RfqStatus::Draft) {
            throw ValidationException::withMessages(['status' => 'Undangan hanya dapat dikirim untuk RFQ draft/published.']);
        }

        $validated = $request->validate([
            'supplier_organization_ids' => ['required', 'array', 'min:1'],
            'supplier_organization_ids.*' => ['uuid', 'exists:organizations,id'],
        ]);

        $created = 0;
        foreach ($validated['supplier_organization_ids'] as $supplierId) {
            if ($supplierId === $organization->id) {
                continue; // cannot invite self
            }
            $invitation = RfqInvitation::firstOrCreate(
                ['rfq_id' => $rfq->id, 'supplier_organization_id' => $supplierId],
                ['invited_by' => $request->user()->id, 'status' => 'sent'],
            );
            if ($invitation->wasRecentlyCreated) {
                $created++;
            }
        }

        return response()->json(['message' => "{$created} undangan dikirim."], 201);
    }

    /** H1 (audit): procurement mutations require rank >= purchasing-staff. */
    private function authorizeProcurement(Request $request): void
    {
        $membership = $request->attributes->get('membership');

        if (RoleRank::rankOf($membership) < RoleRank::PROCUREMENT_MIN) {
            abort(403, 'Peran Anda tidak memiliki akses pengadaan.');
        }
    }
}
