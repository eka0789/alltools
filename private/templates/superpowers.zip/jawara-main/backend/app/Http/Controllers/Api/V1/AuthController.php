<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Identity\Actions\RegisterUserAction;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\RegisterRequest;
use App\Http\Requests\Auth\ResetPasswordRequest;
use App\Http\Requests\Auth\SendResetLinkRequest;
use App\Models\AuditLog;
use App\Models\Notification;
use App\Models\OrganizationInvitation;
use App\Models\OrganizationMember;
use App\Models\ProductInquiry;
use App\Models\User;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Laravel\Sanctum\PersonalAccessToken;

class AuthController extends Controller
{
    public function register(RegisterRequest $request, RegisterUserAction $action): JsonResponse
    {
        $user = $action->execute(
            $request->validated('name'),
            $request->validated('email'),
            $request->validated('password'),
            $request->validated('referral_code'),
        );

        $user->sendEmailVerificationNotification();

        return response()->json([
            'data' => ['user' => ['id' => $user->id, 'name' => $user->name, 'email' => $user->email]],
            'message' => 'Registrasi berhasil. Silakan verifikasi email Anda.',
        ], 201);
    }

    public function resendVerification(): JsonResponse
    {
        $user = request()->user();

        if ($user->hasVerifiedEmail()) {
            return response()->json(['message' => 'Email sudah terverifikasi.']);
        }

        $user->sendEmailVerificationNotification();

        return response()->json(['message' => 'Email verifikasi dikirim ulang.']);
    }

    public function login(LoginRequest $request): JsonResponse
    {
        // AD-7: SPA cookie session. Auth::attempt authenticates the web guard
        // and the stateful API pipeline resolves Sanctum from the session.
        if (! Auth::attempt(
            ['email' => $request->validated('email'), 'password' => $request->validated('password')],
            $request->boolean('remember'),
        )) {
            throw ValidationException::withMessages(['email' => 'Email atau password salah.']);
        }

        // SPA mode runs the session pipeline; token-based clients don't.
        if ($request->hasSession()) {
            $request->session()->regenerate(); // session fixation protection
        }

        $user = $request->user();

        return response()->json([
            'data' => ['user' => ['id' => $user->id, 'name' => $user->name, 'email' => $user->email]],
            'message' => 'Login berhasil.',
        ]);
    }

    public function logout(): JsonResponse
    {
        $token = request()->user()->currentAccessToken();
        if ($token instanceof PersonalAccessToken) {
            $token->delete();
        }

        // C1/Security #7: terminate the SPA cookie session too, not only PATs.
        if (request()->hasSession()) {
            Auth::guard('web')->logout();
            request()->session()->invalidate();
            request()->session()->regenerateToken();
        }

        return response()->json(['message' => 'Logout berhasil.']);
    }

    public function me(): JsonResponse
    {
        $user = request()->user()->load('memberships.role', 'memberships.organization:id,name,slug,organization_type');

        $organizations = $user->memberships
            ->where('status', 'active')
            ->map(fn ($m) => [
                'id' => $m->organization->id,
                'name' => $m->organization->name,
                'slug' => $m->organization->slug,
                'role' => $m->role->slug,
                'referral_code' => $m->organization->referral_code,
            ])->values();

        return response()->json([
            'data' => [
                'user' => ['id' => $user->id, 'name' => $user->name, 'email' => $user->email],
                'organizations' => $organizations,
            ],
        ]);
    }

    /**
     * GDPR: portabilitas data — ekspor JSON seluruh data pribadi akun.
     */
    public function exportData(Request $request): JsonResponse
    {
        $user = $request->user();

        $data = [
            'exported_at' => now()->toIso8601String(),
            'user' => ['id' => $user->id, 'name' => $user->name, 'email' => $user->email, 'created_at' => $user->created_at],
            'profile' => $user->profile?->only(['phone', 'job_title']),
            'memberships' => $user->memberships()->with('organization:id,name,slug')->get()->map(
                fn ($m) => ['organization' => $m->organization?->name, 'role' => $m->role?->slug, 'status' => $m->status, 'joined_at' => $m->joined_at],
            ),
            'inquiries_sent' => ProductInquiry::where('sender_user_id', $user->id)->get(['product_id', 'sender_name', 'sender_email', 'message', 'created_at']),
            'notifications' => Notification::where('user_id', $user->id)->get(['type', 'title', 'body', 'created_at']),
        ];

        return response()->json(['data' => $data])
            ->header('Content-Disposition', 'attachment; filename="jawara-data-export.json"');
    }

    /**
     * GDPR: hak penghapusan. Baris user dipertahankan (12 FK integritas
     * audit/keuangan) tetapi SELURUH PII dianonimkan; keanggotaan,
     * notifikasi, dan token dicabut. Irreversibel.
     */
    public function destroyAccount(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'password' => ['required', 'current_password:web'],
        ]);

        $user = $request->user();

        DB::transaction(function () use ($user) {
            AuditLog::create([
                'actor_user_id' => $user->id,
                'organization_id' => $user->memberships()->first()?->organization_id,
                'action' => 'account.deleted',
                'subject_type' => User::class,
                'subject_id' => $user->id,
            ]);

            // Revoke PAT tokens + refresh sessions.
            $user->tokens()->delete();

            // Keluar dari semua organisasi + cabang undangan yang dibuatnya.
            OrganizationMember::where('user_id', $user->id)->delete();
            OrganizationInvitation::where('invited_by', $user->id)->update(['accepted_at' => now(), 'expires_at' => now()]);

            // Data pribadi turunan.
            Notification::where('user_id', $user->id)->delete();
            $user->profile()?->update(['phone' => null, 'job_title' => null]);

            // Anonimisasi identitas (PII) — baris dipertahankan demi integritas FK.
            $user->forceFill([
                'name' => 'Pengguna Terhapus',
                'email' => 'deleted-'.Str::uuid().'@jawara.invalid',
                'password' => Hash::make(Str::uuid()),
                'email_verified_at' => null,
                'remember_token' => null,
                'onboarding_stage' => 99,
            ])->save();
        });

        // Logout setelah transaksi (audit fix C1 pattern).
        if ($request->hasSession()) {
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
        }

        return response()->json(['message' => 'Akun berhasil dihapus dan data pribadi dianonimkan.']);
    }

    public function sendResetLink(SendResetLinkRequest $request): JsonResponse
    {
        Password::sendResetLink($request->validated());

        return response()->json(['message' => 'Jika email terdaftar, tautan reset telah dikirim.']);
    }

    public function resetPassword(ResetPasswordRequest $request): JsonResponse
    {
        $status = Password::reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function (User $user, string $password) {
                $user->forceFill(['password' => Hash::make($password)])->save();
                event(new PasswordReset($user));
            },
        );

        if ($status !== Password::PASSWORD_RESET) {
            throw ValidationException::withMessages(['token' => __($status)]);
        }

        return response()->json(['message' => 'Password berhasil direset.']);
    }
}
