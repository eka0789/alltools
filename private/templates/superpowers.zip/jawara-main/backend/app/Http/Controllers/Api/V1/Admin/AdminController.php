<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Enums\RfqStatus;
use App\Enums\VerificationStatus;
use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\BusinessProfile;
use App\Models\BusinessVerification;
use App\Models\ModerationAction;
use App\Models\Notification;
use App\Models\Organization;
use App\Models\OrganizationMember;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\Quotation;
use App\Models\Report;
use App\Models\Rfq;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

/**
 * Platform administration (FR-8, spec Phase 08): verification queue with
 * 5-status workflow, organization suspension, reports, audit log viewer.
 * Every moderation action is audited (AD-12); self-approval is blocked;
 * verification documents stay on the private disk (AD-11).
 */
class AdminController extends Controller
{
    public function overview(): JsonResponse
    {
        return response()->json(['data' => [
            'users' => User::count(),
            'organizations' => Organization::count(),
            'verified_organizations' => BusinessProfile::where('verification_status', 'verified')->count(),
            'pending_verifications' => BusinessVerification::where('status', 'pending')->count(),
            'rfqs' => Rfq::count(),
            'open_rfqs' => Rfq::where('status', RfqStatus::Published)->count(),
            'quotations' => Quotation::count(),
            'purchase_orders' => PurchaseOrder::count(),
            'open_reports' => Report::where('status', 'open')->count(),
        ]]);
    }

    public function verifications(Request $request): JsonResponse
    {
        $query = BusinessVerification::with(['organization:id,name,slug', 'businessProfile:id,display_name,slug,verification_status', 'submitter:id,name,email']);

        if ($status = $request->query('status')) {
            $query->where('status', $status);
        }

        $items = $query->orderBy('created_at')->paginate(20);

        return response()->json(['data' => $items->items(), 'meta' => ['current_page' => $items->currentPage(), 'last_page' => $items->lastPage(), 'total' => $items->total()]]);
    }

    public function reviewVerification(Request $request, string $id): JsonResponse
    {
        $validated = $request->validate([
            'action' => ['required', 'in:under_review,approve,reject,resubmit'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ]);

        $verification = BusinessVerification::findOrFail($id);

        // Spec Phase 08: prevent self-approval.
        if ($validated['action'] === 'approve' && $verification->submitted_by === $request->user()->id) {
            throw ValidationException::withMessages(['action' => 'Moderator tidak dapat menyetujui verifikasi yang diajukan sendiri.']);
        }

        $moderatorMembership = $this->moderatorMembership($request);
        $current = $verification->status;

        [$newStatus, $profileStatus, $action] = match ($validated['action']) {
            'under_review' => [VerificationStatus::UnderReview, null, 'under_review'],
            'approve' => [VerificationStatus::Verified, 'verified', 'verified'],
            'reject' => [VerificationStatus::Rejected, 'rejected', 'rejected'],
            'resubmit' => [VerificationStatus::ResubmissionRequired, 'resubmission_required', 'resubmission_required'],
        };

        if (! $current->canTransitionTo($newStatus)) {
            throw ValidationException::withMessages(['action' => "Transisi {$current->value} → {$newStatus->value} tidak diizinkan."]);
        }

        DB::transaction(function () use ($verification, $current, $newStatus, $profileStatus, $validated, $request, $moderatorMembership, $action) {
            $verification->update([
                'status' => $newStatus,
                'notes' => $validated['notes'] ?? $verification->notes,
                'reviewed_by' => $request->user()->id,
                'reviewed_at' => now(),
            ]);

            if ($profileStatus !== null) {
                $verification->businessProfile->update([
                    'verification_status' => $profileStatus,
                    'verified_at' => $profileStatus === 'verified' ? now() : null,
                ]);

                // Tier 3 Founding Partner (spec Phase 10): the first 100
                // verified organizations earn the badge automatically.
                if ($profileStatus === 'verified') {
                    $verifiedCount = BusinessProfile::where('verification_status', 'verified')->count();
                    if ($verifiedCount <= 100) {
                        Organization::where('id', $verification->organization_id)->update(['founding_partner' => true]);
                    }
                }
            }

            ModerationAction::create([
                'moderator_user_id' => $request->user()->id,
                'action' => 'verification.'.$action,
                'subject_type' => BusinessVerification::class,
                'subject_id' => $verification->id,
                'reason' => $validated['notes'] ?? null,
            ]);

            AuditLog::create([
                'actor_user_id' => $request->user()->id,
                'organization_id' => $moderatorMembership?->organization_id,
                'action' => 'verification.'.$action,
                'subject_type' => BusinessVerification::class,
                'subject_id' => $verification->id,
                'before' => ['status' => $current->value],
                'after' => ['status' => $newStatus->value, 'notes' => $validated['notes'] ?? null],
            ]);

            Notification::create([
                'user_id' => $verification->submitted_by,
                'type' => 'verification.'.$action,
                'title' => 'Status verifikasi diperbarui',
                'body' => $validated['notes'] ?? ('Verifikasi bisnis Anda: '.$newStatus->value),
                'link' => '/dashboard',
            ]);
        });

        return response()->json(['data' => $verification->fresh(), 'message' => 'Review tersimpan.']);
    }

    public function downloadVerificationDocument(Request $request, string $id): BinaryFileResponse
    {
        $verification = BusinessVerification::findOrFail($id);

        AuditLog::create([
            'actor_user_id' => $request->user()->id,
            'action' => 'verification.document_viewed',
            'subject_type' => BusinessVerification::class,
            'subject_id' => $verification->id,
        ]);

        abort_unless(Storage::disk('private')->exists($verification->document_path), 404);

        return Storage::disk('private')->response($verification->document_path);
    }

    public function organizations(Request $request): JsonResponse
    {
        $q = $request->query('q');
        $query = Organization::query()->with('businessProfile:id,organization_id,display_name,verification_status');

        if ($q) {
            $query->where('name', 'like', '%'.$q.'%');
        }

        $items = $query->orderBy('name')->paginate(20);

        return response()->json(['data' => $items->items(), 'meta' => ['current_page' => $items->currentPage(), 'last_page' => $items->lastPage(), 'total' => $items->total()]]);
    }

    public function setOrganizationStatus(Request $request, string $id): JsonResponse
    {
        $validated = $request->validate([
            'status' => ['required', 'in:active,suspended,archived'],
            'reason' => ['required_if:status,suspended', 'nullable', 'string', 'max:1000'],
        ]);

        $organization = Organization::findOrFail($id);

        DB::transaction(function () use ($organization, $validated, $request) {
            $before = $organization->status;
            $organization->update(['status' => $validated['status']]);

            ModerationAction::create([
                'moderator_user_id' => $request->user()->id,
                'action' => 'organization.status_changed',
                'subject_type' => Organization::class,
                'subject_id' => $organization->id,
                'reason' => $validated['reason'] ?? null,
                'data' => ['before' => $before, 'after' => $validated['status']],
            ]);

            AuditLog::create([
                'actor_user_id' => $request->user()->id,
                'action' => 'organization.status_changed',
                'subject_type' => Organization::class,
                'subject_id' => $organization->id,
                'before' => ['status' => $before],
                'after' => ['status' => $validated['status'], 'reason' => $validated['reason'] ?? null],
            ]);
        });

        return response()->json(['data' => $organization, 'message' => 'Status organisasi diperbarui.']);
    }

    public function reports(): JsonResponse
    {
        $reports = Report::orderBy('created_at')->paginate(20);

        return response()->json(['data' => $reports->items(), 'meta' => ['current_page' => $reports->currentPage(), 'last_page' => $reports->lastPage(), 'total' => $reports->total()]]);
    }

    public function resolveReport(Request $request, string $id): JsonResponse
    {
        $validated = $request->validate([
            'status' => ['required', 'in:reviewing,resolved,dismissed'],
        ]);

        $report = Report::findOrFail($id);
        $before = $report->status;
        $report->update(['status' => $validated['status']]);

        ModerationAction::create([
            'moderator_user_id' => $request->user()->id,
            'action' => 'report.'.$validated['status'],
            'subject_type' => Report::class,
            'subject_id' => $report->id,
        ]);

        // M1 (audit 2026-11-21): every moderation action pairs ModerationAction
        // with an audit_logs entry — this path previously skipped audit.
        AuditLog::create([
            'actor_user_id' => $request->user()->id,
            'action' => 'report.'.$validated['status'],
            'subject_type' => Report::class,
            'subject_id' => $report->id,
            'before' => ['status' => $before],
            'after' => ['status' => $validated['status']],
        ]);

        return response()->json(['data' => $report, 'message' => 'Laporan diperbarui.']);
    }

    /** Tier 2: feature a published product for N days (revenue stream #2). */
    public function featureProduct(Request $request, string $id): JsonResponse
    {
        $validated = $request->validate(['days' => ['required', 'integer', 'min:1', 'max:90']]);

        $product = Product::published()->findOrFail($id);
        $product->update(['featured_until' => now()->addDays($validated['days'])]);

        ModerationAction::create([
            'moderator_user_id' => $request->user()->id,
            'action' => 'product.featured',
            'subject_type' => Product::class,
            'subject_id' => $product->id,
            'data' => ['days' => $validated['days']],
        ]);

        return response()->json([
            'data' => ['featured_until' => $product->featured_until->toIso8601String()],
            'message' => "Produk ditampilkan selama {$validated['days']} hari.",
        ]);
    }

    public function auditLogs(Request $request): JsonResponse
    {
        $logs = AuditLog::with('actor:id,name')
            ->when($request->query('action'), fn ($q, $a) => $q->where('action', 'like', "%{$a}%"))
            ->latest('created_at')
            ->paginate(50);

        return response()->json(['data' => $logs->items(), 'meta' => ['current_page' => $logs->currentPage(), 'last_page' => $logs->lastPage(), 'total' => $logs->total()]]);
    }

    private function moderatorMembership(Request $request): ?OrganizationMember
    {
        // Platform staff belong to the JAWARA Platform system organization.
        return $request->user()->memberships()
            ->where('status', 'active')
            ->first();
    }
}
