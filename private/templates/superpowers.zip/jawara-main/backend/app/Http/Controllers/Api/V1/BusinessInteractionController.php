<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\BusinessConnection;
use App\Models\BusinessFollow;
use App\Models\Notification;
use App\Models\Organization;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/**
 * Tier 1 network features (spec NOW stage): follow perusahaan, connections
 * antar organisasi. Activation of the dormant business_follows and
 * business_connections tables.
 */
class BusinessInteractionController extends Controller
{
    public function follow(Request $request, string $slug): JsonResponse
    {
        $organization = $this->organizationFromSlug($slug);

        $follow = BusinessFollow::firstOrCreate(
            ['user_id' => $request->user()->id, 'organization_id' => $organization->id],
            ['followed_at' => now()],
        );

        return response()->json([
            'data' => ['following' => true, 'followers_count' => $this->followersCount($organization)],
            'message' => 'Mengikuti '.$organization->name.'.',
        ], 201);
    }

    public function unfollow(Request $request, string $slug): JsonResponse
    {
        $organization = $this->organizationFromSlug($slug);

        BusinessFollow::where('user_id', $request->user()->id)
            ->where('organization_id', $organization->id)
            ->delete();

        return response()->json([
            'data' => ['following' => false, 'followers_count' => $this->followersCount($organization)],
            'message' => 'Berhenti mengikuti '.$organization->name.'.',
        ]);
    }

    /** Connect by explicit target organization id (dashboard "hubungkan" CTA). */
    public function connectById(Request $request): JsonResponse
    {
        $validated = $request->validate(['target_organization_id' => ['required', 'uuid', 'exists:organizations,id']]);
        $target = Organization::findOrFail($validated['target_organization_id']);

        return $this->establishConnection($request, $target);
    }

    public function connect(Request $request, string $slug): JsonResponse
    {
        $target = $this->organizationFromSlug($slug);

        return $this->establishConnection($request, $target);
    }

    private function establishConnection(Request $request, Organization $target): JsonResponse
    {
        $requester = $request->attributes->get('organization');

        if ($requester->id === $target->id) {
            throw ValidationException::withMessages(['connection' => 'Tidak dapat terhubung dengan organisasi sendiri.']);
        }

        // A reverse pending request auto-accepts (handshake semantics).
        $reverse = BusinessConnection::where('requester_organization_id', $target->id)
            ->where('target_organization_id', $requester->id)
            ->where('status', 'pending')
            ->first();

        if ($reverse) {
            $reverse->update(['status' => 'accepted', 'connected_at' => now()]);

            return response()->json([
                'data' => ['status' => 'accepted'],
                'message' => 'Permintaan koneksi dari '.$target->name.' diterima — koneksi terjalin.',
            ]);
        }

        $connection = BusinessConnection::firstOrCreate(
            ['requester_organization_id' => $requester->id, 'target_organization_id' => $target->id],
            ['status' => 'pending'],
        );

        Notification::create([
            'user_id' => $this->ownerUserId($target),
            'type' => 'connection.requested',
            'title' => 'Permintaan koneksi bisnis',
            'body' => $requester->name.' ingin terhubung dengan organisasi Anda.',
            'link' => '/dashboard/connections',
            'data' => ['connection_id' => $connection->id],
        ]);

        return response()->json(['data' => ['status' => $connection->status], 'message' => 'Permintaan koneksi terkirim.'], 201);
    }

    public function respond(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $validated = $request->validate(['action' => ['required', 'in:accept,decline']]);

        // Only the TARGET organization may respond to a request.
        $connection = BusinessConnection::where('target_organization_id', $organization->id)
            ->where('status', 'pending')
            ->findOrFail($id);

        $connection->update([
            'status' => $validated['action'] === 'accept' ? 'accepted' : 'declined',
            'connected_at' => $validated['action'] === 'accept' ? now() : null,
        ]);

        Notification::create([
            'user_id' => $this->ownerUserId(Organization::find($connection->requester_organization_id)),
            'type' => 'connection.'.$validated['action'],
            'title' => $validated['action'] === 'accept'
                ? 'Permintaan koneksi diterima'
                : 'Permintaan koneksi ditolak',
            'body' => $organization->name.' telah merespons permintaan koneksi Anda.',
            'link' => '/dashboard/connections',
            'data' => ['connection_id' => $connection->id],
        ]);

        return response()->json(['data' => $connection, 'message' => 'Koneksi diperbarui.']);
    }

    public function myConnections(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $connections = BusinessConnection::query()
            ->where(fn ($q) => $q
                ->where('requester_organization_id', $organization->id)
                ->orWhere('target_organization_id', $organization->id))
            ->with(['requester:id,name,slug', 'target:id,name,slug'])
            ->orderByDesc('updated_at')
            ->get()
            ->map(fn ($c) => [
                'id' => $c->id,
                'status' => $c->status,
                'direction' => $c->requester_organization_id === $organization->id ? 'outgoing' : 'incoming',
                'organization' => $c->requester_organization_id === $organization->id
                    ? ($c->target ? ['id' => $c->target->id, 'name' => $c->target->name, 'slug' => $c->target->slug] : null)
                    : ($c->requester ? ['id' => $c->requester->id, 'name' => $c->requester->name, 'slug' => $c->requester->slug] : null),
                'connected_at' => $c->connected_at?->toIso8601String(),
            ]);

        return response()->json(['data' => $connections]);
    }

    private function organizationFromSlug(string $slug): Organization
    {
        return Organization::whereHas('businessProfile', fn ($q) => $q->where('slug', $slug)->where('status', 'published'))
            ->firstOrFail();
    }

    private function followersCount(Organization $organization): int
    {
        return BusinessFollow::where('organization_id', $organization->id)->count();
    }

    private function ownerUserId(?Organization $organization): ?string
    {
        return $organization?->members()
            ->where('status', 'active')
            ->whereHas('role', fn ($q) => $q->where('slug', 'organization-owner'))
            ->value('user_id');
    }
}
