<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\BusinessProfile;
use App\Models\Product;
use App\Models\Report;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

/**
 * FR-8 gap closure: user-facing report creation. Previously only the admin
 * resolve side existed — users had no way to report listings/profiles.
 * Guests may report (reporter_user_id nullable by design); abuse is bounded
 * by the api throttle.
 */
class ReportController extends Controller
{
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'subject_type' => ['required', Rule::in(['business_profile', 'product'])],
            'subject_id' => ['required', 'uuid'],
            'reason' => ['required', Rule::in(['spam', 'fraud', 'offensive', 'infringement', 'other'])],
            'description' => ['nullable', 'string', 'max:2000'],
        ]);

        // Pastikan subjek ada — dan hanya subjek yang bisa dilihat publik
        // yang bisa dilaporkan (tanpa kebocoran lintas tenant).
        $exists = $validated['subject_type'] === 'business_profile'
            ? BusinessProfile::query()->published()->whereKey($validated['subject_id'])->exists()
            : Product::query()->published()->whereKey($validated['subject_id'])->exists();

        if (! $exists) {
            throw ValidationException::withMessages([
                'subject_id' => ['Objek yang dilaporkan tidak ditemukan.'],
            ]);
        }

        $report = Report::create([
            'reporter_user_id' => $request->user()?->id,
            'subject_type' => $validated['subject_type'],
            'subject_id' => $validated['subject_id'],
            'reason' => $validated['reason'],
            'description' => $validated['description'] ?? null,
            'status' => 'open',
        ]);

        return response()->json(['data' => $report, 'message' => 'Laporan terkirim. Moderator akan meninjau.'], 201);
    }
}
