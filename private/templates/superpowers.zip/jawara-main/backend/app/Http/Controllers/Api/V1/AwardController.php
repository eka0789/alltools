<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Identity\RoleRank;
use App\Domain\Procurement\Actions\AcceptQuotationAction;
use App\Domain\Procurement\Actions\CreatePurchaseOrderAction;
use App\Domain\Procurement\Actions\RejectQuotationAction;
use App\Domain\Procurement\Actions\TransitionPurchaseOrderAction;
use App\Enums\PurchaseOrderStatus;
use App\Http\Controllers\Controller;
use App\Models\PurchaseOrder;
use App\Models\Quotation;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/**
 * Buyer award + PO lifecycle endpoints (FR-6, S6.3).
 * C7 (audit): PO endpoints are accessible from BOTH sides — the buyer
 * manages the lifecycle, the supplier can only acknowledge an issued PO.
 * H1 (audit): mutations require procurement rank >= RoleRank::PROCUREMENT_MIN.
 */
class AwardController extends Controller
{
    public function acceptQuotation(Request $request, string $quotationId, AcceptQuotationAction $action): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $this->authorizeProcurement($request);

        $quotation = Quotation::with('rfq')->findOrFail($quotationId);

        if ($quotation->rfq->buyer_organization_id !== $organization->id) {
            throw ValidationException::withMessages(['rfq' => 'RFQ ini bukan milik organisasi Anda.']);
        }

        $quotation = $action->execute($quotation, $request->user(), $organization->id);

        return response()->json(['data' => $quotation, 'message' => 'Penawaran diterima. RFQ di-award.']);
    }

    public function rejectQuotation(Request $request, string $quotationId, RejectQuotationAction $action): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $this->authorizeProcurement($request);

        $quotation = Quotation::with('rfq')->findOrFail($quotationId);

        if ($quotation->rfq->buyer_organization_id !== $organization->id) {
            throw ValidationException::withMessages(['rfq' => 'RFQ ini bukan milik organisasi Anda.']);
        }

        $quotation = $action->execute($quotation, $request->user());

        return response()->json(['data' => $quotation, 'message' => 'Penawaran ditolak.']);
    }

    public function createPurchaseOrder(Request $request, string $quotationId, CreatePurchaseOrderAction $action): JsonResponse
    {
        $organization = $request->attributes->get('organization');
        $this->authorizeProcurement($request);

        $quotation = Quotation::with('rfq')->findOrFail($quotationId);

        if ($quotation->rfq->buyer_organization_id !== $organization->id) {
            throw ValidationException::withMessages(['rfq' => 'RFQ ini bukan milik organisasi Anda.']);
        }

        $po = $action->execute($quotation, $request->user());

        return response()->json(['data' => $po->load('items'), 'message' => 'Purchase Order dibuat.'], 201);
    }

    public function purchaseOrders(Request $request): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        // C7 (audit): both buyer and supplier sides can list their POs.
        $pos = $this->scopePoFor($organization->id)
            ->with('supplier:id,name', 'buyer:id,name')
            ->latest()
            ->paginate(15);

        return response()->json(['data' => $pos->items(), 'meta' => [
            'current_page' => $pos->currentPage(),
            'last_page' => $pos->lastPage(),
            'total' => $pos->total(),
        ]]);
    }

    public function showPurchaseOrder(Request $request, string $id): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        $po = $this->scopePoFor($organization->id)
            ->with('items', 'rfq:id,title', 'quotation:id,total_amount')
            ->findOrFail($id);

        return response()->json(['data' => $po]);
    }

    public function transitionPurchaseOrder(Request $request, string $id, TransitionPurchaseOrderAction $action): JsonResponse
    {
        $organization = $request->attributes->get('organization');

        // C7 (audit): load dual-side instead of buyer-only scoping.
        $po = $this->scopePoFor($organization->id)->findOrFail($id);

        $validated = $request->validate([
            'status' => ['required', 'in:'.implode(',', array_column(PurchaseOrderStatus::cases(), 'value'))],
            'reason' => ['nullable', 'string', 'max:500'],
        ]);

        $membership = $request->attributes->get('membership');
        $isSupplierSide = $po->supplier_organization_id === $organization->id;

        if ($isSupplierSide) {
            // Supplier may ONLY acknowledge an issued PO (spec Phase 06).
            if ($validated['status'] !== PurchaseOrderStatus::Acknowledged->value || $po->status !== PurchaseOrderStatus::Issued) {
                throw ValidationException::withMessages(['status' => 'Supplier hanya dapat mengonfirmasi penerimaan PO yang sudah diterbitkan.']);
            }

            // Re-audit H1 completion: acknowledge is financially significant.
            if (RoleRank::rankOf($membership) < RoleRank::PROCUREMENT_MIN) {
                abort(403, 'Peran Anda tidak memiliki akses pengadaan.');
            }
        } else {
            $this->authorizeProcurement($request);

            // Approval/cancellation requires finance or management rank (AD-6).
            if (in_array($validated['status'], [PurchaseOrderStatus::Approved->value, PurchaseOrderStatus::Cancelled->value], true)
                && RoleRank::rankOf($membership) < RoleRank::MANAGEMENT_MIN
                && $membership->role->slug !== 'finance-staff') {
                throw ValidationException::withMessages(['status' => 'Peran Anda tidak dapat melakukan approval/pembatalan PO.']);
            }
        }

        $po = $action->execute($po, PurchaseOrderStatus::from($validated['status']), $request->user(), $validated['reason'] ?? null);

        return response()->json(['data' => $po, 'message' => 'Status PO diperbarui.']);
    }

    /** POs where the context organization is the buyer OR the supplier. */
    private function scopePoFor(string $organizationId): Builder
    {
        return PurchaseOrder::query()
            ->where(fn (Builder $q) => $q
                ->where('buyer_organization_id', $organizationId)
                ->orWhere('supplier_organization_id', $organizationId));
    }

    private function authorizeProcurement(Request $request): void
    {
        $membership = $request->attributes->get('membership');

        if (RoleRank::rankOf($membership) < RoleRank::PROCUREMENT_MIN) {
            abort(403, 'Peran Anda tidak memiliki akses pengadaan.');
        }
    }
}
