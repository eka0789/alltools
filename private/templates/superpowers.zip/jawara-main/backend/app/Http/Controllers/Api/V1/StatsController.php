<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\BusinessProfile;
use App\Models\Organization;
use App\Models\Product;
use App\Models\Rfq;
use App\Models\User;
use Illuminate\Http\JsonResponse;

/**
 * Aggregated platform statistics (FR-9, spec Phase 10). Public stats expose
 * counts only — never private organization data, no fake metrics (product
 * principle).
 */
class StatsController extends Controller
{
    public function public(): JsonResponse
    {
        return response()->json(['data' => [
            'organizations' => Organization::count(),
            'verified_organizations' => BusinessProfile::where('verification_status', 'verified')->count(),
            'published_profiles' => BusinessProfile::published()->count(),
            'published_products' => Product::published()->count(),
            'open_rfqs' => Rfq::where('status', 'published')->count(),
        ]]);
    }

    public function admin(): JsonResponse
    {
        return response()->json(['data' => [
            'users' => User::count(),
            'organizations' => Organization::count(),
            'founding_partners' => Organization::where('founding_partner', true)->count(),
            'rfq_volume_by_status' => [
                'draft' => Rfq::where('status', 'draft')->count(),
                'published' => Rfq::where('status', 'published')->count(),
                'closed' => Rfq::where('status', 'closed')->count(),
                'awarded' => Rfq::where('status', 'awarded')->count(),
            ],
            'quotation_response_rate' => $this->responseRate(),
        ]]);
    }

    private function responseRate(): ?float
    {
        $published = Rfq::whereIn('status', ['published', 'closed', 'awarded'])->count();

        if ($published === 0) {
            return null;
        }

        $withQuotations = Rfq::whereIn('status', ['published', 'closed', 'awarded'])->has('quotations')->count();

        return round($withQuotations / $published * 100, 1);
    }
}
