<?php

namespace App\Http\Controllers\Api\V1;

use App\Domain\Identity\Actions\AcceptInvitationAction;
use App\Domain\Identity\Actions\ChangeMemberRoleAction;
use App\Domain\Identity\Actions\InviteMemberAction;
use App\Domain\Identity\Actions\RemoveMemberAction;
use App\Domain\Identity\RoleRank;
use App\Domain\Organization\Actions\CreateOrganizationAction;
use App\Http\Controllers\Controller;
use App\Http\Requests\Organization\CreateOrganizationRequest;
use App\Http\Requests\Organization\InviteMemberRequest;
use App\Http\Requests\Organization\UpdateMemberRoleRequest;
use App\Http\Requests\Organization\UpdateOrganizationRequest;
use App\Models\BusinessProfile;
use App\Models\Organization;
use App\Models\OrganizationMember;
use App\Models\Role;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class OrganizationController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $organizations = $request->user()->activeOrganizations()->get();

        return response()->json(['data' => $organizations]);
    }

    public function store(CreateOrganizationRequest $request, CreateOrganizationAction $action): JsonResponse
    {
        // M11: email verification gates organization creation (FR-1/FR-2).
        if (! $request->user()->hasVerifiedEmail()) {
            abort(403, 'Verifikasi email Anda terlebih dahulu sebelum membuat organisasi.');
        }

        $organization = $action->execute(
            $request->user(),
            $request->validated('name'),
            $request->validated('organization_type'),
            $request->validated('legal_name'),
        );

        return response()->json(['data' => $organization, 'message' => 'Organisasi berhasil dibuat.'], 201);
    }

    public function show(Request $request, string $id): JsonResponse
    {
        $this->authorizeOrganization($request, $id);

        return response()->json(['data' => Organization::findOrFail($id)]);
    }

    public function update(UpdateOrganizationRequest $request, string $id): JsonResponse
    {
        $this->authorizeOrganization($request, $id, minRank: 4);

        $organization = Organization::findOrFail($id);
        $organization->update($request->validated());

        return response()->json(['data' => $organization, 'message' => 'Organisasi diperbarui.']);
    }

    public function members(Request $request, string $id): JsonResponse
    {
        $this->authorizeOrganization($request, $id);

        $members = OrganizationMember::where('organization_id', $id)
            ->where('status', 'active')
            ->with('user:id,name,email', 'role:id,name,slug')
            ->get(['id', 'user_id', 'role_id', 'status', 'joined_at']);

        return response()->json(['data' => $members]);
    }

    public function inviteMember(InviteMemberRequest $request, string $id, InviteMemberAction $action): JsonResponse
    {
        $membership = $this->authorizeOrganization($request, $id, minRank: 4);

        try {
            $invitation = $action->execute(
                Organization::findOrFail($id),
                $request->user(),
                $request->validated('email'),
                Role::findOrFail($request->validated('role_id')),
                $membership,
            );
        } catch (\DomainException $e) {
            throw ValidationException::withMessages(['role_id' => $e->getMessage()]);
        }

        // H5 (audit): token is delivered by email only — never echoed in the
        // API response.
        return response()->json([
            'data' => ['id' => $invitation->id, 'email' => $invitation->email],
            'message' => 'Undangan terkirim.',
        ], 201);
    }

    public function revokeInvitation(Request $request, string $id, string $invitationId): JsonResponse
    {
        $this->authorizeOrganization($request, $id, minRank: 4);

        $invitation = OrganizationInvitation::where('organization_id', $id)
            ->where('status', 'pending')
            ->findOrFail($invitationId);

        $invitation->update(['status' => 'revoked']);

        return response()->json(['message' => 'Undangan dibatalkan.']);
    }

    /** Tier 3: public referral landing — resolve a referral code to org info. */
    public function resolveReferral(Request $request, string $code): JsonResponse
    {
        $organization = Organization::where('referral_code', $code)
            ->where('status', 'active')
            ->firstOrFail();

        $profile = BusinessProfile::forOrganization($organization)->first();

        return response()->json(['data' => [
            'ref' => $code,
            'organization_name' => $organization->name,
            'profile_name' => $profile?->display_name,
            'profile_slug' => $profile?->slug,
        ]]);
    }

    public function acceptInvitation(Request $request, AcceptInvitationAction $action): JsonResponse
    {
        $validated = $request->validate(['token' => ['required', 'string']]);

        try {
            $invitation = $action->execute($validated['token'], $request->user()->id);
        } catch (\DomainException $e) {
            throw ValidationException::withMessages(['token' => $e->getMessage()]);
        }

        return response()->json(['data' => $invitation, 'message' => 'Undangan diterima.'], 200);
    }

    public function updateMemberRole(UpdateMemberRoleRequest $request, string $id, string $memberId, ChangeMemberRoleAction $action): JsonResponse
    {
        $actorMembership = $this->authorizeOrganization($request, $id, minRank: 4);

        $member = OrganizationMember::where('organization_id', $id)
            ->where('status', 'active')
            ->findOrFail($memberId);

        try {
            $member = $action->execute($member, Role::findOrFail($request->validated('role_id')), $actorMembership);
        } catch (\DomainException $e) {
            throw ValidationException::withMessages(['role_id' => $e->getMessage()]);
        }

        return response()->json(['data' => $member, 'message' => 'Peran anggota diperbarui.']);
    }

    public function removeMember(Request $request, string $id, string $memberId, RemoveMemberAction $action): JsonResponse
    {
        $actorMembership = $this->authorizeOrganization($request, $id, minRank: 4);

        $member = OrganizationMember::where('organization_id', $id)
            ->where('status', 'active')
            ->findOrFail($memberId);

        try {
            $action->execute($member, $actorMembership);
        } catch (\DomainException $e) {
            throw ValidationException::withMessages(['member' => $e->getMessage()]);
        }

        return response()->json(['message' => 'Anggota dikeluarkan dari organisasi.']);
    }

    /**
     * Verifies the authenticated user is an active member of the organization
     * (and holds at least the requested rank). Returns the membership for
     * downstream actions. AD-6: the backend is the gate, never the UI.
     */
    private function authorizeOrganization(Request $request, string $organizationId, int $minRank = 0): OrganizationMember
    {
        $membership = $request->user()->memberships()
            ->where('organization_id', $organizationId)
            ->where('status', 'active')
            ->first();

        if (! $membership) {
            abort(403, 'Anda bukan anggota organisasi ini.');
        }

        if ($minRank > 0) {
            $rank = RoleRank::rankOf($membership);

            if ($rank < $minRank) {
                abort(403, 'Peran Anda tidak cukup untuk aksi ini.');
            }
        }

        return $membership;
    }
}
