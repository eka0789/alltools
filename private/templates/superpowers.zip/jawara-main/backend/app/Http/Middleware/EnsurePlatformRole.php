<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * AD-6: platform-level gate for admin endpoints. Requires an ACTIVE
 * membership whose role is platform-scoped (Super Admin, Moderator).
 */
class EnsurePlatformRole
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        $isPlatformMember = $user->memberships()
            ->join('roles', 'roles.id', '=', 'organization_members.role_id')
            ->where('roles.scope', 'platform')
            ->whereIn('roles.slug', ['super-admin', 'moderator'])
            ->where('organization_members.status', 'active')
            ->exists();

        if (! $isPlatformMember) {
            abort(403, 'Akses khusus moderator platform.');
        }

        return $next($request);
    }
}
