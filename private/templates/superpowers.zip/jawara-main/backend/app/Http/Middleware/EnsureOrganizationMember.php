<?php

namespace App\Http\Middleware;

use App\Models\Organization;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * AD-1/AD-6: organization context resolution. The client sends
 * X-Organization-Id; the server verifies the authenticated user is an ACTIVE
 * member of that organization before the request proceeds. The resolved
 * context is bound for the rest of the request lifecycle.
 */
class EnsureOrganizationMember
{
    public function handle(Request $request, Closure $next): Response
    {
        $organizationId = $request->header('X-Organization-Id');

        if (! $organizationId) {
            return response()->json(['message' => 'Header X-Organization-Id wajib diisi.'], 400);
        }

        $organization = Organization::find($organizationId);

        if (! $organization) {
            return response()->json(['message' => 'Organisasi tidak ditemukan.'], 404);
        }

        // C5 (spec Phase 08): suspended organizations cannot operate. The
        // platform system organization is always active.
        if ($organization->status !== 'active') {
            return response()->json(['message' => 'Organisasi ini sedang ditangguhkan.'], 403);
        }

        $membership = $request->user()->memberships()
            ->where('organization_id', $organization->id)
            ->where('status', 'active')
            ->first();

        if (! $membership) {
            return response()->json(['message' => 'Anda bukan anggota organisasi ini.'], 403);
        }

        $request->attributes->set('organization', $organization);
        $request->attributes->set('membership', $membership);

        return $next($request);
    }
}
