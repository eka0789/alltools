<?php

namespace App\Http\Requests\Organization;

use App\Domain\Identity\RoleRank;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class InviteMemberRequest extends FormRequest
{
    /**
     * AD-6: otorisasi SEBELUM validasi — rank management dicek di sini agar
     * pemanggil tanpa izin tidak menerima bocoran skema validasi (audit 2026-11-24).
     */
    public function authorize(): bool
    {
        $membership = $this->user()?->memberships()
            ->where('organization_id', (string) $this->route('id'))
            ->where('status', 'active')
            ->first();

        if (! $membership) {
            abort(403, 'Anda bukan anggota organisasi ini.');
        }

        if (RoleRank::rankOf($membership) < RoleRank::MANAGEMENT_MIN) {
            abort(403, 'Peran Anda tidak cukup untuk aksi ini.');
        }

        return true;
    }

    /** @return array<string, array<int, mixed>> */
    public function rules(): array
    {
        return [
            'email' => ['required', 'email', 'max:255'],
            // Peran platform tidak dapat diundang ke organisasi: tolak di
            // validasi (422), bukan gagal 500 dari domain action.
            'role_id' => [
                'required',
                'integer',
                Rule::exists('roles', 'id')->where('scope', 'organization'),
            ],
        ];
    }

    /** @return array<string, string> */
    public function messages(): array
    {
        return [
            'role_id.exists' => 'Peran tersebut tidak dapat diberikan pada tingkat organisasi.',
        ];
    }
}
