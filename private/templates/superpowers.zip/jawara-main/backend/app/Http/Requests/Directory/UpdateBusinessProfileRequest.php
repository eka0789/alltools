<?php

namespace App\Http\Requests\Directory;

use Illuminate\Foundation\Http\FormRequest;

class UpdateBusinessProfileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, array<int, mixed>> */
    public function rules(): array
    {
        return [
            'display_name' => ['required', 'string', 'max:200'],
            'description' => ['nullable', 'string', 'max:5000'],
            'category_id' => ['nullable', 'integer', 'exists:business_categories,id'],
            'location_id' => ['nullable', 'integer', 'exists:business_locations,id'],
            'website_url' => ['nullable', 'url', 'max:255', 'regex:#^https?://#i'], // C3: block javascript:/data: schemes
            'public_email' => ['nullable', 'email', 'max:255'],
            'public_phone' => ['nullable', 'string', 'max:30'],
            'full_address' => ['nullable', 'string', 'max:500'],
            'status' => ['sometimes', 'in:draft,published,archived'],
        ];
    }
}
