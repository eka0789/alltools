<?php

namespace App\Console\Commands;

use App\Domain\Shared\Search\SyncMeilisearchAction;
use Illuminate\Console\Command;

/**
 * ROADMAP: Meilisearch indexing pipeline. Pushes published catalog &
 * directory entries so SEARCH_DRIVER=meilisearch has data. Safe no-op with
 * a clear notice when Meilisearch is not configured (default driver is the
 * MariaDB FULLTEXT DatabaseSearchService).
 */
class SyncSearchIndexCommand extends Command
{
    protected $signature = 'jawara:search-index';

    protected $description = 'Sync published catalog & directory entries into Meilisearch indexes';

    public function handle(SyncMeilisearchAction $action): int
    {
        try {
            $result = $action->execute();
        } catch (\RuntimeException $e) {
            $this->error($e->getMessage());

            return self::FAILURE;
        }

        if ($result['skipped']) {
            $this->warn('Meilisearch tidak dikonfigurasi ('.$result['reason'].') — sync dilewati. Driver aktif: database (FULLTEXT).');

            return self::SUCCESS;
        }

        $this->info(
            "Meilisearch ter-sync: {$result['indexed']['products']} produk, ".
            "{$result['indexed']['business_profiles']} profil bisnis."
        );

        return self::SUCCESS;
    }
}
