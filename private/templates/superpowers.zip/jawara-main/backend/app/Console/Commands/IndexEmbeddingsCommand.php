<?php

namespace App\Console\Commands;

use App\Domain\AI\Actions\BuildEmbeddingIndexAction;
use App\Domain\AI\Exceptions\AiUnavailableException;
use Illuminate\Console\Command;

/**
 * Tier 5: nightly semantic index refresh. Scheduled daily (routes/console.php);
 * safe to run ad hoc. No-ops with a friendly notice when AI is not configured
 * so production cron never fails just because the AI feature is off.
 */
class IndexEmbeddingsCommand extends Command
{
    protected $signature = 'jawara:ai-index-embeddings {--limit=100 : Max entries to embed in one run}';

    protected $description = 'Build semantic embeddings for published catalog & directory entries (Tier 5)';

    public function handle(BuildEmbeddingIndexAction $action): int
    {
        try {
            $result = $action->execute((int) $this->option('limit'));
        } catch (AiUnavailableException $e) {
            $this->warn('Embedding gagal: '.$e->getMessage());

            return self::FAILURE;
        }

        if ($result['skipped']) {
            $this->warn('AI belum dikonfigurasi ('.$result['reason'].') — indexing dilewati. Set AI_PROVIDER=gemini + GEMINI_API_KEY untuk mengaktifkan.');

            return self::SUCCESS;
        }

        $this->info("Embeddings diperbarui untuk {$result['indexed']} entri.");

        return self::SUCCESS;
    }
}
