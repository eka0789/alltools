<?php

namespace App\Console\Commands;

use App\Enums\QuotationStatus;
use App\Models\Quotation;
use Illuminate\Console\Command;

/**
 * Expires quotations past their validity window (Phase 11 operational
 * hygiene). Scheduled daily; see routes/console.php.
 */
class ExpireQuotationsCommand extends Command
{
    protected $signature = 'quotations:expire {--dry-run : Report without changing}';

    protected $description = 'Menandai penawaran yang telah melewati masa validitas sebagai expired';

    public function handle(): int
    {
        $expired = Quotation::query()
            ->whereIn('status', [QuotationStatus::Submitted->value, QuotationStatus::Revised->value])
            ->where('valid_until', '<', now());

        $count = $expired->count();

        if ($count === 0) {
            $this->info('Tidak ada penawaran kedaluwarsa.');

            return self::SUCCESS;
        }

        if ($this->option('dry-run')) {
            $this->info("{$count} penawaran akan ditandai expired (dry-run).");

            return self::SUCCESS;
        }

        $expired->update(['status' => QuotationStatus::Expired->value]);
        $this->info("{$count} penawaran ditandai expired.");

        return self::SUCCESS;
    }
}
