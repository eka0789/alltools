<?php

namespace App\Console\Commands;

use App\Mail\GenericNotificationMail;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

/**
 * Tier 3: email onboarding sequence (spec Phase 10 growth features).
 * Day 1: welcome + complete profile; Day 3: publish catalog; Day 7: send RFQ.
 * Skips users who already joined an organization (they are onboarded).
 */
class SendOnboardingEmailsCommand extends Command
{
    protected $signature = 'jawara:send-onboarding-emails';

    protected $description = 'Kirim email onboarding hari 1/3/7 untuk pengguna baru yang belum bergabung dengan organisasi';

    private const STAGES = [
        1 => [
            'days_ago' => 1,
            'subject' => 'Selamat datang di JAWARA — lengkapi profil bisnis Anda',
            'body' => 'Halo %s! Langkah pertama agar bisnis Anda ditemukan pembeli: buat organisasi dan lengkapi profil bisnis (deskripsi, kategori, lokasi, kontak). Profil lengkap tampil lebih atas di direktori JAWARA.',
        ],
        3 => [
            'days_ago' => 3,
            'subject' => 'Tambahkan produk atau jasa Anda ke katalog',
            'body' => 'Halo %s! Katalog adalah etalase Anda. Tambahkan produk/jasa dengan deskripsi dan harga yang jelas agar pembeli dapat menemukan dan menghubungi Anda.',
        ],
        7 => [
            'days_ago' => 7,
            'subject' => 'Butuh supplier? Kirim RFQ pertama Anda',
            'body' => 'Halo %s! Gunakan JAWARA untuk pengadaan: buat RFQ, undang supplier, bandingkan penawaran, dan terbitkan PO — semuanya terdokumentasi.',
        ],
    ];

    public function handle(): int
    {
        $sent = 0;

        foreach (self::STAGES as $stage => $config) {
            $users = User::query()
                ->where('onboarding_stage', '<', $stage)
                ->where('created_at', '<=', now()->subDays($config['days_ago']))
                ->whereDoesntHave('memberships', fn ($q) => $q->where('status', 'active'))
                ->limit(200)
                ->get();

            foreach ($users as $user) {
                // Audit infra: queued Mailable (sebelumnya sync Mail::raw —
                // SMTP latency menahan loop command).
                Mail::to($user->email)->send(
                    new GenericNotificationMail(
                        $config['subject'],
                        sprintf($config['body'], $user->name),
                    ),
                );

                $user->update(['onboarding_stage' => $stage]);
                $sent++;
            }
        }

        $this->info("{$sent} email onboarding dikirim.");

        return self::SUCCESS;
    }
}
