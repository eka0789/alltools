<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * Audit infra 2026-11-22: onboarding + invitation emails sebelumnya sync
 * (Mail::raw) — registrasi/invite menunggu SMTP latency. Kini queued via
 * database/redis queue (QUEUE_CONNECTION).
 */
class GenericNotificationMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(
        public readonly string $subjectLine,
        public readonly string $bodyText,
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(subject: $this->subjectLine);
    }

    public function content(): Content
    {
        return new Content(text: 'emails.generic-notification', with: [
            'bodyText' => $this->bodyText,
        ]);
    }
}
