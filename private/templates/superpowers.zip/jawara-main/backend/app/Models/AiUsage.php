<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Tier 5 (JAWARA Pintar): immutable ledger of successful LLM generations.
 * Serves both as the daily-quota source of truth (per organization + feature)
 * and as cost visibility (token counts per model).
 */
class AiUsage extends Model
{
    use HasUuids;

    protected $table = 'ai_usage';

    protected $fillable = [
        'organization_id',
        'user_id',
        'feature',
        'model',
        'input_tokens',
        'output_tokens',
    ];

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
