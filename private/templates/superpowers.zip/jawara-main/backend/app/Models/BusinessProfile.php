<?php

namespace App\Models;

use App\Enums\VerificationStatus;
use App\Models\Concerns\BelongsToOrganization;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class BusinessProfile extends Model
{
    use BelongsToOrganization, HasFactory, HasUuids, SoftDeletes;

    protected $fillable = [
        'organization_id',
        'category_id',
        'location_id',
        'display_name',
        'slug',
        'description',
        'logo_path',
        'website_url',
        'public_email',
        'public_phone',
        'full_address',
        'verification_status',
        'verified_at',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'verification_status' => VerificationStatus::class,
            'verified_at' => 'datetime',
        ];
    }

    /** @return BelongsTo<BusinessCategory, $this> */
    public function category(): BelongsTo
    {
        return $this->belongsTo(BusinessCategory::class, 'category_id');
    }

    /** @return BelongsTo<BusinessLocation, $this> */
    public function location(): BelongsTo
    {
        return $this->belongsTo(BusinessLocation::class, 'location_id');
    }

    /** @return HasMany<BusinessReview, $this> */
    public function reviews(): HasMany
    {
        return $this->hasMany(BusinessReview::class);
    }

    /**
     * Tier 1: profile completeness percentage (spec Phase 10 — profile
     * completion drives directory quality). Weighted over public fields.
     */
    public function completenessPercentage(): int
    {
        $checks = [
            'display_name' => 10,
            'description' => 25,
            'category_id' => 15,
            'location_id' => 15,
            'logo_path' => 10,
            'public_email' => 10,
            'public_phone' => 5,
            'website_url' => 5,
            'full_address' => 5,
        ];

        $score = 0;
        foreach ($checks as $field => $weight) {
            if (filled($this->{$field})) {
                $score += $weight;
            }
        }

        return $score;
    }

    public function scopePublished(Builder $query): Builder
    {
        return $query->where('status', 'published');
    }
}
