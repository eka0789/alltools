<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

/**
 * Tier 5: stored embedding vector for one public entity (published product
 * or business profile). Only PUBLIC data is embedded — never private
 * procurement records. Entities are re-verified as published at query time,
 * so an embedding left behind by an unpublication never surfaces.
 */
class AiEmbedding extends Model
{
    use HasUuids;

    protected $table = 'ai_embeddings';

    public const TYPE_PRODUCT = 'product';

    public const TYPE_BUSINESS = 'business_profile';

    protected $fillable = [
        'entity_type',
        'entity_id',
        'embedding',
        'model',
        'dimensions',
    ];

    protected $casts = [
        'embedding' => 'array',
    ];
}
