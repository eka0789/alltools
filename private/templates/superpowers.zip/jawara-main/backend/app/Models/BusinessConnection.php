<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BusinessConnection extends Model
{
    use HasUuids;

    protected $fillable = [
        'requester_organization_id',
        'target_organization_id',
        'status',
        'connected_at',
    ];

    protected function casts(): array
    {
        return [
            'connected_at' => 'datetime',
        ];
    }

    /** @return BelongsTo<Organization, $this> */
    public function requester(): BelongsTo
    {
        return $this->belongsTo(Organization::class, 'requester_organization_id');
    }

    /** @return BelongsTo<Organization, $this> */
    public function target(): BelongsTo
    {
        return $this->belongsTo(Organization::class, 'target_organization_id');
    }
}
