<?php

namespace App\Models\Concerns;

use App\Models\Organization;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * AD-1: organization-owned records must be scoped to their organization.
 *
 * Apply to every model with an organization_id column. Listing queries MUST
 * go through forOrganization(); policies additionally verify membership, so
 * this trait is the query-level guarantee and the policy is the rule-level one.
 */
trait BelongsToOrganization
{
    /**
     * Column referencing the owning organization. Multi-sided documents
     * override this property (e.g. Rfq::buyer_organization_id,
     * Quotation::supplier_organization_id).
     */
    protected function organizationForeignKey(): string
    {
        return property_exists($this, 'organizationForeignKey')
            ? $this->organizationForeignKey
            : 'organization_id';
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class, $this->organizationForeignKey());
    }

    public function scopeForOrganization(Builder $query, string|Organization $organization): Builder
    {
        $id = $organization instanceof Organization ? $organization->id : $organization;

        return $query->where($this->getTable().'.'.$this->organizationForeignKey(), $id);
    }
}
