<?php

namespace App\Domain\AI\Exceptions;

use RuntimeException;

/**
 * Fail-closed signal: AI is not configured, unreachable, or refused the
 * request. Controllers map this to a 503 with an Indonesian user message.
 */
class AiUnavailableException extends RuntimeException
{
    public static function unconfigured(): self
    {
        return new self('Fitur AI belum aktif di platform ini.');
    }

    public static function unreachable(): self
    {
        return new self('Layanan AI sedang tidak tersedia. Silakan coba lagi nanti.');
    }

    public static function blocked(string $reason): self
    {
        return new self("Permintaan tidak dapat diproses karena kebijakan konten AI ({$reason}).");
    }

    public static function emptyCandidate(): self
    {
        return new self('AI tidak menghasilkan jawaban. Silakan coba lagi.');
    }
}
