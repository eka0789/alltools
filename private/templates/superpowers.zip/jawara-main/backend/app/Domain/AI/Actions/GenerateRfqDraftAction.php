<?php

namespace App\Domain\AI\Actions;

use App\Domain\AI\Contracts\AiProvider;
use App\Domain\AI\Exceptions\AiInvalidOutputException;
use App\Domain\AI\Services\AiQuotaService;
use App\Models\Organization;
use App\Models\User;

/**
 * Tier 5 (JAWARA Pintar): turns a buyer's natural-language description into
 * a structured RFQ draft. Human-in-the-loop by design — the action NEVER
 * writes RFQ tables; the user reviews and saves via the existing RFQ
 * endpoints (AD-4 state machine untouched). Output is validated before it
 * leaves the domain; unparseable model answers fail closed.
 */
final class GenerateRfqDraftAction
{
    /** Gemini responseSchema (OpenAPI subset, uppercase types). */
    private const SCHEMA = [
        'type' => 'OBJECT',
        'properties' => [
            'title' => ['type' => 'STRING'],
            'description' => ['type' => 'STRING'],
            'category_suggestion' => ['type' => 'STRING'],
            'items' => [
                'type' => 'ARRAY',
                'items' => [
                    'type' => 'OBJECT',
                    'properties' => [
                        'name' => ['type' => 'STRING'],
                        'quantity' => ['type' => 'NUMBER'],
                        'unit' => ['type' => 'STRING'],
                    ],
                    'required' => ['name', 'quantity', 'unit'],
                ],
            ],
        ],
        'required' => ['title', 'description', 'items'],
    ];

    private const SYSTEM_PROMPT = <<<'TXT'
Kamu perancang dokumen pengadaan untuk platform B2B JAWARA yang menghubungkan UMKM Indonesia.
Ubah deskripsi kebutuhan pengguna menjadi draf RFQ profesional dalam Bahasa Indonesia.
Aturan:
- JANGAN mengarang harga atau biaya apa pun.
- Judul harus spesifik dan singkat (maksimal 120 karakter).
- description merangkum kebutuhan, konteks penggunaan, dan lokasi/ketentuan pengiriman jika disebutkan.
- Pecah kebutuhan menjadi item terpisah dengan quantity numerik positif dan unit wajar (pcs, kg, liter, box, unit, paket, meter).
- Jika kebutuhan tidak lengkap, gunakan interpretasi paling masuk akal dan tulis asumsinya pada akhir description dengan awalan "Catatan:".
- category_suggestion adalah kategori bisnis JAWARA yang paling cocok (contoh: "Katering & Pangan", "Konstruksi", "ATK & Percetakan").
- Hanya keluarkan JSON sesuai skema.
TXT;

    public function __construct(
        private readonly AiProvider $ai,
        private readonly AiQuotaService $quota,
    ) {}

    /**
     * @return array{title: string, description: ?string, category_suggestion: ?string, items: array<int, array{name: string, quantity: float, unit: string}>}
     */
    public function execute(Organization $organization, User $user, string $description): array
    {
        $this->quota->assertWithinQuota($organization, 'rfq_draft');

        $result = $this->ai->generate(
            self::SYSTEM_PROMPT,
            [['role' => 'user', 'content' => $description]],
            self::SCHEMA,
            ['temperature' => 0.4, 'maxOutputTokens' => 2048],
        );

        $raw = json_decode($result->text, true);

        if (! is_array($raw)) {
            throw new AiInvalidOutputException('AI menghasilkan format yang tidak valid. Silakan coba lagi.');
        }

        $draft = $this->validate($raw);

        $this->quota->record($organization, $user, 'rfq_draft', $result);

        return $draft;
    }

    /**
     * @return array{title: string, description: ?string, category_suggestion: ?string, items: array<int, array{name: string, quantity: float, unit: string}>}
     */
    private function validate(array $raw): array
    {
        $title = isset($raw['title']) && is_string($raw['title']) ? trim($raw['title']) : '';
        $description = isset($raw['description']) && is_string($raw['description']) ? trim($raw['description']) : '';
        $category = isset($raw['category_suggestion']) && is_string($raw['category_suggestion']) ? trim($raw['category_suggestion']) : '';

        if ($title === '' || mb_strlen($title) > 150) {
            throw new AiInvalidOutputException('AI menghasilkan judul RFQ yang tidak valid. Silakan coba lagi.');
        }

        if (mb_strlen($description) > 2000) {
            $description = mb_substr($description, 0, 2000);
        }

        $items = [];
        if (isset($raw['items']) && is_array($raw['items'])) {
            foreach (array_slice($raw['items'], 0, 20) as $item) {
                if (! is_array($item)) {
                    continue;
                }

                $name = isset($item['name']) && is_string($item['name']) ? trim($item['name']) : '';
                $quantity = $item['quantity'] ?? null;
                $unit = isset($item['unit']) && is_string($item['unit']) ? trim($item['unit']) : '';

                if ($name === '' || mb_strlen($name) > 150 || $unit === '' || mb_strlen($unit) > 30) {
                    continue;
                }

                if (! is_numeric($quantity) || (float) $quantity <= 0) {
                    continue;
                }

                $items[] = [
                    'name' => $name,
                    'quantity' => round((float) $quantity, 2),
                    'unit' => $unit,
                ];
            }
        }

        if ($items === []) {
            throw new AiInvalidOutputException('AI tidak menghasilkan item RFQ yang valid. Silakan coba lagi atau susun manual.');
        }

        return [
            'title' => $title,
            'description' => $description !== '' ? $description : null,
            'category_suggestion' => $category !== '' ? $category : null,
            'items' => $items,
        ];
    }
}
