<?php

namespace App\Domain\AI\Providers;

use App\Domain\AI\Contracts\AiProvider;
use App\Domain\AI\Exceptions\AiUnavailableException;
use App\Domain\AI\Support\AiResult;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Tier 5 (JAWARA Pintar): Google Gemini driver (generativelanguage REST API).
 * Activated by AI_PROVIDER=gemini plus GEMINI_API_KEY. Fail-closed like the
 * XenditProvider: any missing credential, HTTP failure, or safety block
 * throws AiUnavailableException — the caller never receives a fabricated
 * or empty answer.
 *
 * Structured output uses generationConfig.responseMimeType + responseSchema
 * (https://aistudio.google.com/docs/structured-output).
 */
class GeminiProvider implements AiProvider
{
    private const MODEL_BASE = 'https://generativelanguage.googleapis.com/v1beta/models/%s';

    public function key(): string
    {
        return 'gemini';
    }

    public function generate(string $systemPrompt, array $messages, ?array $schema = null, array $options = []): AiResult
    {
        $apiKey = (string) config('jawara.ai.key', '');
        $model = (string) config('jawara.ai.model', 'gemini-2.5-flash');

        // Fail-closed: without credentials there is nothing to call.
        if ($apiKey === '') {
            Log::error('ai.gemini.key_missing');

            throw AiUnavailableException::unconfigured();
        }

        $payload = [
            'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
            'contents' => array_map(
                fn (array $message): array => [
                    // API contract uses user|assistant; Gemini speaks user|model.
                    'role' => $message['role'] === 'assistant' || $message['role'] === 'model' ? 'model' : 'user',
                    'parts' => [['text' => (string) $message['content']]],
                ],
                $messages,
            ),
            'generationConfig' => [
                'temperature' => (float) ($options['temperature'] ?? 0.4),
                'maxOutputTokens' => (int) ($options['maxOutputTokens'] ?? 2048),
            ],
        ];

        if ($schema !== null) {
            $payload['generationConfig']['responseMimeType'] = 'application/json';
            $payload['generationConfig']['responseSchema'] = $schema;
        }

        $response = Http::withHeaders(['x-goog-api-key' => $apiKey])
            ->acceptJson()
            ->timeout(45)
            ->post(sprintf(self::MODEL_BASE, $model).':generateContent', $payload);

        if ($response->failed()) {
            Log::error('ai.gemini.request_failed', [
                'status' => $response->status(),
                'body' => $response->json(),
            ]);

            throw AiUnavailableException::unreachable();
        }

        $blockReason = $response->json('promptFeedback.blockReason');

        if ($blockReason !== null) {
            Log::warning('ai.gemini.blocked', ['reason' => $blockReason]);

            throw AiUnavailableException::blocked((string) $blockReason);
        }

        $text = collect($response->json('candidates.0.content.parts', []))
            ->pluck('text')
            ->filter()
            ->implode('');

        if ($text === '') {
            Log::error('ai.gemini.empty_candidate', [
                'finish_reason' => $response->json('candidates.0.finishReason'),
            ]);

            throw AiUnavailableException::emptyCandidate();
        }

        return new AiResult(
            text: $text,
            inputTokens: (int) $response->json('usageMetadata.promptTokenCount', 0),
            outputTokens: (int) $response->json('usageMetadata.candidatesTokenCount', 0),
            model: $model,
        );
    }

    public function embed(string $text, string $taskType = 'RETRIEVAL_DOCUMENT'): array
    {
        $apiKey = (string) config('jawara.ai.key', '');
        $model = (string) config('jawara.ai.embedding_model', 'gemini-embedding-001');

        // Fail-closed: without credentials there is nothing to call.
        if ($apiKey === '') {
            Log::error('ai.gemini.key_missing');

            throw AiUnavailableException::unconfigured();
        }

        $response = Http::withHeaders(['x-goog-api-key' => $apiKey])
            ->acceptJson()
            ->timeout(30)
            ->post(sprintf(self::MODEL_BASE, $model).':embedContent', [
                'model' => 'models/'.$model,
                'content' => ['parts' => [['text' => $text]]],
                'taskType' => $taskType,
            ]);

        if ($response->failed()) {
            Log::error('ai.gemini.embed_failed', [
                'status' => $response->status(),
                'body' => $response->json(),
            ]);

            throw AiUnavailableException::unreachable();
        }

        $values = $response->json('embedding.values');

        if (! is_array($values) || $values === []) {
            Log::error('ai.gemini.embed_empty');

            throw AiUnavailableException::emptyCandidate();
        }

        return array_map(fn ($value): float => (float) $value, $values);
    }
}
