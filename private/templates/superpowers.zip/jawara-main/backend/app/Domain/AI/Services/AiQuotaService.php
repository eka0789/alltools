<?php

namespace App\Domain\AI\Services;

use App\Domain\AI\Exceptions\AiQuotaExceededException;
use App\Domain\AI\Support\AiResult;
use App\Domain\Billing\Services\EntitlementService;
use App\Models\AiUsage;
use App\Models\Organization;
use App\Models\User;

/**
 * Daily per-organization AI allowances (Tier 5). Quota precedence:
 * plan entitlement (plan_features key "ai_<feature>", monetization — paid
 * plans raise quotas, 0 disables a feature) → platform default
 * (config/jawara.php → ai.quotas). The ai_usage ledger is the source of
 * truth for usage: quota checks count today's successful generations.
 */
final class AiQuotaService
{
    public const FEATURES = ['assistant', 'rfq_draft', 'product_description', 'quotation_comparison'];

    public function __construct(
        private readonly EntitlementService $entitlements,
    ) {}

    /** Whether the AI subsystem is wired to a real provider. */
    public static function providerEnabled(): bool
    {
        return (string) config('jawara.ai.driver') !== 'null'
            && (string) config('jawara.ai.key') !== '';
    }

    public function featureEnabled(Organization $organization, string $feature): bool
    {
        return self::providerEnabled() && $this->dailyQuota($organization, $feature) > 0;
    }

    /** Effective daily quota for the organization (plan entitlement first). */
    public function dailyQuota(Organization $organization, string $feature): int
    {
        $planLimit = $this->entitlements->limitFor($organization, "ai_{$feature}");

        return $planLimit ?? self::dailyQuotaDefault($feature);
    }

    /** Platform default quota when no plan feature row applies. */
    public static function dailyQuotaDefault(string $feature): int
    {
        return (int) config("jawara.ai.quotas.{$feature}", 0);
    }

    public function remainingToday(Organization $organization, string $feature): int
    {
        return max(0, $this->dailyQuota($organization, $feature) - $this->usedToday($organization->id, $feature));
    }

    /**
     * @throws AiQuotaExceededException when today's allowance is exhausted
     */
    public function assertWithinQuota(Organization $organization, string $feature): void
    {
        if ($this->remainingToday($organization, $feature) <= 0) {
            throw new AiQuotaExceededException(
                "Kuota harian fitur AI \"{$feature}\" untuk organisasi ini sudah habis. Coba lagi besok atau tingkatkan langganan Anda."
            );
        }
    }

    /**
     * Records one successful generation in the immutable usage ledger.
     */
    public function record(Organization $organization, User $user, string $feature, AiResult $result): AiUsage
    {
        return AiUsage::create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'feature' => $feature,
            'model' => $result->model,
            'input_tokens' => $result->inputTokens,
            'output_tokens' => $result->outputTokens,
        ]);
    }

    private function usedToday(string $organizationId, string $feature): int
    {
        // Application clock (not DB CURDATE()) — portable across MariaDB and
        // the sqlite test connection.
        return AiUsage::query()
            ->where('organization_id', $organizationId)
            ->where('feature', $feature)
            ->where('created_at', '>=', now()->startOfDay())
            ->count();
    }
}
