<?php

namespace App\Domain\AI\Exceptions;

use RuntimeException;

/**
 * The organization consumed its daily allowance for this AI feature
 * (quotas in config/jawara.php, ledger in ai_usage). Controllers map
 * this to 429 with a reset hint.
 */
class AiQuotaExceededException extends RuntimeException {}
