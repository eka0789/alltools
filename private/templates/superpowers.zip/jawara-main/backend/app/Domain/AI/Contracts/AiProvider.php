<?php

namespace App\Domain\AI\Contracts;

use App\Domain\AI\Exceptions\AiUnavailableException;
use App\Domain\AI\Support\AiResult;

/**
 * Tier 5 (JAWARA Pintar): LLM provider abstraction. Mirrors the
 * PaymentProvider/SearchService contract pattern — new providers (OpenAI,
 * Claude, local models) plug in as drivers without touching domain actions.
 */
interface AiProvider
{
    public function key(): string;

    /**
     * Runs a generation and returns the raw model text.
     *
     * Messages are role/content pairs; roles are normalized to "user"/"model"
     * by each driver. When $responseSchema is given, the driver must request
     * structured (JSON) output conforming to that schema.
     *
     * @param  array<int, array{role: string, content: string}>  $messages
     * @param  array<string, mixed>  $schema  Gemini-style JSON schema (uppercase types)
     * @param  array{temperature?: float, maxOutputTokens?: int}  $options
     *
     * @throws AiUnavailableException when the provider cannot serve the request
     */
    public function generate(string $systemPrompt, array $messages, ?array $schema = null, array $options = []): AiResult;

    /**
     * Embeds one text into a vector (semantic search / retrieval grounding).
     * $taskType tunes the embedding for its purpose (document indexing vs
     * query embedding) — provider-specific, ignored by drivers without it.
     *
     * @return array<int, float>
     *
     * @throws AiUnavailableException when the provider cannot serve the request
     */
    public function embed(string $text, string $taskType = 'RETRIEVAL_DOCUMENT'): array;
}
