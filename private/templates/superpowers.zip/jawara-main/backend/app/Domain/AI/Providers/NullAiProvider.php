<?php

namespace App\Domain\AI\Providers;

use App\Domain\AI\Contracts\AiProvider;
use App\Domain\AI\Exceptions\AiUnavailableException;
use App\Domain\AI\Support\AiResult;

/**
 * Default driver when no AI provider is configured (AI_PROVIDER unset or
 * GEMINI_API_KEY empty). Every generation fails closed with a stable
 * message; the capabilities endpoint lets the frontend hide AI affordances
 * instead of surfacing errors.
 */
class NullAiProvider implements AiProvider
{
    public function key(): string
    {
        return 'null';
    }

    public function generate(string $systemPrompt, array $messages, ?array $schema = null, array $options = []): AiResult
    {
        throw AiUnavailableException::unconfigured();
    }

    public function embed(string $text, string $taskType = 'RETRIEVAL_DOCUMENT'): array
    {
        throw AiUnavailableException::unconfigured();
    }
}
