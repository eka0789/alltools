<?php

namespace App\Domain\AI\Exceptions;

use RuntimeException;

/**
 * The model returned content that did not pass post-generation validation
 * (broken JSON, missing fields, absurd values). AI output is data-only and
 * must never reach the caller unvalidated.
 */
class AiInvalidOutputException extends RuntimeException {}
