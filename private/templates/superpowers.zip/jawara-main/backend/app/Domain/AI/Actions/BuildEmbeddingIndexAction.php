<?php

namespace App\Domain\AI\Actions;

use App\Domain\AI\Contracts\AiProvider;
use App\Domain\AI\Services\AiQuotaService;
use App\Models\AiEmbedding;
use App\Models\BusinessProfile;
use App\Models\Product;

/**
 * Tier 5: builds/refreshes semantic embeddings for PUBLIC catalog and
 * directory entries (published only). Idempotent upserts — one row per
 * entity, skipped when already indexed with the current model. Runs via the
 * jawara:ai-index-embeddings command (scheduled nightly). Never touches
 * private data; entities that later get unpublished simply stop appearing
 * in semantic results because queries re-verify publication.
 */
final class BuildEmbeddingIndexAction
{
    private const MAX_TEXT_LENGTH = 2000;

    public function __construct(private readonly AiProvider $ai) {}

    /**
     * @return array{indexed: int, skipped: bool, reason?: string}
     */
    public function execute(int $batchLimit = 100): array
    {
        if (! AiQuotaService::providerEnabled()) {
            return ['indexed' => 0, 'skipped' => true, 'reason' => 'AI belum dikonfigurasi'];
        }

        $model = (string) config('jawara.ai.embedding_model', 'gemini-embedding-001');
        $existing = AiEmbedding::query()
            ->where('model', $model)
            ->pluck('entity_id')
            ->all();

        $targets = collect()
            ->merge($this->productTargets($existing))
            ->merge($this->businessTargets($existing))
            ->take(max(1, $batchLimit));

        $indexed = 0;

        foreach ($targets as $target) {
            $vector = $this->ai->embed(mb_substr($target['text'], 0, self::MAX_TEXT_LENGTH));

            AiEmbedding::query()->updateOrCreate(
                ['entity_type' => $target['type'], 'entity_id' => $target['id']],
                ['embedding' => $vector, 'model' => $model, 'dimensions' => count($vector)],
            );

            $indexed++;
        }

        return ['indexed' => $indexed, 'skipped' => false];
    }

    /**
     * @param  array<int, string>  $existing  entity ids already indexed with this model
     * @return array<int, array{type: string, id: string, text: string}>
     */
    private function productTargets(array $existing): array
    {
        return Product::query()
            ->published()
            ->get(['id', 'name', 'description'])
            ->reject(fn ($product) => in_array($product->id, $existing, true))
            ->map(fn ($product): array => [
                'type' => AiEmbedding::TYPE_PRODUCT,
                'id' => $product->id,
                'text' => $product->name."\n".($product->description ?? ''),
            ])
            ->values()
            ->all();
    }

    /**
     * @param  array<int, string>  $existing
     * @return array<int, array{type: string, id: string, text: string}>
     */
    private function businessTargets(array $existing): array
    {
        return BusinessProfile::query()
            ->published()
            ->get(['id', 'display_name', 'description'])
            ->reject(fn ($profile) => in_array($profile->id, $existing, true))
            ->map(fn ($profile): array => [
                'type' => AiEmbedding::TYPE_BUSINESS,
                'id' => $profile->id,
                'text' => $profile->display_name."\n".($profile->description ?? ''),
            ])
            ->values()
            ->all();
    }
}
