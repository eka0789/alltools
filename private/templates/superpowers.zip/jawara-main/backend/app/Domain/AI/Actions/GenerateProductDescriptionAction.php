<?php

namespace App\Domain\AI\Actions;

use App\Domain\AI\Contracts\AiProvider;
use App\Domain\AI\Exceptions\AiInvalidOutputException;
use App\Domain\AI\Services\AiQuotaService;
use App\Models\Organization;
use App\Models\User;

/**
 * Tier 5 (JAWARA Pintar): marketing/SEO copy for catalog listings. The
 * description is returned for review — the seller edits and saves through
 * the existing catalog endpoints, so AI never mutates listings directly.
 */
final class GenerateProductDescriptionAction
{
    private const SCHEMA = [
        'type' => 'OBJECT',
        'properties' => [
            'description' => ['type' => 'STRING'],
        ],
        'required' => ['description'],
    ];

    private const SYSTEM_PROMPT = <<<'TXT'
Kamu penulis konten katalog untuk platform B2B JAWARA yang menghubungkan UMKM Indonesia.
Tulis deskripsi produk/jasa untuk listing katalog: Bahasa Indonesia, profesional, menarik, 80-150 kata.
Aturan:
- Fokus pada manfaat bisnis dan nilai jual dari data yang diberikan pengguna.
- JANGAN mengarang spesifikasi teknis, sertifikasi, angka produksi, atau jaminan yang tidak diberikan.
- Hindari klaim berlebihan seperti "terbaik", "nomor satu", atau perbandingan dengan merek lain.
- Jangan menyebut harga.
- Hanya keluarkan JSON sesuai skema.
TXT;

    public function __construct(
        private readonly AiProvider $ai,
        private readonly AiQuotaService $quota,
    ) {}

    /**
     * @param  array<int, string>  $keywords
     * @return array{description: string}
     */
    public function execute(Organization $organization, User $user, string $name, ?string $category = null, array $keywords = []): array
    {
        $this->quota->assertWithinQuota($organization, 'product_description');

        $facts = 'Nama produk/jasa: '.$name;
        $facts .= $category !== null && $category !== '' ? "\nKategori: ".$category : '';
        $facts .= $keywords !== [] ? "\nPoin penting: ".implode('; ', $keywords) : '';

        $result = $this->ai->generate(
            self::SYSTEM_PROMPT,
            [['role' => 'user', 'content' => $facts]],
            self::SCHEMA,
            ['temperature' => 0.7, 'maxOutputTokens' => 1024],
        );

        $raw = json_decode($result->text, true);
        $description = isset($raw['description']) && is_string($raw['description']) ? trim($raw['description']) : '';

        if ($description === '' || mb_strlen($description) < 20) {
            throw new AiInvalidOutputException('AI menghasilkan deskripsi yang tidak valid. Silakan coba lagi.');
        }

        if (mb_strlen($description) > 2500) {
            $description = mb_substr($description, 0, 2500);
        }

        $this->quota->record($organization, $user, 'product_description', $result);

        return ['description' => $description];
    }
}
