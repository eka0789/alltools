<?php

namespace App\Domain\AI\Support;

/**
 * Value object for one successful LLM generation. Token counts feed the
 * ai_usage ledger (cost visibility + daily quota source of truth).
 */
final class AiResult
{
    public function __construct(
        public readonly string $text,
        public readonly int $inputTokens,
        public readonly int $outputTokens,
        public readonly string $model,
    ) {}
}
