<?php

namespace App\Domain\AI\Support;

use InvalidArgumentException;

/**
 * Vector helpers for semantic search. Pure PHP cosine similarity — the
 * platform's entity scale (thousands, not millions) makes in-process
 * comparison over the loaded embedding set acceptable.
 */
final class VectorMath
{
    /**
     * Cosine similarity in [-1, 1]. 0 for orthogonal, 1 for identical direction.
     *
     * @param  array<int, float>  $a
     * @param  array<int, float>  $b
     */
    public static function cosine(array $a, array $b): float
    {
        if (count($a) !== count($b) || $a === []) {
            throw new InvalidArgumentException('Vectors must be non-empty and of equal length.');
        }

        $dot = 0.0;
        $normA = 0.0;
        $normB = 0.0;

        foreach ($a as $i => $value) {
            $dot += $value * $b[$i];
            $normA += $value * $value;
            $normB += $b[$i] * $b[$i];
        }

        if ($normA === 0.0 || $normB === 0.0) {
            return 0.0;
        }

        return $dot / (sqrt($normA) * sqrt($normB));
    }
}
