<?php

namespace App\Domain\Procurement\Actions;

use App\Enums\RfqStatus;
use App\Models\AuditLog;
use App\Models\Rfq;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/** Closes an open RFQ to new quotation submissions (FR-6, AD-4). */
class CloseRfqAction
{
    public function execute(Rfq $rfq, User $actor, string $action): Rfq
    {
        $target = $action === 'cancel' ? RfqStatus::Cancelled : RfqStatus::Closed;

        if (! $rfq->status->canTransitionTo($target)) {
            throw ValidationException::withMessages(['status' => "RFQ tidak dapat diubah ke status {$target->value}."]);
        }

        return DB::transaction(function () use ($rfq, $actor, $target) {
            $rfq->update(['status' => $target]);

            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $rfq->buyer_organization_id,
                'action' => $target === RfqStatus::Cancelled ? 'rfq.cancelled' : 'rfq.closed',
                'subject_type' => Rfq::class,
                'subject_id' => $rfq->id,
                'after' => ['status' => $target->value],
            ]);

            return $rfq;
        });
    }
}
