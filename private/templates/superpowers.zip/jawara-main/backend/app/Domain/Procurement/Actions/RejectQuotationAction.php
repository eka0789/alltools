<?php

namespace App\Domain\Procurement\Actions;

use App\Enums\QuotationStatus;
use App\Models\AuditLog;
use App\Models\Quotation;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * H8 (audit): quotation rejection was inline in the controller without a
 * transaction or audit entry. AD-4/AD-8: guarded state transition inside a
 * transaction with an audit trail, consistent with AcceptQuotationAction.
 */
class RejectQuotationAction
{
    public function execute(Quotation $quotation, User $actor): Quotation
    {
        return DB::transaction(function () use ($quotation, $actor) {
            $quotation = Quotation::where('id', $quotation->id)->lockForUpdate()->firstOrFail();

            $before = $quotation->status;

            if (! $before->canTransitionTo(QuotationStatus::Rejected)) {
                throw ValidationException::withMessages(['status' => "Penawaran tidak dapat ditolak dari status {$before->value}."]);
            }

            $quotation->update(['status' => QuotationStatus::Rejected]);

            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $quotation->rfq->buyer_organization_id,
                'action' => 'quotation.rejected',
                'subject_type' => Quotation::class,
                'subject_id' => $quotation->id,
                'before' => ['status' => $before->value],
                'after' => ['status' => QuotationStatus::Rejected->value],
            ]);

            return $quotation;
        });
    }
}
