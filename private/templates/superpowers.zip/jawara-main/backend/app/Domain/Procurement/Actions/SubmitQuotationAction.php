<?php

namespace App\Domain\Procurement\Actions;

use App\Enums\QuotationStatus;
use App\Enums\RfqStatus;
use App\Models\AuditLog;
use App\Models\Quotation;
use App\Models\QuotationItem;
use App\Models\Rfq;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Submits (or re-submits as revised) a supplier quotation for a published RFQ
 * (FR-6, AD-3, AD-4, AD-12):
 * - supplier eligibility: must be invited OR the RFQ is published (open call)
 * - buyer cannot quote on its own RFQ
 * - totals are computed server-side from items (never trusted from client)
 * - idempotency key prevents double-submit races (AD-12)
 */
class SubmitQuotationAction
{
    /**
     * @param  array<int, array{rfq_item_id: string, unit_price: numeric-string, description?: string|null}>  $items
     */
    public function execute(
        Rfq $rfq,
        string $supplierOrganizationId,
        User $actor,
        array $items,
        ?string $deliveryCost = '0',
        ?string $leadTimeDays = null,
        ?string $validUntil = null,
        ?string $terms = null,
        ?string $idempotencyKey = null,
    ): Quotation {
        if ($rfq->buyer_organization_id === $supplierOrganizationId) {
            throw ValidationException::withMessages(['rfq' => 'Organisasi pembeli tidak dapat menawar RFQ miliknya sendiri.']);
        }

        if ($rfq->status !== RfqStatus::Published) {
            throw ValidationException::withMessages(['rfq' => 'RFQ tidak sedang menerima penawaran.']);
        }

        if ($rfq->quotation_deadline_at && $rfq->quotation_deadline_at->isPast()) {
            throw ValidationException::withMessages(['rfq' => 'Batas waktu penawaran sudah terlewat.']);
        }

        if ($idempotencyKey) {
            $existing = Quotation::where('rfq_id', $rfq->id)
                ->where('supplier_organization_id', $supplierOrganizationId)
                ->where('idempotency_key', $idempotencyKey)
                ->first();

            if ($existing && $existing->status !== QuotationStatus::Draft) {
                return $existing; // idempotent replay (AD-12)
            }
        }

        $rfqItemIds = $rfq->items()->pluck('id')->all();
        $lineTotal = '0';

        // Quantity and unit come from the RFQ item, never from the client (AD-3).
        $rfqItemsById = $rfq->items()->whereIn('id', collect($items)->pluck('rfq_item_id'))->get()->keyBy('id');

        foreach ($items as $item) {
            if (! in_array($item['rfq_item_id'], $rfqItemIds, true)) {
                throw ValidationException::withMessages(['items' => 'Item penawaran tidak sesuai dengan item RFQ.']);
            }
            $rfqItem = $rfqItemsById->get($item['rfq_item_id']);
            $lineTotal = bcadd($lineTotal, bcmul((string) $item['unit_price'], (string) $rfqItem->quantity, 2), 2);
        }

        $total = bcadd($lineTotal, (string) $deliveryCost, 2);

        return DB::transaction(function () use ($rfq, $supplierOrganizationId, $actor, $items, $deliveryCost, $leadTimeDays, $validUntil, $terms, $idempotencyKey, $total) {
            $quotation = Quotation::firstOrNew(
                ['rfq_id' => $rfq->id, 'supplier_organization_id' => $supplierOrganizationId],
            );

            if ($quotation->exists && ! in_array($quotation->status, [QuotationStatus::Draft, QuotationStatus::Submitted, QuotationStatus::Revised], true)) {
                throw ValidationException::withMessages(['status' => "Penawaran tidak dapat diubah dari status {$quotation->status->value}."]);
            }

            $wasSubmitted = $quotation->exists && $quotation->status !== QuotationStatus::Draft;

            $quotation->fill([
                'created_by' => $actor->id,
                'status' => $wasSubmitted ? QuotationStatus::Revised : QuotationStatus::Submitted,
                'total_amount' => $total,
                'delivery_cost' => $deliveryCost,
                'currency' => $rfq->currency,
                'lead_time_days' => $leadTimeDays,
                'valid_until' => $validUntil,
                'terms' => $terms,
                'submitted_at' => now(),
                'idempotency_key' => $idempotencyKey ?? $quotation->idempotency_key,
            ]);
            $quotation->save();

            // Replace items wholesale; line totals are server-computed (AD-3).
            $quotation->items()->delete();
            foreach ($items as $item) {
                $rfqItem = $rfq->items()->where('id', $item['rfq_item_id'])->firstOrFail();

                QuotationItem::create([
                    'quotation_id' => $quotation->id,
                    'rfq_item_id' => $rfqItem->id,
                    'description' => $item['description'] ?? null,
                    'quantity' => $rfqItem->quantity,
                    'unit_of_measure' => $rfqItem->unit_of_measure,
                    'unit_price' => $item['unit_price'],
                    'line_total' => bcmul((string) $item['unit_price'], (string) $rfqItem->quantity, 2),
                ]);
            }

            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $supplierOrganizationId,
                'action' => $wasSubmitted ? 'quotation.revised' : 'quotation.submitted',
                'subject_type' => Quotation::class,
                'subject_id' => $quotation->id,
                'after' => ['total_amount' => $total, 'status' => $quotation->status->value],
            ]);

            return $quotation;
        });
    }
}
