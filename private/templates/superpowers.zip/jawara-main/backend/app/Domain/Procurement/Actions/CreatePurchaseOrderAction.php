<?php

namespace App\Domain\Procurement\Actions;

use App\Enums\PurchaseOrderStatus;
use App\Enums\QuotationStatus;
use App\Enums\RfqStatus;
use App\Models\AuditLog;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderItem;
use App\Models\Quotation;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Creates a Purchase Order from an accepted quotation (FR-6).
 * A PO is a separate business document (spec Phase 06) — created here in
 * draft, then approved/issued through its own lifecycle. The PO inherits the
 * immutable snapshot from the accepted quotation (AD-3) and is idempotent per
 * quotation: one quotation yields at most one non-cancelled PO (AD-12).
 */
class CreatePurchaseOrderAction
{
    public function execute(Quotation $quotation, User $actor): PurchaseOrder
    {
        return DB::transaction(function () use ($quotation, $actor) {
            $rfq = $quotation->rfq()->lockForUpdate()->firstOrFail();

            if ($rfq->status !== RfqStatus::Awarded || $rfq->awarded_quotation_id !== $quotation->id) {
                throw ValidationException::withMessages(['quotation' => 'PO hanya dapat dibuat dari penawaran yang telah di-award.']);
            }

            if ($quotation->status !== QuotationStatus::Accepted) {
                throw ValidationException::withMessages(['quotation' => 'Penawaran belum diterima.']);
            }

            $existing = PurchaseOrder::where('quotation_id', $quotation->id)
                ->whereNot('status', PurchaseOrderStatus::Cancelled->value)
                ->lockForUpdate()
                ->first();

            if ($existing) {
                return $existing; // idempotent (AD-12)
            }

            $snapshot = $quotation->snapshot ?? [
                'total_amount' => (string) $quotation->total_amount,
                'currency' => $quotation->currency,
            ];

            $po = PurchaseOrder::create([
                'buyer_organization_id' => $rfq->buyer_organization_id,
                'supplier_organization_id' => $quotation->supplier_organization_id,
                'rfq_id' => $rfq->id,
                'quotation_id' => $quotation->id,
                'created_by' => $actor->id,
                'number' => 'PO-'.now()->format('Y').'-'.strtoupper(Str::random(8)),
                'status' => PurchaseOrderStatus::Draft,
                'total_amount' => $quotation->total_amount,
                'currency' => $quotation->currency,
                'snapshot' => $snapshot,
            ]);

            foreach ($quotation->items()->get() as $item) {
                PurchaseOrderItem::create([
                    'purchase_order_id' => $po->id,
                    'description' => $item->description ?? 'Item',
                    'quantity' => $item->quantity,
                    'unit_of_measure' => $item->unit_of_measure,
                    'unit_price' => $item->unit_price,
                    'line_total' => $item->line_total,
                ]);
            }

            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $rfq->buyer_organization_id,
                'action' => 'po.created',
                'subject_type' => PurchaseOrder::class,
                'subject_id' => $po->id,
                'after' => ['number' => $po->number, 'total_amount' => $po->total_amount],
            ]);

            return $po;
        });
    }
}
