<?php

namespace App\Domain\Procurement\Actions;

use App\Enums\RfqStatus;
use App\Models\AuditLog;
use App\Models\Rfq;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Publishes a draft RFQ (FR-6). AD-4: explicit state transition in a
 * transaction, with audit log. An RFQ without items cannot be published.
 */
class PublishRfqAction
{
    public function execute(Rfq $rfq, User $actor): Rfq
    {
        if (! $rfq->status->canTransitionTo(RfqStatus::Published)) {
            throw ValidationException::withMessages(['status' => "RFQ tidak dapat dipublikasikan dari status {$rfq->status->value}."]);
        }

        if ($rfq->items()->count() === 0) {
            throw ValidationException::withMessages(['items' => 'RFQ harus memiliki minimal satu item.']);
        }

        return DB::transaction(function () use ($rfq, $actor) {
            $rfq->update([
                'status' => RfqStatus::Published,
                'published_at' => now(),
            ]);

            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $rfq->buyer_organization_id,
                'action' => 'rfq.published',
                'subject_type' => Rfq::class,
                'subject_id' => $rfq->id,
                'after' => ['status' => RfqStatus::Published->value],
            ]);

            return $rfq;
        });
    }
}
