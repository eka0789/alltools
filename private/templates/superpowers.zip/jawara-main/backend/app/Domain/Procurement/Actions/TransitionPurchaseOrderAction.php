<?php

namespace App\Domain\Procurement\Actions;

use App\Enums\PurchaseOrderStatus;
use App\Models\AuditLog;
use App\Models\PurchaseOrder;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Advances a PO through its state machine (AD-4): draft → pending_approval →
 * approved → issued → acknowledged → completed, or cancelled with a reason.
 * Approval requires finance or owner rank; supplier acknowledges after issue.
 */
class TransitionPurchaseOrderAction
{
    public function execute(PurchaseOrder $po, PurchaseOrderStatus $target, User $actor, ?string $reason = null): PurchaseOrder
    {
        if ($target === PurchaseOrderStatus::Cancelled && ! $reason) {
            throw ValidationException::withMessages(['reason' => 'Alasan pembatalan wajib diisi.']);
        }

        return DB::transaction(function () use ($po, $target, $actor, $reason) {
            // H8 (audit): lock the row and capture the OLD status INSIDE the
            // transaction — the previous code read the status after update,
            // making every po.status_changed audit row record before == after.
            $po = PurchaseOrder::where('id', $po->id)->lockForUpdate()->firstOrFail();

            $before = $po->status;

            if (! $before->canTransitionTo($target)) {
                throw ValidationException::withMessages(['status' => "PO tidak dapat berpindah dari {$before->value} ke {$target->value}."]);
            }

            $updates = ['status' => $target];

            $updates = match ($target) {
                PurchaseOrderStatus::Issued => $updates + ['issued_at' => now()],
                PurchaseOrderStatus::Acknowledged => $updates + ['acknowledged_at' => now()],
                PurchaseOrderStatus::Completed => $updates + ['completed_at' => now()],
                PurchaseOrderStatus::Cancelled => $updates + ['cancelled_at' => now(), 'cancellation_reason' => $reason],
                default => $updates,
            };

            $po->update($updates);

            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $po->buyer_organization_id,
                'action' => 'po.status_changed',
                'subject_type' => PurchaseOrder::class,
                'subject_id' => $po->id,
                'before' => ['status' => $before->value],
                'after' => ['status' => $target->value, 'reason' => $reason],
            ]);

            return $po;
        });
    }
}
