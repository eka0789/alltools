<?php

namespace App\Domain\Procurement\Actions;

use App\Enums\QuotationStatus;
use App\Enums\RfqStatus;
use App\Models\AuditLog;
use App\Models\Quotation;
use App\Models\Rfq;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Buyer accepts one quotation on an RFQ (FR-6, AD-3, AD-4).
 *
 * IMPORTANT (spec Phase 06): accepting a quotation does NOT create a completed
 * transaction — it marks the RFQ awarded and freezes an immutable financial
 * snapshot. The Purchase Order is a separate business document with its own
 * lifecycle (see CreatePurchaseOrderAction).
 *
 * Concurrency: the quotation row is locked FOR UPDATE inside the transaction;
 * a competing accept on another quotation of the same RFQ fails with a clear
 * validation error once the RFQ is already awarded.
 */
class AcceptQuotationAction
{
    /**
     * H9 (audit): the buyer check compares against the RESOLVED organization
     * context (X-Organization-Id validated by the controller), not the
     * actor's first membership which is arbitrary for multi-org users.
     */
    public function execute(Quotation $quotation, User $actor, string $buyerOrganizationId): Quotation
    {
        return DB::transaction(function () use ($quotation, $actor, $buyerOrganizationId) {
            $rfq = Rfq::where('id', $quotation->rfq_id)
                ->lockForUpdate()
                ->firstOrFail();

            if ($rfq->status === RfqStatus::Awarded) {
                throw ValidationException::withMessages(['rfq' => 'RFQ sudah di-award ke penawaran lain.']);
            }

            if ($rfq->buyer_organization_id !== $buyerOrganizationId) {
                throw ValidationException::withMessages(['rfq' => 'Anda bukan pembeli pada RFQ ini.']);
            }

            if (! in_array($rfq->status, [RfqStatus::Published, RfqStatus::Closed], true)) {
                throw ValidationException::withMessages(['rfq' => "RFQ dengan status {$rfq->status->value} tidak dapat di-award."]);
            }

            $quotation = Quotation::where('id', $quotation->id)
                ->lockForUpdate()
                ->firstOrFail();

            if (! $quotation->status->canTransitionTo(QuotationStatus::Accepted)) {
                throw ValidationException::withMessages(['status' => "Penawaran dengan status {$quotation->status->value} tidak dapat diterima."]);
            }

            // Immutable financial snapshot (AD-3).
            $snapshot = [
                'accepted_at' => now()->toIso8601String(),
                'rfq' => ['id' => $rfq->id, 'title' => $rfq->title, 'currency' => $rfq->currency],
                'supplier_organization_id' => $quotation->supplier_organization_id,
                'items' => $quotation->items()->get()->map(fn ($i) => [
                    'rfq_item_id' => $i->rfq_item_id,
                    'description' => $i->description,
                    'quantity' => (string) $i->quantity,
                    'unit_of_measure' => $i->unit_of_measure,
                    'unit_price' => (string) $i->unit_price,
                    'line_total' => (string) $i->line_total,
                ])->all(),
                'delivery_cost' => (string) $quotation->delivery_cost,
                'total_amount' => (string) $quotation->total_amount,
                'currency' => $quotation->currency,
                'lead_time_days' => $quotation->lead_time_days,
            ];

            $quotation->update([
                'status' => QuotationStatus::Accepted,
                'accepted_at' => now(),
                'snapshot' => $snapshot,
            ]);

            // Losers get rejected.
            Quotation::where('rfq_id', $rfq->id)
                ->whereNotIn('id', [$quotation->id])
                ->whereIn('status', [QuotationStatus::Submitted, QuotationStatus::Revised])
                ->update(['status' => QuotationStatus::Rejected->value]);

            $rfq->update([
                'status' => RfqStatus::Awarded,
                'awarded_quotation_id' => $quotation->id,
            ]);

            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $rfq->buyer_organization_id,
                'action' => 'quotation.accepted',
                'subject_type' => Quotation::class,
                'subject_id' => $quotation->id,
                'after' => ['total_amount' => $quotation->total_amount, 'snapshot' => $snapshot],
            ]);

            return $quotation;
        });
    }
}
