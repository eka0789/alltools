<?php

namespace App\Domain\Billing\Providers;

use App\Domain\Billing\Contracts\PaymentProvider;
use App\Models\SubscriptionInvoice;

/**
 * Bank-transfer provider with admin/manual confirmation (default for MVP).
 * Activation happens ONLY through admin confirmation or a verified provider
 * webhook — never from frontend state (spec Phase 09).
 */
class ManualPaymentProvider implements PaymentProvider
{
    public function key(): string
    {
        return 'manual';
    }

    public function createCharge(SubscriptionInvoice $invoice): array
    {
        return [
            'provider_ref' => $invoice->number,
            'instructions' => sprintf(
                'Transfer sebesar Rp%s ke rekening JAWARA (BCA 1234567890 a.n. JAWARA Platform). '
                .'Sertakan nomor invoice %s pada berita transfer. Konfirmasi oleh admin dalam 1x24 jam.',
                number_format((float) $invoice->amount, 0, ',', '.'),
                $invoice->number,
            ),
        ];
    }

    public function verifyWebhook(string $rawBody, ?string $signatureHeader): bool
    {
        return false; // manual provider has no webhook
    }
}
