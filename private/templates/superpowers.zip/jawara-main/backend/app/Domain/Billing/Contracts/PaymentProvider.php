<?php

namespace App\Domain\Billing\Contracts;

use App\Models\SubscriptionInvoice;

/**
 * Payment provider abstraction (spec Phase 09: "Keep payment providers behind
 * an abstraction layer"). Swapping manual → Midtrans/Xendit requires only a
 * new implementation + config change — no domain refactor.
 */
interface PaymentProvider
{
    /** Human-readable identifier used on invoices (invoices.provider). */
    public function key(): string;

    /**
     * Creates a charge for an invoice. Returns provider reference and
     * customer-facing payment instructions.
     *
     * @return array{provider_ref: ?string, instructions: string}
     */
    public function createCharge(SubscriptionInvoice $invoice): array;

    /**
     * Verifies a webhook payload signature (spec Phase 09: "Verify provider
     * signatures", "Never trust frontend payment status").
     */
    public function verifyWebhook(string $rawBody, ?string $signatureHeader): bool;
}
