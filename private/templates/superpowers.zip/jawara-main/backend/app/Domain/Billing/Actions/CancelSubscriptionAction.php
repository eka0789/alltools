<?php

namespace App\Domain\Billing\Actions;

use App\Models\AuditLog;
use App\Models\Organization;
use App\Models\Subscription;
use App\Models\User;
use Illuminate\Support\Facades\DB;

/** Cancels the subscription (grace period until current_period_ends_at). */
class CancelSubscriptionAction
{
    public function execute(Organization $organization, User $actor): Subscription
    {
        return DB::transaction(function () use ($organization, $actor) {
            $subscription = Subscription::where('organization_id', $organization->id)->firstOrFail();

            $subscription->update([
                'status' => 'cancelled',
                'cancelled_at' => now(),
            ]);

            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $organization->id,
                'action' => 'billing.subscription_cancelled',
                'subject_type' => Subscription::class,
                'subject_id' => $subscription->id,
            ]);

            return $subscription;
        });
    }
}
