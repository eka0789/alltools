<?php

namespace App\Domain\Billing\Actions;

use App\Domain\Billing\Contracts\PaymentProvider;
use App\Models\AuditLog;
use App\Models\Organization;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\SubscriptionInvoice;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Starts (or upgrades) an organization subscription (FR from Phase 09).
 * Free plan activates immediately; paid plans create a pending invoice that
 * activates only after payment confirmation (admin or verified webhook).
 */
class SubscribeOrganizationAction
{
    public function __construct(private PaymentProvider $provider) {}

    public function execute(Organization $organization, Plan $plan, User $actor): array
    {
        return DB::transaction(function () use ($organization, $plan, $actor) {
            $subscription = Subscription::firstOrNew(['organization_id' => $organization->id]);

            if ($subscription->exists && $subscription->plan_id === $plan->id && $subscription->status === 'active') {
                throw ValidationException::withMessages(['plan' => 'Organisasi sudah berlangganan plan ini.']);
            }

            $previousPlanId = $subscription->exists ? $subscription->getOriginal('plan_id') : null;

            $subscription->fill([
                'plan_id' => $plan->id,
                'status' => 'pending_payment',
                'starts_at' => null,
                'current_period_ends_at' => null,
                'cancelled_at' => null,
            ]);
            $subscription->save();

            // AD-12: plan changes affect billing entitlements (incl. AI quotas)
            // — subscribe/upgrade must leave an audit trail like cancel does.
            AuditLog::create([
                'actor_user_id' => $actor->id,
                'organization_id' => $organization->id,
                'action' => 'billing.subscription_subscribe',
                'subject_type' => Subscription::class,
                'subject_id' => $subscription->id,
                'after' => ['plan_id' => $plan->id, 'previous_plan_id' => $previousPlanId, 'status' => $subscription->status],
            ]);

            $invoice = null;
            $instructions = 'Plan gratis — aktivasi langsung.';

            if ((float) $plan->monthly_price > 0) {
                $invoice = SubscriptionInvoice::create([
                    'subscription_id' => $subscription->id,
                    'number' => 'INV-'.now()->format('Ym').'-'.strtoupper(Str::random(6)),
                    'provider' => $this->provider->key(),
                    'amount' => $plan->monthly_price,
                    'currency' => $plan->currency,
                    'status' => 'pending',
                    'expires_at' => now()->addDays(3),
                ]);

                $charge = $this->provider->createCharge($invoice);
                $invoice->update(['provider_ref' => $charge['provider_ref']]);
                $instructions = $charge['instructions'];
            } else {
                // Free plan: activate immediately.
                $this->activate($subscription);
                $subscription->update(['status' => 'active']);
            }

            return ['subscription' => $subscription->fresh()->load('plan'), 'invoice' => $invoice, 'instructions' => $instructions];
        });
    }

    /** Extends the period by one month from now (or from period end if active). */
    public function activate(Subscription $subscription): void
    {
        $base = $subscription->current_period_ends_at && $subscription->current_period_ends_at->isFuture()
            ? $subscription->current_period_ends_at
            : now();

        $subscription->update([
            'status' => 'active',
            'starts_at' => $subscription->starts_at ?? now(),
            'current_period_ends_at' => $base->copy()->addMonth(),
        ]);
    }
}
