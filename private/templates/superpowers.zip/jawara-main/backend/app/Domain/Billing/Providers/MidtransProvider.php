<?php

namespace App\Domain\Billing\Providers;

use App\Domain\Billing\Contracts\PaymentProvider;
use App\Models\SubscriptionInvoice;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * ROADMAP: Midtrans payment gateway (Snap) behind the existing abstraction —
 * activated by PAYMENT_PROVIDER=midtrans plus MIDTRANS_SERVER_KEY in the
 * environment. Snap's redirect_url IS the hosted payment page, so no extra
 * UI is needed: the invoice instructions carry the link (same shape as the
 * Xendit driver). Fail-closed like XenditProvider.
 *
 * HTTP notification verification (Midtrans spec): signature_key =
 * sha512(order_id + status_code + gross_amount + server_key) — the signature
 * arrives inside the JSON body, not a header.
 */
class MidtransProvider implements PaymentProvider
{
    public function key(): string
    {
        return 'midtrans';
    }

    public function createCharge(SubscriptionInvoice $invoice): array
    {
        $serverKey = (string) config('services.midtrans.server_key', '');

        if ($serverKey === '') {
            Log::error('midtrans.server_key_missing', ['invoice' => $invoice->number]);

            // Fail-closed: without credentials there is nothing to charge.
            return [
                'provider_ref' => null,
                'instructions' => 'Payment gateway sedang tidak tersedia. Silakan hubungi dukungan atau gunakan konfirmasi manual.',
            ];
        }

        // Midtrans Snap: Basic auth username = server_key, password kosong.
        $response = Http::withBasicAuth($serverKey, '')
            ->acceptJson()
            ->post($this->baseUrl().'/snap/v1/transactions', [
                'transaction_details' => [
                    'order_id' => $invoice->number,
                    'gross_amount' => (int) $invoice->amount,
                ],
                'item_details' => [[
                    'id' => $invoice->number,
                    'price' => (int) $invoice->amount,
                    'quantity' => 1,
                    'name' => 'Langganan JAWARA — invoice '.$invoice->number,
                ]],
                'customer_details' => [
                    'email' => $invoice->subscription?->organization?->businessProfile?->public_email,
                ],
                'expiry' => [
                    'unit' => 'minutes',
                    'duration' => 4320, // 3 hari, sama dengan expiry invoice
                ],
            ]);

        if ($response->failed()) {
            Log::error('midtrans.snap_create_failed', [
                'invoice' => $invoice->number,
                'status' => $response->status(),
                'body' => $response->json(),
            ]);

            return [
                'provider_ref' => null,
                'instructions' => 'Gagal membuat tagihan pembayaran. Silakan coba lagi atau hubungi dukungan.',
            ];
        }

        $redirectUrl = $response->json('redirect_url');

        return [
            'provider_ref' => (string) $response->json('token'),
            'instructions' => 'Selesaikan pembayaran melalui halaman pembayaran Midtrans: '.$redirectUrl,
        ];
    }

    public function verifyWebhook(string $rawBody, ?string $signatureHeader): bool
    {
        $serverKey = (string) config('services.midtrans.server_key', '');

        // Fail-closed: a provider without a configured secret never passes.
        if ($serverKey === '' || $rawBody === '') {
            return false;
        }

        $payload = json_decode($rawBody, true);

        if (! is_array($payload)) {
            Log::warning('midtrans.webhook_invalid_json');

            return false;
        }

        $orderId = $payload['order_id'] ?? null;
        $statusCode = $payload['status_code'] ?? null;
        $grossAmount = $payload['gross_amount'] ?? null;
        $signature = $payload['signature_key'] ?? null;

        if (! is_string($orderId) || ! is_string($statusCode) || ! is_string($grossAmount) || ! is_string($signature)) {
            Log::warning('midtrans.webhook_missing_fields');

            return false;
        }

        $expected = hash('sha512', $orderId.$statusCode.$grossAmount.$serverKey);

        return hash_equals($expected, $signature);
    }

    private function baseUrl(): string
    {
        return (bool) config('services.midtrans.is_production', false)
            ? 'https://app.midtrans.com'
            : 'https://app.sandbox.midtrans.com';
    }
}
