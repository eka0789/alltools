<?php

namespace App\Domain\Billing\Services;

use App\Models\Organization;
use App\Models\PlanFeature;
use App\Models\Rfq;
use App\Models\Subscription;
use Illuminate\Validation\ValidationException;

/**
 * Plan feature entitlements (spec Phase 09: usage limits). Free fallback when
 * no subscription row exists. Limits: rfq_monthly_limit, product_listings.
 */
class EntitlementService
{
    public function limitFor(Organization $organization, string $featureKey): ?int
    {
        // H10 (audit): only an ACTIVE subscription grants plan entitlements.
        // pending_payment/cancelled fall back to Free limits.
        $subscription = Subscription::with('plan.features')
            ->where('organization_id', $organization->id)
            ->where('status', 'active')
            ->first();

        $limit = $subscription?->plan->features->firstWhere('feature_key', $featureKey)?->limit_value
            ?? PlanFeature::query()->where('feature_key', $featureKey)->whereHas('plan', fn ($q) => $q->where('slug', 'free'))->value('limit_value')
            ?? 'unlimited';

        return $limit === 'unlimited' ? null : (int) $limit;
    }

    /** Enforces rfq_monthly_limit at RFQ creation time. */
    public function assertCanCreateRfq(Organization $organization): void
    {
        $limit = $this->limitFor($organization, 'rfq_monthly_limit');

        if ($limit === null) {
            return;
        }

        $usedThisMonth = Rfq::forOrganization($organization->id)
            ->where('created_at', '>=', now()->startOfMonth())
            ->count();

        if ($usedThisMonth >= $limit) {
            throw ValidationException::withMessages([
                'plan' => "Batas RFQ bulanan plan Anda tercapai ({$limit}/bulan). Tingkatkan langganan untuk melanjutkan.",
            ]);
        }
    }

    /** True when the organization is subscribed to a paid (non-free) plan. */
    public function isPaidPlan(Organization $organization): bool
    {
        $subscription = Subscription::with('plan')->where('organization_id', $organization->id)->first();

        return $subscription && $subscription->status === 'active' && (float) $subscription->plan->monthly_price > 0;
    }
}
