<?php

namespace App\Domain\Billing\Actions;

use App\Models\AuditLog;
use App\Models\Payment;
use App\Models\Subscription;
use App\Models\SubscriptionInvoice;
use App\Models\User;
use Illuminate\Support\Facades\DB;

/**
 * Marks an invoice paid and activates the subscription (AD-12: audit).
 * Invoked ONLY by admin confirmation or a signature-verified provider webhook
 * — the frontend can never activate a plan directly (spec Phase 09).
 */
class ConfirmPaymentAction
{
    public function __construct(private SubscribeOrganizationAction $subscribe) {}

    public function execute(SubscriptionInvoice $invoice, ?User $actor, string $source): SubscriptionInvoice
    {
        return DB::transaction(function () use ($invoice, $actor, $source) {
            // H2 (audit): lock the invoice row so concurrent webhook retries
            // cannot both pass the pending check (at-least-once delivery).
            $invoice = SubscriptionInvoice::where('id', $invoice->id)->lockForUpdate()->firstOrFail();

            if ($invoice->status !== 'pending') {
                return $invoice; // idempotent replay — no duplicate Payment rows
            }

            $invoice->update(['status' => 'paid', 'paid_at' => now()]);

            Payment::create([
                'invoice_id' => $invoice->id,
                'provider' => $invoice->provider,
                'provider_ref' => $invoice->provider_ref,
                'amount' => $invoice->amount,
                'currency' => $invoice->currency,
                'status' => 'paid',
                'confirmed_by' => $source,
            ]);

            $subscription = Subscription::findOrFail($invoice->subscription_id);
            $this->subscribe->activate($subscription);
            $subscription->update(['status' => 'active']);

            AuditLog::create([
                'actor_user_id' => $actor?->id,
                'organization_id' => $subscription->organization_id,
                'action' => 'billing.invoice_paid',
                'subject_type' => SubscriptionInvoice::class,
                'subject_id' => $invoice->id,
                'after' => ['amount' => (string) $invoice->amount, 'source' => $source],
            ]);

            return $invoice;
        });
    }
}
