<?php

namespace App\Domain\Billing\Providers;

use App\Domain\Billing\Contracts\PaymentProvider;
use App\Models\SubscriptionInvoice;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Tier 2: Xendit payment gateway (spec Phase 09 revenue enablement).
 * Implements the Xendit Invoice API (https://developers.xendit.co) behind
 * the existing abstraction — activated by setting PAYMENT_PROVIDER=xendit
 * plus PAYMENT_WEBHOOK_SECRET + XENDIT_SECRET_KEY in the environment.
 * With the manual provider as default, nothing changes for local dev.
 */
class XenditProvider implements PaymentProvider
{
    public function key(): string
    {
        return 'xendit';
    }

    public function createCharge(SubscriptionInvoice $invoice): array
    {
        $secretKey = (string) config('services.xendit.secret_key', env('XENDIT_SECRET_KEY', ''));

        if ($secretKey === '') {
            Log::error('xendit.secret_key_missing', ['invoice' => $invoice->number]);

            // Fail-closed: without credentials there is nothing to charge.
            return [
                'provider_ref' => null,
                'instructions' => 'Payment gateway sedang tidak tersedia. Silakan hubungi dukungan atau gunakan konfirmasi manual.',
            ];
        }

        // Xendit Invoice API: Basic auth username = secret_key, password kosong.
        $response = Http::withBasicAuth($secretKey, '')
            ->acceptJson()
            ->post('https://api.xendit.co/v2/invoices', [
                'external_id' => $invoice->number,
                'amount' => (float) $invoice->amount,
                'currency' => $invoice->currency,
                'description' => 'Langganan JAWARA — invoice '.$invoice->number,
                'payer_email' => $invoice->subscription?->organization?->businessProfile?->public_email,
                'invoice_duration' => 259200, // 3 days, matches invoice expiry
                'success_redirect_url' => rtrim((string) config('jawara.frontend_url', env('FRONTEND_URL', 'http://localhost:3000')), '/').'/dashboard',
                'failure_redirect_url' => rtrim((string) config('jawara.frontend_url', env('FRONTEND_URL', 'http://localhost:3000')), '/').'/dashboard/org/billing',
            ]);

        if ($response->failed()) {
            Log::error('xendit.invoice_create_failed', [
                'invoice' => $invoice->number,
                'status' => $response->status(),
                'body' => $response->json(),
            ]);

            return [
                'provider_ref' => null,
                'instructions' => 'Gagal membuat tagihan pembayaran. Silakan coba lagi atau hubungi dukungan.',
            ];
        }

        return [
            'provider_ref' => (string) $response->json('id'),
            'instructions' => 'Selesaikan pembayaran melalui halaman pembayaran Xendit: '.$response->json('invoice_url'),
        ];
    }

    public function verifyWebhook(string $rawBody, ?string $signatureHeader): bool
    {
        $secret = (string) config('services.xendit.callback_token', env('PAYMENT_WEBHOOK_SECRET', ''));

        // Fail-closed: a provider without a configured secret never passes.
        if ($secret === '' || $signatureHeader === null) {
            return false;
        }

        // Xendit sends the raw callback token in the x-callback-token header.
        return hash_equals($secret, $signatureHeader);
    }
}
