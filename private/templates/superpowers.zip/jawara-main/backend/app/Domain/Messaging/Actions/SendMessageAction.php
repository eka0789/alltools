<?php

namespace App\Domain\Messaging\Actions;

use App\Events\MessageSent;
use App\Models\Conversation;
use App\Models\ConversationParticipant;
use App\Models\Message;
use App\Models\MessageAttachment;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Sends a message into a conversation (FR-7). Sender must be an active
 * participant; the conversation's last_message_at is bumped and counterpart
 * participants receive an in-app notification (queued email is deferred).
 */
class SendMessageAction
{
    public function execute(Conversation $conversation, User $sender, string $body, ?array $attachment = null): Message
    {
        return DB::transaction(function () use ($conversation, $sender, $body, $attachment) {
            $participant = ConversationParticipant::where('conversation_id', $conversation->id)
                ->where('user_id', $sender->id)
                ->first();

            if (! $participant) {
                throw new \DomainException('Anda bukan peserta percakapan ini.');
            }

            $message = Message::create([
                'conversation_id' => $conversation->id,
                'sender_id' => $sender->id,
                'body' => $body,
            ]);

            if ($attachment) {
                MessageAttachment::create([
                    'message_id' => $message->id,
                    'path' => $attachment['path'],
                    'original_name' => $attachment['original_name'],
                    'mime_type' => $attachment['mime_type'],
                    'size_bytes' => $attachment['size_bytes'],
                ]);
            }

            $conversation->update(['last_message_at' => now()]);
            $participant->update(['last_read_at' => now()]);

            // Notify counterpart participants (H6 audit fix: single bulk
            // insert with explicit UUIDs instead of one model save per row).
            $counterparts = ConversationParticipant::where('conversation_id', $conversation->id)
                ->where('user_id', '!=', $sender->id)
                ->get();

            if ($counterparts->isNotEmpty()) {
                $now = now();

                $rows = $counterparts->map(fn ($counterpart) => [
                    'id' => (string) Str::uuid(),
                    'user_id' => $counterpart->user_id,
                    'type' => 'message.received',
                    'title' => 'Pesan baru dari '.$sender->name,
                    'body' => Str::limit($body, 80),
                    'link' => '/dashboard/messages/'.$conversation->id,
                    'conversation_id' => $conversation->id,
                    'data' => json_encode([
                        'conversation_id' => $conversation->id,
                        'message_id' => $message->id,
                    ]),
                    'read_at' => null,
                    'created_at' => $now,
                    'updated_at' => $now,
                ])->all();

                Notification::insert($rows);
            }

            // Tier 4 realtime: broadcast over the private conversation channel.
            // Frontend falls back to polling when Reverb is unavailable.
            broadcast(new MessageSent($message, $conversation->id))->toOthers();

            return $message->load('attachments');
        });
    }
}
