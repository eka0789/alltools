<?php

namespace App\Domain\Messaging\Actions;

use App\Models\Conversation;
use App\Models\ConversationParticipant;
use App\Models\Organization;
use App\Models\OrganizationMember;
use App\Models\Role;
use Illuminate\Support\Facades\DB;

/**
 * Finds or creates a buyer↔supplier conversation (FR-7).
 * H6 (audit 2026-11-21):
 * - creation is serialized by the unique index on (buyer, supplier) added in
 *   migration 2026_11_21_110002 plus lockForUpdate on the lookup — the old
 *   check-then-create raced into duplicates;
 * - participants are NO LONGER all members of both orgs (a 500-member org
 *   meant 1000 queries per conversation start). Only the initiating user plus
 *   the counterpart organization's management roles participate.
 */
class StartConversationAction
{
    public function execute(Organization $buyerOrg, Organization $supplierOrg, string $userId): Conversation
    {
        if ($buyerOrg->id === $supplierOrg->id) {
            throw new \DomainException('Tidak dapat memulai percakapan dengan organisasi sendiri.');
        }

        return DB::transaction(function () use ($buyerOrg, $supplierOrg, $userId) {
            $conversation = Conversation::where('buyer_organization_id', $buyerOrg->id)
                ->where('supplier_organization_id', $supplierOrg->id)
                ->lockForUpdate()
                ->first();

            if (! $conversation) {
                $conversation = Conversation::create([
                    'type' => 'buyer_supplier',
                    'buyer_organization_id' => $buyerOrg->id,
                    'supplier_organization_id' => $supplierOrg->id,
                    'created_by' => $userId,
                ]);
            }

            // Initiating user (buyer side)...
            ConversationParticipant::firstOrCreate(
                ['conversation_id' => $conversation->id, 'user_id' => $userId],
                ['organization_id' => $buyerOrg->id],
            );

            // ...plus the supplier org's management roles only (bounded fan-out).
            $supplierStakeholders = OrganizationMember::where('organization_id', $supplierOrg->id)
                ->where('status', 'active')
                ->whereIn('role_id', Role::whereIn('slug', ['organization-owner', 'organization-admin', 'sales-manager'])->pluck('id'))
                ->orderBy('joined_at')
                ->limit(10)
                ->pluck('user_id');

            foreach ($supplierStakeholders as $stakeholderId) {
                ConversationParticipant::firstOrCreate(
                    ['conversation_id' => $conversation->id, 'user_id' => $stakeholderId],
                    ['organization_id' => $supplierOrg->id],
                );
            }

            return $conversation;
        });
    }
}
