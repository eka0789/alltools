<?php

namespace App\Domain\Shared\Contracts;

use Illuminate\Database\Eloquent\Builder;

/**
 * AD-10 (audit H7): search behind an interface so the DB-backed MVP
 * implementation can be swapped for Meilisearch without touching controllers.
 */
interface SearchService
{
    /**
     * Applies a term search to the given query over the listed columns.
     *
     * @param  array<int, string>  $columns
     */
    public function apply(Builder $query, array $columns, string $term): Builder;
}
