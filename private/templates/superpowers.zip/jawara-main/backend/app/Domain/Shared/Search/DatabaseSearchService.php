<?php

namespace App\Domain\Shared\Search;

use App\Domain\Shared\Contracts\SearchService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

/**
 * DB-backed search (MVP default). Uses the FULLTEXT indexes added by
 * migration 2026_11_21_110002 on MariaDB/MySQL; falls back to substring
 * LIKE elsewhere (SQLite tests, pre-migration Postgres) so substring
 * semantics are preserved where FULLTEXT is unavailable.
 */
class DatabaseSearchService implements SearchService
{
    public function apply(Builder $query, array $columns, string $term): Builder
    {
        if ($columns === []) {
            throw new InvalidArgumentException('Search columns required.');
        }

        $driver = DB::connection()->getDriverName();
        $term = trim($term);

        if ($term === '') {
            return $query;
        }

        if (in_array($driver, ['mariadb', 'mysql'], true)) {
            return $query->whereFullText($columns, $term);
        }

        // Portable fallback: substring match (semantics preserved from the
        // pre-SearchService implementation; not index-backed).
        $like = '%'.str_replace(['%', '_'], ['\%', '\_'], $term).'%';

        return $query->where(function (Builder $q) use ($columns, $like) {
            foreach ($columns as $column) {
                $q->orWhere($column, 'like', $like);
            }
        });
    }
}
