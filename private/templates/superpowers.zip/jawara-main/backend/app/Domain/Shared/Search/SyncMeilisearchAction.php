<?php

namespace App\Domain\Shared\Search;

use App\Models\BusinessProfile;
use App\Models\Product;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;

/**
 * ROADMAP "Meilisearch indexing pipeline" — sync published catalog &
 * directory entities into Meilisearch indexes so the MeilisearchSearchService
 * driver (SEARCH_DRIVER=meilisearch) has data to search. Document shape must
 * carry `id` (primaryKey) + the searchable text fields. Index names mirror
 * the driver's table→index mapping (underscore → dash). Failures throw; the
 * command surfaces them — enabling the driver with an empty index silently
 * returns nothing, which is worse than a loud failure.
 */
final class SyncMeilisearchAction
{
    private const MAX_TEXT_LENGTH = 2000;

    public function __construct(
        private readonly ?string $host = null,
        private readonly ?string $key = null,
    ) {}

    /**
     * @return array{indexed: array{products: int, business_profiles: int}, skipped: bool, reason?: string}
     */
    public function execute(): array
    {
        $host = $this->host ?? rtrim((string) config('services.meilisearch.host', env('MEILISEARCH_HOST', '')), '/');
        $key = $this->key ?? (string) config('services.meilisearch.key', env('MEILISEARCH_KEY', ''));

        if ($host === '') {
            return ['indexed' => ['products' => 0, 'business_profiles' => 0], 'skipped' => true, 'reason' => 'MEILISEARCH_HOST belum diatur'];
        }

        $headers = $key !== '' ? ['Authorization' => 'Bearer '.$key] : [];

        $productDocs = Product::query()
            ->published()
            ->get(['id', 'name', 'description'])
            ->map(fn ($p): array => [
                'id' => $p->id,
                'name' => $p->name,
                'description' => mb_substr((string) $p->description, 0, self::MAX_TEXT_LENGTH),
            ])
            ->all();

        $profileDocs = BusinessProfile::query()
            ->published()
            ->get(['id', 'display_name', 'description'])
            ->map(fn ($p): array => [
                'id' => $p->id,
                'name' => $p->display_name,
                'description' => mb_substr((string) $p->description, 0, self::MAX_TEXT_LENGTH),
            ])
            ->all();

        $this->push($host, $headers, 'products', new Collection($productDocs));
        $this->push($host, $headers, 'business-profiles', new Collection($profileDocs));

        return [
            'indexed' => ['products' => count($productDocs), 'business_profiles' => count($profileDocs)],
            'skipped' => false,
        ];
    }

    private function push(string $host, array $headers, string $index, Collection $docs): void
    {
        if ($docs->isEmpty()) {
            return;
        }

        $response = Http::withHeaders($headers)
            ->acceptJson()
            ->timeout(60)
            ->post($host.'/indexes/'.$index.'/documents?primaryKey=id', $docs->all());

        if ($response->failed()) {
            throw new \RuntimeException(
                "Meilisearch sync gagal untuk index {$index}: HTTP {$response->status()}"
            );
        }
    }
}
