<?php

namespace App\Domain\Shared\Search;

use App\Domain\Shared\Contracts\SearchService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Http;
use InvalidArgumentException;

/**
 * Tier 4: Meilisearch-backed search implementation. Selected via
 * config('jawara.search_driver') = 'meilisearch' with MEILISEARCH_HOST +
 * MEILISEARCH_KEY configured; records must be indexed into Meilisearch by a
 * sync job (docs/ROADMAP.md — indexing pipeline is the remaining step).
 */
class MeilisearchSearchService implements SearchService
{
    public function apply(Builder $query, array $columns, string $term): Builder
    {
        if ($columns === []) {
            throw new InvalidArgumentException('Search columns required.');
        }

        $host = rtrim((string) config('services.meilisearch.host', env('MEILISEARCH_HOST', '')), '/');
        $key = (string) config('services.meilisearch.key', env('MEILISEARCH_KEY', ''));

        if ($host === '' || $term === '') {
            return $query;
        }

        // Resolve the table from the query and ask Meilisearch for matching
        // primary keys, then constrain the Eloquent query to them.
        $table = $query->getModel()->getTable();
        $index = str_replace('_', '-', $table);

        $response = Http::withHeaders($key !== '' ? ['Authorization' => 'Bearer '.$key] : [])
            ->acceptJson()
            ->post($host.'/indexes/'.$index.'/search', [
                'q' => $term,
                'limit' => 500,
                'attributesToRetrieve' => ['id'],
            ]);

        if ($response->failed()) {
            report(new \RuntimeException('Meilisearch search failed: '.$response->status()));

            return $query; // fail-open to unfiltered listing
        }

        $ids = collect($response->json('hits', []))->pluck('id')->all();

        return $query->whereIn($query->getModel()->getTable().'.id', $ids);
    }
}
