<?php

namespace App\Domain\Identity\Actions;

use App\Domain\Identity\RoleRank;
use App\Mail\GenericNotificationMail;
use App\Models\Organization;
use App\Models\OrganizationInvitation;
use App\Models\OrganizationMember;
use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

/**
 * Invites a member into an organization (FR-2). Idempotent per (org, email)
 * at the database level; re-inviting a pending invitation refreshes its token.
 */
class InviteMemberAction
{
    public function execute(Organization $organization, User $invitedBy, string $email, Role $role, OrganizationMember $actor): OrganizationInvitation
    {
        if ($role->scope === 'platform') {
            // Audit 2026-11-24: sebelumnya InvalidArgumentException — tidak
            // ditangkap controller (hanya DomainException) sehingga 500.
            // Sama seperti ChangeMemberRoleAction: pelanggaran aturan domain.
            throw new \DomainException('Peran platform tidak dapat diatur dari konteks organisasi.');
        }

        // C4 (audit 2026-11-21): same rank ceiling as role-change — an Admin
        // cannot invite an Owner. Blocks the invite-path escalation.
        if (RoleRank::rankOfRole($role) > RoleRank::rankOf($actor)) {
            throw new \DomainException('Tidak dapat mengundang anggota dengan peran di atas peran Anda sendiri.');
        }

        $invitation = OrganizationInvitation::updateOrCreate(
            ['organization_id' => $organization->id, 'email' => $email],
            [
                'role_id' => $role->id,
                'invited_by' => $invitedBy->id,
                'token' => Str::random(48),
                'status' => 'pending',
                'expires_at' => now()->addDays(7),
                'accepted_at' => null,
            ],
        );

        // Audit infra: queued Mailable (sebelumnya sync Mail::raw).
        Mail::to($invitation->email)->send(
            new GenericNotificationMail(
                'Undangan JAWARA',
                "Anda diundang bergabung ke {$organization->name} sebagai {$role->name}. Gunakan token: {$invitation->token}",
            ),
        );

        return $invitation;
    }
}
