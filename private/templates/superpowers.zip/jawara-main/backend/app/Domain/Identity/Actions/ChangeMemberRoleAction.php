<?php

namespace App\Domain\Identity\Actions;

use App\Domain\Identity\RoleRank;
use App\Models\AuditLog;
use App\Models\OrganizationMember;
use App\Models\Role;
use Illuminate\Support\Facades\DB;

/**
 * Changes a member's role (FR-3). Enforces anti-escalation rules (AD-6):
 * - Only organization-owner/admin roles may change roles.
 * - Nobody grants a role above their own rank.
 * - Platform roles are never assignable from organization context.
 */
class ChangeMemberRoleAction
{
    public function execute(OrganizationMember $member, Role $newRole, OrganizationMember $actor): OrganizationMember
    {
        if ($newRole->scope === 'platform') {
            throw new \DomainException('Peran platform tidak dapat diatur dari konteks organisasi.');
        }

        $actorRank = RoleRank::rankOf($actor);
        $targetRank = RoleRank::rankOfRole($newRole);

        if ($actorRank < 4) {
            throw new \DomainException('Hanya Owner atau Admin organisasi yang dapat mengubah peran.');
        }

        if ($targetRank > $actorRank) {
            throw new \DomainException('Tidak dapat memberikan peran di atas peran Anda sendiri.');
        }

        // H4: cannot touch a member ranked above the actor (protects Owner
        // from demotion by an Admin), and cannot demote the LAST owner.
        if (RoleRank::rankOf($member) > $actorRank) {
            throw new \DomainException('Tidak dapat mengubah peran anggota dengan peran lebih tinggi.');
        }

        if ($member->role->slug === 'organization-owner' && $newRole->slug !== 'organization-owner') {
            $activeOwners = OrganizationMember::where('organization_id', $member->organization_id)
                ->where('role_id', $member->role_id)
                ->where('status', 'active')
                ->count();

            if ($activeOwners <= 1) {
                throw new \DomainException('Organisasi harus memiliki minimal satu Owner.');
            }
        }

        return DB::transaction(function () use ($member, $newRole, $actor) {
            $before = $member->role->slug;

            $member->update(['role_id' => $newRole->id]);

            AuditLog::create([
                'actor_user_id' => $actor->user_id,
                'organization_id' => $member->organization_id,
                'action' => 'member.role_changed',
                'subject_type' => OrganizationMember::class,
                'subject_id' => $member->id,
                'before' => ['role' => $before],
                'after' => ['role' => $newRole->slug],
            ]);

            return $member;
        });
    }
}
