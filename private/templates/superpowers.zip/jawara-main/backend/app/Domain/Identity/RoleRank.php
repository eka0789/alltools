<?php

namespace App\Domain\Identity;

use App\Models\OrganizationMember;
use App\Models\Role;

/**
 * H1: shared role-rank table (AD-6). Previously duplicated between
 * ChangeMemberRoleAction and inline controller checks. Rank order:
 * 1 member → 2 staff → 3 managers → 4 admin → 5 owner.
 */
final class RoleRank
{
    public const RANK = [
        'member' => 1,
        'purchasing-staff' => 2,
        'sales-staff' => 2,
        'finance-staff' => 2,
        'business-manager' => 3,
        'procurement-manager' => 3,
        'sales-manager' => 3,
        'organization-admin' => 4,
        'organization-owner' => 5,
    ];

    /** Minimum rank required for procurement mutations (RFQ, quotation accept, PO). */
    public const PROCUREMENT_MIN = 2;

    /** Minimum rank for organization management (members, profile, role changes). */
    public const MANAGEMENT_MIN = 4;

    public static function rankOf(OrganizationMember $member): int
    {
        return self::RANK[$member->role->slug] ?? 0;
    }

    public static function rankOfRole(Role $role): int
    {
        return self::RANK[$role->slug] ?? 0;
    }
}
