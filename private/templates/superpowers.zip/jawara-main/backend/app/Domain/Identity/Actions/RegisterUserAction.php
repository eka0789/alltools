<?php

namespace App\Domain\Identity\Actions;

use App\Models\Organization;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

/**
 * Registers a new user account. Email verification is enforced by
 * MustVerifyEmail (FR-1); an organization is NOT created here.
 */
class RegisterUserAction
{
    public function execute(string $name, string $email, string $password, ?string $referralCode = null): User
    {
        $referredByOrgId = null;

        if ($referralCode) {
            $referredByOrgId = Organization::where('referral_code', strtoupper($referralCode))
                ->where('status', 'active')
                ->value('id');
        }

        return User::create([
            'name' => $name,
            'email' => $email,
            'password' => Hash::make($password),
            'referred_by_org_id' => $referredByOrgId,
        ]);
    }
}
