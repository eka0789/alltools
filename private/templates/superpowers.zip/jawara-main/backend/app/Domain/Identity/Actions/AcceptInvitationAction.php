<?php

namespace App\Domain\Identity\Actions;

use App\Models\OrganizationInvitation;
use App\Models\OrganizationMember;
use App\Models\User;
use Illuminate\Support\Facades\DB;

/**
 * Accepts an invitation (FR-2). Validates token + expiry + invited email,
 * creates the membership inside a transaction.
 */
class AcceptInvitationAction
{
    public function execute(string $token, string $userId): OrganizationInvitation
    {
        $invitation = OrganizationInvitation::where('token', $token)->first();

        if (! $invitation || $invitation->isExpired()) {
            throw new \DomainException('Undangan tidak valid atau sudah kedaluwarsa.');
        }

        // H5 (audit 2026-11-21): invitations are email-bound — only the
        // invited user may accept. Prevents token-sharing takeover.
        $user = User::findOrFail($userId);

        if (strtolower($user->email) !== strtolower($invitation->email)) {
            throw new \DomainException('Undangan ini ditujukan untuk email lain.');
        }

        return DB::transaction(function () use ($invitation, $userId) {
            // Re-audit fix: a previously REMOVED member has an existing row
            // (RemoveMemberAction soft-statuses it) — unique(org, user) would
            // make plain create() throw. Restore/reactivate instead.
            $member = OrganizationMember::where('organization_id', $invitation->organization_id)
                ->where('user_id', $userId)
                ->first();

            if ($member) {
                $member->update([
                    'role_id' => $invitation->role_id,
                    'status' => 'active',
                    'joined_at' => $member->joined_at ?? now(),
                ]);
            } else {
                OrganizationMember::create([
                    'organization_id' => $invitation->organization_id,
                    'user_id' => $userId,
                    'role_id' => $invitation->role_id,
                    'status' => 'active',
                    'joined_at' => now(),
                ]);
            }

            $invitation->update(['status' => 'accepted', 'accepted_at' => now()]);

            return $invitation;
        });
    }
}
