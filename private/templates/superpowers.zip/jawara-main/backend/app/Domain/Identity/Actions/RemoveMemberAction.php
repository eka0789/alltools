<?php

namespace App\Domain\Identity\Actions;

use App\Models\AuditLog;
use App\Models\OrganizationMember;
use Illuminate\Support\Facades\DB;

/**
 * Removes a member from an organization (FR-2). The last Organization Owner
 * cannot be removed, ensuring every organization always has an owner.
 */
class RemoveMemberAction
{
    public function execute(OrganizationMember $member, OrganizationMember $actor): void
    {
        if ($member->role->slug === 'organization-owner') {
            $ownerCount = OrganizationMember::where('organization_id', $member->organization_id)
                ->where('role_id', $member->role_id)
                ->where('status', 'active')
                ->count();

            if ($ownerCount <= 1) {
                throw new \DomainException('Organisasi harus memiliki minimal satu Owner.');
            }
        }

        DB::transaction(function () use ($member, $actor) {
            $member->update(['status' => 'removed']);

            AuditLog::create([
                'actor_user_id' => $actor->user_id,
                'organization_id' => $member->organization_id,
                'action' => 'member.removed',
                'subject_type' => OrganizationMember::class,
                'subject_id' => $member->id,
                'after' => ['status' => 'removed'],
            ]);
        });
    }
}
