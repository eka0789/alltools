<?php

namespace App\Domain\Directory\Actions;

use App\Models\BusinessProfile;
use App\Models\Organization;
use Illuminate\Support\Str;

/**
 * Creates or updates the organization's business profile (FR-2/FR-4).
 * Slug is stable after first creation so public URLs never change (SEO).
 */
class UpsertBusinessProfileAction
{
    public function execute(Organization $organization, array $data): BusinessProfile
    {
        $profile = BusinessProfile::forOrganization($organization)->first();

        if (! $profile) {
            $data['slug'] = Str::slug($data['display_name']).'-'.Str::lower(Str::random(6));
            $data['organization_id'] = $organization->id;

            return BusinessProfile::create($data);
        }

        $profile->update($data);

        return $profile->refresh();
    }
}
