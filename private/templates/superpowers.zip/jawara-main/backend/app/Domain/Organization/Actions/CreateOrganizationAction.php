<?php

namespace App\Domain\Organization\Actions;

use App\Models\Organization;
use App\Models\OrganizationMember;
use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Creates an organization and makes the creator its Organization Owner (FR-2).
 * Slug uniqueness is guaranteed with a random suffix.
 */
class CreateOrganizationAction
{
    public function execute(User $owner, string $name, string $organizationType, ?string $legalName = null): Organization
    {
        return DB::transaction(function () use ($owner, $name, $organizationType, $legalName) {
            $organization = Organization::create([
                'name' => $name,
                'slug' => Str::slug($name).'-'.Str::lower(Str::random(6)),
                'legal_name' => $legalName,
                'organization_type' => $organizationType,
                'status' => 'active',
                // Tier 3 referral: unique shareable code per organization.
                'referral_code' => strtoupper(substr(md5($name.now()->timestamp.Str::random(4)), 0, 8)),
            ]);

            OrganizationMember::create([
                'organization_id' => $organization->id,
                'user_id' => $owner->id,
                'role_id' => Role::where('slug', 'organization-owner')->firstOrFail()->id,
                'status' => 'active',
                'joined_at' => now(),
            ]);

            return $organization;
        });
    }
}
