<?php

namespace App\Enums;

/**
 * AD-4: explicit quotation state machine.
 *
 * draft → submitted → revised → accepted | rejected | withdrawn
 * accepted is terminal within quotation scope; expiry closes open quotations.
 */
enum QuotationStatus: string
{
    case Draft = 'draft';
    case Submitted = 'submitted';
    case Revised = 'revised';
    case Accepted = 'accepted';
    case Rejected = 'rejected';
    case Withdrawn = 'withdrawn';
    case Expired = 'expired';

    /** @return array<string> */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }

    public function allowedTransitions(): array
    {
        return match ($this) {
            self::Draft => [self::Submitted],
            self::Submitted => [self::Revised, self::Accepted, self::Rejected, self::Withdrawn, self::Expired],
            self::Revised => [self::Accepted, self::Rejected, self::Withdrawn, self::Expired],
            self::Accepted, self::Rejected, self::Withdrawn, self::Expired => [],
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return in_array($target, $this->allowedTransitions(), true);
    }
}
