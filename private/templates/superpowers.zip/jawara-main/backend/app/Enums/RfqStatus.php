<?php

namespace App\Enums;

/**
 * AD-4: explicit RFQ state machine.
 *
 * draft → published → closed | cancelled
 * published → awarded (requires an accepted quotation)
 */
enum RfqStatus: string
{
    case Draft = 'draft';
    case Published = 'published';
    case Closed = 'closed';
    case Cancelled = 'cancelled';
    case Awarded = 'awarded';

    /** @return array<string> */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }

    /** Transitions allowed from the current status (AD-4). */
    public function allowedTransitions(): array
    {
        return match ($this) {
            self::Draft => [self::Published, self::Cancelled],
            self::Published => [self::Closed, self::Cancelled, self::Awarded],
            self::Closed => [self::Awarded],
            self::Awarded, self::Cancelled => [],
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return in_array($target, $this->allowedTransitions(), true);
    }
}
