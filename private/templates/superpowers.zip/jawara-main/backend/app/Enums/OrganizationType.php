<?php

namespace App\Enums;

enum OrganizationType: string
{
    case Individual = 'individual';
    case Company = 'company';
    case Enterprise = 'enterprise';

    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }
}
