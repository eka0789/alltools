<?php

namespace App\Enums;

/**
 * AD-4: explicit purchase order state machine (separate lifecycle from
 * quotation acceptance — a PO is a business document of its own, spec Phase 06).
 *
 * draft → pending_approval → approved → issued → acknowledged → completed
 * cancellable from any pre-completed state (reason required).
 */
enum PurchaseOrderStatus: string
{
    case Draft = 'draft';
    case PendingApproval = 'pending_approval';
    case Approved = 'approved';
    case Issued = 'issued';
    case Acknowledged = 'acknowledged';
    case Completed = 'completed';
    case Cancelled = 'cancelled';

    /** @return array<string> */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }

    public function allowedTransitions(): array
    {
        return match ($this) {
            self::Draft => [self::PendingApproval, self::Cancelled],
            self::PendingApproval => [self::Approved, self::Cancelled],
            self::Approved => [self::Issued, self::Cancelled],
            self::Issued => [self::Acknowledged, self::Cancelled],
            self::Acknowledged => [self::Completed, self::Cancelled],
            self::Completed, self::Cancelled => [],
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return in_array($target, $this->allowedTransitions(), true);
    }
}
