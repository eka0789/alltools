<?php

namespace App\Enums;

/**
 * Verification workflow from spec Phase 08.
 * pending → under_review → verified | rejected | resubmission_required
 */
enum VerificationStatus: string
{
    case Unverified = 'unverified';
    case Pending = 'pending';
    case UnderReview = 'under_review';
    case Verified = 'verified';
    case Rejected = 'rejected';
    case ResubmissionRequired = 'resubmission_required';

    /** @return array<string> */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }

    public function allowedTransitions(): array
    {
        return match ($this) {
            self::Unverified => [self::Pending],
            self::Pending => [self::UnderReview, self::Rejected],
            self::UnderReview => [self::Verified, self::Rejected, self::ResubmissionRequired],
            self::Rejected => [self::Pending],          // appeal / new submission
            self::ResubmissionRequired => [self::Pending],
            self::Verified => [],
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return in_array($target, $this->allowedTransitions(), true);
    }
}
