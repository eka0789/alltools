# JAWARA Agent Orchestration Rules

You are working on JAWARA, a production-oriented B2B Business Ecosystem Platform (multi-tenant, Indonesian-first).

Engineering roles (BMAD agent personas + spec roles):

1. Product Architect (BMAD Winston/John) 2. Senior Backend Engineer (Amelia) 3. Senior Frontend Engineer 4. Database Engineer 5. UI/UX Engineer (Sally) 6. QA Engineer 7. Security Reviewer 8. DevOps Engineer

## Mandatory Review Sequence

Product requirements → Architecture → Database → Backend → Frontend → QA → Security → Deployment.

## Execution Rules

- Always inspect before changing. Plan before implementation.
- Work in small, reviewable milestones (Superpowers: plan → TDD → verify → commit).
- Do not skip database design. Do not bypass authorization.
- Do not use mock data as production data. No fake verification badges, metrics, or transactions.
- Do not claim successful tests without execution (verification-before-completion).
- Do not silently change established business rules. Do not mix unrelated domain responsibilities.
- Maintain documentation as the project evolves.

## Architecture Invariants (binding — see ARCHITECTURE-SPINE.md)

- AD-1 Tenant isolation via Laravel Policies + `BelongsToOrganization`; cross-tenant tests wajib.
- AD-2 UUID PK entitas bisnis. AD-3 Uang = decimal(18,2)+currency, snapshot immutable.
- AD-4 State machine procurement eksplisit (RFQ/Quotation/PO), transisi di DB transaction.
- AD-5 API `/api/v1` kontrak terdokumentasi di docs/API_CONTRACT.md.
- AD-6 RBAC di backend (Policies). AD-7 Sanctum cookie httpOnly. AD-8 Logika bisnis di Domain/Actions.
- AD-9 Public pages server-first SEO; private UI client islands. AD-10 SearchService/disk abstraction.
- AD-11 Upload security whitelist. AD-12 Audit log + idempotency operasi kritis.

## Engineering Gate

Never move to the next major milestone if: migrations fail; critical tests fail; cross-tenant access is possible; authorization is incomplete; financial operations are inconsistent; production secrets are exposed.

For every completed milestone report: business objective, files, technical implementation, DB changes, API changes, security considerations, tests executed + results, known limitations, next milestone.
