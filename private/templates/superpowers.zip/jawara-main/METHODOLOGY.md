# JAWARA — Metodologi Pengembangan: BMAD Method × Superpowers

Proyek JAWARA dikembangkan dengan menggabungkan dua metodologi AI-driven engineering:

## 1. BMAD Method (bmad-code-org/bmad-method v6.12.4)

Framework agile planning & orchestration berbasis agent. Terpasang di `_bmad/` dengan 29 skill di `.claude/skills/bmad-*`.

### Alur BMAD yang dijalankan

| Tahap | Skill BMAD | Output | Lokasi |
|---|---|---|---|
| 1. Analisis | `bmad-product-brief` (Mary — Analyst) | `brief.md` | `_bmad-output/planning-artifacts/briefs/brief-jawara-<tanggal>/` |
| 2. PRD | `bmad-prd` (John — PM) | `prd.md` | `_bmad-output/planning-artifacts/prds/prd-jawara-<tanggal>/` |
| 3. Arsitektur | `bmad-architecture` (Winston) | `ARCHITECTURE-SPINE.md` | `_bmad-output/planning-artifacts/architecture/architecture-jawara-<tanggal>/` |
| 4. Epics & Stories | `bmad-create-epics-and-stories` | epics + stories dengan AC | `_bmad-output/planning-artifacts/` |
| 5. Implementasi | `bmad-agent-dev` (Amelia) + review | kode + tests | `backend/`, `frontend/` |

Agent persona BMAD (Mary/John/Sally/Winston/Amelia) dipakai sebagai disiplin peran sesuai
`docs/spec-source/JAWARA-Agent-Orchestration.md`: Product Architect → Backend → Frontend →
QA → Security → Deployment, dengan Engineering Gate (tidak lanjut milestone jika migrasi/tests gagal).

## 2. Superpowers (obra/superpowers)

Library skill eksekusi disalin ke `.methodology/superpowers/`. Skill yang dipakai sebagai disiplin:

| Skill | Digunakan saat |
|---|---|
| `brainstorming` | Eksplorasi masalah sebelum planning |
| `writing-plans` | Menulis implementation plan per epic (tasks kecil, verifiable, file path spesifik) |
| `executing-plans` | Eksekusi plan per task dengan checkpoint commit |
| `test-driven-development` | Feature bisnis inti: RED-GREEN-REFACTOR, tidak ada kode produksi tanpa test gagal dulu |
| `systematic-debugging` | Saat error: reproduce → root cause → fix → regression test, bukan random patch |
| `verification-before-completion` | Wajib sebelum klaim milestone selesai: jalankan perintah, baca output, jangan asumsi |
| `requesting-code-review` / `receiving-code-review` | Review antar-milestone |
| `dispatching-parallel-agents` | Task independen (mis. dokumentasi + seed) dieksekusi paralel |
| `finishing-a-development-branch` | Menutup milestone: merge/rebase + bersih-bersih |

## 3. Cara keduanya digabung di proyek ini

1. **BMAD** memaksa kualitas *planning* (brief → PRD → arsitektur → stories dengan acceptance criteria).
2. **Superpowers** memaksa kualitas *eksekusi* (TDD, verification, debugging sistematis, review).
3. Setiap story BMAD dieksekusi dengan siklus Superpowers: plan task → TDD → verification → commit.
4. Engineering Gate dari spec asli (Agent Orchestration Rules) dipertahankan apa adanya:
   migrasi gagal / tests gagal / cross-tenant bocor / authorization bolong → **tidak lanjut milestone**.

## 4. Keputusan adaptasi environment (2026-11-21)

Mesin lokal: Windows + XAMPP (PHP 8.2, MariaDB 10.4, Apache), Node 24, Redis 3.0 — **tanpa Docker, tanpa PostgreSQL**.

| Spec asli | Adaptasi | Alasan |
|---|---|---|
| PostgreSQL + pgcrypto/JSONB/RLS | MariaDB lokal, migrasi portabel, UUID `char(36)` | Tidak ada PostgreSQL/Docker di mesin; Laravel `HasUuids` jalan di MySQL/MariaDB. Isolasi tenant ditegakkan di layer Policy Laravel (RLS adalah defense-in-depth opsional menurut spec Phase 02) |
| Docker Compose dev | File authored untuk produksi, dev lokal via `artisan serve` + `npm run dev` | Docker tidak tersedia; config tetap disiapkan agar parity produksi terdokumentasi |
| Meilisearch | Search DB (LIKE/full-text) + antarmuka `SearchService` | Swappable saat produksi |
| Laravel Reverb + S3 + queue redis | Didefer ke fase lanjut; queue lokal `database`/`sync` | Fokus MVP core; titik swap didokumentasikan di architecture spine |

Semua keputusan adaptasi dicatat di memlog BMAD masing-masing workspace dan `docs/DECISIONS.md`.
