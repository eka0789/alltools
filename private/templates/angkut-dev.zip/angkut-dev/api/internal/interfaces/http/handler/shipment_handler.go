package handler

import (
	"archive/zip"
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"

	"github.com/angkut/angkut/apps/api/internal/interfaces/http/httpx"
	"github.com/angkut/angkut/apps/api/internal/interfaces/http/middleware"
	"github.com/angkut/angkut/apps/api/internal/interfaces/http/response"
	"github.com/angkut/angkut/apps/internal/application/shipmentapp"
	"github.com/angkut/angkut/apps/internal/domain/shipment"
	"github.com/angkut/angkut/apps/internal/infrastructure/label"
)

// ShipmentService adalah antarmuka minimal service shipment untuk handler.
type ShipmentService interface {
	Create(ctx context.Context, orgID, actorUserID, requestID string, in shipmentapp.CreateInput) (*shipment.Shipment, error)
	Get(ctx context.Context, orgID, id string) (*shipment.Shipment, error)
	List(ctx context.Context, orgID string, f shipment.ListFilter) ([]shipment.Shipment, int, error)
	// GetByIDs dipakai label massal; id milik organisasi lain dilewati.
	GetByIDs(ctx context.Context, orgID string, ids []string) ([]shipment.Shipment, error)
	Transition(ctx context.Context, orgID, actorUserID, requestID, id string, target shipment.Status, reason string) (*shipment.Shipment, error)
	Cancel(ctx context.Context, orgID, actorUserID, requestID, id, reason string) (*shipment.Shipment, error)
}

// ShipmentHandler menangani endpoint pengiriman tenant-scoped.
type ShipmentHandler struct {
	svc ShipmentService
}

// NewShipmentHandler membuat handler pengiriman.
func NewShipmentHandler(svc ShipmentService) *ShipmentHandler {
	return &ShipmentHandler{svc: svc}
}

// RegisterRoutes mendaftarkan rute di /api/v1/shipments.
func (h *ShipmentHandler) RegisterRoutes(r chi.Router) {
	r.Get("/", h.List)
	r.Post("/", h.Create)
	r.Route("/{id}", func(one chi.Router) {
		one.Get("/", h.Get)
		one.Patch("/", h.Update)
		one.Post("/cancel", h.Cancel)
		one.Get("/label", h.Label)
		one.Get("/share-link", h.ShareLink)
	})
}

// List menangani GET /api/v1/shipments.
func (h *ShipmentHandler) List(w http.ResponseWriter, r *http.Request) {
	identity := middleware.IdentityFrom(r.Context())
	if identity == nil {
		response.Fail(w, unauthorized())
		return
	}
	q := r.URL.Query()
	f := shipment.ListFilter{
		Status:      shipment.Status(strings.TrimSpace(q.Get("status"))),
		Courier:     strings.TrimSpace(q.Get("courier")),
		StoreID:     strings.TrimSpace(q.Get("store_id")),
		WarehouseID: strings.TrimSpace(q.Get("warehouse_id")),
		OrderID:     strings.TrimSpace(q.Get("order_id")),
		Search:      strings.TrimSpace(q.Get("search")),
		From:        strings.TrimSpace(q.Get("from")),
		To:          strings.TrimSpace(q.Get("to")),
		Limit:       atoiDefault(q.Get("limit"), 20),
		Offset:      atoiDefault(q.Get("offset"), 0),
	}
	if f.Status != "" && !f.Status.Valid() {
		response.Fail(w, ValidationError(map[string]string{
			"status": "Status pengiriman tidak dikenal.",
		}))
		return
	}

	items, total, err := h.svc.List(r.Context(), identity.OrganizationID, f)
	if err != nil {
		response.Fail(w, err)
		return
	}
	// Sama seperti endpoint lain: kirim payload kontrak FE (objek courier,
	// pricing, dst.) — bukan struct domain mentah.
	payloads := make([]map[string]any, 0, len(items))
	for i := range items {
		payloads = append(payloads, shipmentPayload(&items[i]))
	}
	response.List(w, payloads, map[string]any{
		"total":  total,
		"limit":  f.Limit,
		"offset": f.Offset,
	})
}

// Create menangani POST /api/v1/shipments.
// Header Idempotency-Key wajib (dipasang RequireIdempotency di router) sehingga
// retry klien tidak menghasilkan pengiriman ganda.
func (h *ShipmentHandler) Create(w http.ResponseWriter, r *http.Request) {
	identity := middleware.IdentityFrom(r.Context())
	if identity == nil {
		response.Fail(w, unauthorized())
		return
	}
	req, ok := httpx.Decode[shipmentCreateRequest](w, r)
	if !ok {
		return
	}

	items := make([]shipmentapp.CreateItemInput, 0, len(req.Items))
	for _, it := range req.Items {
		items = append(items, shipmentapp.CreateItemInput{
			OrderItemID: it.OrderItemID,
			VariantID:   it.VariantID,
			Name:        it.Name,
			Qty:         it.Qty,
		})
	}

	sh, err := h.svc.Create(r.Context(), identity.OrganizationID, identity.UserID, requestID(r), shipmentapp.CreateInput{
		OrderID:              req.OrderID,
		StoreID:              req.StoreID,
		WarehouseID:          req.WarehouseID,
		CourierCode:          req.CourierCode,
		ServiceCode:          req.ServiceCode,
		OriginAddressID:      req.OriginAddressID,
		DestinationAddressID: req.DestinationAddressID,
		Weight:               req.Weight,
		Length:               req.Length,
		Width:                req.Width,
		Height:               req.Height,
		PackageType:          req.PackageType,
		IsCOD:                req.IsCOD,
		CODAmount:            req.CODAmount,
		DeclaredValue:        req.DeclaredValue,
		Insurance:            req.Insurance,
		Notes:                req.Notes,
		Items:                items,
		IdempotencyKey:       httpx.IdempotencyKey(r),
	})
	if err != nil {
		response.Fail(w, err)
		return
	}
	response.Created(w, shipmentPayload(sh))
}

// Get menangani GET /api/v1/shipments/{id}.
func (h *ShipmentHandler) Get(w http.ResponseWriter, r *http.Request) {
	identity := middleware.IdentityFrom(r.Context())
	if identity == nil {
		response.Fail(w, unauthorized())
		return
	}
	sh, err := h.svc.Get(r.Context(), identity.OrganizationID, chi.URLParam(r, "id"))
	if err != nil {
		response.Fail(w, err)
		return
	}
	response.OK(w, shipmentPayload(sh))
}

// Update menangani PATCH /api/v1/shipments/{id} — memindahkan status.
func (h *ShipmentHandler) Update(w http.ResponseWriter, r *http.Request) {
	identity := middleware.IdentityFrom(r.Context())
	if identity == nil {
		response.Fail(w, unauthorized())
		return
	}
	req, ok := httpx.Decode[shipmentUpdateRequest](w, r)
	if !ok {
		return
	}
	target := shipment.Status(strings.TrimSpace(req.Status))
	if !target.Valid() {
		response.Fail(w, ValidationError(map[string]string{
			"status": "Status pengiriman tidak dikenal.",
		}))
		return
	}
	sh, err := h.svc.Transition(r.Context(), identity.OrganizationID, identity.UserID, requestID(r),
		chi.URLParam(r, "id"), target, strings.TrimSpace(req.Reason))
	if err != nil {
		response.Fail(w, err)
		return
	}
	response.OK(w, shipmentPayload(sh))
}

// Cancel menangani POST /api/v1/shipments/{id}/cancel.
func (h *ShipmentHandler) Cancel(w http.ResponseWriter, r *http.Request) {
	identity := middleware.IdentityFrom(r.Context())
	if identity == nil {
		response.Fail(w, unauthorized())
		return
	}
	req, ok := httpx.Decode[shipmentCancelRequest](w, r)
	if !ok {
		return
	}
	sh, err := h.svc.Cancel(r.Context(), identity.OrganizationID, identity.UserID, requestID(r),
		chi.URLParam(r, "id"), strings.TrimSpace(req.Reason))
	if err != nil {
		response.Fail(w, err)
		return
	}
	response.OK(w, shipmentPayload(sh))
}

// Label menangani GET /api/v1/shipments/{id}/label?format=pdf|a4|thermal.
// Mengembalikan PDF inline (Content-Type application/pdf) sehingga FE dapat
// mengunduhnya atau menampilkannya langsung.
func (h *ShipmentHandler) Label(w http.ResponseWriter, r *http.Request) {
	identity := middleware.IdentityFrom(r.Context())
	if identity == nil {
		response.Fail(w, unauthorized())
		return
	}
	sh, err := h.svc.Get(r.Context(), identity.OrganizationID, chi.URLParam(r, "id"))
	if err != nil {
		response.Fail(w, err)
		return
	}

	format := strings.TrimSpace(r.URL.Query().Get("format"))
	if format == "" || format == "pdf" {
		format = "a4"
	}
	if format != "a4" && format != "thermal" {
		response.Fail(w, ValidationError(map[string]string{
			"format": "Format label harus a4 atau thermal.",
		}))
		return
	}

	pdf, err := generateLabelPDF(sh, format)
	if err != nil {
		response.Fail(w, fmt.Errorf("membuat label: %w", err))
		return
	}

	w.Header().Set("Content-Type", "application/pdf")
	w.Header().Set("Content-Disposition", `inline; filename="label-`+sh.AWB+`.pdf"`)
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(http.StatusOK)
	if _, err := w.Write(pdf); err != nil {
		// Respons sudah terkirim; hanya catat — tidak bisa mengubah status.
		return
	}
}

// generateLabelPDF membangun satu PDF label (dipakai label tunggal & massal).
func generateLabelPDF(sh *shipment.Shipment, format string) ([]byte, error) {
	cfg := label.DefaultConfig()
	cfg.Format = format
	gen := label.New(cfg)
	return gen.Generate(label.Data{
		Shipment:  sh,
		Origin:    label.Party{Name: warehouseLabel(sh)},
		PrintedAt: time.Now().UTC(),
	})
}

// bulkLabelsRequest adalah body POST /api/v1/shipments/labels/bulk.
type bulkLabelsRequest struct {
	IDs    []string `json:"ids"`
	Format string   `json:"format"`
}

// BulkLabels menangani POST /api/v1/shipments/labels/bulk { ids, format }.
//
// Mengembalikan ZIP berisi satu PDF per pengiriman (kontrak "bulk label
// print"). Prinsip per baris berlaku juga di sini: label yang gagal dibuat
// tidak membatalkan seluruh unduhan — kegagalannya dicatat ke berkas
// gagal.txt di dalam ZIP, dan hanya id milik organisasi ini yang dicetak.
func (h *ShipmentHandler) BulkLabels(w http.ResponseWriter, r *http.Request) {
	identity := middleware.IdentityFrom(r.Context())
	if identity == nil {
		response.Fail(w, unauthorized())
		return
	}
	req, ok := httpx.Decode[bulkLabelsRequest](w, r)
	if !ok {
		return
	}
	format := strings.TrimSpace(req.Format)
	if format == "" || format == "pdf" {
		format = "a4"
	}
	if format != "a4" && format != "thermal" {
		response.Fail(w, ValidationError(map[string]string{
			"format": "Format label harus a4 atau thermal.",
		}))
		return
	}
	if len(req.IDs) == 0 {
		response.Fail(w, ValidationError(map[string]string{"ids": "Minimal satu id pengiriman."}))
		return
	}
	if len(req.IDs) > 1000 {
		response.Fail(w, ValidationError(map[string]string{
			"ids": "Maksimal 1000 label per permintaan.",
		}))
		return
	}
	// Id bukan UUID tidak boleh sampai ke query: `ANY($2::uuid[])` akan gagal
	// di Postgres (22P02) dan berujung 500. Tolak sebagai validasi.
	for _, id := range req.IDs {
		if _, err := uuid.Parse(strings.TrimSpace(id)); err != nil {
			response.Fail(w, ValidationError(map[string]string{
				"ids": "Daftar id memuat nilai yang bukan UUID.",
			}))
			return
		}
	}

	shs, err := h.svc.GetByIDs(r.Context(), identity.OrganizationID, req.IDs)
	if err != nil {
		response.Fail(w, err)
		return
	}
	if len(shs) == 0 {
		response.Fail(w, ValidationError(map[string]string{
			"ids": "Tidak ada pengiriman milik organisasi ini pada daftar.",
		}))
		return
	}

	// Respons streaming: setelah header terkirim, kesalahan per label hanya
	// bisa dicatat ke dalam ZIP (bukan sebagai respons error JSON).
	w.Header().Set("Content-Type", "application/zip")
	w.Header().Set("Content-Disposition",
		`attachment; filename="labels-`+time.Now().UTC().Format("060102-150405")+`.zip"`)
	w.Header().Set("Cache-Control", "no-store")
	zw := zip.NewWriter(w)

	var failed []string
	for i := range shs {
		pdf, perr := generateLabelPDF(&shs[i], format)
		if perr != nil {
			failed = append(failed, shs[i].AWB+": "+perr.Error())
			continue
		}
		fw, cerr := zw.CreateHeader(&zip.FileHeader{
			Name:   "label-" + shs[i].AWB + ".pdf",
			Method: zip.Deflate,
		})
		if cerr != nil {
			failed = append(failed, shs[i].AWB+": menulis ke zip gagal")
			continue
		}
		if _, werr := fw.Write(pdf); werr != nil {
			failed = append(failed, shs[i].AWB+": menulis ke zip gagal")
		}
	}
	if len(failed) > 0 {
		mf, _ := zw.Create("gagal.txt")
		mf.Write([]byte(strings.Join(failed, "\n")))
	}
	_ = zw.Close()
}

// ShareLink menangani GET /api/v1/shipments/{id}/share-link.
// Tautan publik pelacakan dibangun dari WEB_URL + resi. Endpoint publik
// pelacakan ada di TASK-035 (/api/v1/public/track/{awb}); tautan tetap
// dilaporkan apa adanya dengan masa berlaku sehingga FE tidak menyimpan
// logika kadaluarsa.
func (h *ShipmentHandler) ShareLink(w http.ResponseWriter, r *http.Request) {
	identity := middleware.IdentityFrom(r.Context())
	if identity == nil {
		response.Fail(w, unauthorized())
		return
	}
	sh, err := h.svc.Get(r.Context(), identity.OrganizationID, chi.URLParam(r, "id"))
	if err != nil {
		response.Fail(w, err)
		return
	}
	// Masa berlaku 30 hari; nilai ini dipakai FE untuk menampilkan tenggat.
	expires := time.Now().UTC().Add(30 * 24 * time.Hour)
	response.OK(w, map[string]any{
		"awb":        sh.AWB,
		"url":        "/track/" + sh.AWB,
		"expires_at": expires.Format(time.RFC3339),
	})
}

// warehouseLabel mengembalikan nama tampilan asal (sementara: id gudang).
func warehouseLabel(sh *shipment.Shipment) string {
	if sh.WarehouseID != "" {
		return "Gudang " + sh.WarehouseID[:min(8, len(sh.WarehouseID))]
	}
	return "Asal pengiriman"
}

// shipmentPayload menyusun bentuk respons sesuai kontrak: field ringkas +
// detail paket/label yang dibutuhkan FE.
func shipmentPayload(sh *shipment.Shipment) map[string]any {
	if sh == nil {
		return nil
	}
	var qr, barcode string
	if len(sh.Packages) > 0 {
		qr = sh.Packages[0].QRPayload
		barcode = sh.Packages[0].BarcodeValue
	}
	return map[string]any{
		"id":     sh.ID,
		"awb":    sh.AWB,
		"status": string(sh.Status),
		"courier": map[string]any{
			"code":    sh.CourierCode,
			"service": sh.ServiceCode,
		},
		"order_id":               sh.OrderID,
		"store_id":               sh.StoreID,
		"warehouse_id":           sh.WarehouseID,
		"origin_address_id":      sh.OriginAddressID,
		"destination_address_id": sh.DestinationAddressID,
		"package": map[string]any{
			"actual_weight":     sh.ActualWeight,
			"volumetric_weight": sh.VolumetricWeight,
			"chargeable_weight": sh.ChargeableWeight,
			"length":            sh.Length,
			"width":             sh.Width,
			"height":            sh.Height,
			"type":              sh.PackageType,
		},
		"pricing": map[string]any{
			"shipping_price":   sh.ShippingPrice,
			"cost_price":       sh.CostPrice,
			"insurance_amount": sh.InsuranceAmount,
			"cod_fee":          sh.CODFee,
			"is_cod":           sh.IsCOD,
			"cod_amount":       sh.CODAmount,
			"declared_value":   sh.DeclaredValue,
		},
		"eta_min_days":  sh.EtaMinDays,
		"eta_max_days":  sh.EtaMaxDays,
		"qr_payload":    qr,
		"barcode_value": barcode,
		"label_url":     "/api/v1/shipments/" + sh.ID + "/label",
		"items":         sh.Items,
		"packages":      sh.Packages,
		"notes":         sh.Notes,
		"created_at":    sh.CreatedAt,
		"updated_at":    sh.UpdatedAt,
	}
}

// ─── Request DTOs ─────────────────────────────────────────────────────────

type shipmentCreateRequest struct {
	OrderID              string   `json:"order_id"`
	StoreID              string   `json:"store_id"`
	WarehouseID          string   `json:"warehouse_id"`
	CourierCode          string   `json:"courier_code"`
	ServiceCode          string   `json:"service_code"`
	OriginAddressID      string   `json:"origin_address_id"`
	DestinationAddressID string   `json:"destination_address_id"`
	Weight               float64  `json:"weight"`
	Length               *float64 `json:"length"`
	Width                *float64 `json:"width"`
	Height               *float64 `json:"height"`
	PackageType          string   `json:"package_type"`
	IsCOD                bool     `json:"is_cod"`
	CODAmount            int64    `json:"cod_amount"`
	DeclaredValue        int64    `json:"declared_value"`
	Insurance            bool     `json:"insurance"`
	Notes                string   `json:"notes"`
	Items                []struct {
		OrderItemID string `json:"order_item_id"`
		VariantID   string `json:"variant_id"`
		Name        string `json:"name"`
		Qty         int    `json:"qty"`
	} `json:"items"`
}

type shipmentUpdateRequest struct {
	Status string `json:"status"`
	Reason string `json:"reason"`
}

type shipmentCancelRequest struct {
	Reason string `json:"reason"`
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
