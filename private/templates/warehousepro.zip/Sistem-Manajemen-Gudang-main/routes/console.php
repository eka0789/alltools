<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Schedule::command('stock:notify-low-stock')->dailyAt('08:00');

Schedule::command('backup:clean')->dailyAt('02:30');
Schedule::command('backup:run')->dailyAt('02:00');
