<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->foreignId('purchase_unit_id')
                ->nullable()
                ->index()
                ->after('location_id')
                ->constrained('units')
                ->nullOnDelete();
            $table->decimal('units_per_purchase_unit', 15, 4)
                ->nullable()
                ->after('purchase_unit_id');
        });

        Schema::table('stock_in_items', function (Blueprint $table) {
            $table->foreignId('entered_unit_id')
                ->nullable()
                ->index()
                ->after('location_id')
                ->constrained('units')
                ->nullOnDelete();
            $table->decimal('entered_quantity', 15, 4)
                ->nullable()
                ->after('entered_unit_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('stock_in_items', function (Blueprint $table) {
            $table->dropConstrainedForeignId('entered_unit_id');
            $table->dropColumn('entered_quantity');
        });

        Schema::table('products', function (Blueprint $table) {
            $table->dropConstrainedForeignId('purchase_unit_id');
            $table->dropColumn('units_per_purchase_unit');
        });
    }
};
