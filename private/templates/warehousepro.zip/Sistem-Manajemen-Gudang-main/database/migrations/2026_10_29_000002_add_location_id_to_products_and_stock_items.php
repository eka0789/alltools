<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->foreignId('location_id')
                ->nullable()
                ->index()
                ->after('unit_id')
                ->constrained('locations')
                ->nullOnDelete();
        });

        Schema::table('stock_in_items', function (Blueprint $table) {
            $table->foreignId('location_id')
                ->nullable()
                ->index()
                ->after('product_id')
                ->constrained('locations')
                ->nullOnDelete();
        });

        Schema::table('stock_out_items', function (Blueprint $table) {
            $table->foreignId('location_id')
                ->nullable()
                ->index()
                ->after('product_id')
                ->constrained('locations')
                ->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('stock_out_items', function (Blueprint $table) {
            $table->dropConstrainedForeignId('location_id');
        });

        Schema::table('stock_in_items', function (Blueprint $table) {
            $table->dropConstrainedForeignId('location_id');
        });

        Schema::table('products', function (Blueprint $table) {
            $table->dropConstrainedForeignId('location_id');
        });
    }
};
