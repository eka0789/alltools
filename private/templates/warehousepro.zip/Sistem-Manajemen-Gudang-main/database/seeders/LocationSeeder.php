<?php

namespace Database\Seeders;

use App\Models\Location;
use App\Models\Warehouse;
use Illuminate\Database\Seeder;

class LocationSeeder extends Seeder
{
    /**
     * Seed the default rack/floor locations (A-F) for each active warehouse.
     */
    public function run(): void
    {
        $codes = [
            'A' => 'Rack A',
            'B' => 'Rack B',
            'C' => 'Rack C',
            'D' => 'Rack D',
            'E' => 'Rack E',
            'F' => 'F/Floor',
        ];

        $warehouses = Warehouse::query()->where('is_active', true)->get();

        foreach ($warehouses as $warehouse) {
            foreach ($codes as $code => $name) {
                $record = Location::withTrashed()->updateOrCreate(
                    ['warehouse_id' => $warehouse->getKey(), 'code' => $code],
                    [
                        'name' => $name,
                        'description' => null,
                        'is_active' => true,
                    ],
                );

                if ($record->trashed()) {
                    $record->restore();
                }
            }
        }
    }
}
