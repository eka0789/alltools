# Sistem Manajemen Gudang (WarehousePro)

![Laravel](https://img.shields.io/badge/Laravel-12.x-FF2D20?logo=laravel&logoColor=white)
![PHP](https://img.shields.io/badge/PHP-8.2%2B-777BB4?logo=php&logoColor=white)
![Tests](https://img.shields.io/badge/tests-262%20passing-2ea44f)
![License](https://img.shields.io/badge/license-MIT-blue)

**WarehousePro** (Inventory Suite) adalah aplikasi manajemen gudang dan inventori bergaya produksi yang dibangun dengan Laravel 12. Aplikasi ini menangani katalog produk, gudang dan lokasi rak, seluruh operasi stok, purchase order, laporan beserta ekspor, notifikasi low stock, audit log, hingga pengaturan sistem — semuanya dilindungi role dan permission.

> Repositori: [github.com/eka0789/Sistem-Manajemen-Gudang](https://github.com/eka0789/Sistem-Manajemen-Gudang)

## Fitur Utama

| Domain | Fitur |
| --- | --- |
| Autentikasi & Otorisasi | Login/logout berbasis session, RBAC (role + permission kustom), middleware `permission:`, Laravel Gates, dan proteksi elemen Blade sesuai permission. |
| Katalog | CRUD produk, kategori, dan supplier; satuan (unit); slug & SKU unik; validasi Form Request; soft delete; penugasan lokasi rak ke produk. |
| Gudang | Master gudang dan lokasi/rak penyimpanan dengan CRUD, validasi, otorisasi, dan soft delete. |
| Operasi Stok | Stock overview per gudang/produk, stock in, stock out, stock transfer antar gudang, stock adjustment beserta riwayat dan pembalikan (reverse), serta ledger pergerakan stok. |
| Konversi Satuan | Satuan pembelian (mis. karton) dengan `units_per_purchase_unit`; input stock in otomatis dikonversi ke satuan dasar produk. |
| Purchase Order | Draft, approve, cancel, receive (parsial/penuh) ke stok, item PO, dan validasi transisi status. |
| Pencarian & Scan | Pencarian global di topbar (shortcut `/` atau `Ctrl+K`) dan input scan barcode/SKU pada form stock in dan stock out. |
| Dokumen Cetak | Slip dokumen stock in dan stock out siap cetak dengan header perusahaan. |
| Laporan | Laporan inventory, stock movement, low stock, usage, dan purchase order dengan filter tanggal/entitas; ekspor **CSV, XLSX, dan PDF**. |
| Notifikasi | Bell notifikasi in-app, halaman notifikasi, mark-as-read, dan perintah terjadwal `stock:notify-low-stock` (email opsional). |
| Import Data | Import produk, supplier, dan kategori dari file beserta unduh template. |
| Audit & Trash | Audit log read-only untuk aksi penting (dengan penyamaran nilai sensitif) dan trash dengan restore/hapus permanen. |
| Sistem | Manajemen user, role & permission, profil pengguna, pengaturan perusahaan, backup otomatis, dan dashboard ringkas. |

## Tangkapan Layar

### Halaman Login

<p align="center">
  <img src="docs/screenshots/warehouse-login.png" alt="Halaman login WarehousePro" width="900">
</p>

### Dashboard

<p align="center">
  <img src="docs/screenshots/warehouse-dashboard.png" alt="Dashboard WarehousePro" width="900">
</p>

## Teknologi

| Lapisan | Teknologi |
| --- | --- |
| Backend | PHP 8.2+, Laravel 12 |
| Database | MySQL/MariaDB untuk pengembangan, SQLite in-memory untuk test |
| Frontend | Bootstrap 5 + Tailwind CSS 4, Vite 6, Chart.js |
| Ekspor | `maatwebsite/excel` (XLSX), `barryvdh/laravel-dompdf` (PDF), CSV native |
| Operasional | `spatie/laravel-backup`, Laravel Scheduler & Queue |
| Testing | PHPUnit 11 + Laravel feature tests |

## Persyaratan

- PHP 8.2 atau lebih baru (ekstensi `mbstring`, `openssl`, `pdo_mysql`, `zip`, `gd`)
- Composer 2
- Node.js 18+ dan npm
- MySQL/MariaDB (mis. XAMPP) atau database lain yang didukung Laravel
- `mysqldump` tersedia di `PATH` bila ingin memakai fitur backup (di XAMPP: `C:\xampp\mysql\bin`)

## Instalasi

```bash
git clone https://github.com/eka0789/Sistem-Manajemen-Gudang.git
cd Sistem-Manajemen-Gudang

composer install
npm install

cp .env.example .env
php artisan key:generate
```

Sesuaikan koneksi database dan kredensial super admin di `.env`:

```env
APP_NAME=WarehousePro
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=wms
DB_USERNAME=root
DB_PASSWORD=

SEED_SUPER_ADMIN_NAME=superadmin
SEED_SUPER_ADMIN_EMAIL=superadmin@example.com
SEED_SUPER_ADMIN_PASSWORD=ubah-password-ini
```

Jalankan migrasi, seeder, build aset, lalu server:

```bash
php artisan migrate --seed
npm run build
php artisan serve
```

Aplikasi tersedia di `http://127.0.0.1:8000`.

### Catatan XAMPP

- Letakkan proyek di `htdocs` dan akses lewat `http://localhost/Sistem-Manajemen-Gudang/public`, atau arahkan virtual host ke folder `public`.
- Pastikan modul `rewrite` Apache aktif dan MySQL berjalan.
- Buat file `wms` di phpMyAdmin sebelum menjalankan `php artisan migrate --seed`.

## Akun Super Admin

Seeder RBAC membuat 4 role (**Super Admin**, **Manager**, **Warehouse Staff**, **Viewer**), permission beserta pemetaannya, satuan produk, lokasi rak awal, dan satu akun Super Admin.

Kredensial akun awal sepenuhnya berasal dari `.env` (`SEED_SUPER_ADMIN_*`). Jika email atau password kosong, seeder berhenti dengan pesan error dan **tidak** membuat akun default yang tidak aman. Jangan pernah menaruh kredensial asli di dalam repositori.

## Role & Permission

- Nama permission mengikuti pola `modul.aksi`, contoh: `products.view`, `products.create`, `products.import`, `stock-in.create`, `purchase-orders.approve`, `reports.export`, `settings.manage`, `audit-logs.view`.
- Route dilindungi middleware `permission:<nama>`; elemen UI dilindungi `@can('permission', '<nama>')`.
- Role bawaan: **Super Admin** (semua akses), **Manager** (operasional + laporan + backup/settings), **Warehouse Staff** (transaksi stok), **Viewer** (baca saja).
- Ringkasan pemetaan halaman ke permission ada di [docs/operations.md](docs/operations.md).

## Scheduler & Queue

Beberapa fitur bergantung pada Laravel Scheduler dan queue worker:

| Jam | Perintah | Fungsi |
| --- | --- | --- |
| 02:00 | `backup:run` | Backup database + file ke `storage/app/backups` |
| 02:30 | `backup:clean` | Menghapus backup yang melewati masa retensi |
| 08:00 | `stock:notify-low-stock` | Notifikasi item di bawah reorder level |

```bash
# Linux (cron)
* * * * * cd /path/to/wms && php artisan schedule:run >> /dev/null 2>&1

# Windows (Task Scheduler, tiap 1 menit)
C:\xampp\php\php.exe C:\xampp\htdocs\WMS\artisan schedule:run

# Queue worker
php artisan queue:work --tries=1
```

Tanpa queue worker, email notifikasi tidak terkirim; tanpa scheduler, tidak ada notifikasi low stock harian dan backup otomatis.

## Backup & Restore

```bash
php artisan backup:run      # backup manual
php artisan backup:list     # daftar backup
php artisan backup:clean    # bersihkan backup kadaluarsa
```

Konfigurasi ada di `config/backup.php`. Untuk restore, ekstrak file `.zip` di `storage/app/backups`, lalu impor `db-dumps/*.sql`:

```bash
mysql -u root wms < db-dumps/<file>.sql
```

## Testing

```bash
php artisan test        # seluruh test suite
npm run build           # cek build aset frontend
./vendor/bin/pint       # format kode (opsional)
```

Baseline saat ini: **262 tests passing (1498 assertions)**. Test berjalan di SQLite in-memory sesuai `phpunit.xml`, sehingga tidak menyentuh database MySQL pengembangan.

## Struktur Proyek

```text
app/
├── Http/Controllers/     # Controller per modul (Catalog, Stock, PurchaseOrder, Report, System, Warehouse)
├── Http/Requests/        # Validasi Form Request
├── Models/               # Model Eloquent + relasi
├── Services/             # Logika stok, workflow PO, laporan, audit, backup
└── Console/Commands/     # Perintah terjadwal (low stock)
database/
├── migrations/           # Skema database
└── seeders/              # Role, permission, unit, lokasi, super admin
docs/                     # Desain database, ERD, panduan testing & operasional
resources/
├── css/app.css           # Design token & komponen UI
├── js/app.js             # Sidebar, pencarian global, scan barcode, chart
└── views/                # Blade per modul
tests/                    # Feature & unit test
```

## Dokumentasi

- [Desain Database](docs/database/database-design.md)
- [Entity Relationship Diagram](docs/database/erd.md)
- [Panduan Testing](docs/testing/testing-guide.md)
- [Panduan Operasional](docs/operations.md)

## Alur Git

Pengembangan diorganisasi dengan branch fokus dan pull request:

```text
feature/<nama-fitur>
fix/<nama-perbaikan>
```

Prefix commit yang dipakai:

```text
feat: ...
fix: ...
docs: ...
test: ...
refactor: ...
```

Sebelum membuat pull request:

```bash
git status --short
php artisan test
npm run build
git diff --stat
```

## Lisensi

Dirilis di bawah [MIT License](https://opensource.org/licenses/MIT).
