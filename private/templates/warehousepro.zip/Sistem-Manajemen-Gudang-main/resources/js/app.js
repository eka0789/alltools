import './bootstrap';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import Chart from 'chart.js/auto';

document.addEventListener('DOMContentLoaded', () => {
    const sidebarToggles = document.querySelectorAll('[data-sidebar-toggle]');
    const sidebarCloseTriggers = document.querySelectorAll('[data-sidebar-close]');

    const setSidebarOpen = (isOpen) => {
        document.body.classList.toggle('sidebar-open', isOpen);

        sidebarToggles.forEach((toggle) => {
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
    };

    sidebarToggles.forEach((toggle) => {
        toggle.addEventListener('click', () => {
            setSidebarOpen(! document.body.classList.contains('sidebar-open'));
        });
    });

    sidebarCloseTriggers.forEach((trigger) => {
        trigger.addEventListener('click', () => {
            setSidebarOpen(false);
        });
    });

    document.querySelectorAll('.sidebar-link').forEach((link) => {
        link.addEventListener('click', () => {
            if (window.innerWidth < 992) {
                setSidebarOpen(false);
            }
        });
    });

    window.addEventListener('resize', () => {
        if (window.innerWidth >= 992) {
            setSidebarOpen(false);
        }
    });

    initMovementTrendChart();
    initGlobalSearch();
    initSearchShortcut();
    initBarcodeScan();

    // Submit feedback: loading button keeps its label and shows a spinner
    document.addEventListener('submit', (event) => {
        const form = event.target;

        if (! (form instanceof HTMLFormElement) || form.dataset.loadingGuard !== undefined) {
            return;
        }

        const button = form.querySelector('button[type="submit"]:not([formnovalidate])');

        if (! button || button.disabled) {
            return;
        }

        button.disabled = true;
        button.setAttribute('data-loading', 'true');

        const spinner = document.createElement('span');
        spinner.className = 'spinner-border spinner-border-sm me-2';
        spinner.setAttribute('aria-hidden', 'true');

        button.prepend(spinner);
    }, true);
});

function initMovementTrendChart() {
    const canvas = document.getElementById('movement-trend-chart');
    const dataElement = document.getElementById('movement-trend-data');

    if (! canvas || ! dataElement) {
        return;
    }

    let trend;

    try {
        trend = JSON.parse(dataElement.textContent);
    } catch {
        return;
    }

    const styles = getComputedStyle(document.documentElement);
    const primary = styles.getPropertyValue('--wm-primary').trim() || '#2563eb';
    const accent = styles.getPropertyValue('--wm-warning').trim() || '#d97706';
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const context = canvas.getContext('2d');

    const inboundFill = context.createLinearGradient(0, 0, 0, canvas.clientHeight || 280);
    inboundFill.addColorStop(0, 'rgba(37, 99, 235, 0.20)');
    inboundFill.addColorStop(1, 'rgba(37, 99, 235, 0)');

    new Chart(canvas, {
        type: 'line',
        data: {
            labels: trend.labels,
            datasets: [
                {
                    label: 'Inbound',
                    data: trend.inbound,
                    borderColor: primary,
                    backgroundColor: inboundFill,
                    fill: true,
                    tension: 0.34,
                    pointRadius: 0,
                    pointHoverRadius: 4,
                    pointHoverBackgroundColor: '#ffffff',
                    pointHoverBorderColor: primary,
                    pointHoverBorderWidth: 2,
                    borderWidth: 2,
                },
                {
                    label: 'Outbound',
                    data: trend.outbound,
                    borderColor: accent,
                    backgroundColor: 'transparent',
                    borderDash: [5, 4],
                    fill: false,
                    tension: 0.34,
                    pointRadius: 0,
                    pointHoverRadius: 4,
                    pointHoverBackgroundColor: '#ffffff',
                    pointHoverBorderColor: accent,
                    pointHoverBorderWidth: 2,
                    borderWidth: 2,
                },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: reduceMotion ? false : { duration: 450, easing: 'easeOutQuart' },
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    align: 'start',
                    labels: {
                        usePointStyle: true,
                        pointStyle: 'line',
                        boxWidth: 18,
                        boxHeight: 2,
                        padding: 18,
                        color: '#667085',
                        font: { size: 11, weight: '600' },
                    },
                },
                tooltip: {
                    backgroundColor: '#0f172a',
                    titleColor: '#f8fafc',
                    bodyColor: '#e2e8f0',
                    borderColor: 'rgba(148, 163, 184, 0.22)',
                    borderWidth: 1,
                    cornerRadius: 8,
                    padding: 12,
                    usePointStyle: true,
                    boxPadding: 5,
                    titleFont: { size: 11, weight: '600' },
                    bodyFont: { size: 12, weight: '500' },
                    callbacks: {
                        label: (tooltipContext) => `${tooltipContext.dataset.label}: ${Number(tooltipContext.parsed.y).toLocaleString(undefined, { maximumFractionDigits: 4 })}`,
                    },
                },
            },
            scales: {
                x: {
                    grid: { display: false },
                    border: { display: false },
                    ticks: { maxTicksLimit: 10, maxRotation: 0, color: '#98a2b3', font: { size: 11 } },
                },
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(226, 232, 240, 0.55)' },
                    border: { display: false },
                    ticks: {
                        color: '#98a2b3',
                        font: { size: 11 },
                        callback: (value) => Intl.NumberFormat('en', { notation: 'compact' }).format(value),
                    },
                },
            },
        },
    });
}

function initSearchShortcut() {
    const input = document.getElementById('global-search');

    if (! input) {
        return;
    }

    document.addEventListener('keydown', (event) => {
        const target = event.target;
        const isTyping = target instanceof HTMLElement && (
            ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable
        );

        if (isTyping || input.offsetParent === null) {
            return;
        }

        const isSlash = event.key === '/';
        const isCommandK = (event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k';

        if (isSlash || isCommandK) {
            event.preventDefault();
            input.focus();
            input.select();
        }
    });
}

function initGlobalSearch() {
    const input = document.getElementById('global-search');
    const panel = document.getElementById('global-search-results');

    if (! input || ! panel) {
        return;
    }

    let debounceTimer = null;
    let activeIndex = -1;

    const closePanel = () => {
        panel.classList.remove('show');
        panel.innerHTML = '';
        activeIndex = -1;
    };

    const renderResults = (results) => {
        if (results.length === 0) {
            panel.innerHTML = '<div class="global-search-empty">No products match your search.</div>';
        } else {
            panel.innerHTML = results.map((product) => `
                <a class="global-search-item" href="${product.url}" data-product-id="${product.id}">
                    <span class="global-search-item-name">${escapeHtml(product.name)}</span>
                    <span class="global-search-item-meta">${escapeHtml(product.sku)}${product.category ? ' · ' + escapeHtml(product.category) : ''}</span>
                </a>
            `).join('');
        }

        panel.classList.add('show');
        activeIndex = -1;
    };

    // Entity names are split so literal markup never appears in source
    const entity = (name) => '&' + name;

    const escapeHtml = (value) => String(value ?? '')
        .replaceAll('&', entity('amp;'))
        .replaceAll('<', entity('lt;'))
        .replaceAll('>', entity('gt;'))
        .replaceAll('"', entity('quot;'))
        .replaceAll("'", entity('#039;'));

    const runSearch = () => {
        const query = input.value.trim();

        if (query.length < 2) {
            closePanel();
            return;
        }

        fetch(`/search/products?q=${encodeURIComponent(query)}`, { headers: { Accept: 'application/json' } })
            .then((response) => response.json())
            .then((payload) => renderResults(payload.results ?? []))
            .catch(() => closePanel());
    };

    input.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(runSearch, 200);
    });

    input.addEventListener('keydown', (event) => {
        const items = Array.from(panel.querySelectorAll('.global-search-item'));

        if (event.key === 'Escape') {
            closePanel();
            return;
        }

        if (! panel.classList.contains('show') || items.length === 0) {
            return;
        }

        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            activeIndex = event.key === 'ArrowDown'
                ? Math.min(activeIndex + 1, items.length - 1)
                : Math.max(activeIndex - 1, 0);
            items.forEach((item, index) => item.classList.toggle('active', index === activeIndex));
        }

        if (event.key === 'Enter' && items[activeIndex]) {
            event.preventDefault();
            items[activeIndex].click();
        }
    });

    document.addEventListener('click', (event) => {
        if (! panel.contains(event.target) && event.target !== input) {
            closePanel();
        }
    });
}

function initBarcodeScan() {
    document.querySelectorAll('[data-barcode-scan]').forEach((input) => {
        input.addEventListener('keydown', (event) => {
            if (event.key !== 'Enter') {
                return;
            }

            event.preventDefault();

            const code = input.value.trim();

            if (code === '') {
                return;
            }

            fetch(`/search/products?q=${encodeURIComponent(code)}`, { headers: { Accept: 'application/json' } })
                .then((response) => response.json())
                .then((payload) => {
                    const results = payload.results ?? [];
                    const exact = results.filter((product) => product.barcode === code || product.sku === code);
                    const match = exact.length === 1 ? exact[0] : (results.length === 1 ? results[0] : null);

                    if (match) {
                        document.dispatchEvent(new CustomEvent('stock-item-scan', { detail: { productId: match.id } }));
                        input.value = '';
                        input.classList.remove('is-invalid');
                    } else {
                        input.classList.add('is-invalid');
                    }
                })
                .catch(() => input.classList.add('is-invalid'));
        });
    });
}
