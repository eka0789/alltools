@php
    $nextDirection = \App\Support\Sortable::nextDirection($currentSort ?? null, $currentDirection ?? null, $column);
    $isActive = ($currentSort ?? 'created_at') === $column;
    $arrow = '';
    if ($isActive) {
        $arrow = strtolower((string) ($currentDirection ?? 'desc')) === 'asc'
            ? ' <span aria-hidden="true">▲</span>'
            : ' <span aria-hidden="true">▼</span>';
    }
@endphp

<th scope="col" class="{{ $class ?? '' }}">
    <a
        href="{{ request()->fullUrlWithQuery(['sort' => $column, 'direction' => $nextDirection, 'page' => null]) }}"
        class="table-sort-link text-decoration-none"
    >
        {{ $label }}{!! $arrow !!}
    </a>
</th>
