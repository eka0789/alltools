@extends('layouts.app')

@section('title', 'Notifications - ' . config('app.name'))

@section('content')
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Notifications</h1>
            <p class="text-muted mb-0">{{ $unreadCount }} unread of {{ $notifications->total() }} total.</p>
        </div>

        @if ($unreadCount > 0)
            <form method="POST" action="{{ route('notifications.read-all') }}">
                @csrf
                <button type="submit" class="btn btn-outline-primary">Mark all as read</button>
            </form>
        @endif
    </div>

    @if (session('success'))
        <div class="alert alert-success" role="alert">{{ session('success') }}</div>
    @endif

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="list-group list-group-flush">
                @forelse ($notifications as $notification)
                    @php
                        $data = $notification->data;
                        $count = (int) ($data['low_stock_count'] ?? 0);
                        $isUnread = $notification->read_at === null;
                    @endphp
                    <div class="list-group-item d-flex align-items-start justify-content-between gap-3 {{ $isUnread ? 'fw-semibold' : '' }}">
                        <div>
                            <div>
                                @if ($isUnread)
                                    <span class="badge text-bg-primary me-1">New</span>
                                @endif
                                Low stock alert — {{ $count }} item(s) at or below reorder level.
                            </div>
                            <div class="small text-muted mt-1">{{ $notification->created_at->format('M d, Y H:i') }}</div>
                        </div>
                        <div class="d-flex gap-2">
                            <a href="{{ route('reports.low-stock') }}" class="btn btn-outline-secondary btn-sm">View report</a>
                            @if ($isUnread)
                                <form method="POST" action="{{ route('notifications.read', $notification) }}">
                                    @csrf
                                    <button type="submit" class="btn btn-outline-primary btn-sm">Mark read</button>
                                </form>
                            @endif
                        </div>
                    </div>
                @empty
                    <div class="list-group-item text-center text-muted py-5">
                        No notifications yet. Low stock alerts will appear here daily.
                    </div>
                @endforelse
            </div>
        </div>

        @if ($notifications->hasPages())
            <div class="card-footer bg-white">
                {{ $notifications->links() }}
            </div>
        @endif
    </div>
@endsection
