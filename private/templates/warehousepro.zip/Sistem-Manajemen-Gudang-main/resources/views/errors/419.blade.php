@extends('errors.base-error', [
    'code' => '419',
    'title' => 'Session expired',
    'message' => 'Your session has expired. Please go back, refresh the page, and try again.',
])
