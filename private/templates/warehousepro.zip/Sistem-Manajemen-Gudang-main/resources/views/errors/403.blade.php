@extends('errors.base-error', [
    'code' => '403',
    'title' => 'Access denied',
    'message' => 'You do not have permission to view this page. Please contact an administrator if you believe this is a mistake.',
])
