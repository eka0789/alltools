<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f4f6fa">
    <title>{{ $code }} — {{ config('app.name') }}</title>
    <style>
        :root {
            color-scheme: light;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 1.5rem;
            font-family: 'Instrument Sans', 'Segoe UI', system-ui, sans-serif;
            color: #101828;
            background-color: #eef3fb;
            background-image:
                radial-gradient(46rem 28rem at 14% 6%, rgba(56, 189, 248, 0.16), transparent 62%),
                radial-gradient(44rem 26rem at 88% 2%, rgba(37, 99, 235, 0.16), transparent 62%),
                linear-gradient(rgba(15, 23, 42, 0.035) 1px, transparent 1px),
                linear-gradient(90deg, rgba(15, 23, 42, 0.035) 1px, transparent 1px);
            background-size: auto, auto, 32px 32px, 32px 32px;
        }

        .card {
            width: 100%;
            max-width: 27rem;
            padding: 2.6rem 2.4rem;
            background: #ffffff;
            border: 1px solid #e3e8f0;
            border-radius: 1.1rem;
            box-shadow: 0 30px 60px -36px rgba(15, 23, 42, 0.45);
            text-align: center;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            margin-bottom: 1.1rem;
            padding: 0.3rem 0.6rem;
            border: 1px solid #e3e8f0;
            border-radius: 999px;
            background: #f8fafc;
            color: #667085;
            font-size: 0.67rem;
            font-weight: 700;
            letter-spacing: 0.1em;
            text-transform: uppercase;
        }

        .eyebrow::before {
            content: "";
            width: 0.36rem;
            height: 0.36rem;
            border-radius: 50%;
            background: #2563eb;
        }

        .code {
            margin: 0;
            color: #2563eb;
            font-size: 3.6rem;
            font-weight: 800;
            letter-spacing: -0.04em;
            line-height: 1;
        }

        h1 {
            margin: 0.55rem 0 0.7rem;
            color: #0f172a;
            font-size: 1.2rem;
            font-weight: 700;
            letter-spacing: -0.02em;
        }

        p {
            margin: 0 0 1.6rem;
            color: #667085;
            font-size: 0.9rem;
            line-height: 1.6;
        }

        a {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            padding: 0.62rem 1.1rem;
            border-radius: 0.6rem;
            background: #2563eb;
            color: #ffffff;
            text-decoration: none;
            font-size: 0.86rem;
            font-weight: 650;
            box-shadow: 0 10px 20px -12px rgba(37, 99, 235, 0.8);
            transition: background-color 150ms ease-out, transform 150ms ease-out;
        }

        a:hover {
            background: #1d4ed8;
            transform: translateY(-1px);
        }

        a svg {
            width: 0.95rem;
            height: 0.95rem;
        }

        @media (prefers-reduced-motion: reduce) {
            a {
                transition: none;
            }

            a:hover {
                transform: none;
            }
        }
    </style>
</head>
<body>
    <main class="card">
        <span class="eyebrow">Error {{ $code }}</span>
        <p class="code">{{ $code }}</p>
        <h1>{{ $title }}</h1>
        <p>{{ $message }}</p>
        <a href="{{ url('/dashboard') }}">
            Back to dashboard
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h14m0 0-5-5m5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </a>
    </main>
</body>
</html>