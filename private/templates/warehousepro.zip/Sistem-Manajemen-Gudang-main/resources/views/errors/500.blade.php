@extends('errors.base-error', [
    'code' => '500',
    'title' => 'Something went wrong',
    'message' => 'An unexpected error occurred. Please try again, or contact an administrator if the problem persists.',
])
