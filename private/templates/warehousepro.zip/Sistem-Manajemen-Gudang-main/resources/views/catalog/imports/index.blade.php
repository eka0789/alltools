@extends('layouts.app')

@section('title', 'Data Import - ' . config('app.name'))

@section('content')
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Data Import</h1>
            <p class="text-muted mb-0">Bulk import master data from CSV/XLSX. Download a template first.</p>
        </div>
    </div>

    @if (session('error'))
        <div class="alert alert-danger" role="alert">
            {{ session('error') }}
        </div>
    @endif

    @if (is_iterable(session('import_errors')) && count(session('import_errors')) > 0)
        <div class="alert alert-warning" role="alert">
            <strong>{{ count(session('import_errors')) }} row(s) were skipped:</strong>
            <ul class="mb-0 mt-2">
                @foreach (array_slice(session('import_errors'), 0, 25) as $importError)
                    <li>{{ $importError }}</li>
                @endforeach
                @if (count(session('import_errors')) > 25)
                    <li>… and {{ count(session('import_errors')) - 25 }} more.</li>
                @endif
            </ul>
        </div>
    @endif

    <div class="row g-4">
        @foreach ($types as $typeKey => $typeConfig)
            @can('permission', $typeConfig['permission'])
                <div class="col-lg-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <h2 class="h5 mb-0">{{ $typeConfig['label'] }}</h2>
                                <a href="{{ route('imports.template', $typeKey) }}" class="btn btn-outline-secondary btn-sm">Template</a>
                            </div>
                            <p class="small text-muted">Columns: <code>{{ implode(', ', $typeConfig['columns']) }}</code></p>

                            <form method="POST" action="{{ route('imports.store', $typeKey) }}" enctype="multipart/form-data">
                                @csrf
                                <input type="file" name="file" class="form-control form-control-sm @error('file') is-invalid @enderror" accept=".csv,.txt,.xlsx" required>
                                @error('file')<div class="invalid-feedback">{{ $message }}</div>@enderror
                                <button type="submit" class="btn btn-primary btn-sm w-100 mt-3">Upload & Import</button>
                            </form>
                        </div>
                    </div>
                </div>
            @endcan
        @endforeach
    </div>

    <div class="alert alert-light border mt-4" role="alert">
        <strong>Notes:</strong> valid rows are imported, invalid rows are reported and skipped. Products import also supports
        opening stock via <code>warehouse_code</code> + <code>opening_stock</code>. Duplicate names/SKUs inside one file or
        against existing records are rejected.
    </div>
@endsection
