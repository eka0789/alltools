@extends('layouts.app')

@section('title', 'Import Products - ' . config('app.name'))

@section('content')
    <div class="d-flex align-items-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Import Products</h1>
            <p class="text-muted mb-0">Bulk import product master data and opening stock from CSV/XLSX.</p>
        </div>

        <a href="{{ route('products.index') }}" class="btn btn-outline-secondary">Back</a>
    </div>

    @if (session('error'))
        <div class="alert alert-danger" role="alert">
            {{ session('error') }}
        </div>
    @endif

    @if (is_iterable(session('import_errors')) && count(session('import_errors')) > 0)
        <div class="alert alert-warning" role="alert">
            <strong>{{ count(session('import_errors')) }} row(s) were skipped:</strong>
            <ul class="mb-0 mt-2">
                @foreach (array_slice(session('import_errors'), 0, 25) as $importError)
                    <li>{{ $importError }}</li>
                @endforeach
                @if (count(session('import_errors')) > 25)
                    <li>… and {{ count(session('import_errors')) - 25 }} more.</li>
                @endif
            </ul>
        </div>
    @endif

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <h2 class="h5 mb-2">How it works</h2>
            <ul class="text-muted mb-3">
                <li>Download the template, fill in your items, then upload the file below.</li>
                <li><code>sku</code>, <code>name</code>, <code>category</code>, and <code>unit</code> are required.</li>
                <li><code>category</code> must match an existing category name; <code>unit</code> must match a unit short name (e.g. pcs, liter, kg).</li>
                <li><code>location_code</code> must match an existing rack location code (A, B, C, …) — optional.</li>
                <li>Set <code>opening_stock</code> together with <code>warehouse_code</code> to record initial stock; one stock-in document is created per warehouse.</li>
                <li>Valid rows are imported; invalid rows are reported and skipped.</li>
            </ul>
            <a href="{{ route('products.import.template') }}" class="btn btn-outline-primary btn-sm">Download CSV Template</a>
        </div>
    </div>

    <form method="POST" action="{{ route('products.import.store') }}" enctype="multipart/form-data" class="card shadow-sm border-0">
        @csrf

        <div class="card-body">
            <div class="mb-3">
                <label for="file" class="form-label">Import File <span class="text-danger">*</span></label>
                <input
                    type="file"
                    name="file"
                    id="file"
                    class="form-control @error('file') is-invalid @enderror"
                    accept=".csv,.txt,.xlsx"
                    required
                >
                <div class="form-text">Accepted formats: CSV, TXT, XLSX (max 10 MB).</div>
                @error('file')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
        </div>

        <div class="card-footer bg-white d-flex justify-content-end gap-2">
            <a href="{{ route('products.index') }}" class="btn btn-outline-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary">Upload & Import</button>
        </div>
    </form>
@endsection
