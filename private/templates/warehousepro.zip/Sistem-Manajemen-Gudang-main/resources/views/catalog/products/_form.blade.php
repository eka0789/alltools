@php
    $product = $product ?? null;
    $isActive = old('is_active', $product?->is_active ?? true);
    $selectedCategoryId = old('category_id', $product?->category_id);
    $selectedUnitId = old('unit_id', $product?->unit_id);
    $selectedLocationId = old('location_id', $product?->location_id);
@endphp

@if ($categories->isEmpty())
    <div class="alert alert-warning" role="alert">
        Please create an active category before creating a product.
    </div>
@endif

    @if ($units->isEmpty())
        <div class="alert alert-warning" role="alert">
            No active units found. Unit seed/support data is required before creating products.
        </div>
    @endif

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="location_id" class="form-label">Rack / Location</label>
            <select
                name="location_id"
                id="location_id"
                class="form-select @error('location_id') is-invalid @enderror"
            >
                <option value="">No location assigned</option>
                @foreach ($locations as $location)
                    <option value="{{ $location->id }}" @selected((string) $selectedLocationId === (string) $location->id)>
                        {{ $location->code }}@if ($location->name) — {{ $location->name }}@endif
                    </option>
                @endforeach
            </select>
            <div class="form-text">Rack or storage location code (e.g. A, B, C, Floor).</div>
            @error('location_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="col-md-6 mb-3">
            <label for="purchase_unit_id" class="form-label">Purchase Unit (optional)</label>
            <select
                name="purchase_unit_id"
                id="purchase_unit_id"
                class="form-select @error('purchase_unit_id') is-invalid @enderror"
            >
                <option value="">Same as base unit (no conversion)</option>
                @foreach ($units as $unit)
                    @continue($unit->id == $selectedUnitId)
                    <option value="{{ $unit->id }}" @selected((string) old('purchase_unit_id', $product?->purchase_unit_id) === (string) $unit->id)>
                        {{ $unit->name }} ({{ $unit->short_name }})
                    </option>
                @endforeach
            </select>
            <div class="form-text">If goods are received in larger packs (e.g. carton), pick it here.</div>
            @error('purchase_unit_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-3" id="units-per-purchase-unit-wrap" @unless (old('purchase_unit_id', $product?->purchase_unit_id)) style="display:none" @endunless>
            <label for="units_per_purchase_unit" class="form-label">Units per Purchase Unit <span class="text-danger" id="units-per-required-mark">*</span></label>
            <input
                type="number"
                name="units_per_purchase_unit"
                id="units_per_purchase_unit"
                value="{{ old('units_per_purchase_unit', $product?->units_per_purchase_unit) }}"
                class="form-control @error('units_per_purchase_unit') is-invalid @enderror"
                step="0.0001"
                min="0.0001"
                placeholder="e.g. 24 if 1 carton = 24 pcs"
            >
            <div class="form-text">Stock is always stored in the base unit; entries in the purchase unit are converted automatically.</div>
            @error('units_per_purchase_unit')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
        <select
            name="category_id"
            id="category_id"
            class="form-select @error('category_id') is-invalid @enderror"
            required
        >
            <option value="">Select category</option>
            @foreach ($categories as $category)
                <option value="{{ $category->id }}" @selected((string) $selectedCategoryId === (string) $category->id)>
                    {{ $category->name }}
                </option>
            @endforeach
        </select>
        @error('category_id')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="col-md-6 mb-3">
        <label for="unit_id" class="form-label">Unit <span class="text-danger">*</span></label>
        <select
            name="unit_id"
            id="unit_id"
            class="form-select @error('unit_id') is-invalid @enderror"
            required
        >
            <option value="">Select unit</option>
            @foreach ($units as $unit)
                <option value="{{ $unit->id }}" @selected((string) $selectedUnitId === (string) $unit->id)>
                    {{ $unit->name }}@if ($unit->short_name) ({{ $unit->short_name }})@endif
                </option>
            @endforeach
        </select>
        @error('unit_id')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
        <input
            type="text"
            name="name"
            id="name"
            value="{{ old('name', $product?->name) }}"
            class="form-control @error('name') is-invalid @enderror"
            required
        >
        @error('name')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="col-md-6 mb-3">
        <label for="slug" class="form-label">Slug</label>
        <input
            type="text"
            name="slug"
            id="slug"
            value="{{ old('slug', $product?->slug) }}"
            class="form-control @error('slug') is-invalid @enderror"
        >
        <div class="form-text">Leave blank to auto-generate.</div>
        @error('slug')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="sku" class="form-label">SKU <span class="text-danger">*</span></label>
        <input
            type="text"
            name="sku"
            id="sku"
            value="{{ old('sku', $product?->sku) }}"
            class="form-control @error('sku') is-invalid @enderror"
            required
        >
        @error('sku')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="col-md-6 mb-3">
        <label for="barcode" class="form-label">Barcode</label>
        <input
            type="text"
            name="barcode"
            id="barcode"
            value="{{ old('barcode', $product?->barcode) }}"
            class="form-control @error('barcode') is-invalid @enderror"
        >
        @error('barcode')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
</div>

<div class="mb-3">
    <label for="description" class="form-label">Description</label>
    <textarea
        name="description"
        id="description"
        rows="4"
        class="form-control @error('description') is-invalid @enderror"
    >{{ old('description', $product?->description) }}</textarea>
    @error('description')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

<div class="row">
    <div class="col-md-4 mb-3">
        <label for="purchase_price" class="form-label">Purchase Price</label>
        <input
            type="number"
            name="purchase_price"
            id="purchase_price"
            value="{{ old('purchase_price', $product?->purchase_price) }}"
            class="form-control @error('purchase_price') is-invalid @enderror"
            step="0.01"
            min="0"
        >
        @error('purchase_price')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="col-md-4 mb-3">
        <label for="selling_price" class="form-label">Selling Price</label>
        <input
            type="number"
            name="selling_price"
            id="selling_price"
            value="{{ old('selling_price', $product?->selling_price) }}"
            class="form-control @error('selling_price') is-invalid @enderror"
            step="0.01"
            min="0"
        >
        @error('selling_price')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="col-md-4 mb-3">
        <label for="reorder_level" class="form-label">Reorder Level</label>
        <input
            type="number"
            name="reorder_level"
            id="reorder_level"
            value="{{ old('reorder_level', $product?->reorder_level) }}"
            class="form-control @error('reorder_level') is-invalid @enderror"
            step="0.01"
            min="0"
        >
        @error('reorder_level')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
</div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const purchaseUnitSelect = document.getElementById('purchase_unit_id');
        const wrap = document.getElementById('units-per-purchase-unit-wrap');

        if (purchaseUnitSelect && wrap) {
            const toggle = function () {
                wrap.style.display = purchaseUnitSelect.value === '' ? 'none' : '';
            };

            purchaseUnitSelect.addEventListener('change', toggle);
            toggle();
        }
    });
</script>
@endpush
