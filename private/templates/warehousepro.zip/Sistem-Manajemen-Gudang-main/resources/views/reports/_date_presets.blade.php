@php
    $presets = [
        'today' => ['Today', now()->toDateString(), now()->toDateString()],
        'this_month' => ['This month', now()->startOfMonth()->toDateString(), now()->toDateString()],
        'last_30_days' => ['Last 30 days', now()->subDays(29)->toDateString(), now()->toDateString()],
        'this_year' => ['This year', now()->startOfYear()->toDateString(), now()->toDateString()],
    ];
@endphp

<div class="d-flex flex-wrap gap-2 align-items-center">
    <span class="small text-muted">Quick range:</span>
    @foreach ($presets as $preset)
        <a
            href="{{ request()->fullUrlWithQuery(['date_from' => $preset[1], 'date_to' => $preset[2], 'page' => null]) }}"
            class="btn btn-sm btn-outline-secondary"
        >{{ $preset[0] }}</a>
    @endforeach
</div>
