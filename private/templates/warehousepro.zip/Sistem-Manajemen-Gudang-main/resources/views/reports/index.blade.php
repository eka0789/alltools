@extends('layouts.app')

@section('title', 'Reports - ' . config('app.name'))

@section('content')
    @php
        $reports = [
            [
                'title' => 'Inventory Report',
                'description' => 'Current stock balance per product and warehouse.',
                'route' => 'reports.inventory',
                'permission' => 'reports.inventory.view',
                'icon' => '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4.5 8.5 12 4l7.5 4.5v8.8L12 21.5l-7.5-4.2V8.5Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M4.8 8.7 12 12.8l7.2-4.1M12 12.8v8.4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            ],
            [
                'title' => 'Stock Movement Report',
                'description' => 'Transaction history filterable by date, item, type, and warehouse.',
                'route' => 'reports.stock-movements',
                'permission' => 'reports.stock-movements.view',
                'icon' => '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 7h14M5 12h14M5 17h8" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="m16 15 2 2 3-3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            ],
            [
                'title' => 'Low Stock Report',
                'description' => 'Products at or below their reorder level, ready for replenishment.',
                'route' => 'reports.low-stock',
                'permission' => 'reports.low-stock.view',
                'icon' => '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m12 4 8.5 15h-17L12 4Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M12 9v4.5M12 17h.01" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
            ],
            [
                'title' => 'Usage Report',
                'description' => 'Aggregate stock in versus stock out per product for a period.',
                'route' => 'reports.usage',
                'permission' => 'reports.usage.view',
                'icon' => '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19V5M5 19h14" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M8.5 16v-4M12 16V8.5M15.5 16v-6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
            ],
            [
                'title' => 'Purchase Order Report',
                'description' => 'Purchase order status and fulfillment summary for active purchasing work.',
                'route' => 'reports.purchase-orders',
                'permission' => 'reports.purchase-orders.view',
                'icon' => '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7 4.5h7l3.5 3.5v11.5h-10.5v-15Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M14 4.8V8h3.2M9.5 12h5M9.5 15.5h5M9.5 18.5H13" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            ],
        ];
    @endphp

    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Reports</h1>
            <p class="text-muted mb-0">Access read-only warehouse management reports.</p>
        </div>
    </div>

    <div class="row g-4">
        @foreach ($reports as $report)
            @can('permission', $report['permission'])
                <div class="col-md-6 col-xl-4">
                    <div class="card report-card h-100 shadow-sm border-0">
                        <div class="card-body">
                            <span class="report-icon">{!! $report['icon'] !!}</span>
                            <h2>{{ $report['title'] }}</h2>
                            <p>{{ $report['description'] }}</p>
                            <a href="{{ route($report['route']) }}" class="report-link">
                                Open report
                                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h14m0 0-5-5m5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </a>
                        </div>
                    </div>
                </div>
            @endcan
        @endforeach
    </div>
@endsection