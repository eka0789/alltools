<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ $title }}</title>
    <style>
        @page {
            margin: 24px 18px;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 10px;
            color: #212529;
        }

        h1 {
            font-size: 16px;
            margin: 0 0 4px 0;
        }

        .meta {
            color: #6c757d;
            font-size: 9px;
            margin-bottom: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #dee2e6;
            padding: 4px 6px;
            text-align: left;
        }

        th {
            background: #f8f9fa;
            font-size: 9px;
            text-transform: uppercase;
            letter-spacing: 0.02em;
        }

        tr {
            page-break-inside: avoid;
        }

        .footer {
            margin-top: 10px;
            color: #6c757d;
            font-size: 8px;
        }
    </style>
</head>
<body>
    <h1>{{ $title }}</h1>
    <div class="meta">Generated {{ $generatedAt }}</div>

    <table>
        <thead>
            <tr>
                @foreach ($headers as $header)
                    <th>{{ $header }}</th>
                @endforeach
            </tr>
        </thead>
        <tbody>
            @forelse ($rows as $row)
                <tr>
                    @foreach ($row as $cell)
                        <td>{{ $cell }}</td>
                    @endforeach
                </tr>
            @empty
                <tr>
                    <td colspan="{{ max(count($headers), 1) }}">No data available.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <div class="footer">{{ config('app.name') }} — Warehouse Management System</div>
</body>
</html>
