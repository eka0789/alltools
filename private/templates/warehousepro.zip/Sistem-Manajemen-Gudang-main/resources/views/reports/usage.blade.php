@extends('layouts.app')

@section('title', 'Usage Report - ' . config('app.name'))

@section('content')
    @php
        $usageRows = $usageRows ?? collect();
        $warehouses = $warehouses ?? collect();
        $categories = $categories ?? collect();
        $filters = $filters ?? [];
        $totals = $totals ?? ['inbound' => 0, 'outbound' => 0, 'net' => 0];
    @endphp

    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Usage Report</h1>
            <p class="text-muted mb-0">Aggregate stock in vs stock out per product for the selected period.</p>
        </div>
        @can('permission', 'reports.export')
            <div class="btn-group">
                <a href="{{ route('reports.usage.export', array_merge(request()->query(), ['format' => 'xlsx'])) }}" class="btn btn-outline-success">
                    Excel
                </a>
                <a href="{{ route('reports.usage.export', array_merge(request()->query(), ['format' => 'pdf'])) }}" class="btn btn-outline-danger">
                    PDF
                </a>
                <a href="{{ route('reports.usage.export', array_merge(request()->query(), ['format' => 'csv'])) }}" class="btn btn-outline-primary">
                    CSV
                </a>
            </div>
        @endcan
    </div>

    <form method="GET" action="{{ route('reports.usage') }}" class="card shadow-sm border-0 mb-4">
        <div class="card-body">
        @include('reports._date_presets')
        <hr class="my-3">

            <div class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label for="warehouse_id" class="form-label">Warehouse</label>
                    <select name="warehouse_id" id="warehouse_id" class="form-select @error('warehouse_id') is-invalid @enderror">
                        <option value="">All Warehouses</option>
                        @foreach ($warehouses as $warehouse)
                            <option value="{{ $warehouse->id }}" @selected((string) data_get($filters, 'warehouse_id', '') === (string) $warehouse->id)>
                                {{ $warehouse->name }} ({{ $warehouse->code }})
                            </option>
                        @endforeach
                    </select>
                    @error('warehouse_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-3">
                    <label for="category_id" class="form-label">Category</label>
                    <select name="category_id" id="category_id" class="form-select @error('category_id') is-invalid @enderror">
                        <option value="">All Categories</option>
                        @foreach ($categories as $category)
                            <option value="{{ $category->id }}" @selected((string) data_get($filters, 'category_id', '') === (string) $category->id)>
                                {{ $category->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('category_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-2">
                    <label for="date_from" class="form-label">From</label>
                    <input type="date" name="date_from" id="date_from" value="{{ data_get($filters, 'date_from') }}" class="form-control @error('date_from') is-invalid @enderror">
                    @error('date_from')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-2">
                    <label for="date_to" class="form-label">To</label>
                    <input type="date" name="date_to" id="date_to" value="{{ data_get($filters, 'date_to') }}" class="form-control @error('date_to') is-invalid @enderror">
                    @error('date_to')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-12 col-md-2 d-flex justify-content-end gap-2">
                    <a href="{{ route('reports.usage') }}" class="btn btn-outline-secondary">Reset</a>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </div>
    </form>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="text-muted small">Total In</div>
                    <div class="h4 mb-0 text-success">{{ number_format($totals['inbound'], 4) }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="text-muted small">Total Out</div>
                    <div class="h4 mb-0 text-danger">{{ number_format($totals['outbound'], 4) }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="text-muted small">Net Movement</div>
                    <div class="h4 mb-0 {{ $totals['net'] >= 0 ? 'text-success' : 'text-danger' }}">{{ number_format($totals['net'], 4) }}</div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white">
            <h2 class="h5 mb-0">Usage per Product</h2>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">Product</th>
                            <th scope="col">SKU</th>
                            <th scope="col">Category</th>
                            <th scope="col">Unit</th>
                            <th scope="col" class="text-end">Total In</th>
                            <th scope="col" class="text-end">Total Out</th>
                            <th scope="col" class="text-end">Net Movement</th>
                            <th scope="col" class="text-end">Outbound Transactions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($usageRows as $usageRow)
                            <tr>
                                <td class="fw-semibold">{{ $usageRow->name }}</td>
                                <td><code>{{ $usageRow->sku }}</code></td>
                                <td>{{ $usageRow->category?->name ?? '-' }}</td>
                                <td>{{ $usageRow->unit?->short_name ?? $usageRow->unit?->name ?? '-' }}</td>
                                <td class="text-end">{{ number_format((float) $usageRow->inbound_quantity, 4) }}</td>
                                <td class="text-end">{{ number_format((float) $usageRow->outbound_quantity, 4) }}</td>
                                <td class="text-end">
                                    <span class="{{ (float) $usageRow->net_quantity >= 0 ? 'text-success' : 'text-danger' }}">
                                        {{ number_format((float) $usageRow->net_quantity, 4) }}
                                    </span>
                                </td>
                                <td class="text-end">{{ (int) $usageRow->transactions_count }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">No usage records found for the selected period.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if (method_exists($usageRows, 'hasPages') && $usageRows->hasPages())
            <div class="card-footer bg-white">
                {{ $usageRows->links() }}
            </div>
        @endif
    </div>
@endsection
