<!doctype html>
<html>
<head>
    @php
        $company = [
            'name' => $company['company.name'] ?? config('app.name'),
            'address' => $company['company.address'] ?? null,
            'phone' => $company['company.phone'] ?? null,
            'email' => $company['company.email'] ?? null,
        ];
    @endphp
    <meta charset="utf-8">
    <title>{{ $title }}</title>
    <style>
        @page {
            margin: 32px 28px;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 11px;
            color: #1e293b;
        }

        .slip-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid #0f172a;
            padding-bottom: 10px;
        }

        .slip-company {
            font-size: 16px;
            font-weight: bold;
            margin: 0 0 2px 0;
        }

        .slip-company-meta {
            color: #64748b;
            font-size: 10px;
        }

        .slip-title {
            text-align: right;
        }

        .slip-title h1 {
            margin: 0;
            font-size: 15px;
            letter-spacing: 0.05em;
        }

        .slip-title .doc-no {
            color: #64748b;
            font-size: 11px;
        }

        .slip-meta {
            width: 100%;
            margin: 12px 0 4px 0;
            border-collapse: collapse;
        }

        .slip-meta td {
            padding: 2px 0;
            vertical-align: top;
        }

        .slip-meta .label {
            color: #64748b;
            width: 90px;
        }

        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table.items th,
        table.items td {
            border: 1px solid #cbd5e1;
            padding: 5px 7px;
            text-align: left;
        }

        table.items th {
            background: #f1f5f9;
            font-size: 9.5px;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        table.items .num {
            text-align: right;
            font-variant-numeric: tabular-nums;
        }

        .slip-remarks {
            margin-top: 10px;
        }

        .slip-remarks .label {
            color: #64748b;
        }

        .signatures {
            display: flex;
            justify-content: space-between;
            gap: 24px;
            margin-top: 42px;
        }

        .signature {
            flex: 1;
            text-align: center;
        }

        .signature .line {
            margin-top: 34px;
            border-top: 1px solid #475569;
            padding-top: 4px;
            color: #64748b;
            font-size: 10px;
        }

        .slip-footer {
            margin-top: 18px;
            color: #94a3b8;
            font-size: 8.5px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="slip-header">
        <div>
            <p class="slip-company">{{ $company['name'] }}</p>
            @if ($company['address'])
                <div class="slip-company-meta">{{ $company['address'] }}</div>
            @endif
            @if ($company['phone'] || $company['email'])
                <div class="slip-company-meta">
                    {{ trim(($company['phone'] ?? '').($company['phone'] && $company['email'] ? ' · ' : '').($company['email'] ?? '')) }}
                </div>
            @endif
        </div>
        <div class="slip-title">
            <h1>{{ $heading }}</h1>
            <div class="doc-no">{{ $document->document_no }}</div>
        </div>
    </div>

    <table class="slip-meta">
        <tr>
            <td class="label">Date</td>
            <td>{{ $document->stock_date?->format('d M Y') }}</td>
            <td class="label">Warehouse</td>
            <td>{{ $document->warehouse?->name }} ({{ $document->warehouse?->code }})</td>
        </tr>
        <tr>
            <td class="label">Recorded by</td>
            <td>{{ $document->creator?->name ?? '-' }}</td>
            <td class="label">Printed at</td>
            <td>{{ now()->format('d M Y H:i') }}</td>
        </tr>
    </table>

    <table class="items">
        <thead>
            <tr>
                <th style="width: 28px;">#</th>
                <th>Product</th>
                <th>SKU</th>
                <th>Location</th>
                <th style="width: 80px;" class="num">Quantity</th>
                <th style="width: 55px;">Unit</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($document->items as $item)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $item->product?->name ?? 'N/A' }}</td>
                    <td>{{ $item->product?->sku ?? 'N/A' }}</td>
                    <td>{{ $item->location?->code ?? '-' }}</td>
                    <td class="num">{{ number_format((float) $item->quantity, 4) }}
                        @if ($item->entered_quantity !== null)
                            <div style="font-size: 8.5px; color: #94a3b8;">{{ number_format((float) $item->entered_quantity, 4) }} {{ $item->enteredUnit?->short_name ?? '' }} entered</div>
                        @endif
                    </td>
                    <td>{{ $item->product?->unit?->short_name ?? $item->product?->unit?->name ?? '-' }}</td>
                    <td>{{ $item->remarks ?: '-' }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="7">No items recorded.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    @if ($document->remarks)
        <div class="slip-remarks">
            <span class="label">Remarks:</span> {{ $document->remarks }}
        </div>
    @endif

    <div class="signatures">
        <div class="signature">
            <div class="line">Prepared by</div>
        </div>
        <div class="signature">
            <div class="line">{{ $type === 'in' ? 'Received by' : 'Received by' }}</div>
        </div>
        <div class="signature">
            <div class="line">Approved by</div>
        </div>
    </div>

    <div class="slip-footer">{{ $company['name'] }} — {{ $heading }} {{ $document->document_no }}</div>
</body>
</html>
