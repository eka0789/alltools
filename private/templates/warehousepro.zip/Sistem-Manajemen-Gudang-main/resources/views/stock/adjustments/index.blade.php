@extends('layouts.app')

@section('title', 'Stock Adjustments - ' . config('app.name'))

@section('content')
    @php
        $filters = $filters ?? [];
    @endphp

    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Stock Adjustment History</h1>
            <p class="text-muted mb-0">Every stock correction, with the option to reverse a mistake.</p>
        </div>

        @can('permission', 'stock-adjustments.create')
            <a href="{{ route('stock-adjustments.create') }}" class="btn btn-primary">New Adjustment</a>
        @endcan
    </div>

    @if (session('success'))
        <div class="alert alert-success" role="alert">{{ session('success') }}</div>
    @endif

    <form method="GET" action="{{ route('stock-adjustments.index') }}" class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <div class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label for="warehouse_id" class="form-label">Warehouse</label>
                    <select name="warehouse_id" id="warehouse_id" class="form-select">
                        <option value="">All Warehouses</option>
                        @foreach ($warehouses as $warehouse)
                            <option value="{{ $warehouse->id }}" @selected((string) data_get($filters, 'warehouse_id', '') === (string) $warehouse->id)>
                                {{ $warehouse->name }} ({{ $warehouse->code }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="product_id" class="form-label">Product</label>
                    <select name="product_id" id="product_id" class="form-select">
                        <option value="">All Products</option>
                        @foreach ($products as $product)
                            <option value="{{ $product->id }}" @selected((string) data_get($filters, 'product_id', '') === (string) $product->id)>
                                {{ $product->name }} ({{ $product->sku }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-2">
                    <label for="date_from" class="form-label">From</label>
                    <input type="date" name="date_from" id="date_from" value="{{ data_get($filters, 'date_from') }}" class="form-control">
                </div>

                <div class="col-md-2">
                    <label for="date_to" class="form-label">To</label>
                    <input type="date" name="date_to" id="date_to" value="{{ data_get($filters, 'date_to') }}" class="form-control">
                </div>

                <div class="col-12 col-md-2 d-flex justify-content-end gap-2">
                    <a href="{{ route('stock-adjustments.index') }}" class="btn btn-outline-secondary">Reset</a>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </div>
    </form>

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">Date</th>
                            <th scope="col">Warehouse</th>
                            <th scope="col">Product</th>
                            <th scope="col">Type</th>
                            <th scope="col" class="text-end">Quantity</th>
                            <th scope="col" class="text-end">Balance After</th>
                            <th scope="col">Recorded By</th>
                            <th scope="col">Remarks</th>
                            <th scope="col" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($adjustments as $adjustment)
                            @php
                                $isReversal = $adjustment->remarks !== null && str_starts_with((string) $adjustment->remarks, 'Reversal of adjustment');
                            @endphp
                            <tr>
                                <td>{{ $adjustment->created_at?->format('M d, Y H:i') }}</td>
                                <td>{{ $adjustment->warehouse?->name ?? '-' }}</td>
                                <td class="fw-semibold">{{ $adjustment->product?->name ?? '-' }}</td>
                                <td>
                                    <span class="badge {{ $adjustment->movement_type === 'adjustment_in' ? 'text-bg-success' : 'text-bg-warning' }}">
                                        {{ $adjustment->movement_type === 'adjustment_in' ? 'Adjustment In' : 'Adjustment Out' }}
                                    </span>
                                </td>
                                <td class="text-end">{{ number_format((float) $adjustment->quantity, 4) }}</td>
                                <td class="text-end">{{ number_format((float) $adjustment->balance_after, 4) }}</td>
                                <td>{{ $adjustment->creator?->name ?? '-' }}</td>
                                <td class="small {{ $isReversal ? 'text-muted fst-italic' : '' }}">{{ $adjustment->remarks ?: '-' }}</td>
                                <td>
                                    <div class="d-flex justify-content-end gap-2">
                                        @can('permission', 'stock-adjustments.create')
                                            @unless ($isReversal)
                                                <form method="POST" action="{{ route('stock-adjustments.reverse', $adjustment) }}" onsubmit="return confirm('Reverse this adjustment by recording the opposite movement?');">
                                                    @csrf
                                                    <button type="submit" class="btn btn-outline-danger btn-sm">Reverse</button>
                                                </form>
                                            @endunless
                                        @endcan
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">No adjustments found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if ($adjustments->hasPages())
            <div class="card-footer bg-white">
                {{ $adjustments->links() }}
            </div>
        @endif
    </div>
@endsection
