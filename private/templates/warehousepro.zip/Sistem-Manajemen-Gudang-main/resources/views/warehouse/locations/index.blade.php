@extends('layouts.app')

@section('title', 'Locations - ' . config('app.name'))

@section('content')
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Rack Locations</h1>
            <p class="text-muted mb-0">Manage rack and floor location codes (A, B, C, D, E, F/Floor).</p>
        </div>

        @can('permission', 'locations.create')
            <a href="{{ route('locations.create') }}" class="btn btn-primary">Add Location</a>
        @endcan
    </div>

    @if (session('success'))
        <div class="alert alert-success" role="alert">
            {{ session('success') }}
        </div>
    @endif

    <form method="GET" action="{{ route('locations.index') }}" class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label for="search" class="form-label">Search</label>
                    <input
                        type="text"
                        name="search"
                        id="search"
                        value="{{ request('search') }}"
                        class="form-control"
                        placeholder="Code or name"
                    >
                </div>

                <div class="col-md-4">
                    <label for="warehouse_id" class="form-label">Warehouse</label>
                    <select name="warehouse_id" id="warehouse_id" class="form-select">
                        <option value="">All Warehouses</option>
                        @foreach ($warehouses as $warehouse)
                            <option value="{{ $warehouse->id }}" @selected((string) request('warehouse_id') === (string) $warehouse->id)>
                                {{ $warehouse->name }} ({{ $warehouse->code }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-12 col-md-4 d-flex justify-content-end gap-2">
                    <a href="{{ route('locations.index') }}" class="btn btn-outline-secondary">Reset</a>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </div>
    </form>

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <x-sort-header label="Code" column="code" />
                            <x-sort-header label="Name" column="name" />
                            <th scope="col">Warehouse</th>
                            <th scope="col" class="text-end">Products</th>
                            <th scope="col">Status</th>
                            <th scope="col" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($locations as $location)
                            <tr>
                                <td>{{ $locations->firstItem() + $loop->index }}</td>
                                <td class="fw-semibold"><code>{{ $location->code }}</code></td>
                                <td>{{ $location->name ?? '-' }}</td>
                                <td>{{ $location->warehouse?->name ?? 'All warehouses' }}</td>
                                <td class="text-end">{{ $location->products_count }}</td>
                                <td>
                                    @if ($location->is_active)
                                        <span class="badge text-bg-success">Active</span>
                                    @else
                                        <span class="badge text-bg-secondary">Inactive</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex justify-content-end gap-2">
                                        <a href="{{ route('locations.show', $location) }}" class="btn btn-outline-secondary btn-sm">
                                            View
                                        </a>

                                        @can('permission', 'locations.update')
                                            <a href="{{ route('locations.edit', $location) }}" class="btn btn-outline-primary btn-sm">
                                                Edit
                                            </a>
                                        @endcan

                                        @can('permission', 'locations.delete')
                                            <form method="POST" action="{{ route('locations.destroy', $location) }}" onsubmit="return confirm('Delete this location?');">
                                                @csrf
                                                @method('DELETE')

                                                <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                                            </form>
                                        @endcan
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">No locations found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if ($locations->hasPages())
            <div class="card-footer bg-white">
                {{ $locations->links() }}
            </div>
        @endif
    </div>
@endsection
