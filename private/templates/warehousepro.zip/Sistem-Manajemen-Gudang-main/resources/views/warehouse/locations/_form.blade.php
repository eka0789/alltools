@php
    $location = $location ?? null;
    $isActive = old('is_active', $location?->is_active ?? true);
    $selectedWarehouseId = old('warehouse_id', $location?->warehouse_id);
@endphp

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="code" class="form-label">Location Code <span class="text-danger">*</span></label>
        <input
            type="text"
            name="code"
            id="code"
            value="{{ old('code', $location?->code) }}"
            class="form-control @error('code') is-invalid @enderror"
            placeholder="e.g. A, B, C, F/Floor"
            required
        >
        <div class="form-text">Rack or floor code used in the warehouse (A–F, Floor, etc.).</div>
        @error('code')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="col-md-6 mb-3">
        <label for="warehouse_id" class="form-label">Warehouse</label>
        <select
            name="warehouse_id"
            id="warehouse_id"
            class="form-select @error('warehouse_id') is-invalid @enderror"
        >
            <option value="">All warehouses (shared location)</option>
            @foreach ($warehouses as $warehouse)
                <option value="{{ $warehouse->id }}" @selected((string) $selectedWarehouseId === (string) $warehouse->id)>
                    {{ $warehouse->name }} ({{ $warehouse->code }})
                </option>
            @endforeach
        </select>
        @error('warehouse_id')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
</div>

<div class="mb-3">
    <label for="name" class="form-label">Name</label>
    <input
        type="text"
        name="name"
        id="name"
        value="{{ old('name', $location?->name) }}"
        class="form-control @error('name') is-invalid @enderror"
        placeholder="e.g. Rack A - Ground Floor"
    >
    @error('name')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

<div class="mb-3">
    <label for="description" class="form-label">Description</label>
    <textarea
        name="description"
        id="description"
        rows="3"
        class="form-control @error('description') is-invalid @enderror"
    >{{ old('description', $location?->description) }}</textarea>
    @error('description')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

<input type="hidden" name="is_active" value="0">
<div class="form-check">
    <input
        type="checkbox"
        name="is_active"
        id="is_active"
        value="1"
        class="form-check-input @error('is_active') is-invalid @enderror"
        @checked((bool) $isActive)
    >
    <label for="is_active" class="form-check-label">Active</label>
    @error('is_active')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>
