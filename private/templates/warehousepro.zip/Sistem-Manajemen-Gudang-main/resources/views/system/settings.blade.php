@extends('layouts.app')

@section('title', 'Settings - ' . config('app.name'))

@section('content')
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Settings</h1>
            <p class="text-muted mb-0">Company details appear on printed documents and exported PDF reports.</p>
        </div>
    </div>

    @if (session('success'))
        <div class="alert alert-success" role="alert">{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('settings.update') }}" class="card shadow-sm border-0">
        @csrf
        @method('PUT')

        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="company_name" class="form-label">Company Name</label>
                    <input type="text" name="company_name" id="company_name" value="{{ old('company_name', $settings['company.name']) }}" class="form-control @error('company_name') is-invalid @enderror">
                    @error('company_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>

                <div class="col-md-6 mb-3">
                    <label for="company_phone" class="form-label">Phone</label>
                    <input type="text" name="company_phone" id="company_phone" value="{{ old('company_phone', $settings['company.phone']) }}" class="form-control @error('company_phone') is-invalid @enderror">
                    @error('company_phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
            </div>

            <div class="mb-3">
                <label for="company_address" class="form-label">Address</label>
                <textarea name="company_address" id="company_address" rows="2" class="form-control @error('company_address') is-invalid @enderror">{{ old('company_address', $settings['company.address']) }}</textarea>
                @error('company_address')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="company_email" class="form-label">Email</label>
                    <input type="email" name="company_email" id="company_email" value="{{ old('company_email', $settings['company.email']) }}" class="form-control @error('company_email') is-invalid @enderror">
                    @error('company_email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
            </div>

            <hr>

            <div class="form-check form-switch">
                <input
                    type="checkbox"
                    name="low_stock_email_enabled"
                    id="low_stock_email_enabled"
                    value="1"
                    class="form-check-input"
                    role="switch"
                    @checked(old('low_stock_email_enabled', $settings['notifications.low_stock_email']) === '1')
                >
                <label for="low_stock_email_enabled" class="form-check-label">
                    Email the daily low stock alert
                    <span class="text-muted small">— in-app notifications are always sent.</span>
                </label>
            </div>
        </div>

        <div class="card-footer bg-white d-flex justify-content-end">
            <button type="submit" class="btn btn-primary">Save Settings</button>
        </div>
    </form>
@endsection
