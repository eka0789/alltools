@extends('layouts.app')

@section('title', 'Roles - ' . config('app.name'))

@section('content')
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Roles</h1>
            <p class="text-muted mb-0">Manage roles and their permissions.</p>
        </div>

        @can('permission', 'roles.create')
            <a href="{{ route('roles.create') }}" class="btn btn-primary">Add Role</a>
        @endcan
    </div>

    @if (session('success'))
        <div class="alert alert-success" role="alert">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error') || $errors->any())
        <div class="alert alert-danger" role="alert">
            {{ session('error') ?: $errors->first() }}
        </div>
    @endif

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Slug</th>
                            <th scope="col" class="text-end">Users</th>
                            <th scope="col" class="text-end">Permissions</th>
                            <th scope="col">Status</th>
                            <th scope="col" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($roles as $role)
                            <tr>
                                <td>{{ $roles->firstItem() + $loop->index }}</td>
                                <td class="fw-semibold">{{ $role->name }}</td>
                                <td><code>{{ $role->slug }}</code></td>
                                <td class="text-end">{{ $role->users_count }}</td>
                                <td class="text-end">{{ $role->permissions_count }}</td>
                                <td>
                                    @if ($role->is_active)
                                        <span class="badge text-bg-success">Active</span>
                                    @else
                                        <span class="badge text-bg-secondary">Inactive</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex justify-content-end gap-2">
                                        <a href="{{ route('roles.show', $role) }}" class="btn btn-outline-secondary btn-sm">
                                            View
                                        </a>

                                        @can('permission', 'roles.update')
                                            <a href="{{ route('roles.edit', $role) }}" class="btn btn-outline-primary btn-sm">
                                                Edit
                                            </a>
                                        @endcan

                                        @can('permission', 'roles.delete')
                                            @unless ($role->slug === 'super-admin')
                                                <form method="POST" action="{{ route('roles.destroy', $role) }}" onsubmit="return confirm('Delete this role?');">
                                                    @csrf
                                                    @method('DELETE')

                                                    <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                                                </form>
                                            @endunless
                                        @endcan
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">No roles found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if ($roles->hasPages())
            <div class="card-footer bg-white">
                {{ $roles->links() }}
            </div>
        @endif
    </div>
@endsection
