@extends('layouts.app')

@section('title', 'Create Role - ' . config('app.name'))

@section('content')
    <div class="d-flex align-items-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Create Role</h1>
            <p class="text-muted mb-0">Add a new role and pick its permissions.</p>
        </div>

        <a href="{{ route('roles.index') }}" class="btn btn-outline-secondary">Back</a>
    </div>

    <form method="POST" action="{{ route('roles.store') }}" class="card shadow-sm border-0">
        @csrf

        <div class="card-body">
            @include('system.roles._form')
        </div>

        <div class="card-footer bg-white d-flex justify-content-end gap-2">
            <a href="{{ route('roles.index') }}" class="btn btn-outline-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary">Save Role</button>
        </div>
    </form>
@endsection
