@extends('layouts.app')

@section('title', 'Role Detail - ' . config('app.name'))

@section('content')
    <div class="d-flex align-items-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Role: {{ $role->name }}</h1>
            <p class="text-muted mb-0">Role detail, permissions, and members.</p>
        </div>

        <a href="{{ route('roles.index') }}" class="btn btn-outline-secondary">Back</a>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white">
                    <h2 class="h5 mb-0">Permissions ({{ $role->permissions->count() }})</h2>
                </div>
                <div class="card-body">
                    @forelse ($role->permissions->groupBy('module') as $module => $modulePermissions)
                        <h3 class="h6 text-uppercase text-muted mb-2">{{ str_replace('_', ' ', $module) }}</h3>
                        <div class="d-flex flex-wrap gap-1 mb-3">
                            @foreach ($modulePermissions as $permission)
                                <span class="badge text-bg-light border">{{ $permission->name }}</span>
                            @endforeach
                        </div>
                    @empty
                        <span class="text-muted">No permissions assigned.</span>
                    @endforelse
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white">
                    <h2 class="h5 mb-0">Users with this Role ({{ $role->users->count() }})</h2>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($role->users as $user)
                                    <tr>
                                        <td class="fw-semibold">{{ $user->name }}</td>
                                        <td>{{ $user->email }}</td>
                                        <td>
                                            @if ($user->is_active)
                                                <span class="badge text-bg-success">Active</span>
                                            @else
                                                <span class="badge text-bg-secondary">Inactive</span>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="3" class="text-center text-muted py-4">No users assigned to this role.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
