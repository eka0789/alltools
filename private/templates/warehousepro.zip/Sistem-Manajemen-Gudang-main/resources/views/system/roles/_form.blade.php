@php
    $role = $role ?? null;
    $isActive = old('is_active', $role?->is_active ?? true);
    $selectedPermissionIds = old('permissions', $role?->permissions->pluck('id')->all() ?? []);
    $isSuperAdmin = ($role?->slug ?? '') === 'super-admin';
@endphp

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="name" class="form-label">Role Name <span class="text-danger">*</span></label>
        <input
            type="text"
            name="name"
            id="name"
            value="{{ old('name', $role?->name) }}"
            class="form-control @error('name') is-invalid @enderror"
            required
        >
        @error('name')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    @unless ($role)
        <div class="col-md-6 mb-3">
            <label for="slug" class="form-label">Slug</label>
            <input
                type="text"
                name="slug"
                id="slug"
                value="{{ old('slug') }}"
                class="form-control @error('slug') is-invalid @enderror"
                placeholder="Leave blank to auto-generate"
            >
            @error('slug')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    @endunless
</div>

<div class="mb-3">
    <label for="description" class="form-label">Description</label>
    <textarea
        name="description"
        id="description"
        rows="2"
        class="form-control @error('description') is-invalid @enderror"
    >{{ old('description', $role?->description) }}</textarea>
    @error('description')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

<input type="hidden" name="is_active" value="0">
<div class="form-check mb-3">
    <input
        type="checkbox"
        name="is_active"
        id="is_active"
        value="1"
        class="form-check-input @error('is_active') is-invalid @enderror"
        @checked((bool) $isActive)
        @if ($isSuperAdmin) disabled @endif
    >
    <label for="is_active" class="form-check-label">Active</label>
    @if ($isSuperAdmin)
        <span class="text-muted small">(Super Admin must remain active)</span>
    @endif
    @error('is_active')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

@if ($isSuperAdmin)
    <input type="hidden" name="is_active" value="1">
@endif

<div class="mb-3">
    <div class="d-flex align-items-center justify-content-between mb-2">
        <label class="form-label mb-0">Permissions</label>
        <div class="form-check">
            <input type="checkbox" id="select-all-permissions" class="form-check-input">
            <label for="select-all-permissions" class="form-check-label small">Select all</label>
        </div>
    </div>

    <div class="border rounded p-3" style="max-height: 30rem; overflow-y: auto;">
        @forelse ($permissionGroups as $module => $modulePermissions)
            <h3 class="h6 text-uppercase text-muted mb-2">{{ $module }}</h3>
            <div class="row mb-3">
                @foreach ($modulePermissions as $permission)
                    <div class="col-md-4">
                        <div class="form-check">
                            <input
                                type="checkbox"
                                name="permissions[]"
                                id="permission_{{ $permission->id }}"
                                value="{{ $permission->id }}"
                                class="form-check-input js-permission"
                                @checked(in_array($permission->id, $selectedPermissionIds))
                            >
                            <label for="permission_{{ $permission->id }}" class="form-check-label small">
                                {{ $permission->name }}
                            </label>
                        </div>
                    </div>
                @endforeach
            </div>
        @empty
            <span class="text-muted">No permissions found. Run the permission seeder first.</span>
        @endforelse
    </div>
    @error('permissions.*')
        <div class="invalid-feedback d-block">{{ $message }}</div>
    @enderror
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const selectAll = document.getElementById('select-all-permissions');

        if (selectAll) {
            selectAll.addEventListener('change', function () {
                document.querySelectorAll('.js-permission').forEach(function (checkbox) {
                    checkbox.checked = selectAll.checked;
                });
            });
        }
    });
</script>
