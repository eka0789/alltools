@extends('layouts.app')

@section('title', 'Trash - ' . config('app.name'))

@section('content')
    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Trash</h1>
            <p class="text-muted mb-0">Deleted master data. Restore an item or delete it permanently.</p>
        </div>
    </div>

    @if (session('success'))
        <div class="alert alert-success" role="alert">{{ session('success') }}</div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger" role="alert">{{ session('error') }}</div>
    @endif

    <ul class="nav nav-pills gap-2 mb-4">
        @foreach ($types as $typeKey => $typeConfig)
            @can('permission', $typeConfig['viewPermission'])
                <li class="nav-item">
                    <a class="nav-link {{ $typeKey === $type ? 'active' : '' }}" href="{{ route('trash.index', ['type' => $typeKey]) }}">
                        {{ $typeConfig['label'] }}
                    </a>
                </li>
            @endcan
        @endforeach
    </ul>

    <form method="GET" action="{{ route('trash.index') }}" class="card shadow-sm border-0 mb-4">
        <input type="hidden" name="type" value="{{ $type }}">
        <div class="card-body d-flex gap-2 align-items-end">
            <div class="flex-grow-1">
                <label for="search" class="form-label">Search</label>
                <input type="text" name="search" id="search" value="{{ $search }}" class="form-control" placeholder="Search deleted records">
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
        </div>
    </form>

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Deleted At</th>
                            <th scope="col" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($records as $record)
                            <tr>
                                <td>{{ $records->firstItem() + $loop->index }}</td>
                                <td class="fw-semibold">{{ $record->trashDisplayName() }}</td>
                                <td>{{ $record->deleted_at?->format('M d, Y H:i') }}</td>
                                <td>
                                    <div class="d-flex justify-content-end gap-2">
                                        @can('permission', $config['deletePermission'])
                                            <form method="POST" action="{{ route('trash.restore', [$type, $record->id]) }}">
                                                @csrf
                                                <button type="submit" class="btn btn-outline-success btn-sm">Restore</button>
                                            </form>

                                            <form method="POST" action="{{ route('trash.destroy', [$type, $record->id]) }}" onsubmit="return confirm('Permanently delete this record? This cannot be undone.');">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-outline-danger btn-sm">Delete forever</button>
                                            </form>
                                        @endcan
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">Trash is empty for this section.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if ($records->hasPages())
            <div class="card-footer bg-white">
                {{ $records->links() }}
            </div>
        @endif
    </div>
@endsection
