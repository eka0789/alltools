@extends('layouts.app')

@section('title', 'User Detail - ' . config('app.name'))

@section('content')
    <div class="d-flex align-items-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">User: {{ $user->name }}</h1>
            <p class="text-muted mb-0">Account detail and assigned roles.</p>
        </div>

        <a href="{{ route('users.index') }}" class="btn btn-outline-secondary">Back</a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <dl class="row mb-0">
                <dt class="col-sm-3">Name</dt>
                <dd class="col-sm-9">{{ $user->name }}</dd>

                <dt class="col-sm-3">Email</dt>
                <dd class="col-sm-9">{{ $user->email }}</dd>

                <dt class="col-sm-3">Status</dt>
                <dd class="col-sm-9">
                    @if ($user->is_active)
                        <span class="badge text-bg-success">Active</span>
                    @else
                        <span class="badge text-bg-secondary">Inactive</span>
                    @endif
                </dd>

                <dt class="col-sm-3">Roles</dt>
                <dd class="col-sm-9">
                    @forelse ($user->roles as $role)
                        <span class="badge text-bg-info">{{ $role->name }}</span>
                    @empty
                        <span class="text-muted">No roles assigned.</span>
                    @endforelse
                </dd>

                <dt class="col-sm-3">Created At</dt>
                <dd class="col-sm-9">{{ $user->created_at?->format('M d, Y H:i') }}</dd>
            </dl>
        </div>
    </div>
@endsection
