@php
    $user = $user ?? null;
    $isActive = old('is_active', $user?->is_active ?? true);
    $selectedRoleIds = old('roles', $user?->roles->pluck('id')->all() ?? []);
@endphp

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
        <input
            type="text"
            name="name"
            id="name"
            value="{{ old('name', $user?->name) }}"
            class="form-control @error('name') is-invalid @enderror"
            required
        >
        @error('name')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="col-md-6 mb-3">
        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
        <input
            type="email"
            name="email"
            id="email"
            value="{{ old('email', $user?->email) }}"
            class="form-control @error('email') is-invalid @enderror"
            required
        >
        @error('email')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="password" class="form-label">Password @if ($user) <span class="text-muted small">(leave blank to keep current)</span> @else <span class="text-danger">*</span> @endif</label>
        <input
            type="password"
            name="password"
            id="password"
            class="form-control @error('password') is-invalid @enderror"
            @if (! $user) required @endif
            autocomplete="new-password"
        >
        <div class="form-text">Minimum 8 characters.</div>
        @error('password')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="col-md-6 mb-3 d-flex align-items-end">
        <input type="hidden" name="is_active" value="0">
        <div class="form-check">
            <input
                type="checkbox"
                name="is_active"
                id="is_active"
                value="1"
                class="form-check-input @error('is_active') is-invalid @enderror"
                @checked((bool) $isActive)
            >
            <label for="is_active" class="form-check-label">Active</label>
            @error('is_active')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>
</div>

<div class="mb-3">
    <label class="form-label">Roles</label>
    <div class="border rounded p-3">
        @forelse ($roles as $role)
            <div class="form-check">
                <input
                    type="checkbox"
                    name="roles[]"
                    id="role_{{ $role->id }}"
                    value="{{ $role->id }}"
                    class="form-check-input"
                    @checked(in_array($role->id, $selectedRoleIds))
                >
                <label for="role_{{ $role->id }}" class="form-check-label">
                    {{ $role->name }}
                    <span class="text-muted small">— {{ $role->description }}</span>
                </label>
            </div>
        @empty
            <span class="text-muted">No active roles found. Run the role seeder first.</span>
        @endforelse
    </div>
    @error('roles.*')
        <div class="invalid-feedback d-block">{{ $message }}</div>
    @enderror
</div>
