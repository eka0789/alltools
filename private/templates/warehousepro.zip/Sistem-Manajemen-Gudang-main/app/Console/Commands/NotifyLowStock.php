<?php

namespace App\Console\Commands;

use App\Models\Product;
use App\Models\User;
use App\Notifications\LowStockAlert;
use App\Services\Settings\SettingsService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

class NotifyLowStock extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'stock:notify-low-stock
                            {--dry-run : List low stock items without sending notifications}';

    /**
     * The console command description.
     */
    protected $description = 'Send a daily low stock alert to users who can view low stock reports';

    public function handle(SettingsService $settingsService): int
    {
        $lowStockItems = Product::query()
            ->leftJoin('warehouse_stocks', 'products.id', '=', 'warehouse_stocks.product_id')
            ->where('products.is_active', true)
            ->where('products.reorder_level', '>', 0)
            ->select('products.id', 'products.name', 'products.sku', 'products.reorder_level')
            ->selectRaw('COALESCE(SUM(warehouse_stocks.quantity - warehouse_stocks.reserved_quantity), 0) as available_quantity')
            ->groupBy('products.id', 'products.name', 'products.sku', 'products.reorder_level')
            ->havingRaw('COALESCE(SUM(warehouse_stocks.quantity - warehouse_stocks.reserved_quantity), 0) <= products.reorder_level')
            ->orderBy('products.name')
            ->get()
            ->map(fn ($product): array => [
                'name' => $product->name,
                'sku' => $product->sku,
                'available_quantity' => round((float) $product->available_quantity, 4),
                'reorder_level' => round((float) $product->reorder_level, 2),
                'unit' => null,
            ])
            ->values()
            ->all();

        if ($lowStockItems === []) {
            $this->info('No low stock items found. Nothing to notify.');

            return self::SUCCESS;
        }

        $this->info(sprintf('Found %d low stock item(s).', count($lowStockItems)));

        if ($this->option('dry-run')) {
            foreach ($lowStockItems as $item) {
                $this->line(sprintf('- %s (%s): available %s / reorder %s', $item['name'], $item['sku'], $item['available_quantity'], $item['reorder_level']));
            }

            return self::SUCCESS;
        }

        $recipients = User::query()
            ->where('is_active', true)
            ->whereHas('roles.permissions', function ($query): void {
                $query->where('slug', 'reports.low-stock.view');
            })
            ->get();

        if ($recipients->isEmpty()) {
            $this->warn('No active users with low-stock report access were found. Skipping notification.');

            return self::SUCCESS;
        }

        Notification::send($recipients, new LowStockAlert(
            $lowStockItems,
            $settingsService->get(SettingsService::LOW_STOCK_EMAIL_ENABLED) === '1',
        ));

        Log::info('Low stock alert sent.', [
            'recipients' => $recipients->count(),
            'low_stock_items' => count($lowStockItems),
        ]);

        $this->info(sprintf('Notification sent to %d user(s).', $recipients->count()));

        return self::SUCCESS;
    }
}
