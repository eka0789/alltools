<?php

namespace App\Models\Concerns;

trait Trashed
{
    /**
     * Columns searched on the trash page.
     *
     * @return list<string>
     */
    public static function trashSearchColumns(): array
    {
        return ['name'];
    }

    public function trashDisplayName(): string
    {
        return (string) $this->getAttribute('name');
    }
}
