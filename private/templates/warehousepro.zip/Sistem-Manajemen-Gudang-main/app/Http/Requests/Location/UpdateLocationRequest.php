<?php

namespace App\Http\Requests\Location;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateLocationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()?->can('permission', 'locations.update') ?? false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, list<mixed>>
     */
    public function rules(): array
    {
        $location = $this->route('location');
        $locationId = $location instanceof Model ? $location->getKey() : null;

        return [
            'warehouse_id' => ['nullable', 'integer', 'exists:warehouses,id'],
            'code' => [
                'required',
                'string',
                'max:50',
                Rule::unique('locations')->whereNull('deleted_at')->ignore($locationId),
            ],
            'name' => ['nullable', 'string', 'max:150'],
            'description' => ['nullable', 'string', 'max:5000'],
            'is_active' => ['sometimes', 'boolean'],
        ];
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return [
            'warehouse_id' => 'warehouse',
            'code' => 'location code',
            'name' => 'location name',
            'description' => 'description',
            'is_active' => 'active status',
        ];
    }
}
