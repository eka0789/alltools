<?php

namespace App\Http\Controllers\Catalog;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\ImportProductRequest;
use App\Services\Import\ProductImportService;
use Illuminate\Http\RedirectResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ProductImportController extends Controller
{
    public function __construct(
        private readonly ProductImportService $importService,
    ) {
    }

    public function form(): \Illuminate\View\View
    {
        return view('catalog.products.import');
    }

    public function template(): StreamedResponse
    {
        $filename = 'products-import-template-'.now()->format('Ymd').'.csv';

        return response()->streamDownload(function (): void {
            $output = fopen('php://output', 'wb');

            if ($output === false) {
                return;
            }

            fputcsv($output, [
                'sku', 'name', 'category', 'unit', 'barcode',
                'purchase_price', 'selling_price', 'reorder_level',
                'location_code', 'warehouse_code', 'opening_stock',
            ]);

            fputcsv($output, ['PRD-001', 'Copy Paper A4', 'Office Supplies', 'pcs', '', '25000', '35000', '10', 'A', 'WH-01', '100']);

            fclose($output);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function store(ImportProductRequest $request): RedirectResponse
    {
        $path = $request->file('file')?->getRealPath();

        if (! is_string($path) || $path === '') {
            return redirect()
                ->route('products.import.form')
                ->with('error', 'The uploaded file could not be read.');
        }

        $result = $this->importService->import($path, $request->user());

        if ($result['imported'] === 0) {
            return redirect()
                ->route('products.import.form')
                ->with('error', 'Nothing was imported.')
                ->with('import_errors', $result['errors']);
        }

        $message = sprintf(
            '%d product(s) imported successfully%s.',
            $result['imported'],
            $result['stock_documents'] > 0
                ? sprintf(' and %d opening stock document(s) created', $result['stock_documents'])
                : '',
        );

        return redirect()
            ->route('products.index')
            ->with('success', $message)
            ->with('import_errors', $result['errors']);
    }
}
