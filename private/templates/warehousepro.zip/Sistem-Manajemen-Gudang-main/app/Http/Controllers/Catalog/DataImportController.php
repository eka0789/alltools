<?php

namespace App\Http\Controllers\Catalog;

use App\Http\Controllers\Controller;
use App\Services\Import\CategoryImportService;
use App\Services\Import\ProductImportService;
use App\Services\Import\SupplierImportService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class DataImportController extends Controller
{
    private const TYPES = [
        'products' => [
            'label' => 'Products',
            'columns' => ['sku', 'name', 'category', 'unit', 'barcode', 'purchase_price', 'selling_price', 'reorder_level', 'location_code', 'warehouse_code', 'opening_stock'],
            'permission' => 'products.import',
        ],
        'suppliers' => [
            'label' => 'Suppliers',
            'columns' => ['name', 'phone', 'email', 'address', 'is_active'],
            'permission' => 'suppliers.create',
        ],
        'categories' => [
            'label' => 'Categories',
            'columns' => ['name', 'description', 'is_active'],
            'permission' => 'categories.create',
        ],
    ];

    public function index(): View
    {
        return view('catalog.imports.index', [
            'types' => self::TYPES,
        ]);
    }

    public function template(string $type)
    {
        $config = $this->resolve($type);

        $filename = $type.'-import-template-'.now()->format('Ymd').'.csv';

        return response()->streamDownload(function () use ($config): void {
            $output = fopen('php://output', 'wb');

            if ($output === false) {
                return;
            }

            fputcsv($output, $config['columns']);

            fclose($output);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function store(Request $request, string $type): RedirectResponse
    {
        $config = $this->resolve($type);

        $request->validate([
            'file' => ['required', 'file', 'mimes:csv,txt,xlsx', 'max:10240'],
        ], [], ['file' => 'import file']);

        $path = (string) $request->file('file')->getRealPath();

        $result = match ($type) {
            'products' => app(ProductImportService::class)->import($path, $request->user()),
            'suppliers' => app(SupplierImportService::class)->import($path),
            'categories' => app(CategoryImportService::class)->import($path),
            default => ['imported' => 0, 'errors' => ['Unknown import type.'], 'skipped' => 0],
        };

        if ($result['imported'] === 0) {
            return redirect()
                ->route('imports.index')
                ->with('error', 'Nothing was imported.')
                ->with('import_errors', $result['errors']);
        }

        return redirect()
            ->route($type === 'products' ? 'products.index' : ($type === 'suppliers' ? 'suppliers.index' : 'categories.index'))
            ->with('success', sprintf('%d %s record(s) imported successfully.', $result['imported'], $type))
            ->with('import_errors', $result['errors']);
    }

    /**
     * @return array{label: string, columns: list<string>, permission: string}
     */
    private function resolve(string $type): array
    {
        if (! isset(self::TYPES[$type])) {
            abort(404);
        }

        $config = self::TYPES[$type];

        abort_unless(Gate::check('permission', $config['permission']), 403);

        return $config;
    }
}
