<?php

namespace App\Http\Controllers\Warehouse;

use App\Http\Controllers\Controller;
use App\Http\Requests\Location\StoreLocationRequest;
use App\Http\Requests\Location\UpdateLocationRequest;
use App\Models\Location;
use App\Models\Warehouse;
use App\Services\Warehouse\LocationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class LocationController extends Controller
{
    public function __construct(
        private readonly LocationService $locationService,
    ) {
    }

    public function index(): View
    {
        $locations = $this->locationService->paginate(request()->only(['warehouse_id', 'search']));
        $warehouses = Warehouse::active()->orderBy('name')->get();

        return view('warehouse.locations.index', compact('locations', 'warehouses'));
    }

    public function create(): View
    {
        $warehouses = Warehouse::active()->orderBy('name')->get();

        return view('warehouse.locations.create', compact('warehouses'));
    }

    public function store(StoreLocationRequest $request): RedirectResponse
    {
        $this->locationService->create($request->validated());

        return redirect()
            ->route('locations.index')
            ->with('success', 'Location created successfully.');
    }

    public function show(Location $location): View
    {
        $location->load(['warehouse', 'products.unit']);

        return view('warehouse.locations.show', compact('location'));
    }

    public function edit(Location $location): View
    {
        $warehouses = Warehouse::active()->orderBy('name')->get();

        return view('warehouse.locations.edit', compact('location', 'warehouses'));
    }

    public function update(UpdateLocationRequest $request, Location $location): RedirectResponse
    {
        $this->locationService->update($location, $request->validated());

        return redirect()
            ->route('locations.index')
            ->with('success', 'Location updated successfully.');
    }

    public function destroy(Location $location): RedirectResponse
    {
        $this->locationService->delete($location);

        return redirect()
            ->route('locations.index')
            ->with('success', 'Location deleted successfully.');
    }
}
