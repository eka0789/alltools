<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    /**
     * Global quick search: products by name, SKU, or barcode.
     */
    public function products(Request $request): JsonResponse
    {
        $query = trim((string) $request->query('q', ''));

        if (mb_strlen($query) < 2) {
            return response()->json(['results' => []]);
        }

        $results = Product::query()
            ->active()
            ->with(['category', 'unit'])
            ->where(function ($queryBuilder) use ($query): void {
                $queryBuilder
                    ->where('name', 'like', '%'.$query.'%')
                    ->orWhere('sku', 'like', '%'.$query.'%')
                    ->orWhere('barcode', 'like', '%'.$query.'%');
            })
            ->orderBy('name')
            ->limit(8)
            ->get()
            ->map(fn (Product $product): array => [
                'id' => $product->getKey(),
                'name' => $product->name,
                'sku' => $product->sku,
                'barcode' => $product->barcode,
                'category' => $product->category?->name,
                'unit_id' => $product->unit_id,
                'unit_short' => $product->unit?->short_name ?? $product->unit?->name,
                'url' => route('products.show', $product),
            ]);

        return response()->json(['results' => $results]);
    }
}
