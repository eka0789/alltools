<?php

namespace App\Http\Controllers\Stock;

use App\Http\Controllers\Controller;
use App\Http\Requests\Stock\StoreStockAdjustmentRequest;
use App\Models\StockMovement;
use App\Services\Stock\StockAdjustmentService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class StockAdjustmentController extends Controller
{
    public function __construct(
        private readonly StockAdjustmentService $stockAdjustmentService,
    ) {
    }

    public function index(): View
    {
        $filters = request()->only(['warehouse_id', 'product_id', 'movement_type', 'date_from', 'date_to', 'sort', 'direction']);
        $adjustments = $this->stockAdjustmentService->paginate($filters);
        $warehouses = $this->stockAdjustmentService->activeWarehouses();
        $products = $this->stockAdjustmentService->activeProducts();

        return view('stock.adjustments.index', compact('adjustments', 'warehouses', 'products', 'filters'));
    }

    public function create(): View
    {
        $warehouses = $this->stockAdjustmentService->activeWarehouses();
        $products = $this->stockAdjustmentService->activeProducts();

        return view('stock.adjustments.create', compact('warehouses', 'products'));
    }

    public function store(StoreStockAdjustmentRequest $request): RedirectResponse
    {
        $this->stockAdjustmentService->create(
            $request->validated(),
            (int) $request->user()->id,
        );

        return redirect()
            ->route('stock-adjustments.index')
            ->with('success', 'Stock adjustment saved successfully.');
    }

    public function reverse(StockMovement $movement): RedirectResponse
    {
        $reversal = $this->stockAdjustmentService->reverse($movement, (int) auth()->id());

        return redirect()
            ->route('stock-adjustments.index')
            ->with('success', sprintf('Adjustment #%d reversed with a new adjustment (movement #%d).', $movement->getKey(), $reversal->getKey()));
    }
}
