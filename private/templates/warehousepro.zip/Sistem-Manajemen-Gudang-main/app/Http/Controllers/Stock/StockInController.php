<?php

namespace App\Http\Controllers\Stock;

use App\Http\Controllers\Controller;
use App\Http\Requests\Stock\StockInIndexRequest;
use App\Http\Requests\Stock\StoreStockInRequest;
use App\Models\Location;
use App\Models\StockIn;
use App\Services\Stock\StockInService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class StockInController extends Controller
{
    public function __construct(
        private readonly StockInService $stockInService,
    ) {
    }

    public function index(StockInIndexRequest $request): View
    {
        $filters = $request->validated();
        $stockIns = $this->stockInService->paginate($filters);
        $warehouses = $this->stockInService->activeWarehouses();
        $products = $this->stockInService->activeProducts();

        return view('stock.ins.index', compact('stockIns', 'warehouses', 'products', 'filters'));
    }

    public function create(): View
    {
        $warehouses = $this->stockInService->activeWarehouses();
        $products = $this->stockInService->activeProducts();
        $locations = Location::active()->with('warehouse')->orderBy('code')->get();

        return view('stock.ins.create', compact('warehouses', 'products', 'locations'));
    }

    public function store(StoreStockInRequest $request): RedirectResponse
    {
        $stockIn = $this->stockInService->create($request->validated(), $request->user());

        return redirect()
            ->route('stock-ins.show', $stockIn)
            ->with('success', 'Stock in document created successfully.');
    }

    public function show(StockIn $stockIn): View
    {
        $stockIn = $this->stockInService->loadForShow($stockIn);
        $movements = $this->stockInService->movements($stockIn);

        return view('stock.ins.show', compact('stockIn', 'movements'));
    }

    public function slip(
        StockIn $stockIn,
        \App\Services\Settings\SettingsService $settingsService,
    ): \Illuminate\Http\Response {
        $stockIn = $this->stockInService->loadForShow($stockIn);

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('stock._slip', [
            'document' => $stockIn,
            'type' => 'in',
            'heading' => 'STOCK IN DOCUMENT',
            'title' => 'Stock In '.$stockIn->document_no,
            'company' => $settingsService->all(),
        ]);

        return $pdf->stream('stock-in-'.$stockIn->document_no.'.pdf');
    }
}
