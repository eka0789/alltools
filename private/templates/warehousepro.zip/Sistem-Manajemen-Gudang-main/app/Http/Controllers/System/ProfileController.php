<?php

namespace App\Http\Controllers\System;

use App\Http\Controllers\Controller;
use App\Services\Audit\AuditLogService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ProfileController extends Controller
{
    public function __construct(
        private readonly AuditLogService $auditLogService,
    ) {
    }

    public function edit(): View
    {
        $user = auth()->user()->load('roles');

        return view('system.profile', compact('user'));
    }

    public function update(Request $request): RedirectResponse
    {
        $user = $request->user();

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email,'.$user->getKey()],
            'current_password' => ['nullable', 'string'],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
        ], [], [
            'current_password' => 'current password',
            'password' => 'new password',
        ]);

        $attributes = [
            'name' => $validated['name'],
            'email' => $validated['email'],
        ];

        if (isset($validated['password']) && $validated['password'] !== '') {
            if (! isset($validated['current_password']) || ! Hash::check($validated['current_password'], $user->password)) {
                return redirect()
                    ->route('profile.edit')
                    ->withErrors(['current_password' => 'The current password is incorrect.'])
                    ->withInput();
            }

            $attributes['password'] = Hash::make($validated['password']);
        }

        $user->update($attributes);

        $this->auditLogService->record(
            event: 'updated',
            module: 'profile',
            auditable: $user,
            description: sprintf('User "%s" updated their own profile.', $user->name),
            newValues: ['name' => $user->name, 'email' => $user->email],
            metadata: ['model' => 'user'],
            user: $user,
        );

        return redirect()
            ->route('profile.edit')
            ->with('success', 'Profile updated successfully.');
    }
}
