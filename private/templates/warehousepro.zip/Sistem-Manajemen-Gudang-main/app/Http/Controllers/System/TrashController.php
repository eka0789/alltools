<?php

namespace App\Http\Controllers\System;

use App\Http\Controllers\Controller;
use App\Services\System\TrashService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class TrashController extends Controller
{
    public function __construct(
        private readonly TrashService $trashService,
    ) {
    }

    public function index(): View
    {
        $type = (string) request('type', 'products');
        $search = trim((string) request('search', ''));

        $resolved = $this->trashService->resolveType($type);
        $type = $resolved['type'];
        $config = $resolved['config'];

        abort_unless(Gate::check('permission', $config['viewPermission']), 403);

        $records = $this->trashService->paginate($type, $search);
        $types = TrashService::types();

        return view('system.trash.index', compact('records', 'types', 'type', 'search', 'config'));
    }

    public function restore(string $type, int $id): RedirectResponse
    {
        $config = $this->trashService->resolveType($type)['config'];

        abort_unless(Gate::check('permission', $config['deletePermission']), 403);

        $record = $this->trashService->restore($type, $id);

        return redirect()
            ->route('trash.index', ['type' => $type])
            ->with('success', sprintf('"%s" was restored.', $record->trashDisplayName()));
    }

    public function destroy(string $type, int $id): RedirectResponse
    {
        $config = $this->trashService->resolveType($type)['config'];

        abort_unless(Gate::check('permission', $config['deletePermission']), 403);

        try {
            $this->trashService->forceDelete($type, $id);
        } catch (ValidationException $exception) {
            return redirect()
                ->route('trash.index', ['type' => $type])
                ->with('error', $exception->errors()['force_delete'][0] ?? 'Record could not be permanently deleted.');
        }

        return redirect()
            ->route('trash.index', ['type' => $type])
            ->with('success', 'Record permanently deleted.');
    }
}
