<?php

namespace App\Http\Controllers\System;

use App\Http\Controllers\Controller;
use App\Services\Settings\SettingsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SettingsController extends Controller
{
    public function __construct(
        private readonly SettingsService $settingsService,
    ) {
    }

    public function edit(): View
    {
        $settings = $this->settingsService->all();

        return view('system.settings', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'company_name' => ['nullable', 'string', 'max:150'],
            'company_address' => ['nullable', 'string', 'max:2000'],
            'company_phone' => ['nullable', 'string', 'max:50'],
            'company_email' => ['nullable', 'email', 'max:150'],
            'low_stock_email_enabled' => ['sometimes', 'boolean'],
        ], [], [
            'company_name' => 'company name',
            'company_address' => 'company address',
            'company_phone' => 'company phone',
            'company_email' => 'company email',
            'low_stock_email_enabled' => 'low stock email',
        ]);

        $this->settingsService->setMany([
            SettingsService::COMPANY_NAME => $validated['company_name'] ?? null,
            SettingsService::COMPANY_ADDRESS => $validated['company_address'] ?? null,
            SettingsService::COMPANY_PHONE => $validated['company_phone'] ?? null,
            SettingsService::COMPANY_EMAIL => $validated['company_email'] ?? null,
            SettingsService::LOW_STOCK_EMAIL_ENABLED => ($request->boolean('low_stock_email_enabled') ? '1' : '0'),
        ]);

        return redirect()
            ->route('settings.edit')
            ->with('success', 'Settings saved successfully.');
    }
}
