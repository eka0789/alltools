<?php

declare(strict_types=1);

namespace App\Support;

use Maatwebsite\Excel\Concerns\ToArray;

class CsvXlsxReader
{
    /**
     * Read a CSV or XLSX upload into a list of rows (each a list of string|null cells).
     *
     * @return list<list<string|null>>
     */
    public static function read(string $path): array
    {
        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));

        if ($extension === 'csv' || $extension === 'txt') {
            return self::readCsv($path);
        }

        return self::readXlsx($path);
    }

    /**
     * @return list<list<string|null>>
     */
    private static function readCsv(string $path): array
    {
        $handle = fopen($path, 'rb');

        if ($handle === false) {
            return [];
        }

        $rows = [];

        while (($row = fgetcsv($handle, 0, ',')) !== false) {
            if ($row === [null]) {
                continue;
            }

            $rows[] = $row;
        }

        fclose($handle);

        return $rows;
    }

    /**
     * @return list<list<string|null>>
     */
    private static function readXlsx(string $path): array
    {
        $sheets = \Maatwebsite\Excel\Facades\Excel::toArray(
            new class implements ToArray
            {
                /**
                 * @param  array<int, mixed>  $array
                 */
                public function array(array $array): void
                {
                }
            },
            $path,
        );

        $firstSheet = $sheets[0] ?? [];

        return array_map(
            fn ($row): array => array_map(fn ($cell): ?string => $cell === null ? null : (string) $cell, $row),
            $firstSheet,
        );
    }

    /**
     * Parse a header row into normalized lowercase keys.
     *
     * @param  list<list<string|null>>  $rows
     * @return list<string>
     */
    public static function normalizeHeader(array $rows): array
    {
        $header = array_shift($rows) ?? [];

        return array_map(
            fn ($value): string => strtolower(trim((string) preg_replace('/^\xEF\xBB\xBF/', '', (string) $value))),
            $header,
        );
    }
}
