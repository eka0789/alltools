<?php

declare(strict_types=1);

namespace App\Support;

use Illuminate\Database\Eloquent\Builder;

class Sortable
{
    /**
     * Apply a whitelisted sort to a query.
     *
     * @param  Builder  $query
     * @param  array<string, string>  $columns  sort key => SQL column
     * @param  string|null  $sort
     * @param  string|null  $direction
     * @param  string  $default
     */
    public static function apply(Builder $query, array $columns, string|null $sort, string|null $direction, string $default = 'created_at'): Builder
    {
        $column = $columns[$sort ?? ''] ?? $columns[$default];
        $direction = strtolower((string) $direction) === 'asc' ? 'asc' : 'desc';

        return $query->orderBy($column, $direction);
    }

    /**
     * The direction a column header should link to next.
     */
    public static function nextDirection(string|null $currentSort, string|null $currentDirection, string $column): string
    {
        if (($currentSort ?? '') !== $column || strtolower((string) $currentDirection) !== 'asc') {
            return 'asc';
        }

        return 'desc';
    }
}
