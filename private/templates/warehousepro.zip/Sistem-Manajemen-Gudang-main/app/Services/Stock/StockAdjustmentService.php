<?php

declare(strict_types=1);

namespace App\Services\Stock;

use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Warehouse;
use App\Models\WarehouseStock;
use App\Services\Audit\AuditLogService;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class StockAdjustmentService
{
    public const MOVEMENT_OPENING_BALANCE = 'opening_balance';

    public const MOVEMENT_ADJUSTMENT_IN = 'adjustment_in';

    public const MOVEMENT_ADJUSTMENT_OUT = 'adjustment_out';

    public function __construct(
        private readonly AuditLogService $auditLogService,
    ) {
    }

    /**
     * @param  array{warehouse_id: int|string, product_id: int|string, movement_type: string, quantity: int|float|string, remarks?: string|null}  $data
     */
    public function create(array $data, int $createdBy): WarehouseStock
    {
        $result = DB::transaction(function () use ($data, $createdBy): array {
            $warehouseId = (int) $data['warehouse_id'];
            $productId = (int) $data['product_id'];
            $movementType = (string) $data['movement_type'];
            $quantity = round((float) $data['quantity'], 4);

            $stock = $this->lockedWarehouseStock($warehouseId, $productId);
            $currentQuantity = round((float) $stock->quantity, 4);
            $reservedQuantity = round((float) $stock->reserved_quantity, 4);

            $balanceAfter = match ($movementType) {
                self::MOVEMENT_OPENING_BALANCE => $this->openingBalance($warehouseId, $productId, $quantity, $reservedQuantity),
                self::MOVEMENT_ADJUSTMENT_IN => $currentQuantity + $quantity,
                self::MOVEMENT_ADJUSTMENT_OUT => $currentQuantity - $quantity,
                default => throw ValidationException::withMessages([
                    'movement_type' => 'The selected movement type is invalid.',
                ]),
            };
            $balanceAfter = round($balanceAfter, 4);

            $this->ensureStockCanSettle($balanceAfter, $reservedQuantity);

            $stock->update([
                'quantity' => $balanceAfter,
            ]);

            $movement = StockMovement::create([
                'warehouse_id' => $warehouseId,
                'product_id' => $productId,
                'movement_type' => $movementType,
                'quantity' => $quantity,
                'balance_after' => $balanceAfter,
                'reference_type' => null,
                'reference_id' => null,
                'remarks' => $data['remarks'] ?? null,
                'created_by' => $createdBy,
            ]);

            return [
                'stock' => $stock->refresh(),
                'movement' => $movement,
                'previous_quantity' => $currentQuantity,
                'new_quantity' => $balanceAfter,
            ];
        });

        /** @var WarehouseStock $stock */
        $stock = $result['stock'];
        /** @var StockMovement $movement */
        $movement = $result['movement'];
        $movement->loadMissing(['warehouse', 'product']);

        $this->auditLogService->record(
            event: 'stock_adjusted',
            module: 'stock_adjustments',
            auditable: $movement,
            description: sprintf(
                'Stock adjustment was recorded for product "%s" in warehouse "%s".',
                $movement->product?->name ?? 'Unknown Product',
                $movement->warehouse?->name ?? 'Unknown Warehouse',
            ),
            newValues: [
                'warehouse_id' => $movement->warehouse_id,
                'warehouse_name' => $movement->warehouse?->name,
                'product_id' => $movement->product_id,
                'product_name' => $movement->product?->name,
                'movement_type' => $movement->movement_type,
                'quantity' => $movement->quantity,
                'previous_quantity' => $this->formatQuantity((float) $result['previous_quantity']),
                'new_quantity' => $this->formatQuantity((float) $result['new_quantity']),
                'remarks' => $movement->remarks,
            ],
            metadata: [
                'model' => 'stock_adjustment',
                'stock_movement_id' => $movement->id,
                'warehouse_stock_id' => $stock->id,
            ],
        );

        return $stock;
    }

    public function activeWarehouses(): Collection
    {
        return Warehouse::active()
            ->orderBy('name')
            ->orderBy('code')
            ->get();
    }

    public function activeProducts(): Collection
    {
        return Product::active()
            ->with(['category', 'unit'])
            ->orderBy('name')
            ->get();
    }

    /**
     * @param  array{warehouse_id?: int|string|null, product_id?: int|string|null, movement_type?: string|null, date_from?: string|null, date_to?: string|null, sort?: string|null, direction?: string|null}  $filters
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function paginate(array $filters, int $perPage = 15)
    {
        $sortColumns = [
            'created_at' => 'stock_movements.created_at',
            'product' => 'products.name',
            'warehouse' => 'warehouses.name',
            'quantity' => 'stock_movements.quantity',
        ];

        return StockMovement::query()
            ->whereIn('movement_type', [self::MOVEMENT_ADJUSTMENT_IN, self::MOVEMENT_ADJUSTMENT_OUT])
            ->with(['warehouse', 'product', 'creator'])
            ->join('products', 'products.id', '=', 'stock_movements.product_id')
            ->join('warehouses', 'warehouses.id', '=', 'stock_movements.warehouse_id')
            ->when($filters['warehouse_id'] ?? null, function ($query, int|string $warehouseId): mixed {
                return $query->where('stock_movements.warehouse_id', $warehouseId);
            })
            ->when($filters['product_id'] ?? null, function ($query, int|string $productId): mixed {
                return $query->where('stock_movements.product_id', $productId);
            })
            ->when($filters['movement_type'] ?? null, function ($query, string $movementType): mixed {
                return $query->where('stock_movements.movement_type', $movementType);
            })
            ->when($filters['date_from'] ?? null, function ($query, string $dateFrom): mixed {
                return $query->whereDate('stock_movements.created_at', '>=', $dateFrom);
            })
            ->when($filters['date_to'] ?? null, function ($query, string $dateTo): mixed {
                return $query->whereDate('stock_movements.created_at', '<=', $dateTo);
            })
            ->select('stock_movements.*')
            ->orderBy(
                $sortColumns[$filters['sort'] ?? 'created_at'] ?? 'stock_movements.created_at',
                strtolower((string) ($filters['direction'] ?? 'desc')) === 'asc' ? 'asc' : 'desc',
            )
            ->paginate($perPage)
            ->appends(array_filter($filters, fn ($value): bool => $value !== null && $value !== ''));
    }

    /**
     * Reverse an adjustment by recording the opposite movement.
     */
    public function reverse(StockMovement $movement, int $createdBy): StockMovement
    {
        if (! in_array($movement->movement_type, [self::MOVEMENT_ADJUSTMENT_IN, self::MOVEMENT_ADJUSTMENT_OUT], true)) {
            throw ValidationException::withMessages([
                'movement' => 'Only stock adjustments can be reversed.',
            ]);
        }

        if ($movement->reversal_of_id !== null) {
            throw ValidationException::withMessages([
                'movement' => 'This adjustment has already been reversed.',
            ]);
        }

        $reversed = StockMovement::query()
            ->where('reversal_of_id', $movement->getKey())
            ->exists();

        if ($reversed) {
            throw ValidationException::withMessages([
                'movement' => 'This adjustment has already been reversed.',
            ]);
        }

        $oppositeType = $movement->movement_type === self::MOVEMENT_ADJUSTMENT_IN
            ? self::MOVEMENT_ADJUSTMENT_OUT
            : self::MOVEMENT_ADJUSTMENT_IN;

        $this->create([
            'warehouse_id' => $movement->warehouse_id,
            'product_id' => $movement->product_id,
            'movement_type' => $oppositeType,
            'quantity' => $movement->quantity,
            'remarks' => sprintf('Reversal of adjustment #%d.', $movement->getKey()),
        ], $createdBy);

        $reversal = StockMovement::query()
            ->where('movement_type', $oppositeType)
            ->where('warehouse_id', $movement->warehouse_id)
            ->where('product_id', $movement->product_id)
            ->where('remarks', sprintf('Reversal of adjustment #%d.', $movement->getKey()))
            ->latest('id')
            ->firstOrFail();

        $movement->update(['reversal_of_id' => $reversal->getKey()]);

        return $reversal;
    }

    private function lockedWarehouseStock(int $warehouseId, int $productId): WarehouseStock
    {
        $stock = WarehouseStock::query()
            ->where('warehouse_id', $warehouseId)
            ->where('product_id', $productId)
            ->lockForUpdate()
            ->first();

        if ($stock) {
            return $stock;
        }

        WarehouseStock::create([
            'warehouse_id' => $warehouseId,
            'product_id' => $productId,
            'quantity' => 0,
            'reserved_quantity' => 0,
        ]);

        return WarehouseStock::query()
            ->where('warehouse_id', $warehouseId)
            ->where('product_id', $productId)
            ->lockForUpdate()
            ->firstOrFail();
    }

    private function openingBalance(int $warehouseId, int $productId, float $quantity, float $reservedQuantity): float
    {
        $hasExistingMovement = StockMovement::query()
            ->where('warehouse_id', $warehouseId)
            ->where('product_id', $productId)
            ->exists();

        if ($hasExistingMovement) {
            throw ValidationException::withMessages([
                'movement_type' => 'Opening balance can only be created before any stock movement exists for this warehouse and product.',
            ]);
        }

        if ($quantity < $reservedQuantity) {
            throw ValidationException::withMessages([
                'quantity' => 'Stock quantity cannot be lower than reserved quantity.',
            ]);
        }

        return $quantity;
    }

    private function ensureStockCanSettle(float $balanceAfter, float $reservedQuantity): void
    {
        if ($balanceAfter < 0) {
            throw ValidationException::withMessages([
                'quantity' => 'Stock quantity cannot be reduced below zero.',
            ]);
        }

        if ($balanceAfter < $reservedQuantity) {
            throw ValidationException::withMessages([
                'quantity' => 'Stock quantity cannot be lower than reserved quantity.',
            ]);
        }
    }

    private function formatQuantity(float $quantity): string
    {
        return number_format($quantity, 4, '.', '');
    }
}
