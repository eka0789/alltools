<?php

declare(strict_types=1);

namespace App\Services\System;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\Warehouse;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class TrashService
{
    /**
     * @return array<string, array{class: class-string<Model>, label: string, viewPermission: string, deletePermission: string}>
     */
    public static function types(): array
    {
        return [
            'products' => [
                'class' => Product::class,
                'label' => 'Products',
                'viewPermission' => 'products.view',
                'deletePermission' => 'products.delete',
            ],
            'categories' => [
                'class' => Category::class,
                'label' => 'Categories',
                'viewPermission' => 'categories.view',
                'deletePermission' => 'categories.delete',
            ],
            'suppliers' => [
                'class' => Supplier::class,
                'label' => 'Suppliers',
                'viewPermission' => 'suppliers.view',
                'deletePermission' => 'suppliers.delete',
            ],
            'warehouses' => [
                'class' => Warehouse::class,
                'label' => 'Warehouses',
                'viewPermission' => 'warehouses.view',
                'deletePermission' => 'warehouses.delete',
            ],
        ];
    }

    /**
     * @return array{type: string, config: array{class: class-string<Model>, label: string, viewPermission: string, deletePermission: string}}
     */
    public function resolveType(string $type): array
    {
        $types = self::types();

        if (! isset($types[$type])) {
            throw ValidationException::withMessages([
                'type' => 'Unknown trash section.',
            ]);
        }

        return ['type' => $type, 'config' => $types[$type]];
    }

    /**
     * @return \Illuminate\Contracts\Pagination\LengthAwarePaginator
     */
    public function paginate(string $type, string $search = '', int $perPage = 15)
    {
        $modelClass = $this->resolveType($type)['config']['class'];

        return $modelClass::onlyTrashed()
            ->when($search !== '', function ($query) use ($search, $modelClass): mixed {
                return $query->where(function ($query) use ($search, $modelClass): mixed {
                    foreach ($modelClass::trashSearchColumns() as $column) {
                        $query->orWhere($column, 'like', '%'.$search.'%');
                    }

                    return $query;
                });
            })
            ->orderByDesc('deleted_at')
            ->paginate($perPage)
            ->appends(['search' => $search, 'type' => $type]);
    }

    public function restore(string $type, int $id): Model
    {
        $config = $this->resolveType($type)['config'];
        $record = $config['class']::onlyTrashed()->findOrFail($id);
        $name = $record->trashDisplayName();

        $record->restore();

        app(\App\Services\Audit\AuditLogService::class)->record(
            event: 'restored',
            module: $type,
            auditable: $record,
            description: sprintf('%s "%s" was restored from trash.', ucfirst((string) str($type)->singular()), $name),
            metadata: ['model' => $type],
        );

        return $record;
    }

    public function forceDelete(string $type, int $id): void
    {
        $config = $this->resolveType($type)['config'];
        $record = $config['class']::onlyTrashed()->findOrFail($id);
        $name = $record->trashDisplayName();

        try {
            DB::transaction(function () use ($record): void {
                $record->forceDelete();
            });
        } catch (\Illuminate\Database\QueryException $exception) {
            throw ValidationException::withMessages([
                'force_delete' => '"'.$name.'" cannot be permanently deleted because related transaction records still reference it.',
            ]);
        }

        app(\App\Services\Audit\AuditLogService::class)->record(
            event: 'force_deleted',
            module: $type,
            auditable: $record,
            description: sprintf('%s "%s" was permanently deleted from trash.', ucfirst((string) str($type)->singular()), $name),
            oldValues: ['name' => $name],
            metadata: ['model' => $type],
        );
    }
}
