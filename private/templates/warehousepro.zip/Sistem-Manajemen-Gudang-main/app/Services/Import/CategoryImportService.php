<?php

declare(strict_types=1);

namespace App\Services\Import;

use App\Models\Category;
use App\Services\Audit\AuditLogService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CategoryImportService
{
    private const REQUIRED_HEADERS = ['name'];

    public function __construct(
        private readonly AuditLogService $auditLogService,
    ) {
    }

    /**
     * @return array{imported: int, errors: list<string>, skipped: int}
     */
    public function import(string $uploadedPath): array
    {
        $rows = \App\Support\CsvXlsxReader::read($uploadedPath);

        if ($rows === []) {
            return ['imported' => 0, 'errors' => ['The uploaded file contains no data rows.'], 'skipped' => 0];
        }

        $header = array_map(
            fn ($value): string => strtolower(trim((string) preg_replace('/^\xEF\xBB\xBF/', '', (string) $value))),
            array_shift($rows),
        );

        $missing = array_diff(self::REQUIRED_HEADERS, $header);
        if ($missing !== []) {
            return ['imported' => 0, 'errors' => ['Missing required column(s): '.implode(', ', $missing).'.'], 'skipped' => 0];
        }

        $existing = Category::withTrashed()->get()->keyBy(fn (Category $category): string => strtolower($category->name));
        $seen = [];
        $toCreate = [];
        $errors = [];

        foreach (array_values($rows) as $index => $row) {
            $rowNumber = $index + 2;
            $data = array_combine($header, array_pad(array_slice($row, 0, count($header)), count($header), null));
            $name = trim((string) ($data['name'] ?? ''));

            if ($name === '') {
                continue;
            }

            if (isset($seen[strtolower($name)])) {
                $errors[] = "Row {$rowNumber}: Duplicate name \"{$name}\" inside the uploaded file.";

                continue;
            }

            if (isset($existing[strtolower($name)])) {
                $errors[] = "Row {$rowNumber}: Category \"{$name}\" already exists.";

                continue;
            }

            $seen[strtolower($name)] = true;
            $toCreate[] = [
                'name' => $name,
                'slug' => $this->uniqueSlug($name),
                'description' => trim((string) ($data['description'] ?? '')) ?: null,
                'is_active' => strtolower(trim((string) ($data['is_active'] ?? '1'))) !== '0',
            ];
        }

        if ($toCreate === []) {
            return ['imported' => 0, 'errors' => $errors !== [] ? $errors : ['No valid rows found to import.'], 'skipped' => count($errors)];
        }

        DB::transaction(function () use ($toCreate): void {
            foreach ($toCreate as $attributes) {
                $category = Category::query()->create($attributes);

                $this->auditLogService->record(
                    event: 'created',
                    module: 'categories',
                    auditable: $category,
                    description: sprintf('Category "%s" was created by bulk import.', $category->name),
                    newValues: ['name' => $category->name],
                    metadata: ['model' => 'category', 'imported' => true],
                );
            }
        });

        return ['imported' => count($toCreate), 'errors' => $errors, 'skipped' => count($errors)];
    }

    private function uniqueSlug(string $name): string
    {
        $base = Str::slug($name) ?: 'category';
        $slug = $base;
        $counter = 2;

        while (Category::withTrashed()->where('slug', $slug)->exists()) {
            $slug = $base.'-'.$counter++;
        }

        return $slug;
    }
}
