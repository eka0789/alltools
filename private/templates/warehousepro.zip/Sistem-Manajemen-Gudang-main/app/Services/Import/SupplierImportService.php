<?php

declare(strict_types=1);

namespace App\Services\Import;

use App\Models\Supplier;
use App\Services\Audit\AuditLogService;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\ToArray;

class SupplierImportService
{
    private const REQUIRED_HEADERS = ['name'];

    public function __construct(
        private readonly AuditLogService $auditLogService,
    ) {
    }

    /**
     * @return array{imported: int, errors: list<string>, skipped: int}
     */
    public function import(string $uploadedPath): array
    {
        $rows = \App\Support\CsvXlsxReader::read($uploadedPath);

        if ($rows === []) {
            return ['imported' => 0, 'errors' => ['The uploaded file contains no data rows.'], 'skipped' => 0];
        }

        $header = array_map(
            fn ($value): string => strtolower(trim((string) preg_replace('/^\xEF\xBB\xBF/', '', (string) $value))),
            array_shift($rows),
        );

        $missing = array_diff(self::REQUIRED_HEADERS, $header);
        if ($missing !== []) {
            return ['imported' => 0, 'errors' => ['Missing required column(s): '.implode(', ', $missing).'.'], 'skipped' => 0];
        }

        $existing = Supplier::withTrashed()->get()->keyBy(fn (Supplier $supplier): string => strtolower($supplier->name));
        $seen = [];
        $toCreate = [];
        $errors = [];

        foreach (array_values($rows) as $index => $row) {
            $rowNumber = $index + 2;
            $data = array_combine($header, array_pad(array_slice($row, 0, count($header)), count($header), null));
            $name = trim((string) ($data['name'] ?? ''));

            if ($name === '') {
                continue;
            }

            $rowErrors = [];
            if (isset($seen[strtolower($name)])) {
                $rowErrors[] = "Duplicate name \"{$name}\" inside the uploaded file.";
            } elseif (isset($existing[strtolower($name)])) {
                $rowErrors[] = "Supplier \"{$name}\" already exists.";
            }

            $email = trim((string) ($data['email'] ?? ''));
            if ($email !== '' && ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $rowErrors[] = "Email \"{$email}\" is not valid.";
            }

            if ($rowErrors !== []) {
                foreach ($rowErrors as $rowError) {
                    $errors[] = "Row {$rowNumber}: {$rowError}";
                }

                continue;
            }

            $seen[strtolower($name)] = true;
            $toCreate[] = [
                'name' => $name,
                'email' => $email !== '' ? $email : null,
                'phone' => trim((string) ($data['phone'] ?? '')) ?: null,
                'address' => trim((string) ($data['address'] ?? '')) ?: null,
                'is_active' => strtolower(trim((string) ($data['is_active'] ?? '1'))) !== '0',
            ];
        }

        if ($toCreate === []) {
            return ['imported' => 0, 'errors' => $errors !== [] ? $errors : ['No valid rows found to import.'], 'skipped' => count($errors)];
        }

        DB::transaction(function () use ($toCreate): void {
            foreach ($toCreate as $attributes) {
                $supplier = Supplier::query()->create($attributes);

                $this->auditLogService->record(
                    event: 'created',
                    module: 'suppliers',
                    auditable: $supplier,
                    description: sprintf('Supplier "%s" was created by bulk import.', $supplier->name),
                    newValues: ['name' => $supplier->name, 'email' => $supplier->email],
                    metadata: ['model' => 'supplier', 'imported' => true],
                );
            }
        });

        return ['imported' => count($toCreate), 'errors' => $errors, 'skipped' => count($errors)];
    }

}
