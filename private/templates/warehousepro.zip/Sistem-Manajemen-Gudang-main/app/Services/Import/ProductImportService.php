<?php

declare(strict_types=1);

namespace App\Services\Import;

use App\Services\Catalog\ProductService;
use App\Services\Stock\StockInService;
use App\Models\Category;
use App\Models\Location;
use App\Models\Product;
use App\Models\Unit;
use App\Models\Warehouse;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\ToArray;

class ProductImportService
{
    private const HEADER_ROW = 1;

    private const REQUIRED_HEADERS = ['sku', 'name', 'category', 'unit'];

    public function __construct(
        private readonly ProductService $productService,
        private readonly StockInService $stockInService,
    ) {
    }

    /**
     * Import products (and optional opening stock) from an uploaded
     * CSV/XLSX file. Rows that fail validation are reported; valid rows
     * are imported inside one transaction.
     *
     * @return array{imported: int, stock_documents: int, errors: list<string>, skipped: int}
     */
    public function import(string $uploadedPath, \App\Models\User $user): array
    {
        $rows = \App\Support\CsvXlsxReader::read($uploadedPath);

        if ($rows === []) {
            return [
                'imported' => 0,
                'stock_documents' => 0,
                'errors' => ['The uploaded file contains no data rows.'],
                'skipped' => 0,
            ];
        }

        $header = array_map(
            fn ($value): string => strtolower(trim((string) preg_replace('/^\xEF\xBB\xBF/', '', (string) $value))),
            array_shift($rows),
        );

        $missing = array_diff(self::REQUIRED_HEADERS, $header);

        if ($missing !== []) {
            return [
                'imported' => 0,
                'stock_documents' => 0,
                'errors' => ['Missing required column(s): '.implode(', ', $missing).'. Required columns: '.implode(', ', self::REQUIRED_HEADERS).'.'],
                'skipped' => 0,
            ];
        }

        $categories = Category::query()->get()->keyBy(fn (Category $category): string => strtolower($category->name));
        $units = Unit::query()->get()->keyBy(fn (Unit $unit): string => strtolower($unit->short_name));
        $warehouses = Warehouse::query()->get()->keyBy(fn (Warehouse $warehouse): string => strtolower($warehouse->code));
        $locations = Location::query()->get()->keyBy(fn (Location $location): string => strtolower($location->code));
        $existingSkus = Product::withTrashed()->pluck('sku')->keyBy(fn (string $sku): string => strtolower($sku));

        $errors = [];
        $productsToCreate = [];
        $openingStock = [];
        $seenSkus = [];

        foreach (array_values($rows) as $index => $row) {
            $rowNumber = $index + self::HEADER_ROW + 1;
            $data = $this->mapRow($header, $row);

            $sku = trim((string) ($data['sku'] ?? ''));
            $name = trim((string) ($data['name'] ?? ''));
            $categoryName = strtolower(trim((string) ($data['category'] ?? '')));
            $unitName = strtolower(trim((string) ($data['unit'] ?? '')));

            if ($sku === '' && $name === '' && $categoryName === '' && $unitName === '') {
                continue;
            }

            $rowErrors = [];

            if ($sku === '') {
                $rowErrors[] = 'SKU is required.';
            } elseif (isset($seenSkus[strtolower($sku)])) {
                $rowErrors[] = "Duplicate SKU \"{$sku}\" inside the uploaded file.";
            } elseif (isset($existingSkus[strtolower($sku)])) {
                $rowErrors[] = "SKU \"{$sku}\" already exists.";
            }

            if ($name === '') {
                $rowErrors[] = 'Name is required.';
            }

            $category = $categories[$categoryName] ?? null;
            if ($categoryName === '') {
                $rowErrors[] = 'Category is required.';
            } elseif ($category === null) {
                $rowErrors[] = "Category \"{$data['category']}\" not found.";
            }

            $unit = $units[$unitName] ?? null;
            if ($unitName === '') {
                $rowErrors[] = 'Unit is required.';
            } elseif ($unit === null) {
                $rowErrors[] = "Unit \"{$data['unit']}\" not found.";
            }

            $location = null;
            $locationCode = strtolower(trim((string) ($data['location_code'] ?? '')));
            if ($locationCode !== '') {
                $location = $locations[$locationCode] ?? null;
                if ($location === null) {
                    $rowErrors[] = "Location \"{$data['location_code']}\" not found.";
                }
            }

            $openingQuantity = 0.0;
            $openingRaw = trim((string) ($data['opening_stock'] ?? ''));
            if ($openingRaw !== '') {
                if (! is_numeric($openingRaw) || (float) $openingRaw < 0) {
                    $rowErrors[] = "Opening stock \"{$openingRaw}\" is not a valid non-negative number.";
                } else {
                    $openingQuantity = round((float) $openingRaw, 4);
                }

                $warehouseCode = strtolower(trim((string) ($data['warehouse_code'] ?? '')));
                if ($warehouseCode === '') {
                    if ($openingQuantity > 0) {
                        $rowErrors[] = 'Warehouse code is required when opening stock is provided.';
                    }
                } elseif (! isset($warehouses[$warehouseCode])) {
                    $rowErrors[] = "Warehouse \"{$data['warehouse_code']}\" not found.";
                }
            }

            if ($rowErrors !== []) {
                foreach ($rowErrors as $rowError) {
                    $errors[] = "Row {$rowNumber}: {$rowError}";
                }

                continue;
            }

            $seenSkus[strtolower($sku)] = true;

            $productsToCreate[] = [
                'category_id' => $category?->getKey(),
                'unit_id' => $unit?->getKey(),
                'location_id' => $location?->getKey(),
                'name' => $name,
                'sku' => $sku,
                'barcode' => trim((string) ($data['barcode'] ?? '')) ?: null,
                'purchase_price' => is_numeric($data['purchase_price'] ?? null) ? (float) $data['purchase_price'] : 0,
                'selling_price' => is_numeric($data['selling_price'] ?? null) ? (float) $data['selling_price'] : 0,
                'reorder_level' => is_numeric($data['reorder_level'] ?? null) ? (float) $data['reorder_level'] : 0,
                'is_active' => true,
            ];

            if ($openingQuantity > 0) {
                $openingStock[$warehouses[strtolower(trim((string) ($data['warehouse_code'] ?? '')))]->getKey()][] = [
                    'product_id' => $sku,
                    'quantity' => $openingQuantity,
                    'remarks' => 'Opening balance from import',
                ];
            }
        }

        if ($productsToCreate === []) {
            return [
                'imported' => 0,
                'stock_documents' => 0,
                'errors' => $errors !== [] ? $errors : ['No valid rows found to import.'],
                'skipped' => count($errors),
            ];
        }

        $stockDocuments = 0;

        DB::transaction(function () use ($productsToCreate, &$openingStock, &$stockDocuments, $user): void {
            $skuToId = [];

            foreach ($productsToCreate as $productData) {
                $product = $this->productService->create($productData);
                $skuToId[$product->sku] = $product->getKey();
            }

            foreach ($openingStock as $warehouseId => $items) {
                $items = array_map(function (array $item) use ($skuToId): array {
                    return [
                        'product_id' => $skuToId[$item['product_id']],
                        'quantity' => $item['quantity'],
                        'remarks' => $item['remarks'],
                    ];
                }, $items);

                $this->stockInService->create([
                    'warehouse_id' => $warehouseId,
                    'stock_date' => now()->toDateString(),
                    'remarks' => 'Opening stock created by bulk import',
                    'items' => $items,
                ], $user);

                $stockDocuments++;
            }
        });

        return [
            'imported' => count($productsToCreate),
            'stock_documents' => $stockDocuments,
            'errors' => $errors,
            'skipped' => count($errors),
        ];
    }


    /**
     * @param  list<string>  $header
     * @param  list<mixed>  $row
     * @return array<string, mixed>
     */
    private function mapRow(array $header, array $row): array
    {
        $data = [];

        foreach ($header as $index => $key) {
            $data[$key] = $row[$index] ?? null;
        }

        return $data;
    }
}
