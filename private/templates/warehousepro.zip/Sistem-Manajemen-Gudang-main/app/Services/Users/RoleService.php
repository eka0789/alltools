<?php

declare(strict_types=1);

namespace App\Services\Users;

use App\Models\Permission;
use App\Models\Role;
use App\Services\Audit\AuditLogService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class RoleService
{
    public function __construct(
        private readonly AuditLogService $auditLogService,
    ) {
    }

    public function paginate(int $perPage = 15): LengthAwarePaginator
    {
        return Role::query()
            ->withCount(['users', 'permissions'])
            ->orderBy('name')
            ->paginate($perPage);
    }

    /**
     * @return array<string, Collection<int, Permission>>
     */
    public function permissionsByModule(): array
    {
        $permissions = Permission::query()
            ->where('is_active', true)
            ->orderBy('module')
            ->orderBy('name')
            ->get()
            ->groupBy('module');

        $grouped = [];

        foreach ($permissions as $module => $modulePermissions) {
            $grouped[(string) Str::of($module)->replace('_', ' ')->title()] = $modulePermissions;
        }

        ksort($grouped);

        return $grouped;
    }

    public function create(array $data): Role
    {
        $role = DB::transaction(function () use ($data): Role {
            $role = Role::query()->create([
                'name' => $data['name'],
                'slug' => Str::slug($data['slug'] ?? $data['name']),
                'description' => $data['description'] ?? null,
                'is_active' => (bool) ($data['is_active'] ?? true),
            ]);

            $role->permissions()->sync($this->permissionIds($data));

            return $role;
        });

        $this->auditLogService->record(
            event: 'created',
            module: 'roles',
            auditable: $role,
            description: sprintf('Role "%s" was created.', $role->name),
            newValues: $this->auditValues($role),
            metadata: [
                'model' => 'role',
            ],
        );

        return $role;
    }

    public function update(Role $role, array $data): Role
    {
        if ($role->slug === 'super-admin' && isset($data['is_active']) && ! $data['is_active']) {
            throw ValidationException::withMessages([
                'is_active' => 'The Super Admin role cannot be deactivated.',
            ]);
        }

        $oldValues = $this->auditValues($role);

        DB::transaction(function () use ($role, $data): void {
            $role->update([
                'name' => $data['name'],
                'description' => $data['description'] ?? null,
                'is_active' => (bool) ($data['is_active'] ?? true),
            ]);

            $role->permissions()->sync($this->permissionIds($data));
        });

        $role = $role->refresh();
        $role->load('permissions');

        $this->auditLogService->record(
            event: 'updated',
            module: 'roles',
            auditable: $role,
            description: sprintf('Role "%s" was updated.', $role->name),
            oldValues: $oldValues,
            newValues: $this->auditValues($role),
            metadata: [
                'model' => 'role',
            ],
        );

        return $role;
    }

    public function delete(Role $role): bool|null
    {
        if ($role->slug === 'super-admin') {
            throw ValidationException::withMessages([
                'role' => 'The Super Admin role cannot be deleted.',
            ]);
        }

        $oldValues = $this->auditValues($role);
        $name = $role->name;
        $deleted = $role->delete();

        if ($deleted) {
            $this->auditLogService->record(
                event: 'deleted',
                module: 'roles',
                auditable: $role,
                description: sprintf('Role "%s" was deleted.', $name),
                oldValues: $oldValues,
                metadata: [
                    'model' => 'role',
                ],
            );
        }

        return $deleted;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    private function permissionIds(array $data): array
    {
        return Permission::query()
            ->whereIn('id', array_map(intval(...), $data['permissions'] ?? []))
            ->pluck('id')
            ->all();
    }

    /**
     * @return array<string, mixed>
     */
    private function auditValues(Role $role): array
    {
        return [
            'name' => $role->name,
            'slug' => $role->slug,
            'description' => $role->description,
            'is_active' => $role->is_active,
            'permissions' => $role->permissions->pluck('slug')->values()->all(),
        ];
    }

    /**
     * @param  array{search?: string|null}  $filters
     */
    public function filterQuery(array $filters): Builder
    {
        return Role::query()
            ->when($filters['search'] ?? null, function (Builder $query, string $search): Builder {
                return $query->where(function (Builder $query) use ($search): Builder {
                    return $query
                        ->where('name', 'like', '%'.$search.'%')
                        ->orWhere('slug', 'like', '%'.$search.'%');
                });
            });
    }
}
