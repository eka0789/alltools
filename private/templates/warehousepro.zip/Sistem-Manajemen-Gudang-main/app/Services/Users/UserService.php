<?php

declare(strict_types=1);

namespace App\Services\Users;

use App\Models\Role;
use App\Models\User;
use App\Services\Audit\AuditLogService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class UserService
{
    public function __construct(
        private readonly AuditLogService $auditLogService,
    ) {
    }

    /**
     * @param  array{search?: string|null, role_id?: int|string|null}  $filters
     */
    public function paginate(array $filters, int $perPage = 15): LengthAwarePaginator
    {
        $query = User::query()
            ->with('roles')
            ->withCount('roles')
            ->when($filters['search'] ?? null, function (Builder $query, string $search): Builder {
                return $query->where(function (Builder $query) use ($search): Builder {
                    return $query
                        ->where('name', 'like', '%'.$search.'%')
                        ->orWhere('email', 'like', '%'.$search.'%');
                });
            })
            ->when($filters['role_id'] ?? null, function (Builder $query, int|string $roleId): Builder {
                return $query->whereHas('roles', function (Builder $query) use ($roleId): Builder {
                    return $query->where('roles.id', $roleId);
                });
            });

        \App\Support\Sortable::apply($query, [
            'created_at' => 'users.created_at',
            'name' => 'users.name',
            'email' => 'users.email',
        ], $filters['sort'] ?? null, $filters['direction'] ?? null, 'name');

        return $query->paginate($perPage)->appends($this->filledFilters($filters));
    }

    public function activeRoles(): Collection
    {
        return Role::query()
            ->where('is_active', true)
            ->orderBy('name')
            ->get();
    }

    /**
     * @param  array{name: string, email: string, password?: string|null, is_active?: bool, roles?: list<int|string>}  $data
     */
    public function create(array $data): User
    {
        $user = DB::transaction(function () use ($data): User {
            $user = User::query()->create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => Hash::make((string) $data['password']),
                'is_active' => (bool) ($data['is_active'] ?? true),
            ]);

            $user->roles()->sync(array_map(intval(...), $data['roles'] ?? []));

            return $user;
        });

        $this->auditLogService->record(
            event: 'created',
            module: 'users',
            auditable: $user,
            description: sprintf('User "%s" was created.', $user->name),
            newValues: $this->auditValues($user),
            metadata: [
                'model' => 'user',
            ],
        );

        return $user;
    }

    /**
     * @param  array{name?: string, email?: string, password?: string|null, is_active?: bool, roles?: list<int|string>}  $data
     */
    public function update(User $user, array $data): User
    {
        $oldValues = $this->auditValues($user);

        DB::transaction(function () use ($user, $data): void {
            $attributes = [
                'name' => $data['name'],
                'email' => $data['email'],
                'is_active' => (bool) ($data['is_active'] ?? true),
            ];

            if (isset($data['password']) && (string) $data['password'] !== '') {
                $attributes['password'] = Hash::make((string) $data['password']);
            }

            $user->update($attributes);

            $user->roles()->sync(array_map(intval(...), $data['roles'] ?? []));
        });

        $user = $user->refresh();
        $user->load('roles');

        $this->auditLogService->record(
            event: 'updated',
            module: 'users',
            auditable: $user,
            description: sprintf('User "%s" was updated.', $user->name),
            oldValues: $oldValues,
            newValues: $this->auditValues($user),
            metadata: [
                'model' => 'user',
            ],
        );

        return $user;
    }

    public function delete(User $user): bool|null
    {
        $authenticatedUser = auth()->user();

        if ($authenticatedUser instanceof User && $authenticatedUser->getKey() === $user->getKey()) {
            throw ValidationException::withMessages([
                'user' => 'You cannot delete your own account.',
            ]);
        }

        $oldValues = $this->auditValues($user);
        $name = $user->name;
        $deleted = $user->delete();

        if ($deleted) {
            $this->auditLogService->record(
                event: 'deleted',
                module: 'users',
                auditable: $user,
                description: sprintf('User "%s" was deleted.', $name),
                oldValues: $oldValues,
                metadata: [
                    'model' => 'user',
                ],
            );
        }

        return $deleted;
    }

    /**
     * @return array<string, mixed>
     */
    private function auditValues(User $user): array
    {
        return [
            'name' => $user->name,
            'email' => $user->email,
            'is_active' => $user->is_active,
            'roles' => $user->roles->pluck('name')->values()->all(),
        ];
    }

    /**
     * @param  array<string, mixed>  $filters
     * @return array<string, mixed>
     */
    private function filledFilters(array $filters): array
    {
        return array_filter($filters, fn ($value): bool => $value !== null && $value !== '');
    }
}
