<?php

declare(strict_types=1);

namespace App\Services\Settings;

use App\Models\Setting;
use Illuminate\Support\Facades\Cache;

class SettingsService
{
    public const COMPANY_NAME = 'company.name';

    public const COMPANY_ADDRESS = 'company.address';

    public const COMPANY_PHONE = 'company.phone';

    public const COMPANY_EMAIL = 'company.email';

    public const LOW_STOCK_EMAIL_ENABLED = 'notifications.low_stock_email';

    private const CACHE_KEY = 'app-settings';

    /**
     * @return array<string, string|null>
     */
    public function all(): array
    {
        $stored = Cache::rememberForever(self::CACHE_KEY, fn (): array => Setting::query()
            ->pluck('value', 'key')
            ->all());

        return collect($this->defaults())
            ->map(fn ($default, $key): ?string => $stored[$key] ?? $default)
            ->all();
    }

    public function get(string $key): ?string
    {
        return $this->all()[$key] ?? null;
    }

    /**
     * @param  array<string, string|null>  $values
     */
    public function setMany(array $values): void
    {
        foreach ($values as $key => $value) {
            Setting::query()->updateOrCreate(['key' => $key], ['value' => $value]);
        }

        Cache::forget(self::CACHE_KEY);
    }

    /**
     * @return array<string, string|null>
     */
    private function defaults(): array
    {
        return [
            self::COMPANY_NAME => config('app.name'),
            self::COMPANY_ADDRESS => null,
            self::COMPANY_PHONE => null,
            self::COMPANY_EMAIL => null,
            self::LOW_STOCK_EMAIL_ENABLED => '1',
        ];
    }
}
