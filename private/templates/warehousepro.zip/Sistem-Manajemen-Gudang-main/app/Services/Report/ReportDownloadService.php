<?php

declare(strict_types=1);

namespace App\Services\Report;

use Barryvdh\DomPDF\Facade\Pdf as PdfFacade;
use Illuminate\Http\Response;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportDownloadService
{
    private const FORMATS = ['csv', 'xlsx', 'pdf'];

    public function __construct(
        private readonly ReportCsvExportService $csvExportService,
    ) {
    }

    /**
     * Download a report in the requested format (csv, xlsx, or pdf).
     *
     * @param  list<string>  $headers
     * @param  iterable<int, list<mixed>>  $rows
     */
    public function download(string $filenamePrefix, array $headers, iterable $rows, ?string $format = null): StreamedResponse|BinaryFileResponse|Response
    {
        $format = strtolower((string) ($format ?? 'csv'));

        if (! in_array($format, self::FORMATS, true)) {
            $format = 'csv';
        }

        $filename = sprintf('%s-%s', $filenamePrefix, now()->format('Y-m-d-H-i-s'));

        if ($format === 'xlsx') {
            return Excel::download(
                new ReportArrayExport(
                    headers: $headers,
                    rows: $this->materialize($rows),
                    title: $this->title($filenamePrefix),
                ),
                $filename.'.xlsx',
            );
        }

        if ($format === 'pdf') {
            $pdf = PdfFacade::loadView('reports._pdf_table', [
                'title' => $this->title($filenamePrefix),
                'generatedAt' => now()->format('d M Y H:i'),
                'headers' => $headers,
                'rows' => $this->materialize($rows),
            ]);

            return $pdf->download($filename.'.pdf');
        }

        return $this->csvExportService->download($filenamePrefix, $headers, $rows);
    }

    /**
     * @param  iterable<int, list<mixed>>  $rows
     * @return list<list<mixed>>
     */
    private function materialize(iterable $rows): array
    {
        if (is_array($rows)) {
            return $rows;
        }

        return iterator_to_array($rows, false);
    }

    private function title(string $filenamePrefix): string
    {
        return (string) str($filenamePrefix)
            ->replace(['-', '_'], ' ')
            ->title();
    }
}
