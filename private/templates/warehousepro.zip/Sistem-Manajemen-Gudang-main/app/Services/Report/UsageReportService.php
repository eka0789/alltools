<?php

declare(strict_types=1);

namespace App\Services\Report;

use App\Models\Category;
use App\Models\Product;
use App\Models\Warehouse;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Query\Builder as QueryBuilder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\LazyCollection;

class UsageReportService
{
    /**
     * @param  array{warehouse_id?: int|string|null, category_id?: int|string|null, date_from?: string|null, date_to?: string|null}  $filters
     * @return array{
     *     usageRows: LengthAwarePaginator,
     *     totals: array<string, float>,
     *     warehouses: Collection<int, Warehouse>,
     *     categories: Collection<int, Category>,
     *     filters: array<string, mixed>
     * }
     */
    public function generate(array $filters): array
    {
        $normalizedFilters = $this->normalizeFilters($filters);

        return [
            'usageRows' => $this->usageRows($normalizedFilters),
            'totals' => $this->totals($normalizedFilters),
            'warehouses' => $this->activeWarehouses(),
            'categories' => $this->activeCategories(),
            'filters' => $normalizedFilters,
        ];
    }

    /**
     * @param  array<string, mixed>  $filters
     * @return LazyCollection<int, list<string>>
     */
    public function exportRows(array $filters): LazyCollection
    {
        return $this->baseUsageQuery($this->normalizeFilters($filters))
            ->lazy()
            ->map(function (Product $product): array {
                $unit = $product->unit;

                return [
                    $product->sku,
                    $product->name,
                    $product->category?->name ?? '',
                    $unit?->short_name ?? $unit?->name ?? '',
                    $this->formatDecimal($product->inbound_quantity),
                    $this->formatDecimal($product->outbound_quantity),
                    $this->formatDecimal($product->net_quantity),
                    (string) (int) $product->transactions_count,
                ];
            });
    }

    /**
     * @return list<string>
     */
    public function exportHeaders(): array
    {
        return [
            'Product SKU',
            'Product Name',
            'Category',
            'Unit',
            'Total In (Qty)',
            'Total Out (Qty)',
            'Net Movement (Qty)',
            'Outbound Transactions',
        ];
    }

    /**
     * @param  array<string, mixed>  $filters
     * @return array<string, float>
     */
    private function totals(array $filters): array
    {
        $inboundQuery = DB::table('stock_in_items')
            ->join('stock_ins', 'stock_ins.id', '=', 'stock_in_items.stock_in_id')
            ->when($filters['warehouse_id'] ?? null, function (QueryBuilder $query, int|string $warehouseId): QueryBuilder {
                return $query->where('stock_ins.warehouse_id', $warehouseId);
            });

        $outboundQuery = DB::table('stock_out_items')
            ->join('stock_outs', 'stock_outs.id', '=', 'stock_out_items.stock_out_id')
            ->when($filters['warehouse_id'] ?? null, function (QueryBuilder $query, int|string $warehouseId): QueryBuilder {
                return $query->where('stock_outs.warehouse_id', $warehouseId);
            });

        $this->applyPeriod($inboundQuery, $filters, 'stock_ins.stock_date');
        $this->applyPeriod($outboundQuery, $filters, 'stock_outs.stock_date');

        $inbound = (float) $inboundQuery->sum('stock_in_items.quantity');
        $outbound = (float) $outboundQuery->sum('stock_out_items.quantity');

        return [
            'inbound' => round($inbound, 4),
            'outbound' => round($outbound, 4),
            'net' => round($inbound - $outbound, 4),
        ];
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    private function usageRows(array $filters): LengthAwarePaginator
    {
        return $this->baseUsageQuery($filters)
            ->paginate(15)
            ->appends($this->filledFilters($filters));
    }

    /**
     * Aggregate stock in vs out per product for the selected period,
     * using document stock dates. Aggregations are computed in subqueries
     * to avoid row multiplication when both joins land on the same product.
     */
    private function baseUsageQuery(array $filters): Builder
    {
        $inboundSub = DB::table('stock_in_items')
            ->join('stock_ins', 'stock_ins.id', '=', 'stock_in_items.stock_in_id')
            ->when($filters['warehouse_id'] ?? null, function (QueryBuilder $query, int|string $warehouseId): QueryBuilder {
                return $query->where('stock_ins.warehouse_id', $warehouseId);
            })
            ->selectRaw('stock_in_items.product_id as product_id, SUM(stock_in_items.quantity) as qty, COUNT(*) as transactions_count')
            ->groupBy('stock_in_items.product_id');

        $this->applyPeriod($inboundSub, $filters, 'stock_ins.stock_date');

        $outboundSub = DB::table('stock_out_items')
            ->join('stock_outs', 'stock_outs.id', '=', 'stock_out_items.stock_out_id')
            ->when($filters['warehouse_id'] ?? null, function (QueryBuilder $query, int|string $warehouseId): QueryBuilder {
                return $query->where('stock_outs.warehouse_id', $warehouseId);
            })
            ->selectRaw('stock_out_items.product_id as product_id, SUM(stock_out_items.quantity) as qty, COUNT(*) as transactions_count')
            ->groupBy('stock_out_items.product_id');

        $this->applyPeriod($outboundSub, $filters, 'stock_outs.stock_date');

        return Product::query()
            ->from('products')
            ->when($filters['category_id'] ?? null, function (Builder $query, int|string $categoryId): Builder {
                return $query->where('products.category_id', $categoryId);
            })
            ->leftJoinSub($inboundSub, 'ins', 'ins.product_id', '=', 'products.id')
            ->leftJoinSub($outboundSub, 'outs', 'outs.product_id', '=', 'products.id')
            ->select('products.*')
            ->selectRaw('COALESCE(ins.qty, 0) as inbound_quantity')
            ->selectRaw('COALESCE(outs.qty, 0) as outbound_quantity')
            ->selectRaw('COALESCE(ins.qty, 0) - COALESCE(outs.qty, 0) as net_quantity')
            ->selectRaw('COALESCE(outs.transactions_count, 0) as transactions_count')
            ->orderByDesc('outbound_quantity')
            ->orderBy('products.name');
    }

    /**
     * @param  QueryBuilder  $query
     * @param  array<string, mixed>  $filters
     */
    private function applyPeriod(QueryBuilder $query, array $filters, string $dateColumn): void
    {
        if (isset($filters['date_from']) && $filters['date_from'] !== null && $filters['date_from'] !== '') {
            $query->whereDate($dateColumn, '>=', $filters['date_from']);
        }

        if (isset($filters['date_to']) && $filters['date_to'] !== null && $filters['date_to'] !== '') {
            $query->whereDate($dateColumn, '<=', $filters['date_to']);
        }
    }

    private function activeWarehouses(): Collection
    {
        return Warehouse::active()->orderBy('name')->orderBy('code')->get();
    }

    private function activeCategories(): Collection
    {
        return Category::active()->orderBy('name')->get();
    }

    /**
     * @param  array<string, mixed>  $filters
     * @return array<string, mixed>
     */
    private function normalizeFilters(array $filters): array
    {
        return [
            'warehouse_id' => $filters['warehouse_id'] ?? null,
            'category_id' => $filters['category_id'] ?? null,
            'date_from' => $filters['date_from'] ?? null,
            'date_to' => $filters['date_to'] ?? null,
        ];
    }

    private function formatDecimal(mixed $value, int $decimals = 4): string
    {
        return number_format((float) $value, $decimals, '.', '');
    }

    /**
     * @param  array<string, mixed>  $filters
     * @return array<string, mixed>
     */
    private function filledFilters(array $filters): array
    {
        return array_filter($filters, fn ($value): bool => $value !== null && $value !== '');
    }
}
