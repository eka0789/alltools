<?php

declare(strict_types=1);

namespace App\Services\Warehouse;

use App\Models\Location;
use App\Services\Audit\AuditLogService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;

class LocationService
{
    private const AUDIT_FIELDS = [
        'warehouse_id',
        'code',
        'name',
        'description',
        'is_active',
    ];

    public function __construct(
        private readonly AuditLogService $auditLogService,
    ) {
    }

    /**
     * @param  array{warehouse_id?: int|string|null, search?: string|null}  $filters
     */
    public function paginate(array $filters, int $perPage = 15): LengthAwarePaginator
    {
        $query = Location::query()
            ->with('warehouse')
            ->withCount('products')
            ->when($filters['warehouse_id'] ?? null, function (Builder $query, int|string $warehouseId): Builder {
                return $query->where('warehouse_id', $warehouseId);
            })
            ->when($filters['search'] ?? null, function (Builder $query, string $search): Builder {
                return $query->where(function (Builder $query) use ($search): Builder {
                    return $query
                        ->where('code', 'like', '%'.$search.'%')
                        ->orWhere('name', 'like', '%'.$search.'%');
                });
            });

        \App\Support\Sortable::apply($query, [
            'code' => 'locations.code',
            'name' => 'locations.name',
            'created_at' => 'locations.created_at',
        ], $filters['sort'] ?? null, $filters['direction'] ?? null, 'code');

        return $query->paginate($perPage)->appends($this->filledFilters($filters));
    }

    public function activeLocations(): Collection
    {
        return Location::active()
            ->with('warehouse')
            ->orderBy('code')
            ->get();
    }

    public function create(array $data): Location
    {
        $location = Location::query()->create($data)->refresh();

        $this->auditLogService->record(
            event: 'created',
            module: 'locations',
            auditable: $location,
            description: sprintf('Location "%s" was created.', $location->code),
            newValues: $this->auditValues($location),
            metadata: [
                'model' => 'location',
            ],
        );

        return $location;
    }

    public function update(Location $location, array $data): Location
    {
        $oldValues = $this->auditValues($location);

        $location->update($data);
        $location = $location->refresh();

        $changedOldValues = [];
        $changedNewValues = [];

        foreach (self::AUDIT_FIELDS as $field) {
            $oldValue = $oldValues[$field];
            $newValue = $location->getAttribute($field);

            if ($oldValue === $newValue) {
                continue;
            }

            $changedOldValues[$field] = $oldValue;
            $changedNewValues[$field] = $newValue;
        }

        if ($changedNewValues !== []) {
            $this->auditLogService->record(
                event: 'updated',
                module: 'locations',
                auditable: $location,
                description: sprintf('Location "%s" was updated.', $location->code),
                oldValues: $changedOldValues,
                newValues: $changedNewValues,
                metadata: [
                    'model' => 'location',
                ],
            );
        }

        return $location;
    }

    public function delete(Location $location): bool|null
    {
        $oldValues = $this->auditValues($location);
        $code = $location->code;
        $deleted = $location->delete();

        if ($deleted) {
            $this->auditLogService->record(
                event: 'deleted',
                module: 'locations',
                auditable: $location,
                description: sprintf('Location "%s" was deleted.', $code),
                oldValues: $oldValues,
                metadata: [
                    'model' => 'location',
                ],
            );
        }

        return $deleted;
    }

    /**
     * @return array<string, mixed>
     */
    private function auditValues(Location $location): array
    {
        $values = [];

        foreach (self::AUDIT_FIELDS as $field) {
            $values[$field] = $location->getAttribute($field);
        }

        return $values;
    }

    /**
     * @param  array<string, mixed>  $filters
     * @return array<string, mixed>
     */
    private function filledFilters(array $filters): array
    {
        return array_filter($filters, fn ($value): bool => $value !== null && $value !== '');
    }
}
