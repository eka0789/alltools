<?php

namespace App\Notifications;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class LowStockAlert extends Notification implements ShouldQueue
{
    use Queueable;

    /**
     * @param  list<array<string, mixed>>  $lowStockItems
     */
    public function __construct(
        private readonly array $lowStockItems,
        private readonly bool $emailEnabled = true,
    ) {
    }

    /**
     * @return list<string>
     */
    public function via(object $notifiable): array
    {
        return $this->emailEnabled ? ['mail', 'database'] : ['database'];
    }

    public function toMail(User $notifiable): MailMessage
    {
        $count = count($this->lowStockItems);

        $mail = (new MailMessage)
            ->subject(sprintf('[%s] Low Stock Alert — %d item(s) at or below reorder level', config('app.name'), $count))
            ->greeting('Hello '.$notifiable->name.',')
            ->line(sprintf('%d item(s) are at or below their reorder level. Please review and restock.', $count));

        foreach (array_slice($this->lowStockItems, 0, 20) as $item) {
            $mail->line(sprintf(
                '• %s (%s) — available %s %s, reorder level %s',
                $item['name'],
                $item['sku'],
                $item['available_quantity'],
                $item['unit'] ?? '',
                $item['reorder_level'],
            ));
        }

        if ($count > 20) {
            $mail->line(sprintf('… and %d more item(s).', $count - 20));
        }

        return $mail
            ->action('Open Low Stock Report', route('reports.low-stock'))
            ->line('This is an automated daily low stock notification.');
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            'low_stock_count' => count($this->lowStockItems),
        ];
    }
}
