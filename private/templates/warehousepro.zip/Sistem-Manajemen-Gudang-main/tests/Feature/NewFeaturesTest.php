<?php

namespace Tests\Feature\System;

use App\Models\Location;
use App\Models\Permission;
use App\Models\Product;
use App\Models\Role;
use App\Models\User;
use App\Models\Warehouse;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class NewFeaturesTest extends TestCase
{
    use RefreshDatabase;

    protected function makeProduct(array $overrides = []): Product
    {
        $category = \App\Models\Category::query()->create([
            'name' => 'Test Cat '.uniqid(),
            'slug' => 'test-cat-'.uniqid(),
            'is_active' => true,
        ]);

        return Product::query()->create(array_merge([
            'category_id' => $category->id,
            'unit_id' => \App\Models\Unit::query()->first()?->id ?? \App\Models\Unit::query()->create(["name" => "Pieces", "short_name" => "pcs", "is_active" => true])->id,
            'name' => 'Test Product '.uniqid(),
            'slug' => 'test-product-'.uniqid(),
            'sku' => 'TST-'.strtoupper(substr(uniqid(), -6)),
            'is_active' => true,
        ], $overrides));
    }

    protected function seedRbac(): void
    {
        $this->seed([
            \Database\Seeders\RoleSeeder::class,
            \Database\Seeders\PermissionSeeder::class,
            \Database\Seeders\RolePermissionSeeder::class,
            \Database\Seeders\UnitSeeder::class,
        ]);
    }

    protected function userWithPermissions(array $slugs): User
    {
        $this->seedRbac();

        $user = User::factory()->create();
        $role = Role::query()->create(['name' => 'Test Role '.uniqid(), 'slug' => 'test-'.uniqid(), 'is_active' => true]);
        $role->permissions()->sync(Permission::query()->whereIn('slug', $slugs)->pluck('id'));
        $user->roles()->sync([$role->id]);

        return $user;
    }

    public function test_locations_crud_page_loads_and_stores(): void
    {
        $user = $this->userWithPermissions(['locations.view', 'locations.create']);

        Warehouse::query()->create(['code' => 'WH-T', 'name' => 'Test Warehouse', 'is_active' => true]);

        $this->actingAs($user)->get(route('locations.index'))->assertOk();

        $response = $this->actingAs($user)->post(route('locations.store'), [
            'code' => 'A',
            'name' => 'Rack A',
            'is_active' => '1',
        ]);

        $response->assertRedirect(route('locations.index'));
        $this->assertDatabaseHas('locations', ['code' => 'A', 'name' => 'Rack A']);
    }

    public function test_search_endpoint_returns_matching_products(): void
    {
        $user = $this->userWithPermissions(['products.view']);

        $this->makeProduct(['name' => 'Stapler Heavy', 'slug' => 'stapler-heavy', 'sku' => 'STP-1', 'barcode' => '8991001']);

        $response = $this->actingAs($user)->getJson(route('search.products', ['q' => 'stapler']));

        $response->assertOk()->assertJsonCount(1, 'results');
        $this->assertEquals('STP-1', $response->json('results.0.sku'));
    }

    public function test_adjustment_history_page_and_reverse(): void
    {
        $user = $this->userWithPermissions(['stock-adjustments.view', 'stock-adjustments.create']);

        $warehouse = Warehouse::query()->create(['code' => 'WH-R', 'name' => 'Rev WH', 'is_active' => true]);
        $product = $this->makeProduct(['name' => 'Rev Product', 'sku' => 'REV-1']);

        $this->actingAs($user)
            ->post(route('stock-adjustments.store'), [
                'warehouse_id' => $warehouse->id,
                'product_id' => $product->id,
                'movement_type' => 'adjustment_in',
                'quantity' => 10,
                'remarks' => 'found extra',
            ])
            ->assertRedirect(route('stock-adjustments.index'));

        $movement = \App\Models\StockMovement::query()->where('movement_type', 'adjustment_in')->first();
        $this->assertNotNull($movement);

        $this->get(route('stock-adjustments.index'))->assertOk()->assertSee('Adjustment In');

        $this->actingAs($user)
            ->post(route('stock-adjustments.reverse', $movement))
            ->assertRedirect(route('stock-adjustments.index'));

        $this->assertDatabaseHas('stock_movements', ['movement_type' => 'adjustment_out', 'quantity' => 10]);
        $this->assertEquals(0, (float) \App\Models\WarehouseStock::query()->where('product_id', $product->id)->value('quantity'));
    }

    public function test_trash_lists_and_restores_soft_deleted_products(): void
    {
        $user = $this->userWithPermissions(['products.view', 'products.delete']);

        $product = $this->makeProduct(['name' => 'Trashed Product', 'sku' => 'TRASH-1']);
        $product->delete();

        $this->actingAs($user)->get(route('trash.index', ['type' => 'products']))
            ->assertOk()
            ->assertSee('Trashed Product');

        $this->post(route('trash.restore', ['products', $product->id]))
            ->assertRedirect();

        $this->assertNull($product->fresh()->deleted_at);
    }

    public function test_profile_update_changes_name_and_password(): void
    {
        $user = $this->userWithPermissions([]);

        $this->actingAs($user)
            ->from(route('profile.edit'))
            ->put(route('profile.update'), [
                'name' => 'Renamed Admin',
                'email' => $user->email,
                'current_password' => 'password',
                'password' => 'newpassword123',
                'password_confirmation' => 'newpassword123',
            ])
            ->assertRedirect(route('profile.edit'));

        $this->assertTrue(\Illuminate\Support\Facades\Hash::check('newpassword123', $user->fresh()->password));
    }

    public function test_profile_update_rejects_wrong_current_password(): void
    {
        $user = $this->userWithPermissions([]);

        $this->actingAs($user)
            ->from(route('profile.edit'))
            ->put(route('profile.update'), [
                'name' => $user->name,
                'email' => $user->email,
                'current_password' => 'wrong-password',
                'password' => 'newpassword123',
                'password_confirmation' => 'newpassword123',
            ])
            ->assertSessionHasErrors('current_password');
    }

    public function test_settings_page_saves_company_details(): void
    {
        $user = $this->userWithPermissions(['settings.manage']);

        $this->actingAs($user)->get(route('settings.edit'))->assertOk();

        $this->actingAs($user)->put(route('settings.update'), [
            'company_name' => 'PT Gudang Jaya',
            'company_phone' => '021-555',
            'low_stock_email_enabled' => '1',
        ])->assertRedirect(route('settings.edit'));

        $service = app(\App\Services\Settings\SettingsService::class);
        $this->assertSame('PT Gudang Jaya', $service->get(\App\Services\Settings\SettingsService::COMPANY_NAME));
    }

    public function test_usage_report_page_renders(): void
    {
        $user = $this->userWithPermissions(['reports.usage.view']);

        $this->actingAs($user)->get(route('reports.usage'))->assertOk();
    }

    public function test_slip_pdf_streams_for_stock_in(): void
    {
        $user = $this->userWithPermissions(['stock-in.view']);

        $warehouse = Warehouse::query()->create(['code' => 'WH-S', 'name' => 'Slip WH', 'is_active' => true]);
        $product = $this->makeProduct(['name' => 'Slip Product', 'sku' => 'SLIP-1']);

        app(\App\Services\Stock\StockInService::class)->create([
            'warehouse_id' => $warehouse->id,
            'stock_date' => now()->toDateString(),
            'items' => [['product_id' => $product->id, 'quantity' => 5]],
        ], $user);

        $stockIn = \App\Models\StockIn::query()->first();

        $response = $this->actingAs($user)->get(route('stock-ins.slip', $stockIn));

        $response->assertOk();
        $this->assertStringStartsWith('%PDF', $response->getContent());
    }

    public function test_low_stock_command_stores_database_notifications(): void
    {
        $user = $this->userWithPermissions(['reports.low-stock.view']);

        $warehouse = Warehouse::query()->create(['code' => 'WH-N', 'name' => 'Notif WH', 'is_active' => true]);
        $product = $this->makeProduct(['name' => 'Notif Product', 'sku' => 'NOTIF-1', 'reorder_level' => 5]);
        \App\Models\WarehouseStock::query()->create([
            'warehouse_id' => $warehouse->id, 'product_id' => $product->id, 'quantity' => 1,
        ]);

        $this->artisan('stock:notify-low-stock')->assertSuccessful();

        $this->assertGreaterThan(0, $user->fresh()->notifications()->count());
    }

    public function test_supplier_and_category_import_endpoints(): void
    {
        $user = $this->userWithPermissions(['suppliers.create', 'categories.create']);

        $suppliersCsv = tmpfile();
        fwrite($suppliersCsv, "name,phone,email\nPT Import Test,0812,test@import.co\n");
        fseek($suppliersCsv, 0);

        $this->actingAs($user)
            ->post(route('imports.store', 'suppliers'), [
                'file' => new \Illuminate\Http\UploadedFile(
                    stream_get_meta_data($suppliersCsv)['uri'],
                    'suppliers.csv',
                    'text/csv',
                    null,
                    true,
                ),
            ])
            ->assertRedirect(route('suppliers.index'));

        $this->assertDatabaseHas('suppliers', ['name' => 'PT Import Test']);

        $categoriesCsv = tmpfile();
        fwrite($categoriesCsv, "name,description\nImported Category,desc\n");
        fseek($categoriesCsv, 0);

        $this->actingAs($user)
            ->post(route('imports.store', 'categories'), [
                'file' => new \Illuminate\Http\UploadedFile(
                    stream_get_meta_data($categoriesCsv)['uri'],
                    'categories.csv',
                    'text/csv',
                    null,
                    true,
                ),
            ])
            ->assertRedirect(route('categories.index'));

        $this->assertDatabaseHas('categories', ['name' => 'Imported Category']);
    }

    public function test_unit_conversion_on_stock_in(): void
    {
        $user = $this->userWithPermissions(['stock-in.create']);

        $warehouse = Warehouse::query()->create(['code' => 'WH-C', 'name' => 'Conv WH', 'is_active' => true]);
        $baseUnit = \App\Models\Unit::query()->first() ?? \App\Models\Unit::query()->create(['name' => 'Pieces', 'short_name' => 'pcs', 'is_active' => true]);
        $carton = \App\Models\Unit::query()->skip(1)->first() ?? \App\Models\Unit::query()->create(['name' => 'Carton', 'short_name' => 'ctn', 'is_active' => true]);

        $product = $this->makeProduct([
            'name' => 'Conv Product', 'sku' => 'CONV-1',
            'unit_id' => $baseUnit->id, 'purchase_unit_id' => $carton->id,
            'units_per_purchase_unit' => 24,
        ]);

        app(\App\Services\Stock\StockInService::class)->create([
            'warehouse_id' => $warehouse->id,
            'stock_date' => now()->toDateString(),
            'items' => [['product_id' => $product->id, 'quantity' => 2, 'unit_id' => $carton->id]],
        ], $user);

        $this->assertEquals(48.0, (float) \App\Models\WarehouseStock::query()->where('product_id', $product->id)->value('quantity'));
    }

    public function test_sortable_product_index(): void
    {
        $user = $this->userWithPermissions(['products.view']);

        $this->actingAs($user)
            ->get(route('products.index', ['sort' => 'name', 'direction' => 'asc']))
            ->assertOk();

        $this->actingAs($user)
            ->get(route('products.index', ['sort' => 'evil-column']))
            ->assertOk();
    }
}
