# Operations Guide — WMS

Panduan operasional untuk server produksi (Windows/XAMPP atau Linux).

## 1. Scheduler (WAJIB berjalan)

Beberapa fitur bergantung pada Laravel Scheduler. Tanpa scheduler, tidak ada
notifikasi low stock harian dan **tidak ada backup otomatis**.

```bash
# Tambahkan ke cron (Linux):
* * * * * cd /path/to/wms && php artisan schedule:run >> /dev/null 2>&1

# Windows (Task Scheduler): jalankan setiap 1 menit
C:\xampp\php\php.exe C:\xampp\htdocs\WMS\artisan schedule:run
```

Job terjadwal:

| Jam | Job | Fungsi |
|---|---|---|
| 02:00 | `backup:run` | Backup database + file ke `storage/app/backups` |
| 02:30 | `backup:clean` | Bersihkan backup lebih lama dari retensi |
| 08:00 | `stock:notify-low-stock` | Notifikasi item di bawah reorder level (email opsional + in-app) |

## 2. Queue worker

Notifikasi low stock dikirim via queue (`ShouldQueue`). Jalankan worker di produksi:

```bash
php artisan queue:work --tries=1          # foreground
# atau sebagai service/supervisor, restart tiap deploy:
php artisan queue:restart
```

Tanpa worker, email/bel notifikasi tidak akan terkirim.

## 3. Backup & restore

Dikonfigurasi via `config/backup.php` (sudah di-publish). Default menyimpan ke
local disk `storage/app/backups`. Untuk simpan ke S3/dropbox, sesuaikan
`backup.destination.disks` di `config/backup.php` dan konfigurasi filesystem.

```bash
php artisan backup:run          # backup manual
php artisan backup:list         # lihat daftar backup
php artisan backup:clean        # hapus backup kadaluarsa

# Restore (mysqldump hasil backup):
# gunakan file .zip di storage/app/backups → db-dumps/*.sql
mysql -u root wms < db-dumps/<file>.sql
```

**Catatan Windows/XAMPP:** `mysqldump` harus ada di PATH (ada di
`C:\xampp\mysql\bin`). Tambahkan ke PATH sistem bila backup gagal.

## 4. Env kunci

| Key | Keterangan |
|---|---|
| `APP_NAME` | Nama aplikasi (muncul di UI) |
| `SEED_SUPER_ADMIN_EMAIL/PASSWORD` | Kredensial akun super admin awal (`php artisan db:seed`) |
| `MAIL_MAILER` | `log` saat development, `smtp` di produksi untuk email low stock |
| `QUEUE_CONNECTION` | `database` (default) — butuh queue worker berjalan |

## 5. Halaman & fitur berpermission baru

| Halaman | Permission | Role default |
|---|---|---|
| `/stock-adjustments` (riwayat) | `stock-adjustments.view` | Super Admin, Manager, Staff |
| Reverse adjustment | `stock-adjustments.create` | Super Admin, Manager, Staff |
| `/trash` | `*.delete` per modul | Super Admin, Manager |
| `/settings` | `settings.manage` | Super Admin, Manager |
| `/imports` | `products.import` / `suppliers.create` / `categories.create` | per modul |
| `/profile` | semua user yang login | — |
| Notifikasi | semua user yang login | — |

## 6. Konversi satuan (Stock In)

Produk dapat punya *purchase unit* (mis. karton) + `units_per_purchase_unit`
(24). Saat Stock In memakai purchase unit, sistem mengonversi ke satuan dasar
secara otomatis — stok selalu tersimpan dalam satuan dasar produk.
